# AOIX-1 Full Operating System — End-to-End Bible

This document is the complete, exhaustive description of what AOIX-1 is, how it works, what it uses to trade, and how every part fits together. No summary: the full system.

---

## 1. What AOIX-1 Is

- **Name:** AOIX-1 (version 1.1.0).
- **Purpose:** Options-focused trading system that scans the market, classifies regimes, scores opportunities, recommends option structures, backtests strategies, and can run an autonomous trading engine (paper or live via IBKR).
- **Stack:** Node.js, TypeScript, ESM. Server: custom (Vite + esbuild for production). API: tRPC. Data: Yahoo Finance (primary), Interactive Brokers Client Portal Gateway (when connected). Frontend: React, Vite, Radix UI.
- **Entry points:**
  - **App:** `pnpm dev` (server + client), `pnpm start` (production).
  - **Backtest:** `pnpm backtest` (full backtest script), `pnpm backtest:optimal` (grid-search optimizer).
  - **Tests:** `pnpm test`. E2E (health + full flow): `E2E_SERVER_URL=http://localhost:3000 pnpm test` (start server first).
- **Operations:** See **docs/RUNBOOK.md** for startup, health, backtest, deployment, and troubleshooting. HTTP health: `GET /api/health` returns `ok`, `readyForTrade`, `status`, `timestamp` (uses full `system.health`).

---

## 2. Data Sources

### 2.1 Yahoo Finance (primary)

- **Module:** `server/real-market-data.ts`.
- **Library:** `yahoo-finance2`.
- **Used for:** Stock quotes (price, change, volume, 52w high/low), option chain data (IV, ivRank, put/call ratio), historical chart data for backtest and trend.
- **Symbols:** `REAL_STOCK_SYMBOLS` → deduped to `UNIQUE_SYMBOLS` (180+ names: mega cap tech, indices, financials, healthcare, industrials, discretionary, etc.). Scanner iterates over `UNIQUE_SYMBOLS`.
- **Caching:** 1-minute TTL for quotes and options data to stay under rate limits.
- **Functions:** `getRealStockPrice(symbol)`, `getRealOptionsData(symbol)`, `getRealTrend(symbol, lookback)`, option expiry/chain helpers.

### 2.2 Interactive Brokers (when connected)

- **Modules:** `server/ib-market-data.ts`, `server/ib-orders.ts`, `server/ibkr.ts`, `server/tws-api-client.ts`, `server/tcp-https-proxy.ts`, `server/tunnel-proxy.ts`.
- **Usage:** When IB Client Portal Gateway is running and reachable, the scanner can use IB for live price/volume per symbol; otherwise it falls back to Yahoo. Execution (paper or live) goes through IB when configured.
- **Check:** `checkIBGatewayConnection()` in `ib-orders.ts`; if true, `getIBMarketData(symbol)` is used in `MarketScanner.analyzeStock()`.

### 2.3 VIX

- Fetched for market conditions (e.g. `getRealVIX()` or equivalent) and passed into `determineMarketConditions()` for adaptive risk (volatility regime: low / normal / high / extreme).

---

## 3. Regime Classification (11 Regimes)

- **Defined in:** `server/services.ts` → `RegimeType`, `analyzeRegime()`.
- **Used in:** Scanner (`server/market-scanner.ts`), backtest (`server/backtest-runner.ts`), advanced signals (`server/advanced-signals.ts` → `determineRegime()`).

**List of 11 regimes:**

| # | Regime ID | Description |
|---|-----------|-------------|
| 1 | `bull_vol_compression` | Bullish trend, low/decreasing volatility |
| 2 | `bull_vol_expansion` | Bullish trend, high/increasing volatility |
| 3 | `bear_vol_compression` | Bearish trend, low vol |
| 4 | `bear_vol_expansion` | Bearish trend, high vol |
| 5 | `mean_reverting` | Neutral, low vol, range-bound |
| 6 | `chaotic` | High vol, unclear trend, LSI > 0.7 |
| 7 | `crisis` | Extreme stress; LSI > 0.85 or very high vol |
| 8 | `liquidity_drought` | Very low liquidity (e.g. volume ratio < 0.5) |
| 9 | `trending_bull` | Strong upward momentum; \|trend\| > 5% |
| 10 | `trending_bear` | Strong downward momentum |
| 11 | `sector_rotation` | Sector leadership rotating (placeholder when sector data available) |

**Scanner regime logic (market-scanner.ts):**  
Uses trend (from `getRealTrend`), volatility (from options IV), volume ratio. Order: `crisis` (vol > 0.45) → `liquidity_drought` (volume ratio < 0.5) → `trending_bull` / `trending_bear` (strong momentum) → `bull_vol_expansion` / `bear_vol_expansion` → `bull_vol_compression` / `bear_vol_compression` → `mean_reverting`.

**Backtest regime logic (backtest-runner.ts):**  
Per bar: trend over 20 days, recent realized vol (volPct). Order: `crisis` (volPct > 5) → `trending_bull` / `trending_bear` (trend > 5%) → bull/bear vol compression/expansion (trend ±2%, volPct 2) → `mean_reverting` (|trend| < 1%) → else `chaotic`.

**Services `analyzeRegime()`:**  
Uses spot vs MA20, IV/RV ratio, LSI (sofr, move index, fx vol, order book depth), strong momentum threshold, low liquidity depth. Produces regime + transition probability + confidence.

---

## 4. Market Scanner — End to End

- **Module:** `server/market-scanner.ts`.
- **Singleton:** `getMarketScanner()`.

### 4.1 Scan flow

1. **Scan:** `scan()` iterates over `UNIQUE_SYMBOLS` in batches (e.g. 10), 250 ms delay between batches. For each symbol:
   - Prefer IB market data if gateway connected; else `getRealStockPrice(symbol)` (Yahoo).
   - `getRealOptionsData(symbol)` (Yahoo) for IV, ivRank, put/call.
   - `getRealTrend(symbol, 20)` for trend.
   - Regime computed from trend, volatility, volume ratio (see above).
   - Regime stability and transition probability derived (stability = f(trend, vol)).
   - Signal: try `generateAdvancedSignal(symbol, priceData, optionsData, [])`; if not used, fallback to best of dealer gamma, flow, momentum signals from `services.ts`.
   - Structure: `selectOptimalStructure(regime, confidence, expectedMove, volatility, ivRank, symbol)` — includes `symbol` so structure variety varies by symbol (iron condor, butterfly, vertical, CSP, etc.).
   - Score: `calculateRealScore(priceData, optionsData, signal, volumeRatio)` (see below).
   - Win probability: `calculateRealWinProbability(signalConfidence, regime, volumeRatio, ivRank)`.
   - Expected return: `|priceChangePercent| * signal.confidenceScore * 2`.
   - Risk/reward: `expectedReturn / (volatility * 100)`.
   - Result stored in `Map<symbol, MarketOpportunity>` and returned as array.

### 4.2 Opportunity score (calculateRealScore)

- **Module:** `server/ranking-utils.ts` provides regime-signal alignment, regime win-prob bounds, expected-return multiplier, stability penalty, IV regime multiplier, structure Greeks score, data freshness.
- Base 50. + Signal confidence × 25. + Volume surge (1.2–2+ → up to 15). + Price momentum (1–3%+ → up to 10). + **IV rank bonus regime-calibrated:** raw bonus 0–10 then × `getIVRegimeMultiplier(regime, ivRank)` (e.g. bull_vol_compression favors IV rank 20–40 → 1.15×; bull_vol_expansion favors IV rank 70+ → 1.2×). + 52-week position. + Alternative data and options flow. Then **× regime-signal alignment** (0.7–1.3) via `getRegimeSignalAlignment(regime, signalClass)`. Then **× (1 - stability penalty)** from `getStabilityPenalty(regimeStability, transitionProbability)`. + **Greeks-based structure score** (±5) from `getStructureGreeksScore(regime, structureType, greeks)`. Clamped 0–100.

### 4.3 Win probability (calculateRealWinProbability)

- Base 0.45. + Signal confidence × 0.2. + Regime bonuses (e.g. bull_vol_compression +0.08, bear_vol_expansion +0.05). + Volume > 1.5× +0.05. + IV rank > 60 +0.05. **Clamped by regime-specific bounds** from `getRegimeWinProbBounds(regime)` (e.g. mean_reverting 0.58–0.90, crisis 0.25–0.65, chaotic 0.40–0.70).

### 4.4 Ranking and “best one”

- **Composite score (getTopOpportunities):**  
  `compositeScore(opp)` = score×0.32 + winProb×38 + expectedReturn (capped)×0.22 + signalConf×18 + growthBias + stabilityBonus, normalized 0–100. Used to sort; optional filters: minScore, minWinProbability, structureType, regime, symbolSearch. Returns top N (max 200).

- **Explosive score (one-stop / growth):**  
  `explosiveScore(opp)` = winProb×45 + expectedReturn×25 + score/100×15 + signalConf×10 + riskReward×5. Used to pick the single highest-probability, highest-profit setup.

- **getHighestExplosiveSetup(options?):**  
  Filters by minWinProbability (0–100), minScore, regime if provided; sorts by `explosiveScore` descending; returns first (or undefined).

- **getTopOpportunities(count, filters?):**  
  Sorts by `compositeScore` descending, applies filters, returns slice(0, count).

### 4.5 MarketOpportunity shape

- symbol, currentPrice, priceChange, priceChangePercent, volume, avgVolume, high52Week, low52Week, regime, regimeStability?, transitionProbability?, signal { class, confidence, direction }, opportunity { score, expectedReturn, riskReward, winProbability }, structure { type, direction, expectedValue, cvar }, greeks?, impliedVolatility?, ivRank?, **daysToExpiry?** (optional; used for DTE score factor), timestamp, dataSource.

---

## 5. Structure Selection (Options)

- **Module:** `server/services.ts` → `selectOptimalStructure(regime, signalConfidence, expectedMove, iv, ivPercentile, symbolHint?)`.
- **Role:** Chooses option structure type and direction (bullish/bearish/neutral) per regime; `symbolHint` is hashed so different symbols get different structures (iron condor, vertical, butterfly, CSP, calendar, etc.).

**Regime → structure examples (see REGIMES_REFERENCE.md for full table):**

- bull_vol_compression: vertical_call_spread, covered_call, cash_secured_put, iron_condor, calendar_spread (hash picks one).
- bull_vol_expansion: vertical_call_spread, straddle, strangle, iron_condor, iron_butterfly.
- bear_vol_compression / bear_vol_expansion: vertical_put_spread, iron_condor, iron_butterfly.
- mean_reverting: iron_condor, iron_butterfly, calendar_spread.
- chaotic: calendar_spread, iron_condor, strangle.
- crisis: vertical_put_spread, calendar_spread, iron_condor.
- liquidity_drought: calendar_spread, iron_condor.
- trending_bull: vertical_call_spread, cash_secured_put, iron_condor, covered_call, iron_butterfly.
- trending_bear: vertical_put_spread, iron_condor.
- sector_rotation: iron_condor, calendar_spread.
- Default: calendar_spread, iron_condor, vertical_call/put_spread, diagonal_spread.

**Structure types (strategy-types.ts ALL_STRUCTURE_TYPES):** iron_condor, iron_butterfly, vertical_call_spread, vertical_put_spread, calendar_spread, diagonal_spread, straddle, strangle, butterfly, cash_secured_put, covered_call.

---

## 6. Strategy Types (Engine Modes)

- **Module:** `server/strategy-types.ts`.
- **Types:** `wheel`, `short_term`, `iron_condor`, `adaptive`.

**Config per strategy:**

- **wheel:** preferredStructures [cash_secured_put, covered_call, vertical_put/call_spread], maxHoldDays 45, minWinProbability 0.70, takeProfit 50%, stopLoss 1.0 (wide), maxPositionsBonus 1.
- **short_term:** vertical_call/put_spread, straddle, iron_condor; maxHoldDays 7, minWinProbability 0.60, TP 25%, SL 25%.
- **iron_condor:** iron_condor, iron_butterfly, calendar, verticals; maxHoldDays 30, minWinProbability 0.65, TP 50%, SL 1.0.
- **adaptive:** vertical_call_spread, iron_condor, straddle, calendar; maxHoldDays 0 (regime default), minWinProbability 0.60, TP 30%, SL 20%.

**Strategy–regime fit:**

- `getPreferredStructureForRegime(strategy, regime)` — for non-adaptive, returns preferred structure type for that regime (bull → call/covered, bear → put/iron_condor, mean revert → iron_condor/calendar/straddle).
- `isRegimeFavorableForStrategy(strategy, regime)` — wheel/short_term favored in bull/trending_bull; iron_condor/short_term in mean_reverting, chaotic, crisis, liquidity_drought, sector_rotation, trending_bear.
- `isStructurePreferredForStrategy(strategy, structureType)` — true for adaptive; else structure must be in strategy’s preferredStructures.

---

## 7. Backtest System

### 7.1 Historical backtest (server/backtest-runner.ts)

- **Function:** `runHistoricalBacktest(symbol, days, holdDays, onlyTradeRegimes?, useOptionStylePnl?, riskPerTrade?, contractsPerTrade?)`.
- **Data:** Yahoo `chart(symbol, period1, period2, interval: '1d')`. Needs at least 25 bars; fetches `days + 10` calendar days.
- **Per bar (from bar i, hold holdDays):**  
  Trend = (close[i] - close[i-20])/close[i-20]. Recent vol = volPct (20-day). Regime = crisis (volPct>5) | trending_bull/bear (trend ±5%) | bull/bear vol compression/expansion (trend ±2%, volPct 2) | mean_reverting (|trend|<1%) | chaotic.
- **P&L:** If `useOptionStylePnl` true: synthetic option. Sell-premium regimes (bull_vol_compression, mean_reverting, trending_bull) → short put (Black–Scholes at entry, intrinsic at exit). Crisis → long put. Bear/trending_bear → long put. Bull_vol_expansion/chaotic → long call. Else raw stock return over hold.
- **Sizing:** Each trade return scaled by `riskPerTrade * contractsPerTrade * stressMultiplier`. Stress: when volPct > VOL_STRESS_THRESHOLD (3.5), multiplier 0.5; else 1.0.
- **Filter:** If `onlyTradeRegimes` set, only bars whose regime is in that list count as trades.
- **Output:** success, symbol, days, trades, sharpeRatio, maxDrawdownPercent, winRate, profitFactor, cumulativeGrowth, totalReturnPercent, regimeSummary, message, durationMs.

### 7.2 Strategy backtest (scanner-based)

- **Function:** `runBacktest(config: BacktestConfig)`.
- **Config:** strategy, symbols?, oneStop?, initialCapital, maxPositions.
- **Opportunities:** If `oneStop`: scan if empty, then `getHighestExplosiveSetup({ minWinProbability: 55, minScore: 50 })` → single opportunity, maxPositions 1. Else symbols list → getOpportunity per symbol, or `getTopOpportunities(20)`.
- **Per opportunity:** Regime, preferred structure from `getPreferredStructureForRegime`, `selectOptimalStructure` for recommended; win prob vs strategy `minWinProbability` → count as simulated trade. Estimated P&L: for each “taken” trade, `initialCapital * (winProb * (expectedReturn/100) - (1-winProb)*0.005)`; bestSymbol and expectedReturnPercent from that pick.
- **Result:** success, strategy, simulatedTrades, opportunitiesEvaluated, structureSummary, message, durationMs, sharpeRatio, maxDrawdownPercent, winRate, profitFactor, estimatedPnl?, bestSymbol?, expectedReturnPercent?, seed?, configSnapshot?.

### 7.3 Full backtest script (scripts/run-full-backtest.ts)

- **Modes (env):**
  - **BACKTEST_GROWTH=1:** One symbol only = QQQ (aggressive growth). Hold 2 days, risk 1.2%. Skip historical if BACKTEST_ONE_STOP also set? No — BACKTEST_GROWTH only changes symbols/hold/risk; BACKTEST_ONE_STOP skips historical and runs strategy backtest one-stop.
  - **BACKTEST_ONE_STOP=1:** Skip historical backtest. Run scan, print best one (getHighestExplosiveSetup(55, 50)). Run strategy backtests with oneStop: true, maxPositions 1. Print one-stop summary with Est. P&L.
  - **BACKTEST_SYMBOLS:** Comma list or `one`/`1`/`best_one` → [QQQ], or `best` → [SPY, QQQ]. Else ALL_SYMBOLS (20 names).
  - **BACKTEST_DAYS:** 252 default (12 months), or 126 (6 months), or 35 etc.
  - **BACKTEST_HOLD_DAYS:** Default 3 (or 2 if BACKTEST_GROWTH=1).
  - **BACKTEST_CAPITAL:** Default 100_000; e.g. 2500 for $2.5k.
  - **BACKTEST_REGIMES:** Default unset = use `['bull_vol_compression','mean_reverting','trending_bull']`. Set to empty string = all 11 regimes. Comma list = override.
  - **BACKTEST_RISK_PER_TRADE:** Default 0.008 (0.8%) or 0.012 if BACKTEST_GROWTH=1.
  - **BACKTEST_CONTRACTS:** Default 1.
  - **BACKTEST_6_AND_12:** If 1, run both 6-month and 12-month historical.
- **Flow:** Optional small-account warning (capital < 2500). Optional growth banner. Run historical period(s) for HISTORICAL_SYMBOLS (unless BACKTEST_ONE_STOP), print summary, optional weekly/monthly projection (if 12m). If BACKTEST_ONE_STOP, scan and print best one. Run strategy backtests (wheel, short_term, iron_condor, adaptive) with oneStop and maxPositions when BACKTEST_ONE_STOP. Print BACKTEST COMPLETE, historical count, strategies count, one-stop Est. P&L line if applicable, best historical if any.

### 7.4 Optimizer (scripts/find-optimal-backtest.ts)

- **Command:** `pnpm backtest:optimal`.
- **Grid:** riskPerTrade in [0.008, 0.01, 0.012, 0.015, 0.02], holdDays in [3,4,5,6,7], regime filter on/off (DEFAULT_REGIMES vs all). Symbols: SPY, QQQ, IWM, AAPL, GOOGL, JNJ, NVDA, MSFT. 12 months (252 days).
- **Robust score:** avgSharpe - 0.15*avgMaxDD; then penalize if any symbol has maxDD > 15% or winRate < 55%. Picks params that maximize robust score (no “hidden stress” on one symbol).

---

## 8. Auto-Trading Engine

- **Module:** `server/auto-trading-engine.ts`.
- **Singleton:** `getAutoTradingEngine()`. State: accountBalance, totalEquity, positions, trades, currentRegime, lastScanTime, lastOpportunities, riskMetrics, aggressionTier, strategyType (default `adaptive`).

### 8.1 Cycle (runCycle)

1. Kill switch check.
2. **Scan:** `scanner.scan()` (retries 2). Store opportunities, update currentRegime from top opportunity.
3. **Update positions** with real prices.
4. **Performance:** From closed positions → `calculatePerformanceMetrics` (win rate, profit factor, sharpe, drawdown, consecutive wins/losses).
5. **VIX** and **market conditions** → `determineMarketConditions(realVIX, marketTrend, positions)`.
6. **Adaptive risk:** `calculateAdaptiveRisk(performance, marketConditions)` → riskMultiplier, maxPositions, minScoreThreshold, takeProfit/stopLoss multipliers, rationale. Then **aggression tier** from `getAggressionTier(performance, closedCount)`. Then **regime overlay** `getRegimeRiskMultiplier(currentRegime, leadSignalConfidence)` — multiplies risk, adjusts max positions.
7. **Tradable opportunities:**  
   If **TRADE_ONE_STOP=1:** tradableOpportunities = [getHighestExplosiveSetup({ minWinProbability: 55, minScore: 50 })], maxPositions = 1, effectiveRisk = { ...riskAdjustment, maxPositions: 1 }. Log “One stop: trading only highest explosive setup — SYMBOL …”.  
   Else: filter opportunities by adaptiveMinScore, MIN_WIN_PROBABILITY (0.60), dataSource yahoo_finance, MIN_REGIME_CONFIDENCE (0.85). If strategy !== adaptive, filter by structure preferred and regime favorable, sort, slice(0, 5). effectiveRisk = riskAdjustment.
8. **Evaluate and trade:** For each tradable opportunity call `evaluateAndTradeAdvanced(opp, effectiveRisk)`: check not already in position, under max positions; fetch price/options, generate advanced signal (min confidence 0.65), multi-timeframe analysis, position size (Kelly/adaptive), then place/simulate order (paper or IB).

### 8.2 Position sizing (engine uses position-sizing.ts)

- **calculateOptimalPositionSize(inputs):** If win/avgWin/avgLoss available → Kelly (25% fractional) with adaptive cap; else adaptive. Returns quantity (min 1), riskAmount, positionValue, maxSize.
- **calculatePortfolioAwareSize:** Reduces size if total delta exposure would exceed 15% of account.
- **Inputs:** accountBalance, winProbability, avgWinSize, avgLossSize, currentDrawdown, volatility, correlation, maxRiskPerTrade, optionPrice, strike, currentPrice.

### 8.3 Constants (engine)

- INITIAL_BALANCE 100000, MAX_RISK_PER_TRADE 0.01, TAKE_PROFIT_PERCENT 0.30, STOP_LOSS_PERCENT 0.20, MOMENTUM_GLIDE_THRESHOLD 0.15, TRAILING_STOP_PERCENT 0.10, DAILY_LOSS_LIMIT 0.05, RUIN_PROBABILITY_THRESHOLD 0.10, MAX_POSITIONS 3, CHECK_INTERVAL_MS 30000, MIN_SCORE_THRESHOLD 85, MIN_WIN_PROBABILITY 0.60, MIN_REGIME_CONFIDENCE 0.85.

---

## 9. Adaptive Risk and Regime Overlay

- **Module:** `server/adaptive-risk.ts`.

**calculateAdaptiveRisk(performance, marketConditions, baseRisk, baseMaxPositions):**  
Adjusts riskMultiplier, maxPositions, minScoreThreshold, takeProfitMultiplier, stopLossMultiplier from: current drawdown (10%+ → aggressive cut, 5–10% → moderate, 2–5% → slight), consecutive losses (5 → heavy cut, 3 → moderate), consecutive wins (5 and low DD → slight increase), win rate (< 45% reduce, > 65% and good PF slight increase), profit factor < 1 → aggressive reduction, volatility regime (extreme/high VIX → reduce), market trend (strong_down reduce, strong_up slight increase if DD low), correlation > 0.8 reduce, Sharpe (low reduce, high and low DD slight increase). Caps: riskMultiplier 0.1–1.2, maxPositions 1 to 2×base, minScoreThreshold 80–98.

**getRegimeRiskMultiplier(regime, confidence):**  
Crisis → 0.25, maxPos -2. Liquidity_drought → 0.5, -1. Bear_vol_expansion / chaotic / trending_bear → 0.6–0.7, -1. Bull + high conf → 1.0; low conf → 0.8. Mean_reverting/chaotic/sector_rotation → 0.7–1.0 by confidence.

**getRegimePositionSizeMultiplier(regime):**  
crisis 0.15, liquidity_drought 0.4, bear_vol_expansion/chaotic/trending_bear 0.25, bear_vol_compression 0.5, mean_reverting/sector_rotation 0.8, bull_vol_expansion 1.0, trending_bull 1.2, bull_vol_compression 1.5.

---

## 10. Signals (Services)

- **Module:** `server/services.ts`.  
- **Dealer gamma:** `generateDealerGammaSignal(gex, vegaExposure, spotPrice, iv)` — Class A, confidence from gex intensity.  
- **Flow:** `generateFlowSignal(sweepVolume, avgVolume, blockTradeCount, bidAskSpread)` — Class B.  
- **Momentum:** `generateMomentumSignal(roc, rsi, bbPosition, volatility)` — Class C.  
- **Catalyst:** `generateCatalystSignal(daysToEvent, expectedMove, historicalMove)` — Class D.  
- **Advanced:** `server/advanced-signals.ts` → `generateAdvancedSignal(symbol, priceData, optionsData, historical)` used by scanner when confidence >= 0.5; otherwise scanner uses best of dealer/flow/momentum.

---

## 11. APIs (tRPC)

### 11.1 Market scanner (server/routers/market-scanner.ts)

- **scan:** query, no input. Calls scanner.scan(), returns { success, count, opportunities, timestamp, dataSource }.
- **getBestOne:** input { minWinProbability?, minScore?, regime?, runScanIfEmpty? }. If runScanIfEmpty and no opportunities, scan. Then getHighestExplosiveSetup(options). Returns { success, oneStop: true, opportunity, message, dataSource }.
- **getTopOpportunities:** input { count, minScore?, minWinProbability?, structureType?, regime?, symbolSearch? }. Returns { success, count, opportunities, dataSource }.
- **getKnownStrategies:** returns strategies, regimes, strategyTypes from strategy-types.
- **getOpportunity:** input { symbol }. Returns single opportunity or null.
- **getAllOpportunities:** returns all from scanner.
- **getStatus:** scanner status (isScanning, lastScanTime, totalOpportunities, errors).
- **clear:** clears scanner opportunities.

### 11.2 Auto-trading (server/routers/auto-trading.ts)

- **getState:** current engine state (balance, equity, positions, regime, risk metrics, etc.).
- **start:** mutation, starts engine (protected).
- **stop:** mutation, stops engine.
- **reset:** mutation, resetAutoTradingEngine().
- **getPositions:** open positions.
- **getAllPositions:** all positions (limit).
- **getTrades:** recent trades (limit).
- **getRiskMetrics:** risk metrics.
- **getLogs:** engine logs (limit).
- **setStrategyType:** set strategy (wheel, short_term, iron_condor, adaptive).
- **runBacktest:** strategy backtest (strategy, symbols?, initialCapital, maxPositions).
- **runHistoricalBacktest:** single-symbol historical backtest (symbol, days, holdDays, onlyTradeRegimes?, useOptionStylePnl?, riskPerTrade?).

### 11.3 Other routers

- **gateway:** IB Gateway status, connect, disconnect, etc.
- **omega0:** Execution flow, account value, order placement (see server/routers/omega0.ts).
- **tws-connection:** TWS/API connection.

---

## 12. Environment and Configuration

- **Backtest:** BACKTEST_CAPITAL, BACKTEST_DAYS, BACKTEST_GROWTH, BACKTEST_ONE_STOP, BACKTEST_SYMBOLS, BACKTEST_REGIMES, BACKTEST_HOLD_DAYS, BACKTEST_RISK_PER_TRADE, BACKTEST_CONTRACTS, BACKTEST_6_AND_12.
- **Live/engine:** TRADE_ONE_STOP=1 → engine trades only the single highest explosive setup, max 1 position.
- **IBKR:** Gateway URL, credentials (see docs/IBKR_CONNECTION.md, GATEWAY_SETUP.md).

---

## 13. File Map (Critical Pieces)

| Responsibility | File(s) |
|----------------|--------|
| Regime type + analyzeRegime, signals, selectOptimalStructure, dynamic risk | server/services.ts |
| Strategy types, preferred structures, regime favorability | server/strategy-types.ts |
| Ranking: regime-signal alignment, win-prob bounds, expected-return multiplier, stability penalty, IV regime, Greeks score, freshness, DTE, data source, correlation | server/ranking-utils.ts |
| A+++ 9-pillar composite ranker (score 0–100 + Tier; uses structure-selector, greeks-engine, iv-surface) | server/composite-ranker.ts |
| Phase 1: Bayesian regime classifier, portfolio optimizer, signal ensemble | server/bayesian-regime-classifier.ts, server/portfolio-optimizer.ts, server/signal-ensemble.ts |
| Phase 2: Greeks engine, structure selector (150 triplets), IV surface analyzer | server/greeks-engine.ts, server/structure-selector.ts, server/iv-surface-analyzer.ts |
| Phase 3: Microstructure signals, execution cost model | server/microstructure-signals.ts, server/execution-cost-model.ts |
| Phase 4: OOS validator, walk-forward validation | server/oos-validator.ts |
| Scanner: scan, analyzeStock, score, win prob, composite/explosive, getAPlusRank, getTopOpportunities, getHighestExplosiveSetup | server/market-scanner.ts |
| Real market data (Yahoo) | server/real-market-data.ts |
| IB market data, orders, gateway | server/ib-market-data.ts, ib-orders.ts, ibkr.ts |
| Historical + strategy backtest | server/backtest-runner.ts |
| Full backtest script, env vars, one-stop, growth | scripts/run-full-backtest.ts |
| Backtest optimizer (grid, robust score) | scripts/find-optimal-backtest.ts |
| Adaptive risk, regime overlay, position size multiplier | server/adaptive-risk.ts |
| Position sizing (Kelly, fixed fractional, adaptive, portfolio-aware) | server/position-sizing.ts |
| Auto-trading engine (cycle, scan, risk, one-stop, evaluateAndTrade) | server/auto-trading-engine.ts |
| Aggression tier | server/aggression-tier.ts |
| Advanced signals | server/advanced-signals.ts |
| Market scanner API, getBestOne | server/routers/market-scanner.ts |
| Auto-trading API | server/routers/auto-trading.ts |
| Regime reference (11 regimes, backtest vs app, strategy–regime) | REGIMES_REFERENCE.md |

---

## 14. End-to-End Flow (How It All Fits)

1. **Data:** Yahoo (and optionally IB) provides quotes, options data, history. Scanner uses that for 180+ symbols.
2. **Regime:** Every bar (backtest) or every symbol (scanner) gets one of 11 regimes from trend, vol, liquidity.
3. **Signal:** Per symbol, best signal (advanced or dealer/flow/momentum) gives confidence and direction.
4. **Structure:** selectOptimalStructure(regime, confidence, move, iv, ivRank, symbol) picks option structure and direction; strategy type (wheel/short_term/iron_condor/adaptive) can bias or filter.
5. **Score:** Real score (0–100) and win probability (0.35–0.85) from signal, regime, volume, IV rank, flow/sentiment. Composite rank = score + winProb + expectedReturn + stability for “top N”. Explosive rank = winProb + expectedReturn heavy for “best one”.
6. **Backtest:** Historical = Yahoo daily bars, regime per bar, option-style P&L, stress-sized, filter by BACKTEST_REGIMES. Strategy = current scan, count trades meeting min win prob, estimated P&L from expected return and win prob. One-stop = single getHighestExplosiveSetup, max 1 position, Est. P&L printed.
7. **Live/paper engine:** Scan → adaptive risk + aggression + regime overlay → tradable list (either top 5 by composite or single best by explosive if TRADE_ONE_STOP=1, max 1 pos) → evaluateAndTradeAdvanced (advanced signal, position size, place order). Position sizing uses Kelly/adaptive and portfolio cap.

---

## 15. Execution and Exits

### 15.1 Execution path

- **Paper / live:** Auto-trading engine calls position sizing then places orders. When IB Gateway is used, orders go through `server/ib-orders.ts`, `server/ibkr.ts`, or Client Portal API. Gateway adapter (`server/gateway-adapter.ts`) and TWS client (`server/tws-api-client.ts`, `server/tws-market-data.ts`) support TWS/API connectivity. Omega0 router (`server/routers/omega0.ts`) exposes account value, balance, and order/execution endpoints for the app.
- **Order flow:** Engine decides symbol, structure, quantity from position-sizing; then submit order (paper: update state; live: IB order placement). Market impact (`server/market-impact.ts`) can cap quantity by ADV.

### 15.2 Dynamic exits (server/dynamic-exits.ts)

- **determineExitStrategy(position, market, performance):** Returns ExitDecision: action (hold | take_profit | stop_loss | trailing_stop | time_stop | regime_exit), exitPrice, reason, urgency, confidence.
- **Priority:** Stop loss first, then take profit, then dynamic take profit (adjusted by performance and market), trailing stop (e.g. from high water mark), time-based exit, regime-based exit. Uses position context (entry/current price, days to expiry, unrealized P&L, regime) and market context (VIX, trend, time of day).

---

## 16. A+++ 9-Pillar Architecture (Phases 1–4 Complete)

**Target:** Sharpe 3.5–4.2, Max DD 6–8%, Win Rate 72–76%, Ranking Accuracy ≥95%.

**Composite formula:** `FINAL_SCORE = (p1×0.22 + p2×0.18 + p3×0.16 + p4×0.15 + p5×0.13 + p6×0.11 + p7×0.10 + p8×0.08 + p9×0.07) × 100`

**Tiers:** 85–100 Elite (100% sizing) | 70–84 Strong (75%) | 55–69 Moderate (50%) | 40–54 Watch (25%) | 0–39 Reject (0%).

**Phase 1 (Foundation):** bayesian-regime-classifier.ts (regime persistence, vol target, transition risk), portfolio-optimizer.ts (risk contribution, correlation, diversification, Greeks cap), signal-ensemble.ts (multi-TF alignment, signal agreement).

**Phase 2 (Greeks):** greeks-engine.ts (BS expected move, vol decay, greeksProfileScore), structure-selector.ts (150+ regime–signal–structure triplets), iv-surface-analyzer.ts (term structure, skew, regimeVolAlignment).

**Phase 3 (Microstructure):** microstructure-signals.ts (order book proxy, sweep, spread bonus, unusual flow), execution-cost-model.ts (spread, market impact, commission, time-of-day).

**Phase 4 (Validation):** oos-validator.ts (validateOOS, validateWalkForward, getLiveDivergencePenalty).

**Composite ranker:** Uses structure-selector (P7), greeks-engine (P3), iv-surface (P6). Optional inputs: microstructureCompositeScore (P5), executionCostMultiplier (P8), oosPenaltyFactor (P9).

**Usage:** `scanner.getAPlusRank(opp, existingPositions)` returns `{ score, tier, tierLabel, pillarScores }`. Precompute microstructure (getMicrostructureSignals), execution cost (getExecutionCost), OOS penalty (validateOOS) and pass into CompositeRankerInput for full A+++ scoring.

---

### §17 Readiness / Verification

- **Routers:** `server/routers.ts` (appRouter) aggregates: auth, market, regime, signals, structures, risk, execution, trades, metaIntelligence, failures, shadowSystem, correlations, omega0, autoTrading, gateway, marketScanner, twsConnection. All procedures use real logic or DB; no fake data in critical paths.
- **Endpoints:** Omega0 (placeOrder with MKT/LMT, closePosition, getOptionChain, portfolio risk, getPortfolioStress, suggestQuantity), marketScanner (scan, getTopOpportunities with regime ranking bonus, getBestOne, getStatus), autoTrading (getState, getTCASummary, start, stop, runBacktest, runHistoricalBacktest), gateway, twsConnection. System health: `system.health`.
- **Implemented (approved):** Regime filter in live scanner (getRegimeRankingBonus for bull_vol_compression, mean_reverting, trending_bull). Position sizing in Trade Now (suggestQuantity + “Suggested: N contracts”). TCA and portfolio stress on Execution page (getTCASummary, getPortfolioStress). Deploy checklist: `node scripts/deploy-check.js`. Backtest: BACKTEST_REGIMES env; portfolio avg Sharpe in summary. Limit orders: placeOrder accepts orderType MKT/LMT and limitPrice. Options flow: OPTIONS_FLOW_API_URL used when set (options-flow.ts). Portfolio risk: OpenPositionForRisk.greeks optional for real Greeks from IB/chain. E2E: server/e2e/health.e2e.test.ts (skips unless E2E_SERVER_URL set).
- **Tests:** `pnpm test` runs all suites; `pnpm check` passes.

---

This is the full operating system: data → regime → signal → structure → score → rank → backtest or trade → risk and sizing → execution and dynamic exits at every step.
