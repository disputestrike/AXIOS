/**
 * AOIX-1 Intent-driven governance. Full organism: trade the truth, all we can trade.
 * Claude = Chief Strategist (intent picks the best). Core = execution + risk.
 * Governance = coherence + ability to trade everything; intent chooses the best. No regime-based blocking.
 */

/** Canonical regime (blueprint). Scanner uses snake_case; normalize to this for law. */
export type Regime =
  | "BULL_VOL_COMP"
  | "BEAR_VOL_COMP"
  | "TRENDING_BULL"
  | "TRENDING_BEAR"
  | "MEAN_REVERTING"
  | "CHAOTIC"
  | "CRISIS"
  | "LIQUIDITY_DROUGHT"
  | "SECTOR_ROTATION";

/** Strategy classes (NOT named strategies). Map structures internally. */
export type StrategyClass =
  | "DIRECTIONAL_DEFINED_RISK"
  | "NEUTRAL_RANGE"
  | "VOLATILITY"
  | "TIME_SKEW"
  | "STOCK_ANCHORED";

/** Claude intent output (STRICT). Claude must NOT name strategies, strikes, or size. */
export interface IntentDecision {
  direction: "BULLISH" | "BEARISH" | "NEUTRAL";
  volatilityBias: "SELL" | "BUY" | "NEUTRAL";
  allowedClasses: StrategyClass[];
  forbiddenClasses: StrategyClass[];
  confidence: number; // 0–1
  rationale: string; // 2–3 sentences max
}

/** All strategy classes — full universe. We can trade all of these; intent picks the best. */
export const ALL_STRATEGY_CLASSES: StrategyClass[] = [
  "DIRECTIONAL_DEFINED_RISK",
  "NEUTRAL_RANGE",
  "VOLATILITY",
  "TIME_SKEW",
  "STOCK_ANCHORED",
];

/**
 * Strategy compatibility: every regime can trade every strategy class.
 * No blocking. Regime + signal inform scoring/ranking; intent picks the best.
 */
export const STRATEGY_COMPATIBILITY: Record<Regime, StrategyClass[]> = {
  BULL_VOL_COMP: ALL_STRATEGY_CLASSES,
  BEAR_VOL_COMP: ALL_STRATEGY_CLASSES,
  TRENDING_BULL: ALL_STRATEGY_CLASSES,
  TRENDING_BEAR: ALL_STRATEGY_CLASSES,
  MEAN_REVERTING: ALL_STRATEGY_CLASSES,
  CHAOTIC: ALL_STRATEGY_CLASSES,
  CRISIS: ALL_STRATEGY_CLASSES,
  LIQUIDITY_DROUGHT: ALL_STRATEGY_CLASSES,
  SECTOR_ROTATION: ALL_STRATEGY_CLASSES,
};

/** Map scanner regime string → canonical Regime. */
export function normalizeRegimeToCanonical(regime: string): Regime {
  const r = (regime ?? "").toLowerCase();
  if (r.includes("bull_vol_comp") || r === "bull_vol_compression") return "BULL_VOL_COMP";
  if (r.includes("bear_vol_comp") || r === "bear_vol_compression") return "BEAR_VOL_COMP";
  if (r.includes("trending_bull") || r.includes("bull_vol_expansion")) return "TRENDING_BULL";
  if (r.includes("trending_bear") || r.includes("bear_vol_expansion")) return "TRENDING_BEAR";
  if (r === "mean_reverting") return "MEAN_REVERTING";
  if (r === "chaotic") return "CHAOTIC";
  if (r === "crisis") return "CRISIS";
  if (r === "liquidity_drought") return "LIQUIDITY_DROUGHT";
  if (r === "sector_rotation") return "SECTOR_ROTATION";
  // Defaults for unknown
  if (r.includes("bull")) return "BULL_VOL_COMP";
  if (r.includes("bear")) return "BEAR_VOL_COMP";
  return "MEAN_REVERTING";
}

/** Structure id → strategy class (internal mapping). */
export const STRUCTURE_TO_CLASS: Record<string, StrategyClass> = {
  vertical_call_spread: "DIRECTIONAL_DEFINED_RISK",
  vertical_put_spread: "DIRECTIONAL_DEFINED_RISK",
  iron_condor: "NEUTRAL_RANGE",
  iron_butterfly: "NEUTRAL_RANGE",
  butterfly: "NEUTRAL_RANGE",
  calendar_spread: "NEUTRAL_RANGE",
  straddle: "VOLATILITY",
  strangle: "VOLATILITY",
  diagonal_spread: "TIME_SKEW",
  cash_secured_put: "STOCK_ANCHORED",
  covered_call: "STOCK_ANCHORED",
};

/** Get strategy class for a structure id. */
export function getStrategyClassForStructure(structureId: string): StrategyClass | null {
  const id = (structureId ?? "").toLowerCase().replace(/\s+/g, "_").trim();
  return STRUCTURE_TO_CLASS[id] ?? null;
}

/** Get all structure ids that belong to a strategy class. */
export function getStructuresForClass(cls: StrategyClass): string[] {
  return Object.entries(STRUCTURE_TO_CLASS)
    .filter(([, c]) => c === cls)
    .map(([id]) => id);
}

/**
 * Allowed strategy classes = intent (allowedClasses, forbiddenClasses). Regime does not block.
 * Intent picks the best; we can trade everything compatible with intent.
 */
export function filterStrategies(intent: IntentDecision, regime: Regime): StrategyClass[] {
  const available = STRATEGY_COMPATIBILITY[regime];
  return available.filter(
    (cls) =>
      intent.allowedClasses.includes(cls) &&
      !intent.forbiddenClasses.includes(cls)
  );
}

/** Regime risk multiplier for position sizing (Kelly-lite). Blueprint values. */
export function getRegimeRiskMultiplierForSizing(regime: Regime): number {
  switch (regime) {
    case "CRISIS":
      return 0.4;
    case "CHAOTIC":
      return 0.5;
    case "MEAN_REVERTING":
      return 0.8;
    case "TRENDING_BULL":
    case "TRENDING_BEAR":
    case "BULL_VOL_COMP":
    case "BEAR_VOL_COMP":
    case "LIQUIDITY_DROUGHT":
    case "SECTOR_ROTATION":
      return 1.0;
    default:
      return 1.0;
  }
}
