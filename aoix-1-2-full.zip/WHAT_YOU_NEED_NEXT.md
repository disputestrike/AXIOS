# What You Need Next — One Place

This doc answers: **What's your pain point? What should happen next? Who's the audience? What format?**  
Use the section that fits. Everything below is ready to use.

---

## 1. Quick start (5–10 min to get running)

| Step | Do this | Verify |
|------|---------|--------|
| 1 | `npm install` | No errors |
| 2 | `npm run dev` | Server starts; open http://localhost:3000 |
| 3 | Log in if prompted | Demo user works |
| 4 | Go to **Market Opportunities** | List loads (scan runs on mount or click Scan) |
| 5 | Click **Trade Now** on any row | Dialog opens; set contracts → **Place order** |
| 6 | Go to **Execution** | Your open position appears; optional **X Close** |
| 7 | (Optional) **Auto Trading** → **Start engine** | Status "Running"; positions/trades may appear over time |

**You do not need** TWS, IB Gateway, or a populated database for steps 1–6.

---

## 2. Deployment checklist (production readiness)

| Item | Done? | Notes |
|------|-------|--------|
| **Build** | | `npm run build` then `npm start` (or `cross-env NODE_ENV=production node dist/index.js`) |
| **Port** | | Set `PORT` env (default 3000); same server serves API + frontend |
| **Database** | | Drizzle/SQLite; run migrations if schema changed; optional for paper-only |
| **Secrets** | | No hardcoded keys; use env for JWT, API keys, DB path |
| **Health** | | `GET /api/health` returns `{ ok: true }` |
| **TWS** | | Optional; set `TWS_HOST`, `TWS_PORT` or use Configure in UI |
| **CORS** | | Already set for dev; tighten `Access-Control-Allow-Origin` for prod |
| **Static** | | Production serves built client from Express (serveStatic) |

---

## 3. Troubleshooting flowchart (when things break)

```
Something broken?
    │
    ├─ App won't start
    │     → Port in use? Try different PORT
    │     → npm install; Node version
    │
    ├─ Trade Now does nothing / errors
    │     → Browser console + Network tab for /api/trpc (omega0.placeOrder)
    │     → Session cookie / log in again
    │
    ├─ $NaN or wrong P&L
    │     → Backend uses option premium (not underlying); safeNum/fmtMoney in place
    │     → System Health; check getAccountSummary / getOpenTrades
    │
    ├─ No opportunities on Market Opportunities
    │     → marketScanner.scan / getTopOpportunities; Yahoo/real-market-data
    │     → Scan on mount + "Scan Market" button
    │
    ├─ TWS won't connect
    │     → IB Gateway running at host:port? Use gear → Configure & Connect
    │     → Paper trading works without TWS
    │
    ├─ Execution page empty / "no trades"
    │     → Manual: place via Trade Now or Execution form
    │     → Engine: start engine on Auto Trading; positions show on Execution
    │
    └─ System Health errors
          → getDataCache: fixed (export getDataCache)
          → TWS/Gateway: expected "warning" if not connected
          → Other component: check server logs and ROUTERS_AND_ENDPOINTS.md §10–11
```

---

## 4. Feature inventory (what works / done / pending)

| Area | Status | Notes |
|------|--------|--------|
| **Auth** | Done | Demo login; session cookie |
| **Market scan** | Done | Yahoo; scan + getTopOpportunities |
| **Paper trading (Omega-0)** | Done | Place order, close position, open/closed trades, P&L, option price from chain or fallback |
| **Execution page** | Done | Manual + engine positions/trades; Close buttons |
| **Trade Now** | Done | Dialog with contracts; Place order |
| **Auto-trading engine** | Done | Start/stop, state, performance, positions, trades, unrealized/total P&L, close position |
| **System Health** | Done | All components; getDataCache fixed |
| **TWS connection** | Done | Configure host/port; Connect; works when IB Gateway running |
| **DB persist** | Done | Trades saved on place/close (omega0, engine); optional |
| **Regime / Signals / Structures / Risk / etc.** | Implemented | Routers exist; dashboards may show empty until DB or services populated |
| **Deploy** | Pending | Use deployment checklist above |
| **Live IB trading** | Pending | TWS + Gateway; then enable live mode in Gateway adapter |
| **Automated tests** | Partial | Some server tests; add E2E if needed |
| **User docs** | Partial | QUICKSTART, ROUTERS_AND_ENDPOINTS, DEVELOPER_QUESTIONS, this doc |

---

## 5. Who it's for / what format

| Audience | What to give them |
|----------|--------------------|
| **Developers** | ROUTERS_AND_ENDPOINTS.md (routers, endpoints, dependencies, troubleshooting), DEVELOPER_QUESTIONS.md (answers), this doc (quick start + deployment + flowchart + inventory). |
| **End users** | QUICKSTART.md (dashboard tour + trading rules); this doc §1 (quick start). |
| **Stakeholders** | DEVELOPER_QUESTIONS.md (answers table), this doc §4 (feature inventory) + §2 (deployment checklist). |

---

## 6. What should happen next (by goal)

| If your goal is… | Do this |
|------------------|--------|
| **Just run and paper trade** | Use §1 Quick start. Done. |
| **Populate dashboards (Regime, Signals, etc.)** | Seed DB or wire those pages to live services; see ROUTERS_AND_ENDPOINTS.md for which routers read from DB. |
| **Deploy** | Use §2 Deployment checklist; set PORT, env, run build + start. |
| **Connect TWS** | Run IB Gateway (or tunnel); Auto Trading → TWS card → Configure & Connect. |
| **User guides** | Give end users QUICKSTART + §1; give devs ROUTERS_AND_ENDPOINTS + DEVELOPER_QUESTIONS. |
| **Automated tests** | Add E2E for: login → Market Opportunities → Trade Now → Execution sees position. |
| **Status report** | Use DEVELOPER_QUESTIONS.md Answers + this doc §4 (feature inventory). |

---

**You have everything above.** Pick the section that matches what you need right now; if you tell me the exact goal (e.g. "deploy to X" or "seed DB for Regime"), I can turn that into a step-by-step plan.
