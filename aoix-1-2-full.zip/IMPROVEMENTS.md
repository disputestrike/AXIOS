# AOIX-1 Optimizations & Improvement Roadmap

Prioritized list of what we did and what to do next to improve performance, robustness, and UX.

---

## ✅ Done (recent)

| Area | Change | Impact |
|------|--------|--------|
| **Scanner speed** | Batch size 5→10, delay 400ms→250ms | ~40% faster full scan (fewer batches, shorter wait) |
| **Backtest selectivity** | Optional `onlyTradeRegimes` (e.g. `['bull_vol_compression','mean_reverting']`) | Fewer trades, potentially better Sharpe by skipping weak regimes |
| **Suggested quantity** | New `omega0.suggestQuantity` (position sizing + ADV cap) | UI can show recommended size before placing order |
| **Dollar P&L in backtest** | `cumulativeGrowth` / `totalReturnPercent` + script output | Clear “how much money” in backtest summary |

---

## High priority (do next)

1. **Regime filter in live scanner**  
   Use backtest regime win rates (or a config flag) to rank/filter opportunities by regime (e.g. prefer bull_vol_compression, mean_reverting). Already supported in historical backtest; wire same idea into scanner ranking or min-score by regime.

2. **Position sizing in placeOrder**  
   When placing from UI, optionally call `suggestQuantity` (or pass account + win prob) and use that quantity instead of user-entered only, still capped by `getMaxOrderSize`.

3. **Historical backtest with regime filter in script**  
   Run `pnpm backtest` with `onlyTradeRegimes: ['bull_vol_compression','mean_reverting']` and compare Sharpe/P&L to all-regime (already supported in API; add to `scripts/run-full-backtest.ts` as optional mode).

4. **Yahoo cache TTL**  
   `real-market-data` cache is 1 min. Consider 2–3 min for options data to reduce rate-limit risk during heavy scans (tune if you see 429s).

---

## Medium priority

5. **Options flow API**  
   Set `OPTIONS_FLOW_API_URL` (e.g. Unusual Whales, Cheddar) so scanner score uses real flow; currently uses proxy from put/call + IV when unset.

6. **TCA in UI**  
   Show `getTCASummary()` (slippage, implementation shortfall) on a dashboard or after trades so you can monitor execution quality.

7. **Stress test in UI**  
   Show `getPortfolioStress()` (SPY ±5%, VIX +50%) on the portfolio/risk view so users see scenario P&L.

8. **Limit orders**  
   Backtest and placeOrder use MKT; add LIMIT order type and optional limit price for better fill quality and TCA.

---

## Lower priority

9. **Multi-symbol historical backtest**  
   Run historical backtest on a list of symbols and aggregate equity curve / Sharpe (portfolio view).

10. **Walk-forward backtest**  
    Use `runWalkForward` with real historical windows (train on T-k..T, test on T..T+h) once multi-symbol series are available.

11. **Real Greeks for positions**  
    Replace estimated Greeks in portfolio risk with IB (or options chain) Greeks when available for more accurate VaR/stress.

12. **Strike/expiry in place flow**  
    When user clicks “Place” without picking strike/expiry, call `getBestStrikeExpiry` and prefill or suggest.

---

## Quick reference

- **Faster scan:** Already increased batch size and reduced delay; if Yahoo rate-limits, lower batch to 8 or raise delay to 300ms.
- **Better backtest:** Use `onlyTradeRegimes` in API or script to trade only in selected regimes.
- **Better size:** Use `omega0.suggestQuantity` before placing; optionally use that as default quantity in UI.
- **Capacity:** `getMaxOrderSize` already caps size vs ADV; pass `optionAdv` when you have it for tighter caps.
