import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function CrossAssetReflexivity() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Cross-Asset Reflexivity</h1>
        <p className="text-slate-400 mt-2">Real-time correlation tracking and break detection</p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Key Correlations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <p><strong>SPX / TLT:</strong> -0.42</p>
            <p><strong>VIX / Gold:</strong> +0.68</p>
            <p><strong>HY Spreads / VIX:</strong> +0.85</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
