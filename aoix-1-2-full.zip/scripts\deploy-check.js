#!/usr/bin/env node
/**
 * Deploy checklist: print production readiness items. Run build separately: pnpm build
 * Run: node scripts/deploy-check.js
 */
console.log('AOIX-1 Deploy checklist\n');
console.log('1. Build:  pnpm build');
console.log('2. Start:  PORT=3000 pnpm start  (or NODE_ENV=production node dist/index.js)\n');
console.log('Production readiness:');
console.log('   [ ] PORT — set env (default 3000)');
console.log('   [ ] Database — Drizzle/SQLite; run pnpm db:migrate if schema changed');
console.log('   [ ] Secrets — JWT, API keys via env (no hardcoded keys)');
console.log('   [ ] Health — GET /api/health returns { ok: true }');
console.log('   [ ] TWS — optional; TWS_HOST, TWS_PORT or Configure in UI');
console.log('   [ ] CORS — tighten Access-Control-Allow-Origin for prod');
console.log('   [ ] Static — production serves built client (serveStatic)\n');
