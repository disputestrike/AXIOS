-- Trade History Table for Persistence
CREATE TABLE IF NOT EXISTS trade_history (
  id VARCHAR(36) PRIMARY KEY,
  symbol VARCHAR(20) NOT NULL,
  asset_type VARCHAR(20) NOT NULL,
  entry_price DECIMAL(12, 4) NOT NULL,
  entry_time BIGINT NOT NULL,
  exit_price DECIMAL(12, 4),
  exit_time BIGINT,
  quantity INT NOT NULL,
  direction VARCHAR(10) NOT NULL,
  structure_type VARCHAR(50) NOT NULL,
  entry_signal_class VARCHAR(1),
  entry_signal_confidence DECIMAL(3, 2),
  entry_regime VARCHAR(20),
  exit_reason VARCHAR(50),
  pnl DECIMAL(12, 4),
  pnl_percent DECIMAL(6, 2),
  max_profit DECIMAL(12, 4),
  max_loss DECIMAL(12, 4),
  duration_seconds INT,
  status VARCHAR(20) NOT NULL DEFAULT 'open',
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  INDEX idx_symbol (symbol),
  INDEX idx_status (status),
  INDEX idx_entry_time (entry_time),
  INDEX idx_created_at (created_at)
);

-- Trade Performance Metrics Table
CREATE TABLE IF NOT EXISTS trade_performance (
  id VARCHAR(36) PRIMARY KEY,
  total_trades INT DEFAULT 0,
  winning_trades INT DEFAULT 0,
  losing_trades INT DEFAULT 0,
  win_rate DECIMAL(5, 2) DEFAULT 0,
  profit_factor DECIMAL(6, 2) DEFAULT 0,
  sharpe_ratio DECIMAL(6, 2) DEFAULT 0,
  max_drawdown DECIMAL(6, 2) DEFAULT 0,
  avg_win DECIMAL(12, 4) DEFAULT 0,
  avg_loss DECIMAL(12, 4) DEFAULT 0,
  largest_win DECIMAL(12, 4) DEFAULT 0,
  largest_loss DECIMAL(12, 4) DEFAULT 0,
  total_pnl DECIMAL(12, 4) DEFAULT 0,
  daily_pnl DECIMAL(12, 4) DEFAULT 0,
  consecutive_wins INT DEFAULT 0,
  consecutive_losses INT DEFAULT 0,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  PRIMARY KEY (id)
);

-- System Health Status Table
CREATE TABLE IF NOT EXISTS system_health (
  id VARCHAR(36) PRIMARY KEY,
  component VARCHAR(50) NOT NULL,
  status VARCHAR(20) NOT NULL,
  last_check BIGINT NOT NULL,
  error_message TEXT,
  response_time_ms INT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  UNIQUE KEY unique_component (component),
  INDEX idx_status (status),
  INDEX idx_last_check (last_check)
);

-- API Rate Limit Table
CREATE TABLE IF NOT EXISTS api_rate_limits (
  id VARCHAR(36) PRIMARY KEY,
  user_id VARCHAR(36) NOT NULL,
  endpoint VARCHAR(255) NOT NULL,
  request_count INT DEFAULT 1,
  window_start BIGINT NOT NULL,
  window_end BIGINT NOT NULL,
  created_at BIGINT NOT NULL,
  UNIQUE KEY unique_limit (user_id, endpoint, window_start),
  INDEX idx_user_id (user_id),
  INDEX idx_window_end (window_end)
);
