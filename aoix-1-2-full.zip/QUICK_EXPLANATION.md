# AOIX-1: Quick Explanation

## 🎯 What Is It?

**AOIX-1 = Self-Driving Car for Options Trading**

A computer program that:
- ✅ Scans 100+ stocks automatically
- ✅ Finds profitable trading opportunities
- ✅ Executes trades automatically
- ✅ Manages your risk
- ✅ Works 24/7 without you watching

---

## 👤 Who Is It For?

### ✅ Perfect For:
- Options traders who want automation
- People who want to trade while sleeping
- Traders who want strict risk management
- Tech-savvy people comfortable with software

### ❌ NOT For:
- Complete beginners (need options knowledge)
- People who want full manual control
- Those uncomfortable with automated trading

---

## 🔧 How It Works (Simple)

```
1. Scans Markets
   ↓
2. Finds Opportunities
   ↓
3. Checks Risk Limits
   ↓
4. Executes Trades
   ↓
5. Monitors Positions
   ↓
6. Exits Automatically
```

**That's it!** It does this automatically, over and over.

---

## 💰 What You Need

1. **Interactive Brokers Account**
   - Free paper trading account (for testing)
   - Live account (for real trading)

2. **IB Gateway Software**
   - Free download from Interactive Brokers
   - Connects AOIX-1 to your account

3. **Computer**
   - Windows, Mac, or Linux
   - Node.js installed

---

## 🚀 How to Start

### Step 1: Install
```bash
pnpm install
```

### Step 2: Configure
```bash
cp .env.local.example .env.local
# Edit .env.local with your info
```

### Step 3: Start
```bash
pnpm dev
```

### Step 4: Open Browser
- Go to http://localhost:5173
- Click "Start Engine"
- Watch it trade!

---

## 🛡️ Safety Features

**Built-in Protection:**
- ✅ Max 1% risk per trade
- ✅ Max 3 positions at once
- ✅ Automatic stop-loss (-20%)
- ✅ Automatic take-profit (+30%)
- ✅ Kill switch (stops at -5% daily loss)

**You can't lose more than you set!**

---

## 📊 What You See

**Dashboards Show:**
- Current positions
- Real-time profit/loss
- Trading opportunities
- System health
- Trade history

**Everything in real-time!**

---

## 🎓 Two Modes

### 1. Paper Trading (Testing)
- ✅ Real market data
- ✅ Simulated trades
- ✅ No real money
- ✅ Perfect for learning

### 2. Live Trading (Real)
- ✅ Real market data
- ✅ Real trades
- ✅ Real money
- ✅ Use after testing!

---

## ⚡ Quick Start Checklist

- [ ] Install Node.js
- [ ] Get IB account
- [ ] Install IB Gateway
- [ ] Run `pnpm install`
- [ ] Configure `.env.local`
- [ ] Start IB Gateway
- [ ] Run `pnpm dev`
- [ ] Open browser
- [ ] Start trading!

---

## 💡 Key Points

1. **It's Automated** - Runs without you
2. **It's Safe** - Built-in risk limits
3. **It's Real** - Uses real market data
4. **It's Testable** - Paper trading mode first
5. **It's Monitored** - Dashboards show everything

---

## 📖 Want More Details?

Read `WHAT_IS_AOIX1.md` for the complete guide!

---

## 🎯 Bottom Line

**AOIX-1 = Automated Options Trading System**

- Scans markets automatically
- Finds opportunities automatically  
- Executes trades automatically
- Manages risk automatically

**You just:**
1. Set it up
2. Start it
3. Monitor it
4. Profit! (hopefully)

---

**Questions?** Check the documentation or review the code!
