# 🚀 Quick Start - Get Running NOW

## Step-by-Step Setup

### ✅ Step 1: Prerequisites (DONE!)
- ✅ Node.js v24.5.0 (required: 22+)
- ✅ pnpm 10.4.1 (installed)

### ⚠️ Step 2: Install Dependencies

```bash
pnpm install
```

### ⚠️ Step 3: Create .env.local

Copy `.env.local.example` to `.env.local` and fill in:

**Minimum Required:**
- `DATABASE_URL` - Your MySQL connection
- `JWT_SECRET` - Random secret (I'll generate this)
- OAuth/Forge API keys (from Manus, or use placeholders for testing)

### ⚠️ Step 4: Setup Database

```bash
# Create database (if local MySQL)
# Then run migrations
pnpm db:push
```

### ⚠️ Step 5: Verify Setup

```bash
pnpm verify
```

### ⚠️ Step 6: Start System

```bash
pnpm dev
```

Then open: http://localhost:5173

---

## Quick Commands

```bash
# 1. Install
pnpm install

# 2. Setup database
pnpm db:push

# 3. Verify
pnpm verify

# 4. Start
pnpm dev
```
