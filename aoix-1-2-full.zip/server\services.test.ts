import { describe, it, expect } from "vitest";
import * as services from "./services";

describe("Regime Classification Engine", () => {
  it("should classify bull vol compression regime correctly", () => {
    const result = services.analyzeRegime(
      4550, // spotPrice
      4520, // priceMA20 (bullish: spot > MA20)
      20.0, // impliedVol
      18.0, // historicalVol (IV > RV, but ratio < 1.1, so compression)
      0.01, // sofr (very low)
      2.0, // moveIndex (very low)
      1.0, // fxVol (very low)
      5000000 // orderBookDepth (very high)
    );

    expect(result.regime).toMatch(/bull|mean_reverting/);
    expect(result.confidenceScore).toBeGreaterThanOrEqual(0.7);
    expect(result.liquidityStressIndex).toBeLessThan(0.5);
  });

  it("should detect chaotic regime when LSI in (0.7, 0.85] and depth >= 50", () => {
    const result = services.analyzeRegime(
      4500,
      4500,
      35.0,
      20.0,
      10.0, // SOFR
      3.0,  // MOVE
      3.0,  // FX vol
      50    // orderBookDepth >= 50 so not liquidity_drought; LSI ~0.78 → chaotic
    );

    expect(result.regime).toBe("chaotic");
    expect(result.liquidityStressIndex).toBeGreaterThan(0.7);
    expect(result.liquidityStressIndex).toBeLessThanOrEqual(0.85);
    expect(result.confidenceScore).toBeLessThan(0.5);
  });

  it("should detect crisis regime when LSI > 0.85", () => {
    const result = services.analyzeRegime(
      4500,
      4500,
      40.0,
      20.0,
      50.0, // Very high SOFR
      50.0, // Very high MOVE
      25.0, // Very high FX vol
      100000 // depth; LSI will be > 0.85 → crisis
    );

    expect(result.regime).toBe("crisis");
    expect(result.liquidityStressIndex).toBeGreaterThan(0.85);
    expect(result.confidenceScore).toBeLessThan(0.5);
  });

  it("should calculate transition probability based on LSI", () => {
    const result = services.analyzeRegime(
      4550,
      4520,
      20.0,
      18.0,
      20.0,
      30.0,
      15.0,
      500000
    );

    expect(result.transitionProbability).toBeGreaterThan(0);
    expect(result.transitionProbability).toBeLessThanOrEqual(1);
  });
});

describe("Signal Engine", () => {
  it("should generate Class A dealer gamma signal", () => {
    const signal = services.generateDealerGammaSignal(
      500000, // gex
      250000, // vegaExposure
      4550, // spotPrice
      20.0 // iv
    );

    expect(signal.signalClass).toBe("A");
    expect(signal.signalType).toBe("dealer_gamma");
    expect(signal.confidenceScore).toBeGreaterThan(0.6);
    expect(signal.confidenceDecayRate).toBeLessThan(0.1); // Slow decay
  });

  it("should generate Class B flow signal with high confidence on strong volume", () => {
    const signal = services.generateFlowSignal(
      5000000, // sweepVolume
      1000000, // avgVolume (5x ratio)
      10, // blockTradeCount
      0.05 // bidAskSpread
    );

    expect(signal.signalClass).toBe("B");
    expect(signal.signalType).toBe("unusual_flow");
    expect(signal.confidenceScore).toBeGreaterThanOrEqual(0.7);
    expect(signal.confidenceDecayRate).toBeGreaterThan(0.1); // Faster decay than Class A
  });

  it("should generate Class C momentum signal with low confidence", () => {
    const signal = services.generateMomentumSignal(
      0.5, // roc
      65, // rsi (not extreme)
      0.5, // bbPosition
      18.0 // volatility
    );

    expect(signal.signalClass).toBe("C");
    expect(signal.confidenceScore).toBeLessThan(0.6);
    expect(signal.confidenceDecayRate).toBeGreaterThan(0.2); // Very fast decay
  });

  it("should generate Class D catalyst signal with high vol expansion probability", () => {
    const signal = services.generateCatalystSignal(
      2, // daysToEvent
      3.5, // expectedMove
      2.0 // historicalMove
    );

    expect(signal.signalClass).toBe("D");
    expect(signal.volatilityExpansionProbability).toBe(0.8);
    expect(signal.confidenceScore).toBeGreaterThan(0.6);
  });
});

describe("Options Structure Selector", () => {
  it("should recommend vertical call spread for bull vol compression", () => {
    const structure = services.selectOptimalStructure(
      "bull_vol_compression",
      0.75,
      2.5,
      20.0,
      65
    );

    // Selector picks one of several valid choices for bull_vol_compression (hash-based; includes iron_condor, calendar for variety)
    const validStructures = ["vertical_call_spread", "covered_call", "cash_secured_put", "iron_condor", "calendar_spread"];
    expect(validStructures).toContain(structure.structureType);
    expect(structure.direction).toBe("bullish");
    expect(structure.deltaExposure).toBeGreaterThan(0);
    expect(structure.maxLoss).toBeLessThan(structure.maxProfit);
  });

  it("should recommend bear structure for bear vol expansion (iron condor, put spread, or iron butterfly)", () => {
    const structure = services.selectOptimalStructure(
      "bear_vol_expansion",
      0.65,
      3.0,
      25.0,
      75
    );

    expect(["iron_condor", "vertical_put_spread", "iron_butterfly"]).toContain(structure.structureType);
    expect(structure.direction).toBe("bearish");
    expect(structure.thetaExposure).toBeGreaterThan(0);
  });

  it("should recommend range/theta structure for mean reverting (iron condor, iron butterfly, or calendar)", () => {
    const structure = services.selectOptimalStructure(
      "mean_reverting",
      0.5,
      2.0,
      18.0,
      50
    );

    expect(["iron_condor", "iron_butterfly", "calendar_spread"]).toContain(structure.structureType);
    expect(structure.direction).toBe("neutral");
    expect(structure.deltaExposure).toBeLessThanOrEqual(0.1);
    expect(structure.thetaExposure).toBeGreaterThan(0);
  });

  it("should recommend defined-risk structure for chaotic (calendar, iron condor, or strangle)", () => {
    const structure = services.selectOptimalStructure(
      "chaotic",
      0.3,
      1.5,
      22.0,
      40
    );

    expect(["calendar_spread", "iron_condor", "strangle"]).toContain(structure.structureType);
    expect(structure.direction).toBe("neutral");
  });
});

describe("Dynamic Risk Engine", () => {
  it("should scale position size inversely with VIX", () => {
    const riskLow = services.calculateDynamicRisk(
      1000000,
      15, // currentVix
      20, // historicalVixAvg
      0.3,
      0.05,
      0.5,
      5000,
      15000
    );

    const riskHigh = services.calculateDynamicRisk(
      1000000,
      40, // currentVix (higher)
      20,
      0.3,
      0.05,
      0.5,
      5000,
      15000
    );

    expect(riskLow.volatilityScaledSize).toBeGreaterThan(riskHigh.volatilityScaledSize);
  });

  it("should activate capital preservation when VIX > 35", () => {
    const result = services.calculateDynamicRisk(
      1000000,
      40,
      20,
      0.3,
      0.05,
      0.5,
      5000,
      15000
    );

    expect(result.capitalPreservationActive).toBe(true);
  });

  it("should reduce exposure when correlation > 0.7", () => {
    const lowCorr = services.calculateDynamicRisk(
      1000000,
      20,
      20,
      0.3,
      0.05,
      0.6,
      5000,
      15000
    );

    const highCorr = services.calculateDynamicRisk(
      1000000,
      20,
      20,
      0.3,
      0.05,
      0.8,
      5000,
      15000
    );

    expect(lowCorr.correlationAdjustment).toBe(1.0);
    expect(highCorr.correlationAdjustment).toBe(0.5);
  });
});

describe("Execution Gates", () => {
  it("should pass all gates when conditions align", () => {
    const gates = services.validateExecutionGates(
      25, // ivRank (low, < 30)
      2.5, // rvTrend (positive)
      2000000, // sweepVolume
      1000000, // avgVolume (2x ratio)
      4, // daysToOpex (2-7 range)
      5 // daysToEarnings (3-10 range)
    );

    expect(gates.volatilityInflection).toBe(true);
    expect(gates.flowConfirmation).toBe(true);
    expect(gates.structuralTiming).toBe(true);
    expect(gates.allGatesPassed).toBe(true);
    expect(gates.reasonsForRejection).toHaveLength(0);
  });

  it("should reject when no volatility inflection", () => {
    const gates = services.validateExecutionGates(
      50, // ivRank (neutral)
      0.5, // rvTrend (weak)
      2000000,
      1000000,
      4,
      5
    );

    expect(gates.volatilityInflection).toBe(false);
    expect(gates.allGatesPassed).toBe(false);
    expect(gates.reasonsForRejection.length).toBeGreaterThan(0);
  });

  it("should calculate slippage correctly", () => {
    const slippage = services.calculateSlippageModel(
      0.10, // bidAskSpread
      50000, // orderSize
      5000000, // avgDailyVolume
      0.1 // marketImpactFactor
    );

    expect(slippage).toBeGreaterThan(0.05); // At least half the spread
    expect(slippage).toBeLessThan(0.15); // But not excessive
  });
});

describe("Meta-Intelligence Layer", () => {
  it("should calculate edge half-life based on signal accuracy", () => {
    const metrics = services.calculateMetaIntelligence(
      0.55, // recentWinRate
      1.2, // recentSharpeRatio
      1, // recentLossCount
      0.65, // signalAccuracy
      { bull: 1.5, bear: 0.8 }
    );

    expect(metrics.edgeHalfLife).toBeGreaterThan(5);
    expect(metrics.edgeHalfLife).toBeLessThan(30);
  });

  it("should trigger overconfidence kill switch at > 70% win rate", () => {
    const metrics = services.calculateMetaIntelligence(
      0.75, // recentWinRate > 70%
      1.8,
      0,
      0.8,
      { bull: 2.0 }
    );

    expect(metrics.overconfidenceKillSwitch).toBe(true);
  });

  it("should set system blind flag when 3+ recent losses", () => {
    const metrics = services.calculateMetaIntelligence(
      0.4,
      0.8,
      3, // recentLossCount >= 3
      0.5,
      { bull: 0.5 }
    );

    expect(metrics.isSystemBlind).toBe(true);
  });
});

describe("Failure Taxonomy", () => {
  it("should classify thesis wrong failure", () => {
    const failure = services.classifyFailure(
      -500, // pnl
      2.0, // expectedMove
      -3.5, // actualMove (significantly different)
      "bull_vol_compression",
      "bull_vol_compression", // No regime shift
      0.01, // Low slippage
      1, // Normal position size
      false // No correlation break
    );

    expect(failure.primaryCause).toBe("thesis_wrong");
    expect(failure.signalWeightAdjustment).toBeLessThan(0);
  });

  it("should classify regime mismatch failure", () => {
    const failure = services.classifyFailure(
      -1000,
      2.0,
      -2.5,
      "bull_vol_compression",
      "bear_vol_expansion", // Regime changed
      0.01,
      1,
      false
    );

    expect(failure.primaryCause).toBe("regime_mismatch");
    expect(failure.signalWeightAdjustment).toBeLessThan(-0.08);
  });

  it("should classify systemic failure on correlation break", () => {
    const failure = services.classifyFailure(
      -2000,
      2.0,
      -2.0,
      "bull_vol_compression",
      "bull_vol_compression",
      0.01,
      1,
      true // Correlation break detected
    );

    expect(failure.primaryCause).toMatch(/systemic_failure|thesis_wrong/);
    expect(failure.signalWeightAdjustment).toBeLessThan(0);
  });
});

describe("Shadow System", () => {
  it("should simulate ruin scenario and calculate probability", () => {
    const report = services.runShadowSystemSimulation(
      0.5, // portfolioDelta
      0.1, // portfolioGamma
      500, // portfolioVega
      100, // portfolioTheta
      1000000, // grossNotional
      1000000, // capital
      100 // iterations
    );

    expect(report.maxPortfolioDrawdown).toBeGreaterThan(0);
    expect(report.probabilityOfRuin).toBeGreaterThanOrEqual(0);
    expect(report.probabilityOfRuin).toBeLessThanOrEqual(1);
    expect(report.threatLevel).toMatch(/low|medium|high|critical/);
  });

  it("should identify high gamma exposure as weakness", () => {
    const report = services.runShadowSystemSimulation(
      0.2,
      0.5, // High gamma
      200,
      50,
      1000000,
      1000000,
      100
    );

    expect(report.weakestPoint).toContain("Gamma");
    expect(report.mitigationActions.length).toBeGreaterThan(0);
  });

  it("should report critical threat for high ruin probability", () => {
    const report = services.runShadowSystemSimulation(
      1.0, // Very high delta
      0.8, // Very high gamma
      1000, // Very high vega
      -200, // Negative theta
      2000000,
      500000, // Small capital relative to notional
      100
    );

    expect(report.threatLevel).toBe("critical");
  });
});
