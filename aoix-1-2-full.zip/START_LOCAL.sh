#!/bin/bash

# AOIX-1 Local Startup Script
# This script starts AOIX-1 locally with proper configuration

set -e

echo "================================"
echo "AOIX-1 Local Startup"
echo "================================"
echo ""

# Check prerequisites
echo "Checking prerequisites..."

if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js 22+ from https://nodejs.org/"
    exit 1
fi

if ! command -v pnpm &> /dev/null; then
    echo "❌ pnpm not found. Install with: npm install -g pnpm"
    exit 1
fi

echo "✅ Node.js $(node --version)"
echo "✅ pnpm $(pnpm --version)"
echo ""

# Check .env.local exists
if [ ! -f ".env.local" ]; then
    echo "❌ .env.local not found!"
    echo ""
    echo "Please create .env.local with your configuration:"
    echo ""
    echo "DATABASE_URL=your_database_connection_string"
    echo "JWT_SECRET=your_jwt_secret"
    echo "VITE_APP_ID=your_app_id"
    echo "OAUTH_SERVER_URL=https://api.manus.im"
    echo "VITE_OAUTH_PORTAL_URL=https://oauth.manus.im"
    echo "OWNER_NAME=Your Name"
    echo "OWNER_OPEN_ID=your_open_id"
    echo "BUILT_IN_FORGE_API_URL=https://api.manus.im"
    echo "BUILT_IN_FORGE_API_KEY=your_api_key"
    echo "VITE_FRONTEND_FORGE_API_URL=https://api.manus.im"
    echo "VITE_FRONTEND_FORGE_API_KEY=your_frontend_key"
    echo "TWS_HOST=localhost"
    echo "TWS_PORT=4001"
    echo "VITE_APP_TITLE=AOIX-1"
    echo ""
    exit 1
fi

echo "✅ .env.local found"
echo ""

# Check IB Gateway
echo "Checking IB Gateway connection..."
if nc -z localhost 4001 2>/dev/null; then
    echo "✅ IB Gateway is running on localhost:4001"
else
    echo "⚠️  IB Gateway not responding on localhost:4001"
    echo "   Make sure IB Gateway is running and API is enabled"
    echo "   (Configuration → API → Settings → Enable ActiveX and Socket Clients)"
    echo ""
fi

echo ""
echo "Installing dependencies..."
pnpm install --frozen-lockfile

echo ""
echo "================================"
echo "Starting AOIX-1 Development Server"
echo "================================"
echo ""
echo "Frontend: http://localhost:5173"
echo "API: http://localhost:3000"
echo ""
echo "Press Ctrl+C to stop"
echo ""

# Start development server
pnpm dev
