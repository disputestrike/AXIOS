/**
 * Live Regime Heatmap — top opportunities by regime (color, recommendation, score).
 * Uses regime.getRegimeHeatmap (scanner top 200 → regime per symbol).
 */

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { BarChart3, RefreshCw } from "lucide-react";

interface RegimeCell {
  symbol: string;
  currentRegime: string;
  probability: number;
  color: string;
  recommendation: string;
  score: number;
}

export function RegimeHeatmap() {
  const { data, isLoading, refetch, isRefetching } = trpc.regime.getRegimeHeatmap.useQuery(undefined, {
    refetchInterval: 30_000,
  });

  if (isLoading) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="pt-6 flex items-center justify-center py-12 text-slate-400">
          <RefreshCw className="h-6 w-6 animate-spin mr-2" />
          Loading regime heatmap…
        </CardContent>
      </Card>
    );
  }

  const heatmap = (data ?? []) as RegimeCell[];
  if (heatmap.length === 0) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <BarChart3 className="h-5 w-5" />
            Market Regime Heatmap
          </CardTitle>
          <CardDescription>Run a market scan to populate regime data.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-slate-400 text-sm">No opportunities yet. Go to Market Opportunities and click &quot;Scan Market&quot;.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-800/50 border-slate-700">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-lg">
              <BarChart3 className="h-5 w-5" />
              Market Regime Heatmap
            </CardTitle>
            <CardDescription>Top symbols by regime — green = bullish, red = bearish. Suggested structure per symbol.</CardDescription>
          </div>
          <button
            type="button"
            onClick={() => refetch()}
            disabled={isRefetching}
            className="text-slate-400 hover:text-white transition-colors p-1 rounded"
            aria-label="Refresh heatmap"
          >
            <RefreshCw className={`h-4 w-4 ${isRefetching ? "animate-spin" : ""}`} />
          </button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
          {heatmap.slice(0, 24).map((cell) => (
            <div
              key={cell.symbol}
              className="p-3 rounded-lg border-2 transition-all hover:shadow-lg"
              style={{
                borderColor: cell.color === "green" ? "rgb(34 197 94 / 0.6)" : cell.color === "red" ? "rgb(239 68 68 / 0.6)" : "rgb(100 116 139 / 0.6)",
                backgroundColor: cell.color === "green" ? "rgb(34 197 94 / 0.1)" : cell.color === "red" ? "rgb(239 68 68 / 0.1)" : "rgb(100 116 139 / 0.1)",
              }}
            >
              <div className="text-lg font-bold">{cell.symbol}</div>
              <div className="text-xs text-slate-300 mt-1 truncate" title={cell.currentRegime}>
                {cell.currentRegime.replace(/_/g, " ")}
              </div>
              <div className="text-xs text-slate-400 mt-0.5">
                Prob: {((cell.probability ?? 0) * 100).toFixed(0)}% · Score: {cell.score?.toFixed(0) ?? "—"}
              </div>
              <div className="mt-2 pt-2 border-t border-slate-600">
                <div className="text-xs font-semibold text-amber-400/90">Suggested</div>
                <div className="text-xs text-slate-300 truncate" title={cell.recommendation}>
                  {cell.recommendation?.replace(/_/g, " ") ?? "—"}
                </div>
              </div>
            </div>
          ))}
        </div>
        <p className="text-xs text-slate-500 mt-3">Showing up to 24 symbols. Refreshes every 30s.</p>
      </CardContent>
    </Card>
  );
}
