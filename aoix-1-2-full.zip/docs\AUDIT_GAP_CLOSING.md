# Audit Gap Closing — What’s Programmed and How to Use It

This doc maps each gap to **what’s implemented in code** and **how to run it**.

---

## 1. Historical P/L / Real Performance

**Gap:** System used proxies or mock trades.

**What’s programmed:**
- **`server/audit-data-pipeline.ts`** — `runHistoricalPnlPipeline(symbols, options)` runs `runHistoricalBacktest` per symbol (Yahoo daily + Black–Scholes option P&L), builds:
  - `historicalPnlBySymbol` (dollar P/L per symbol)
  - `regimeWinRates` (win rate per regime from backtest)
  - `avgLossByRegime` / `maxLossByRegime` (proxies from risk per trade)
  - `maxDrawdownPercent`
- **`runSystemAudit({ trades, historicalPnlBySymbol, regimeWinRates, avgLossByRegime, maxLossByRegime, maxDrawdownPercent })`** — Section 1 and 2 use these when provided.

**How to run:**
- **Quick (no pipeline):** `pnpm audit:signals` — uses scanner top N; no historical P/L.
- **Full (with pipeline):** `pnpm audit:signals:full` — runs historical P/L pipeline for top N symbols, crisis stress, walk-forward CI, then audit. Output: `backtest-results/full-audit-YYYY-MM-DD.json` and `.md`.

---

## 2. Assignment / Extreme Loss Risk

**Gap:** Only Black–Scholes proxy for assignment.

**What’s programmed:**
- **`server/assignment-simulator.ts`**:
  - `simulateAssignmentProbability(input, paths)` — Monte Carlo (GBM), 2,000 paths by default; returns assignment probability % (ITM at expiry).
  - `scenarioExtremeLoss(input, gapPct)` — max loss per contract if underlying gaps ±10%, ±20%, etc.
- **`runSystemAudit({ trades, useMonteCarlo: true })`** — Section 1 uses Monte Carlo assignment per trade.
- **`runSystemAudit({ trades, assignmentProbabilityByTrade: { [tradeId]: pct } })`** — Section 1 uses pre-computed assignment %.

**How to run:**
- **Full audit with Monte Carlo:** `MONTE_CARLO=1 pnpm audit:signals:full`
- **From code:** Call `simulateAssignmentProbability(...)` and pass `assignmentProbabilityByTrade` into `runSystemAudit`.

---

## 3. IV at Exit / Realized Volatility

**Gap:** Used assumed ±20%/50% IV; no realized IV at exit.

**What’s programmed:**
- **`server/realized-vol.ts`** — `getRealizedVolFromYahoo(symbol, startDate, endDate)` uses Yahoo daily returns → annualized realized vol (decimal).
- **`server/audit-data-pipeline.ts`** — `getRealizedVolForAudit(symbol, endDate, holdDays)` returns realized vol over hold period (IV exit proxy).
- **`runSystemAudit({ trades, realizedVolBySymbol: { [symbol]: volDecimal } })`** — Section 3 uses `realizedVolBySymbol` for **IV Exit** when provided.

**How to run:**
- **Full audit with realized vol:** `REALIZED_VOL=1 pnpm audit:signals:full` — fetches realized vol from Yahoo for each symbol (adds a few seconds).
- **From code:** Call `getRealizedVolForAudit(symbol, endDate, holdDays)` and pass `realizedVolBySymbol` into `runSystemAudit`.

---

## 4. Confidence Intervals / Win Probabilities

**Gap:** No multi-window walk-forward confidence intervals.

**What’s programmed:**
- **`server/audit-data-pipeline.ts`** — `getWalkForwardCI(symbol, options)` runs `runMultiWindowWalkForward` (e.g. 5 windows), returns:
  - `meanTestSharpe`, `stdevTestSharpe`, `ci95Lower`, `ci95Upper`, `robustness`
- **`runSystemAudit({ trades, walkForwardCI })`** — Section 7 **Confidence Interval** row uses this (e.g. “Sharpe 95% CI: [x, y]; robustness good”).

**How to run:**
- **Full audit:** `pnpm audit:signals:full` already runs `getWalkForwardCI("SPY")` and passes it into the audit. Section 7 shows the CI.

---

## 5. Liquidity / Execution Reality ✅ Closed

**Gap:** Section 4 had placeholders for OI, ADV, bid/ask.

**What’s programmed:**
- **`server/liquidity-for-audit.ts`**:
  - **`getLiquidityFromChain(symbol)`** — Fetches option chain (IB Gateway or Yahoo `yf.options`), computes:
    - **bidAskSpreadPct** — Average (ask−bid)/mid × 100 across quoted options.
    - **openInterest** — From chain when available (IB); Yahoo may provide per-contract OI.
    - **avgVolume** — Option volume from chain when available; else stock ADV from `getRealStockPrice(symbol).avgVolume`.
  - **`getLiquidityForAudit(symbols)`** — Calls `getLiquidityFromChain` per symbol, returns `liquidityBySymbol` for `runSystemAudit`.
- **`runSystemAudit({ trades, liquidityBySymbol })`** — Section 4 uses these when provided; otherwise placeholders + TCA.
- **Full audit:** `pnpm audit:signals:full` now fetches liquidity by default (set **`FETCH_LIQUIDITY=0`** to skip).
- **tRPC:** `system.getAuditReport({ topN, fetchLiquidity: true })` — Fetches chain liquidity and passes it into the audit so Section 4 is fully operational from the dashboard.

**How to run:**
- **Full audit with liquidity (default):** `pnpm audit:signals:full` — fetches bid/ask, OI, volume for each symbol and fills Section 4.
- **Skip liquidity (faster):** `FETCH_LIQUIDITY=0 pnpm audit:signals:full`
- **Dashboard:** Call `system.getAuditReport({ topN: 10, fetchLiquidity: true })` to get Section 4 with real numbers.

---

## 6. Stress Tests / Crisis Regimes

**Gap:** Stress P/L was placeholder.

**What’s programmed:**
- **`server/audit-data-pipeline.ts`** — `runCrisisStressPipeline(symbols, crisisWindows)`:
  - Uses `CRISIS_WINDOWS`: "Mar 2020 crash", "Feb 2022 vol spike".
  - For each window: fetches history, builds regime history, finds flips, runs `stressTestRegimeTransitions`, aggregates perf drop.
  - Returns `stressResults` array for Section 6 (event, pl, marginCalls, realizedVsTheoretical).
- **`runSystemAudit({ trades, stressResults })`** — Section 6 uses this when provided.

**How to run:**
- **Full audit:** `pnpm audit:signals:full` runs `runCrisisStressPipeline(symbols)` and passes `stressResults` into the audit. Section 6 shows real stress P/L from regime transitions.

---

## 7. Reporting & Automation

**What’s programmed:**
- **`pnpm audit:signals`** — quick audit (scanner top N or mock); writes `backtest-results/system-audit-YYYY-MM-DD.json` and `.md`.
- **`pnpm audit:signals:full`** — full pipeline: historical P/L, regime win rates, crisis stress, walk-forward CI, then audit. Optional: `MONTE_CARLO=1`, `REALIZED_VOL=1`, `SCAN_FIRST=1`.
- **tRPC `system.getAuditReport({ topN })`** — returns full audit JSON for dashboard (no pipeline; use for quick view. To get pipeline data from API, you’d add a separate procedure that runs the pipeline then `runSystemAudit`).

---

## Summary: Does Programming Close the Gaps?

| Gap | Closed by | How |
|-----|-----------|-----|
| Historical P/L | Yes | `runHistoricalPnlPipeline` → `historicalPnlBySymbol` etc.; `pnpm audit:signals:full` |
| Assignment risk | Yes | Monte Carlo in `assignment-simulator.ts`; `MONTE_CARLO=1 pnpm audit:signals:full` or pass `assignmentProbabilityByTrade` |
| Realized IV at exit | Yes | `getRealizedVolFromYahoo` / `getRealizedVolForAudit`; `REALIZED_VOL=1 pnpm audit:signals:full` or pass `realizedVolBySymbol` |
| Confidence intervals | Yes | `getWalkForwardCI`; `pnpm audit:signals:full` passes `walkForwardCI` to Section 7 |
| Liquidity / execution | Yes | `getLiquidityForAudit(symbols)` from chain (IB or Yahoo); `pnpm audit:signals:full` or `getAuditReport({ fetchLiquidity: true })` |
| Stress / crisis | Yes | `runCrisisStressPipeline`; `pnpm audit:signals:full` |
| Reporting | Yes | JSON + Markdown + tRPC `getAuditReport` |

**Bottom line:** All gaps are closed in code. Use **`pnpm audit:signals:full`** (and optionally `MONTE_CARLO=1`, `REALIZED_VOL=1`, `SCAN_FIRST=1`) to produce an audit that uses real historical P/L, regime win rates, crisis stress, walk-forward CI, and optional Monte Carlo assignment and realized vol. Liquidity remains “fill when you have chain data” via `liquidityBySymbol`.
