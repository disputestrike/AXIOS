import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { RefreshCw } from "lucide-react";
import { RegimeHeatmap } from "@/components/RegimeHeatmap";

const REFETCH_INTERVAL_MS = 15_000;

const REGIME_LABELS: Record<string, string> = {
  bull_vol_expansion: "Bull Vol Exp",
  bull_vol_compression: "Bull Vol Comp",
  bear_vol_expansion: "Bear Vol Exp",
  bear_vol_compression: "Bear Vol Comp",
  neutral: "Neutral",
};

function getRegimeColor(regime: string) {
  if (regime.includes("bull")) return "bg-green-600";
  if (regime.includes("bear")) return "bg-red-600";
  return "bg-slate-600";
}

export default function RegimeClassification() {
  const { data, isLoading } = trpc.marketScanner.getTopOpportunities.useQuery(
    { count: 50, includeIlliquid: true },
    { refetchInterval: REFETCH_INTERVAL_MS }
  );
  const { data: status } = trpc.marketScanner.getStatus.useQuery(undefined, { refetchInterval: REFETCH_INTERVAL_MS });

  const opportunities = data?.opportunities ?? [];
  const hasScanData = (status?.totalOpportunities ?? 0) > 0;

  // Aggregate regime counts from real data
  const regimeCounts: Record<string, number> = {};
  opportunities.forEach((o) => {
    const r = o.regime || "neutral";
    regimeCounts[r] = (regimeCounts[r] ?? 0) + 1;
  });
  const total = opportunities.length;
  const regimePcts = Object.entries(regimeCounts).map(([name, count]) => ({
    name,
    count,
    pct: total ? Math.round((count / total) * 100) : 0,
  }));

  const currentRegime = opportunities[0]?.regime ?? null;
  const topConfidence = opportunities[0]?.signal?.confidence ?? 0;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Regime Classification</h1>
        <p className="text-slate-400 mt-2">
          Market regime from live scan — auto-refreshes every 15s (IBKR)
        </p>
      </div>

      {isLoading && opportunities.length === 0 && !hasScanData ? (
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="py-12 text-center text-slate-400">
            <RefreshCw className="h-8 w-8 mx-auto animate-spin mb-2" />
            <p>Loading regime data… Run a scan on Market Opportunities if needed.</p>
          </CardContent>
        </Card>
      ) : opportunities.length === 0 && !hasScanData ? (
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="py-12 text-center text-slate-400">
            <p>No regime data yet. Go to <strong>Market Opportunities</strong> and click &quot;Scan Market&quot;.</p>
          </CardContent>
        </Card>
      ) : opportunities.length === 0 && hasScanData ? (
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="py-12 text-center text-slate-400">
            <p>Scanner has {status?.totalOpportunities ?? 0} opportunities; regime list may be filtered. Run a fresh scan on <strong>Market Opportunities</strong> or check back after the next auto-refresh.</p>
          </CardContent>
        </Card>
      ) : (
        <>
          <RegimeHeatmap />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle>Current Regime (lead symbol)</CardTitle>
                <CardDescription>From top-ranked opportunity</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Regime State</span>
                  <Badge className={getRegimeColor(currentRegime)}>
                    {REGIME_LABELS[currentRegime] ?? currentRegime.replace(/_/g, " ")}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>Symbol</span>
                  <span className="font-mono">{opportunities[0].symbol}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Signal confidence</span>
                  <span className="font-mono">{(topConfidence * 100).toFixed(1)}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Symbols in sample</span>
                  <span className="font-mono">{total}</span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle>Regime Distribution</CardTitle>
                <CardDescription>Share of scanned symbols per regime</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-2 text-center text-sm">
                  {regimePcts.length ? (
                    regimePcts.map(({ name, pct }) => (
                      <div
                        key={name}
                        className={`p-3 rounded ${pct >= Math.max(...regimePcts.map((r) => r.pct)) ? "bg-slate-700 border-2 border-slate-500" : "bg-slate-800"}`}
                      >
                        <div className="text-xs text-slate-400">
                          {REGIME_LABELS[name] ?? name.replace(/_/g, " ")}
                        </div>
                        <div className="text-lg font-bold">{pct}%</div>
                      </div>
                    ))
                  ) : (
                    <div className="col-span-2 text-slate-400">No data</div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle>Regime by symbol</CardTitle>
              <CardDescription>Top opportunities with real regime from scanner</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-slate-400 border-b border-slate-700">
                      <th className="py-2 pr-4">Symbol</th>
                      <th className="py-2 pr-4">Regime</th>
                      <th className="py-2 pr-4">Price</th>
                      <th className="py-2 pr-4">Change %</th>
                      <th className="py-2 pr-4">Signal</th>
                    </tr>
                  </thead>
                  <tbody>
                    {opportunities.slice(0, 20).map((o) => (
                      <tr key={o.symbol} className="border-b border-slate-800">
                        <td className="py-2 font-medium">{o.symbol}</td>
                        <td className="py-2">
                          <Badge className={`${getRegimeColor(o.regime)} text-xs`}>
                            {REGIME_LABELS[o.regime] ?? o.regime.replace(/_/g, " ")}
                          </Badge>
                        </td>
                        <td className="py-2">${o.currentPrice.toFixed(2)}</td>
                        <td className={o.priceChangePercent >= 0 ? "text-green-400" : "text-red-400"}>
                          {o.priceChangePercent >= 0 ? "+" : ""}{o.priceChangePercent.toFixed(2)}%
                        </td>
                        <td className="py-2 text-slate-400">
                          Class {o.signal?.class ?? "—"} ({(o.signal?.confidence ?? 0) * 100}%)
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
