# Cloud-to-Local IB Gateway Tunnel Setup

## Overview
This guide sets up a secure tunnel so AOIX-1 running in the Manus cloud can connect to your local IB Gateway for real trading.

## Prerequisites
- IB Gateway running locally on your machine (port 4001)
- AOIX-1 running in Manus cloud
- ngrok account (free) for tunneling

## Step 1: Download and Install ngrok

1. Go to https://ngrok.com/download
2. Download ngrok for your operating system (Windows/Mac/Linux)
3. Extract the file to a folder on your computer
4. Create a free ngrok account at https://ngrok.com/signup

## Step 2: Get Your ngrok Auth Token

1. Log in to ngrok dashboard: https://dashboard.ngrok.com
2. Go to "Your Authtoken" section
3. Copy your auth token (looks like: `2Xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`)

## Step 3: Configure ngrok

1. Open Command Prompt (Windows) or Terminal (Mac/Linux)
2. Navigate to the ngrok folder
3. Run this command (replace YOUR_AUTH_TOKEN with your actual token):

```
ngrok config add-authtoken YOUR_AUTH_TOKEN
```

## Step 4: Start the Tunnel

1. In the same terminal, run:

```
ngrok tcp 4001
```

2. You'll see output like:
```
Forwarding                    tcp://X.tcp.ngrok.io:XXXXX -> localhost:4001
```

3. **Copy the forwarding address** (e.g., `X.tcp.ngrok.io:XXXXX`)
4. **Keep this terminal open** - the tunnel needs to stay running

## Step 5: Configure AOIX-1 to Use the Tunnel

1. Go to AOIX-1 dashboard in your browser
2. Go to Settings → Secrets
3. Update these environment variables:
   - `TWS_HOST`: Set to your ngrok address (e.g., `X.tcp.ngrok.io`)
   - `TWS_PORT`: Set to the ngrok port (e.g., `XXXXX`)

4. Save and restart AOIX-1

## Step 6: Verify Connection

1. Go to AOIX-1 dashboard
2. Go to "System Health" page
3. Look for "Gateway Adapter" status
4. Should show "Connected" in green

## Step 7: Start Trading!

1. Go to "Auto Trading" page
2. Click "Start Engine"
3. Watch it scan markets and execute trades

## Troubleshooting

**Tunnel keeps disconnecting?**
- Make sure IB Gateway is still running
- Restart ngrok tunnel

**AOIX-1 can't connect?**
- Verify ngrok address in Settings → Secrets
- Check that IB Gateway is running locally
- Restart AOIX-1 after updating settings

**Need to stop trading?**
- Close the ngrok terminal to stop the tunnel
- AOIX-1 will automatically fall back to paper trading mode

## Security Notes

- ngrok tunnels are encrypted and secure
- Only you have access to your ngrok auth token
- The tunnel is temporary and can be stopped anytime
- For production, consider using a VPN instead of ngrok
