/**
 * Dynamic Momentum Glide — Adjust targets, stops, partial profits, exits by momentum strength.
 * Consumes position + market data; outputs glide decisions (extend/tighten/partial/exit).
 */

export interface PositionSnapshot {
  symbol: string;
  entryPrice: number;
  currentPrice: number;
  takeProfitPrice: number;
  stopLossPrice: number;
  trailingStopPrice: number | null;
  highWaterMark: number;
  unrealizedPnLPercent: number;
  daysToExpiry: number;
  entryTime: number;
  regime: string;
}

export interface MomentumContext {
  /** Short-term momentum (e.g. 5d return or RSI-derived) 0–1 strength */
  momentumStrength: number;
  /** Volatility regime: low / normal / high */
  volRegime: "low" | "normal" | "high";
  /** Price vs entry: "above" | "near" | "below" */
  priceVsEntry: "above" | "near" | "below";
}

export type GlideAction =
  | "hold"
  | "tighten_stop"
  | "extend_target"
  | "take_partial_25"
  | "take_partial_50"
  | "take_partial_75"
  | "exit_full";

export interface GlideAdvice {
  action: GlideAction;
  reason: string;
  /** Suggested new stop (if tighten_stop) */
  suggestedStop?: number;
  /** Suggested new target (if extend_target) */
  suggestedTarget?: number;
  /** Partial % to take (25, 50, 75) */
  partialPercent?: number;
  urgency: "low" | "medium" | "high";
  confidence: number;
  timestamp: number;
}

/**
 * Compute momentum strength from price change and optional RSI/vol.
 * Returns 0–1 (0 = no momentum, 1 = very strong).
 */
export function computeMomentumStrength(
  priceChangePercent: number,
  volRegime?: "low" | "normal" | "high"
): number {
  const abs = Math.abs(priceChangePercent);
  let raw = Math.min(1, abs / 8);
  if (volRegime === "high") raw *= 1.1;
  if (volRegime === "low") raw *= 0.9;
  return Math.min(1, Math.max(0, raw));
}

/**
 * Get Dynamic Momentum Glide advice for a position.
 * Uses position snapshot + momentum context to recommend hold / tighten / extend / partial / exit.
 */
export function getGlideAdvice(
  position: PositionSnapshot,
  momentum: MomentumContext
): GlideAdvice {
  const now = Date.now();
  const { momentumStrength, volRegime, priceVsEntry } = momentum;
  const up = position.currentPrice >= position.entryPrice;
  const pnlPct = position.unrealizedPnLPercent;

  // Stop loss breach
  if (position.currentPrice <= position.stopLossPrice) {
    return {
      action: "exit_full",
      reason: "Stop loss level reached.",
      urgency: "high",
      confidence: 1,
      timestamp: now,
    };
  }

  // Take profit reached
  if (position.currentPrice >= position.takeProfitPrice) {
    return {
      action: "exit_full",
      reason: "Take profit target reached.",
      urgency: "medium",
      confidence: 0.95,
      timestamp: now,
    };
  }

  // Strong profit + strong momentum: extend target or take partial
  if (pnlPct >= 30 && momentumStrength > 0.6 && priceVsEntry === "above") {
    return {
      action: "extend_target",
      reason: "Strong momentum and profit; consider extending target.",
      suggestedTarget: position.currentPrice * 1.05,
      urgency: "low",
      confidence: 0.7,
      timestamp: now,
    };
  }

  if (pnlPct >= 50 && priceVsEntry === "above") {
    return {
      action: "take_partial_50",
      reason: "Significant profit; lock in 50%.",
      partialPercent: 50,
      urgency: "medium",
      confidence: 0.8,
      timestamp: now,
    };
  }

  if (pnlPct >= 25 && pnlPct < 50 && momentumStrength < 0.4) {
    return {
      action: "take_partial_25",
      reason: "Moderate profit with fading momentum; lock 25%.",
      partialPercent: 25,
      urgency: "medium",
      confidence: 0.75,
      timestamp: now,
    };
  }

  // Trailing stop: tighten if we've given back gains
  if (
    position.highWaterMark > position.entryPrice &&
    position.currentPrice < position.highWaterMark * 0.95 &&
    pnlPct > 10
  ) {
    const suggestedStop = position.entryPrice + (position.highWaterMark - position.entryPrice) * 0.5;
    return {
      action: "tighten_stop",
      reason: "Giving back gains; tighten stop to lock profit.",
      suggestedStop,
      urgency: "high",
      confidence: 0.85,
      timestamp: now,
    };
  }

  // Time decay: if near expiry and small profit, consider partial
  if (position.daysToExpiry <= 3 && pnlPct >= 15) {
    return {
      action: "take_partial_50",
      reason: "Near expiry with profit; lock 50%.",
      partialPercent: 50,
      urgency: "medium",
      confidence: 0.75,
      timestamp: now,
    };
  }

  return {
    action: "hold",
    reason: "No change; hold position.",
    urgency: "low",
    confidence: 0.6,
    timestamp: now,
  };
}
