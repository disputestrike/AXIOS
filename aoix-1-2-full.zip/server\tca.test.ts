/**
 * TCA (Transaction Cost Analysis) unit tests — flow cache, tca log, slippage, execution quality.
 * Run: pnpm test -- --grep "tca"
 */
import { describe, it, expect, beforeEach } from "vitest";
import {
  logTCA,
  getTCASummary,
  getTCALog,
  getTCADrillDown,
  computeExecutionQualityScore,
  type TCAEntry,
} from "./tca";

describe("TCA — transaction cost analysis", () => {
  beforeEach(() => {
    // Clear TCA log between tests by logging then relying on getTCALog(0) or by testing summary after known adds
    // (tca.ts does not export clear; we test additive behavior or use a fresh summary)
  });

  it("tca: logTCA records entry with correct slippage for BUY", () => {
    logTCA({
      timestamp: Date.now(),
      symbol: "SPY",
      side: "BUY",
      quantity: 1,
      intendedPrice: 4.0,
      fillPrice: 4.02,
      orderType: "MKT",
    });
    const log = getTCALog(1);
    expect(log.length).toBeGreaterThanOrEqual(1);
    const e = log[0]!;
    expect(e.symbol).toBe("SPY");
    expect(e.side).toBe("BUY");
    expect(e.slippagePerContract).toBeCloseTo(0.02, 4);
    expect(e.slippagePercent).toBeCloseTo(0.5, 2); // 0.02/4 * 100
  });

  it("tca: logTCA records entry with correct slippage for SELL", () => {
    logTCA({
      timestamp: Date.now(),
      symbol: "SPY",
      side: "SELL",
      quantity: 1,
      intendedPrice: 4.0,
      fillPrice: 3.98,
      orderType: "MKT",
    });
    const log = getTCALog(1);
    expect(log.length).toBeGreaterThanOrEqual(1);
    const e = log[0]!;
    expect(e.side).toBe("SELL");
    expect(e.slippagePerContract).toBeCloseTo(0.02, 4); // intended - fill
    expect(e.slippagePercent).toBeCloseTo(0.5, 2);
  });

  it("tca: slippage calculation is correct when fill equals intended", () => {
    logTCA({
      timestamp: Date.now(),
      symbol: "QQQ",
      side: "BUY",
      quantity: 2,
      intendedPrice: 2.5,
      fillPrice: 2.5,
      orderType: "MKT",
    });
    const log = getTCALog(1);
    const e = log[0]!;
    expect(e.slippagePerContract).toBe(0);
    expect(e.slippagePercent).toBe(0);
  });

  it("tca: getTCASummary returns structure with execution quality score", () => {
    const summary = getTCASummary();
    expect(summary).toHaveProperty("totalTrades");
    expect(summary).toHaveProperty("avgSlippagePercent");
    expect(summary).toHaveProperty("maxSlippagePercent");
    expect(summary).toHaveProperty("executionQualityScore");
    expect(summary.executionQualityScore).toBeGreaterThanOrEqual(0);
    expect(summary.executionQualityScore).toBeLessThanOrEqual(100);
  });

  it("tca: computeExecutionQualityScore returns 100 for zero slippage", () => {
    expect(computeExecutionQualityScore(0)).toBe(100);
  });

  it("tca: computeExecutionQualityScore decreases with higher slippage", () => {
    const s05 = computeExecutionQualityScore(0.5);
    const s1 = computeExecutionQualityScore(1);
    const s2 = computeExecutionQualityScore(2);
    expect(s05).toBeLessThanOrEqual(100);
    expect(s1).toBeLessThanOrEqual(s05);
    expect(s2).toBeLessThanOrEqual(s1);
  });

  it("tca: getTCALog returns entries in reverse chronological order", () => {
    const t = Date.now();
    logTCA({ timestamp: t - 2, symbol: "A", side: "BUY", quantity: 1, intendedPrice: 1, fillPrice: 1, orderType: "MKT" });
    logTCA({ timestamp: t - 1, symbol: "B", side: "BUY", quantity: 1, intendedPrice: 1, fillPrice: 1, orderType: "MKT" });
    const log = getTCALog(5);
    expect(log.length).toBeGreaterThanOrEqual(2);
    expect(log[0]!.timestamp).toBeGreaterThanOrEqual(log[1]!.timestamp);
  });

  it("tca: getTCADrillDown returns null for unknown orderId", () => {
    const drill = getTCADrillDown("nonexistent-order-id");
    expect(drill).toBeNull();
  });

  it("tca: getTCADrillDown returns entries and summary when orderId matches", () => {
    const orderId = "test-order-" + Date.now();
    logTCA({
      timestamp: Date.now(),
      symbol: "SPY",
      side: "BUY",
      quantity: 2,
      intendedPrice: 5,
      fillPrice: 5.05,
      orderType: "MKT",
      orderId,
    });
    const drill = getTCADrillDown(orderId);
    expect(drill).not.toBeNull();
    expect(drill!.orderId).toBe(orderId);
    expect(drill!.entries.length).toBeGreaterThanOrEqual(1);
    expect(drill!.symbol).toBe("SPY");
    expect(drill!.totalSlippagePercent).toBeGreaterThanOrEqual(0);
    expect(drill!.executionQualityScore).toBeGreaterThanOrEqual(0);
  });

  it("tca: execution quality score 0–100 for filled at mid", () => {
    const score = computeExecutionQualityScore(0);
    expect(score).toBe(100);
  });

  it("tca: execution quality score ~95 for 0.5% avg slippage", () => {
    const score = computeExecutionQualityScore(0.5);
    expect(score).toBeGreaterThanOrEqual(90);
    expect(score).toBeLessThanOrEqual(100);
  });

  it("tca: implementation shortfall estimate in summary", () => {
    const summary = getTCASummary();
    expect(summary).toHaveProperty("implementationShortfallEstimate");
    expect(typeof summary.implementationShortfallEstimate).toBe("number");
  });

  it("tca: TCA entry has required fields", () => {
    logTCA({
      timestamp: Date.now(),
      symbol: "IWM",
      side: "BUY",
      quantity: 1,
      intendedPrice: 3,
      fillPrice: 3.01,
      orderType: "LMT",
      structureType: "vertical_call_spread",
    });
    const log = getTCALog(1);
    const e = log[0]!;
    expect(e.id).toBeDefined();
    expect(e.timestamp).toBeDefined();
    expect(e.symbol).toBe("IWM");
    expect(e.side).toBe("BUY");
    expect(e.quantity).toBe(1);
    expect(e.intendedPrice).toBe(3);
    expect(e.fillPrice).toBe(3.01);
    expect(e.slippagePerContract).toBeCloseTo(0.01, 4);
    expect(e.orderType).toBe("LMT");
    expect(e.structureType).toBe("vertical_call_spread");
  });
});
