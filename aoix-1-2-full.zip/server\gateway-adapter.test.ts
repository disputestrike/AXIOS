/**
 * Unit tests for the Gateway Adapter
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { GatewayAdapter, getGatewayAdapter, resetGatewayAdapter, type GatewayConfig } from './gateway-adapter';
import { getAutoTradingEngine, resetAutoTradingEngine } from './auto-trading-engine';

describe('GatewayAdapter', () => {
  let adapter: GatewayAdapter;
  let engine = getAutoTradingEngine();

  beforeEach(() => {
    resetAutoTradingEngine();
    resetGatewayAdapter();
    engine = getAutoTradingEngine();
    adapter = getGatewayAdapter(engine);
  });

  afterEach(() => {
    adapter.disconnect();
    resetGatewayAdapter();
    resetAutoTradingEngine();
  });

  describe('Initialization', () => {
    it('should initialize with default configuration', () => {
      const config = adapter.getConfig();
      
      expect(config.host).toBe('localhost');
      expect(config.port).toBe(7497);
      expect(config.clientId).toBe(1);
      expect(config.enabled).toBe(false);
    });

    it('should initialize with paper trading mode', () => {
      const status = adapter.getConnectionStatus();
      
      expect(status.isConnected).toBe(false);
      expect(status.mode).toBe('paper');
    });
  });

  describe('Configuration', () => {
    it('should update configuration', () => {
      adapter.setConfig({
        host: '192.168.1.100',
        port: 7498,
        accountId: 'DU123456',
      });

      const config = adapter.getConfig();
      expect(config.host).toBe('192.168.1.100');
      expect(config.port).toBe(7498);
      expect(config.accountId).toBe('DU123456');
    });

    it('should enable Gateway', () => {
      adapter.enableGateway();
      const config = adapter.getConfig();
      
      expect(config.enabled).toBe(true);
    });

    it('should disable Gateway', () => {
      adapter.enableGateway();
      adapter.disableGateway();
      const config = adapter.getConfig();
      
      expect(config.enabled).toBe(false);
      expect(adapter.isPaperMode()).toBe(true);
    });
  });

  describe('Connection Management', () => {
    it('should return false when Gateway is disabled', async () => {
      adapter.disableGateway();
      const connected = await adapter.connect();
      
      expect(connected).toBe(false);
      expect(adapter.isPaperMode()).toBe(true);
    });

    it('should disconnect from Gateway', () => {
      adapter.disconnect();
      const status = adapter.getConnectionStatus();
      
      expect(status.isConnected).toBe(false);
      expect(status.mode).toBe('paper');
    });
  });

  describe('Mode Detection', () => {
    it('should detect paper mode when not connected', () => {
      expect(adapter.isPaperMode()).toBe(true);
      expect(adapter.isLiveMode()).toBe(false);
    });

    it('should detect paper mode when Gateway is disabled', () => {
      adapter.disableGateway();
      
      expect(adapter.isPaperMode()).toBe(true);
      expect(adapter.isLiveMode()).toBe(false);
    });
  });

  describe('Singleton Pattern', () => {
    it('should return the same instance', () => {
      const adapter1 = getGatewayAdapter(engine);
      const adapter2 = getGatewayAdapter(engine);
      
      expect(adapter1).toBe(adapter2);
    });

    it('should create new instance after reset', () => {
      const adapter1 = getGatewayAdapter(engine);
      resetGatewayAdapter();
      const adapter2 = getGatewayAdapter(engine);
      
      expect(adapter1).not.toBe(adapter2);
    });
  });

  describe('Connection Status', () => {
    it('should have connection status fields', () => {
      const status = adapter.getConnectionStatus();
      
      expect(status).toHaveProperty('isConnected');
      expect(status).toHaveProperty('lastConnectAttempt');
      expect(status).toHaveProperty('lastSuccessfulConnection');
      expect(status).toHaveProperty('connectionError');
      expect(status).toHaveProperty('mode');
    });

    it('should track connection attempts', { timeout: 12_000 }, async () => {
      adapter.enableGateway();
      const statusBefore = adapter.getConnectionStatus();
      expect(statusBefore.lastConnectAttempt).toBeNull();
      
      await adapter.connect();
      const statusAfter = adapter.getConnectionStatus();
      expect(statusAfter.lastConnectAttempt).not.toBeNull();
    });
  });

  describe('Default Configuration', () => {
    it('should have correct default host', () => {
      const config = adapter.getConfig();
      expect(config.host).toBe('localhost');
    });

    it('should have correct default port (7497)', () => {
      const config = adapter.getConfig();
      expect(config.port).toBe(7497);
    });

    it('should have correct default client ID', () => {
      const config = adapter.getConfig();
      expect(config.clientId).toBe(1);
    });
  });

  describe('Fallback Behavior', () => {
    it('should start in paper mode by default', () => {
      expect(adapter.isPaperMode()).toBe(true);
      expect(adapter.isLiveMode()).toBe(false);
    });

    it('should support enabling Gateway for live trading', () => {
      adapter.enableGateway();
      const config = adapter.getConfig();
      expect(config.enabled).toBe(true);
    });
  });
});

describe('GatewayAdapter Order Execution', () => {
  let adapter: GatewayAdapter;

  beforeEach(() => {
    resetAutoTradingEngine();
    resetGatewayAdapter();
    const engine = getAutoTradingEngine();
    adapter = getGatewayAdapter(engine);
  });

  afterEach(() => {
    adapter.disconnect();
    resetGatewayAdapter();
    resetAutoTradingEngine();
  });

  describe('Paper Trading Execution', () => {
    it('should execute position in paper mode', async () => {
      const mockPosition = {
        id: 'test-pos-1',
        symbol: 'SPX',
        optionType: 'call' as const,
        strike: 5900,
        expiry: '2026-02-07',
        quantity: 1,
        entryPrice: 50.00,
        entryTime: Date.now(),
        currentPrice: 50.00,
        unrealizedPnL: 0,
        unrealizedPnLPercent: 0,
        regime: 'bull_vol_compression',
        signalClass: 'A' as const,
        takeProfitPrice: 65.00,
        stopLossPrice: 40.00,
        trailingStopPrice: null,
        status: 'open' as const,
      };

      const result = await adapter.executePosition(mockPosition);
      
      expect(result.success).toBe(true);
      expect(result.executedPrice).toBe(50.00);
      expect(result.executedQuantity).toBe(1);
    });

    it('should close position in paper mode', async () => {
      const mockPosition = {
        id: 'test-pos-1',
        symbol: 'SPX',
        optionType: 'call' as const,
        strike: 5900,
        expiry: '2026-02-07',
        quantity: 1,
        entryPrice: 50.00,
        entryTime: Date.now(),
        currentPrice: 65.00,
        unrealizedPnL: 1500,
        unrealizedPnLPercent: 0.30,
        regime: 'bull_vol_compression',
        signalClass: 'A' as const,
        takeProfitPrice: 65.00,
        stopLossPrice: 40.00,
        trailingStopPrice: null,
        status: 'closed' as const,
      };

      const result = await adapter.closePosition(mockPosition, 65.00);
      
      expect(result.success).toBe(true);
      expect(result.executedPrice).toBe(65.00);
    });
  });
});
