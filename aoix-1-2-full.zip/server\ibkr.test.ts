import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { IBKRBroker, Omega0Engine } from "./ibkr";

describe("IBKR Broker Integration", () => {
  let broker: IBKRBroker;

  beforeAll(() => {
    broker = new IBKRBroker({
      host: "127.0.0.1",
      port: 7497,
      clientId: 1,
      paperTrading: true,
    });
  });

  afterAll(() => {
    broker.disconnect();
  });

  describe("Broker Initialization", () => {
    it("should create broker instance with default config", () => {
      const testBroker = new IBKRBroker();
      expect(testBroker).toBeDefined();
    });

    it("should create broker instance with custom config", () => {
      const testBroker = new IBKRBroker({
        host: "192.168.1.100",
        port: 7496,
        clientId: 2,
        paperTrading: false,
      });
      expect(testBroker).toBeDefined();
    });
  });

  describe("Position Tracking", () => {
    it("should initialize with empty positions", () => {
      const positions = broker.getOpenPositions();
      expect(positions).toBeDefined();
      expect(Array.isArray(positions)).toBe(true);
    });

    it("should initialize with empty trades", () => {
      const trades = broker.getClosedTrades();
      expect(trades).toBeDefined();
      expect(Array.isArray(trades)).toBe(true);
    });

    it("should return empty open trades", () => {
      const openTrades = broker.getOpenTrades();
      expect(openTrades).toBeDefined();
      expect(Array.isArray(openTrades)).toBe(true);
    });
  });

  describe("Performance Metrics", () => {
    it("should calculate metrics with zero trades", () => {
      const metrics = broker.getPerformanceMetrics();
      expect(metrics).toHaveProperty("totalTrades");
      expect(metrics).toHaveProperty("closedTrades");
      expect(metrics).toHaveProperty("winRate");
      expect(metrics).toHaveProperty("totalPnL");
      expect(metrics).toHaveProperty("profitFactor");
      expect(metrics.totalTrades).toBe(0);
      expect(metrics.winRate).toBe(0);
    });

    it("should initialize profit factor as zero", () => {
      const metrics = broker.getPerformanceMetrics();
      expect(metrics.profitFactor).toBe(0);
    });
  });
});

describe("Omega-0 Execution Engine", () => {
  let broker: IBKRBroker;
  let engine: Omega0Engine;

  beforeAll(() => {
    broker = new IBKRBroker({
      host: "127.0.0.1",
      port: 7497,
      clientId: 1,
      paperTrading: true,
    });

    engine = new Omega0Engine(broker, {
      symbol: "SPY",
      maxRiskPct: 0.01,
      takeProfitRatio: 1.3,
      stopLossRatio: 0.8,
      expiryDaysOut: 0,
    });
  });

  afterAll(() => {
    engine.stop();
    broker.disconnect();
  });

  describe("Engine Configuration", () => {
    it("should initialize with valid config", () => {
      expect(engine).toBeDefined();
    });

    it("should enforce max risk percentage", () => {
      const config = {
        symbol: "SPY",
        maxRiskPct: 0.02,
        takeProfitRatio: 1.3,
        stopLossRatio: 0.8,
        expiryDaysOut: 0,
      };
      const testEngine = new Omega0Engine(broker, config);
      expect(testEngine).toBeDefined();
    });

    it("should enforce take profit ratio > 1.0", () => {
      const config = {
        symbol: "SPY",
        maxRiskPct: 0.01,
        takeProfitRatio: 1.5,
        stopLossRatio: 0.8,
        expiryDaysOut: 0,
      };
      const testEngine = new Omega0Engine(broker, config);
      expect(testEngine).toBeDefined();
    });

    it("should enforce stop loss ratio < 1.0", () => {
      const config = {
        symbol: "SPY",
        maxRiskPct: 0.01,
        takeProfitRatio: 1.3,
        stopLossRatio: 0.7,
        expiryDaysOut: 0,
      };
      const testEngine = new Omega0Engine(broker, config);
      expect(testEngine).toBeDefined();
    });
  });

  describe("Performance Reporting", () => {
    it("should return performance report", () => {
      const report = engine.getPerformanceReport();
      expect(report).toHaveProperty("totalTrades");
      expect(report).toHaveProperty("winRate");
      expect(report).toHaveProperty("totalPnL");
    });

    it("should report zero trades on new engine", () => {
      const newEngine = new Omega0Engine(broker, {
        symbol: "QQQ",
        maxRiskPct: 0.01,
        takeProfitRatio: 1.3,
        stopLossRatio: 0.8,
        expiryDaysOut: 0,
      });

      const report = newEngine.getPerformanceReport();
      expect(report.totalTrades).toBe(0);
    });

    it("should have zero win rate on new engine", () => {
      const newEngine = new Omega0Engine(broker, {
        symbol: "IWM",
        maxRiskPct: 0.01,
        takeProfitRatio: 1.3,
        stopLossRatio: 0.8,
        expiryDaysOut: 0,
      });

      const report = newEngine.getPerformanceReport();
      expect(report.winRate).toBe(0);
    });

    it("should have zero P&L on new engine", () => {
      const newEngine = new Omega0Engine(broker, {
        symbol: "QQQ",
        maxRiskPct: 0.01,
        takeProfitRatio: 1.3,
        stopLossRatio: 0.8,
        expiryDaysOut: 0,
      });

      const report = newEngine.getPerformanceReport();
      expect(report.totalPnL).toBe(0);
    });
  });

  describe("Risk Parameters", () => {
    it("should validate max risk percentage", () => {
      const config = {
        symbol: "SPY",
        maxRiskPct: 0.01,
        takeProfitRatio: 1.3,
        stopLossRatio: 0.8,
        expiryDaysOut: 0,
      };
      expect(config.maxRiskPct).toBe(0.01);
      expect(config.maxRiskPct).toBeGreaterThan(0);
      expect(config.maxRiskPct).toBeLessThan(0.1);
    });

    it("should validate take profit ratio", () => {
      const config = {
        symbol: "SPY",
        maxRiskPct: 0.01,
        takeProfitRatio: 1.3,
        stopLossRatio: 0.8,
        expiryDaysOut: 0,
      };
      expect(config.takeProfitRatio).toBeGreaterThan(1.0);
    });

    it("should validate stop loss ratio", () => {
      const config = {
        symbol: "SPY",
        maxRiskPct: 0.01,
        takeProfitRatio: 1.3,
        stopLossRatio: 0.8,
        expiryDaysOut: 0,
      };
      expect(config.stopLossRatio).toBeLessThan(1.0);
      expect(config.stopLossRatio).toBeGreaterThan(0);
    });
  });
});
