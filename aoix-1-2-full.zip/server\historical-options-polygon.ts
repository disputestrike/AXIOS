/**
 * Historical options prices — Polygon.io (optional)
 * When POLYGON_API_KEY is set, can fetch real historical option OHLC for backtest.
 * Without key: returns null; backtest uses synthetic option P&L (Black–Scholes) from real stock prices.
 *
 * Polygon options: https://polygon.io/docs/options/getting-started
 * - Day aggregates: GET /v1/open-close/O:{underlying}/{date} for a contract
 * - Contract format: O:SPY251219C00600000 (SPY 2025-12-19 Call 600)
 */

export interface HistoricalOptionBar {
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  date: string; // YYYY-MM-DD
}

/**
 * Fetch historical option close (or OHLC) for one contract on one date.
 * Returns null if no API key or contract not found.
 */
export async function getHistoricalOptionClose(
  underlying: string,
  date: string, // YYYY-MM-DD
  strike: number,
  expiry: string, // YYYYMMDD
  optionType: 'C' | 'P'
): Promise<number | null> {
  const apiKey = process.env.POLYGON_API_KEY?.trim();
  if (!apiKey) return null;

  // Polygon contract: O:SPY251219C00600000 (underlying + YYMMDD + C/P + strike*1000)
  const exp = expiry.slice(2, 8); // YYMMDD
  const strikeStr = (strike * 1000).toFixed(0).padStart(8, '0');
  const contract = `O:${underlying}${exp}${optionType}${strikeStr}`;

  try {
    const url = `https://api.polygon.io/v1/open-close/${contract}/${date}?adjusted=true&apiKey=${apiKey}`;
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return null;
    const data = (await res.json()) as { close?: number; status?: string };
    if (data?.status === 'OK' && typeof data.close === 'number') return data.close;
    return null;
  } catch {
    return null;
  }
}
