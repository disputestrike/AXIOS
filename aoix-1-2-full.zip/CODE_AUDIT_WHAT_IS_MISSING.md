# AOIX-1 Code Audit: What Is Missing, How, Why, Who & Where

**Status:** All listed issues have been fixed and persisted. See "Fixes Applied" at the end.

## Summary

| Question | Answer |
|----------|--------|
| **What** is missing? | Trade DB persistence, Windows start script, one orphan page, and optional Phase 4–7 features. |
| **How** does it affect the app? | Trades and health data are in-memory only; production start fails on Windows; one page is unreachable. |
| **Why** is it missing? | Stub services never wired to Drizzle; platform-specific script; route not added; roadmap items not done. |
| **Who** is affected? | Anyone running production on Windows; anyone expecting trades/health to survive restart; anyone looking for ExecutionInterface. |
| **Where** in the codebase? | See sections below with file paths. |

---

## 1. Trade persistence to database (critical gap)

### What is missing
- **Auto-trading engine** and **omega0** paper trades are **in-memory only**. They are not written to the Drizzle `trades` table.
- **DatabaseTradeService** (`server/db-trade-service.ts`) is a **stub**: it logs “Trade saved” but does **not** call `db.insert(trades)` (see comments “In production, use: …”).
- **TradeHistoryService** (`server/trade-history-service.ts`) keeps trades in a `Map`; it does not use the database.

### How it breaks
- Server restart wipes all paper/auto-trade history.
- `routers.ts` exposes `trades.getOpenTrades` and `trades.getHistory` (they read from Drizzle `trades`), but **no code path** in the server ever **inserts** into `trades`, so those procedures always return empty (unless you insert via SQL manually).
- The Execution dashboard uses **omega0** (in-memory), not the main `trades` router, so the UI never shows DB-backed trades.

### Why
- `todo.md` Phase 12 marks “Add trade history persistence to database” and “Create trade history service with in-memory storage” as done, but the **persistence** part (writing to Drizzle) was never implemented in `DatabaseTradeService`.

### Who is affected
- Anyone expecting trade history to survive restarts or to be queryable from the main `trades` API.

### Where
- **Reads (used by main API, unused by current UI):** `server/db.ts` — `getUserOpenTrades`, `getUserTradeHistory`.
- **Stub (no real persistence):** `server/db-trade-service.ts` — `saveTradeRecord`, `updateTradeRecord`, `getTradeRecord`, etc.
- **In-memory only:** `server/trade-history-service.ts`, `server/auto-trading-engine.ts` (state), `server/routers/omega0.ts` (paperTrades array).
- **Schema:** `drizzle/schema.ts` — `trades` table exists but is never written by app code.

---

## 2. Windows production start script

### What is missing
- `package.json` has: `"start": "NODE_ENV=production node dist/index.js"`.
- On **Windows** (PowerShell/CMD), `NODE_ENV=production` does **not** set the env var; that syntax is Unix-only.

### How it breaks
- On Windows, `pnpm start` runs without `NODE_ENV=production`, so the server may run in development behavior (e.g. Vite dev, different logging).

### Why
- Script was written for Unix; no cross-platform helper was added.

### Who is affected
- Anyone running `pnpm start` (production) on Windows.

### Where
- **File:** `package.json` — `scripts.start`.

**Fix options:** Use `cross-env` (e.g. `cross-env NODE_ENV=production node dist/index.js`) or a small Node script that sets `process.env.NODE_ENV` then requires `dist/index.js`.

---

## 3. Orphan page: ExecutionInterface

### What is missing
- **ExecutionInterface** exists at `client/src/pages/ExecutionInterface.tsx` but is **not** registered in `App.tsx` routes.
- Only **ExecutionDashboard** is mounted at `/execution`.

### How it breaks
- ExecutionInterface is dead code: no URL leads to it.

### Why
- Likely an older or alternate UI that was never wired into the router.

### Who is affected
- Developers or users looking for “ExecutionInterface” or a second execution view.

### Where
- **Page:** `client/src/pages/ExecutionInterface.tsx`.
- **Router:** `client/src/App.tsx` — only `ExecutionDashboard` is used for `/execution`.

**Fix:** Either add a route that renders `ExecutionInterface` (e.g. `/execution/interface`) or remove the file if it’s obsolete.

---

## 4. Main `trades` router unused by frontend

### What is missing
- The main API exposes `trades.getOpenTrades` and `trades.getHistory` (backed by Drizzle `trades`), but **no client code** calls them (grep for `trpc.trades` / `trades.getOpenTrades` / `trades.getHistory` in `client` returns no matches).
- Execution dashboard uses **omega0** (in-memory paper trades) only.

### How it affects
- The “trades” procedures are unused; all visible execution/trade data in the UI comes from omega0 and the auto-trading engine (both in-memory).

### Where
- **Backend:** `server/routers.ts` — `trades` router.
- **Frontend:** No imports or `trpc.trades.*` usage in `client/`.

---

## 5. Optional / roadmap items (from todo.md)

These are **not** bugs; they are planned work that is still open:

- **Phase 4:** Stock options support (chains, IV rank, corporate actions, etc.).
- **Phase 5:** Dynamic asset selection (no hard-coded SPX/QQQ/SPY/IWM; top-N opportunities).
- **Phase 6:** Broader testing (real market data, ranking accuracy, stock options, dynamic rebalancing, dashboard click-through).
- **Phase 7:** Live trading (IB Gateway live execution, fills/slippage, real P&L, kill switch validation).
- **Phase 13:** IB Gateway real market data (replace simulated data in scanner/dashboards).
- **Phase 14 (partial):** Auto-refresh and wiring of all dashboards to live data; some items still “in progress”.
- **UI/UX:** “Update dashboard to show all green indicators”, “Add status badges”, “Create system health page”, “Add performance metrics display” — some done, some optional.

**Where:** `todo.md` — Phases 4–7, 13, 14, UI/UX section.

---

## 6. Quick reference: file → role

| File / area | Role | Gap (if any) |
|-------------|------|--------------|
| `server/db-trade-service.ts` | Should persist trades to DB | Only logs; no `db.insert(trades)` |
| `server/trade-history-service.ts` | In-memory trade history | No DB write |
| `server/auto-trading-engine.ts` | Autonomous engine state | In-memory only; no DB persistence |
| `server/routers/omega0.ts` | Paper trading | In-memory `paperTrades`; no Drizzle writes |
| `server/db.ts` | Drizzle queries | `getUserOpenTrades` / `getUserTradeHistory` exist; no caller writes to `trades` |
| `server/routers.ts` | `trades.getOpenTrades` / `getHistory` | Used by no frontend; DB table never filled by app |
| `package.json` → `scripts.start` | Production start | Unix-only env; fails on Windows |
| `client/src/App.tsx` | Routes | ExecutionInterface not routed |
| `client/src/pages/ExecutionInterface.tsx` | Alternate execution UI | Orphan; no route |

---

## Fixes Applied (All Issues Addressed)

1. **Windows production start** – Added `cross-env` to devDependencies and `scripts.start` uses `cross-env NODE_ENV=production node dist/index.js`. Run `pnpm install` once.
2. **Trade persistence** – Reimplemented `server/db-trade-service.ts` to persist to Drizzle `trades` table. Wired omega0, auto-trading engine, and TradeHistoryService to call the DB service. Trades now survive server restarts.
3. **ExecutionInterface route** – Added route `/execution/interface` in `client/src/App.tsx` for `ExecutionInterface`.

---

## Recommended order of fixes

1. **Windows start:** Add `cross-env` (or equivalent) so `pnpm start` sets `NODE_ENV=production` on Windows.
2. **Trade persistence:** In `DatabaseTradeService`, implement `saveTradeRecord` / `updateTradeRecord` (and related methods) using Drizzle `trades` table; then wire the auto-trading engine and/or omega0 to call it when trades are opened/closed.
3. **ExecutionInterface:** Either add a route in `App.tsx` or delete the orphan page.
4. **Optional:** Have Execution (or another dashboard) use `trades.getOpenTrades` / `trades.getHistory` once trades are persisted, so DB-backed history is visible in the UI.

After that, the “what / how / why / who / where” for the main gaps are addressed; remaining work is the planned Phase 4–7 and 13–14 items in `todo.md`.
