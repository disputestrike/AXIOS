# Catalyst Detection + Claude Validation — How We Get It Done

This doc answers: **Do we need specialized APIs? Can we use scraping? Can we use Claude? How do we implement it?**

---

## 1. Do we need specialized APIs?

**No.** We follow the same pattern the codebase already uses:

| Layer | Approach | Already in codebase? |
|-------|----------|----------------------|
| **Catalyst detection** | Optional env URLs/API keys (e.g. `CATALYST_NEWS_API_URL`, `EARNINGS_API_URL`, `SEC_FILINGS_API_URL`). When **set** → call them; when **not set** → use free sources or stubs. | Same as `OPTIONS_FLOW_API_URL`, `SENTIMENT_API_URL` in `options-flow.ts` and `alternative-data.ts`. |
| **Options generation** | Use **existing** data: Polygon (IV/history), IB (live chain), `options-flow` (implied move). | Yes — no new API. |
| **Claude validation** | Use **existing** LLM path (Forge) or add **one** key: `ANTHROPIC_API_KEY` for direct Claude. | LLM in `server/_core/llm.ts` (Forge + `BUILT_IN_FORGE_API_KEY`). |
| **Dynamic Momentum Glide** | Pure logic on top of existing market data (IB, Polygon, real-time). | No new API. |
| **Dashboard** | Existing stack; new “Today’s Opportunity” view. | No new API. |

So we **don’t depend** on any new paid API. We can ship with free/scraping/stubs and add optional paid APIs later via env.

---

## 2. Can we use scraping / free sources?

**Yes.** For catalysts we can:

- **News:** Yahoo Finance RSS, or any public news RSS; optional paid News API/Benzinga when `CATALYST_NEWS_API_URL` (or similar) is set.
- **SEC filings:** SEC EDGAR is public — fetch RSS or scrape (with cache + timeout); optional paid SEC API via env if you add one later.
- **FDA / earnings:** Free tiers (e.g. Alpha Vantage, Polygon if you already have `POLYGON_API_KEY`) or stub; optional dedicated FDA/earnings API via env later.

Implementation: small fetcher modules (same style as `real-market-data.ts`, `alternative-data.ts`) with cache and timeout. We can “figure it out” with `fetch` + light parsing; no new stack.

---

## 3. Claude vs “our own LLM”

We **don’t** need to build our own LLM. Two ways to “use Claude”:

**Option A — Use existing Forge LLM (simplest)**  
- The app already calls Forge (`server/_core/llm.ts`) with `BUILT_IN_FORGE_API_KEY`; model is currently `gemini-2.5-flash`.  
- If your Forge endpoint can route to **Claude**, you just configure that.  
- “Claude validation” = same `invokeLLM()` with a **validation prompt** (trade + context → approve / reject / modify). No new keys.

**Option B — Direct Anthropic API**  
- Add `ANTHROPIC_API_KEY` and a small `invokeClaude()` (or `validateWithClaude()`) that calls Anthropic’s API for the **validation step only**.  
- Rest of the app stays on Forge (or whatever you use today).  
- Gives you guaranteed Claude for validation without changing the rest of the LLM setup.

So: **use Claude via API** (Forge or Anthropic); no custom model or self-hosted LLM needed.

---

## 4. How we get it done (concrete)

1. **Catalyst detection**  
   - New module(s), e.g. `server/catalyst-detection.ts` (or split by source).  
   - Each source: (a) optional env API/URL, (b) free fetch (RSS, SEC, etc.), or (c) stub.  
   - Output: unified “catalyst events” (type, symbol, time, confidence, source).  
   - Same plug-point pattern as `options-flow.ts` and `alternative-data.ts`.

2. **Options generation**  
   - Use existing: scan results, Polygon/IB options data, `getUnusualFlow` / implied move.  
   - New logic only: build Conservative / Balanced / Aggressive trade options and compare implied vs historical move.  
   - No new API.

3. **Claude validation**  
   - Single validation function that takes (trade option + catalyst + market context).  
   - Calls either existing `invokeLLM()` (if Forge → Claude) or new Anthropic client.  
   - Returns: approve / reject / modify (with optional text reason).  
   - No new infra beyond one optional env key if we go Option B.

4. **Dynamic Momentum Glide**  
   - New module that consumes existing market/position data; adjusts targets/stops, partial profits, exits based on momentum.  
   - No new API.

5. **Execution & dashboard**  
   - “Today’s Opportunity” view, “Click to Execute”, live position tracking, daily digest: all on existing backend and frontend stack.  
   - New routes/components only.

---

## 5. Summary

| Question | Answer |
|----------|--------|
| Specialized APIs required? | **No.** Optional env APIs + free/scraping/stubs. |
| Can we use scraping? | **Yes.** SEC, news RSS, etc., with cache + timeout. |
| Use Claude? | **Yes.** Via existing Forge (if it routes to Claude) or one `ANTHROPIC_API_KEY` for validation. |
| Our own LLM? | **No.** Use Claude (or current Forge model) via API. |
| How we get it done? | Catalyst modules (optional API + free/stub), existing data for options, existing or one new LLM client for Claude, glide + dashboard on current stack. |

If you confirm Option A (Forge → Claude) vs Option B (direct Anthropic for validation), we can implement the validation step accordingly and then wire Catalyst + Options generation + Glide + dashboard on top.
