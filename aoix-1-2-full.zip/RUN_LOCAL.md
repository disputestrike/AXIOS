# Run AOIX-1 locally

## 1. Start the server

In a terminal, from the project folder:

```bash
pnpm dev
```

**Windows PowerShell:**
```powershell
cd "c:\Users\benxp\Downloads\aoix-1(2)"
pnpm dev
```

Or use the script:
```powershell
.\START_LOCAL.ps1
```

## 2. Open the app in your browser

- **Look at the terminal** – it will print something like:
  - `>>> Server running: http://localhost:3000/`
  - or `Port 3000 is busy, using port 3001 instead` then `>>> Server running: http://localhost:3001/`

- **Open that exact URL** in Firefox (or Chrome):
  - If you see port **3001** → use **http://localhost:3001**
  - If you see port **3000** → use **http://localhost:3000**

If you get “Unable to connect”:

1. Make sure the server is still running (terminal window open, no errors).
2. Use the **port number shown** in the terminal (e.g. 3001, not 3000).
3. Try **http://127.0.0.1:3001** if **http://localhost:3001** fails.

## First time setup

- Copy `.env.local.example` to `.env.local` and fill in any required values.
- Run `pnpm install` and `pnpm db:push` if you haven’t already.
