/**
 * Market Impact / Capacity — Hedge fund style
 * Cap order size vs ADV so we don't move the market or trade illiquid.
 */

/** Option ADV = average daily volume (contracts). From chain or env. */
export interface CapacityInput {
  symbol: string;
  /** Requested quantity (contracts) */
  quantity: number;
  /** Average daily volume in options for this symbol (contracts). Use 0 if unknown. */
  optionAdv?: number;
  /** Max fraction of ADV we allow per order (e.g. 0.1 = 10%) */
  maxAdvFraction?: number;
  /** Absolute max contracts per order when ADV unknown */
  defaultMaxContracts?: number;
}

const DEFAULT_MAX_ADV_FRACTION = 0.1;
const DEFAULT_MAX_CONTRACTS = 50;

/**
 * Return allowed quantity (capped by ADV and absolute max).
 * Use before placeOrder to avoid trading size that would move the market.
 */
export function getMaxOrderSize(input: CapacityInput): number {
  const maxFrac = input.maxAdvFraction ?? DEFAULT_MAX_ADV_FRACTION;
  const absMax = input.defaultMaxContracts ?? DEFAULT_MAX_CONTRACTS;
  if (input.optionAdv != null && input.optionAdv > 0) {
    const advCap = Math.max(1, Math.floor(input.optionAdv * maxFrac));
    return Math.min(input.quantity, advCap, absMax);
  }
  return Math.min(input.quantity, absMax);
}

/**
 * Check if order size is within capacity (no-op if within; returns capped size if over).
 */
export function capOrderSize(input: CapacityInput): { allowed: number; capped: boolean } {
  const allowed = getMaxOrderSize(input);
  const capped = allowed < input.quantity;
  return { allowed, capped };
}
