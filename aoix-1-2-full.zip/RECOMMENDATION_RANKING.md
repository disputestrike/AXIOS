# How We Choose the Best Recommendations

## Goal

We scan **as many stocks as possible** (100+ from `REAL_STOCK_SYMBOLS`) and return the **top 100** best-of-best opportunities, with optional **filters** so you can narrow by strategy, regime, min score, min win probability, or symbol search.

## Ranking Formula (Composite Score)

The **best** recommendations are chosen by a **composite score** that combines:

| Factor | Weight | Description |
|--------|--------|-------------|
| **Score** | 35% | Opportunity score 0–100 (signal confidence, volume, momentum, IV rank, 52w range). |
| **Win probability** | 40% | Stored 0–1 (e.g. 0.70 = 70%); higher = more likely to profit. |
| **Expected return** | 25% | % expected move; capped for sanity. |
| **Signal confidence** | 20% | Regime/signal conviction 0–1. |
| **High-growth bias** | Bonus | Momentum (`priceChangePercent`) + expected return; favors high-growth names. |

Sort order: **descending composite score**. We then take the **top N** (default **100**).

- **Why top 100?** So we check as many stocks as possible and surface the best 100, not just 20.
- **Why high-growth bias?** Extra weight on momentum and expected return surfaces high-growth opportunities.

## All Known Strategies

Strategies and structures are defined in one place: `server/strategy-types.ts`.

- **Strategy types (engine):** `adaptive`, `wheel`, `short_term`, `iron_condor`.
- **Structure types (filters/execution):** iron_condor, iron_butterfly, vertical_call_spread, vertical_put_spread, calendar_spread, diagonal_spread, straddle, strangle, butterfly, cash_secured_put, covered_call.
- **Regimes (filters):** bull, bear, mean_reverting.

The API `getKnownStrategies` returns these for filter dropdowns so the UI and backend stay in sync.

## Filters

You can narrow the top 100 with:

- **Strategy (structure type):** e.g. only vertical call spreads or iron condors.
- **Regime:** bull, bear, mean_reverting.
- **Min score (0–100):** drop low-score names.
- **Min win probability % (0–100):** e.g. only ≥ 70% win prob.
- **Symbol search:** e.g. "NVDA" or "AAPL".

Filters are applied **before** sorting by composite score; then we take the top 100 of the filtered list.

## Data Flow

1. **Scan:** `marketScanner.scan()` runs over all `UNIQUE_SYMBOLS` (100+), fetches real Yahoo Finance data, computes regime, signal, structure, score, win probability, expected return.
2. **Filter (optional):** Apply min score, min win prob, structure type, regime, symbol search.
3. **Rank:** Sort by `compositeScore` (descending).
4. **Slice:** Return top `count` (default 100).

All strategies and the ranking formula are implemented in `server/market-scanner.ts` and exposed via `getTopOpportunities` and `getKnownStrategies`.
