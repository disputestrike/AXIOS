# AOIX-1 Local Startup Script for Windows PowerShell
# This script starts AOIX-1 locally with proper configuration

$ErrorActionPreference = "Stop"

Write-Host "================================" -ForegroundColor Cyan
Write-Host "AOIX-1 Local Startup" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""

# Check prerequisites
Write-Host "Checking prerequisites..." -ForegroundColor Yellow

# Check Node.js
try {
    $nodeVersion = node --version
    $nodeMajorVersion = [int]($nodeVersion -replace 'v(\d+)\..*', '$1')
    if ($nodeMajorVersion -lt 22) {
        Write-Host "❌ Node.js version 22+ required. Current version: $nodeVersion" -ForegroundColor Red
        Write-Host "   Please install Node.js 22+ from https://nodejs.org/" -ForegroundColor Red
        exit 1
    }
    Write-Host "✅ Node.js $nodeVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Node.js not found. Please install Node.js 22+ from https://nodejs.org/" -ForegroundColor Red
    exit 1
}

# Check pnpm
try {
    $pnpmVersion = pnpm --version
    Write-Host "✅ pnpm $pnpmVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ pnpm not found. Install with: npm install -g pnpm" -ForegroundColor Red
    exit 1
}

Write-Host ""

# Check .env.local exists
if (-not (Test-Path ".env.local")) {
    Write-Host "❌ .env.local not found!" -ForegroundColor Red
    Write-Host ""
    Write-Host "Please create .env.local with your configuration:" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "You can copy from .env.local.example:" -ForegroundColor Yellow
    Write-Host "  Copy-Item .env.local.example .env.local" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Then edit .env.local and fill in your actual values." -ForegroundColor Yellow
    Write-Host ""
    exit 1
}

Write-Host "✅ .env.local found" -ForegroundColor Green
Write-Host ""

# Check IB Gateway (optional, just warn if not available)
Write-Host "Checking IB Gateway connection..." -ForegroundColor Yellow
try {
    $tcpClient = New-Object System.Net.Sockets.TcpClient
    $tcpClient.Connect("localhost", 4001)
    $tcpClient.Close()
    Write-Host "✅ IB Gateway is running on localhost:4001" -ForegroundColor Green
} catch {
    Write-Host "⚠️  IB Gateway not responding on localhost:4001" -ForegroundColor Yellow
    Write-Host "   Make sure IB Gateway is running and API is enabled" -ForegroundColor Yellow
    Write-Host "   (Configuration → API → Settings → Enable ActiveX and Socket Clients)" -ForegroundColor Yellow
    Write-Host ""
}

Write-Host ""
Write-Host "Installing dependencies..." -ForegroundColor Yellow
pnpm install --frozen-lockfile

Write-Host ""
Write-Host "Running database migrations..." -ForegroundColor Yellow
try {
    pnpm db:push
    Write-Host "✅ Database migrations completed" -ForegroundColor Green
} catch {
    Write-Host "⚠️  Database migration failed. Continuing anyway..." -ForegroundColor Yellow
    Write-Host "   Make sure DATABASE_URL is correct in .env.local" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "================================" -ForegroundColor Cyan
Write-Host "Starting AOIX-1 Development Server" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Frontend: http://localhost:5173" -ForegroundColor Green
Write-Host "API: http://localhost:3000" -ForegroundColor Green
Write-Host ""
Write-Host "Press Ctrl+C to stop" -ForegroundColor Yellow
Write-Host ""

# Start development server
pnpm dev
