# 🧪 Local Testing Guide - AOIX-1

## Quick Summary

**Good News:** You can test locally **WITHOUT** IB Gateway! The system works with Yahoo Finance data.

**Better News:** IB Gateway is **OPTIONAL** but provides better data (real-time prices, Greeks, options chains).

---

## Option 1: Test WITHOUT IB Gateway ✅ (Easiest)

### What You Get:
- ✅ Real stock prices from Yahoo Finance
- ✅ Real options data (IV, put/call ratio)
- ✅ Paper trading simulation
- ✅ All advanced features work
- ✅ Pattern recognition
- ✅ Multi-timeframe analysis
- ✅ Kelly Criterion sizing
- ✅ Adaptive risk management

### Setup Steps:

1. **Install dependencies:**
   ```bash
   pnpm install
   ```

2. **Configure `.env.local`:**
   ```env
   # Database (required)
   DATABASE_URL=mysql://user:password@localhost:3306/aoix1
   
   # JWT Secret (required)
   JWT_SECRET=your-generated-secret-here
   
   # OAuth/Forge API keys (from Manus)
   VITE_APP_ID=your_app_id
   OWNER_OPEN_ID=your_open_id
   BUILT_IN_FORGE_API_KEY=your_api_key
   VITE_FRONTEND_FORGE_API_KEY=your_frontend_key
   
   # IB Gateway (OPTIONAL - leave as default or don't set)
   TWS_HOST=localhost
   TWS_PORT=4001
   ```

3. **Setup database:**
   ```bash
   # Create database (if local MySQL)
   mysql -u root -p
   CREATE DATABASE aoix1;
   
   # Run migrations
   pnpm db:push
   ```

4. **Start the system:**
   ```bash
   pnpm dev
   ```

5. **Access:**
   - Frontend: http://localhost:5173
   - API: http://localhost:3000

### What Happens:
- System automatically uses Yahoo Finance for market data
- No IB Gateway needed
- All features work perfectly
- Paper trading mode (simulated execution)

---

## Option 2: Test WITH IB Gateway ✅ (Better Data)

### What You Get (Additional):
- ✅ Real-time market data (faster updates)
- ✅ Real option Greeks (delta, gamma, theta, vega)
- ✅ More accurate options chains
- ✅ Better signal quality
- ✅ Can execute real trades (if live account)

### Setup Steps:

#### Step 1: Install IB Gateway

1. **Download IB Gateway:**
   - Visit: https://www.interactivebrokers.com/en/trading/platforms/ib-gateway.php
   - Download for your OS (Windows/Mac/Linux)
   - Install following IB instructions

2. **Launch IB Gateway:**
   - Start the application
   - Log in with your IB credentials
   - Select **Paper Trading** (recommended for testing)

#### Step 2: Configure IB Gateway API

**Important:** There are TWO different IB Gateway APIs:

### A. Client Portal API (Port 4001) - Recommended for AOIX-1

1. **Enable Client Portal:**
   - IB Gateway uses Client Portal API by default
   - Runs on port **4001** (HTTP REST API)
   - No special configuration needed

2. **Verify it's running:**
   ```bash
   # Test connection
   curl http://localhost:4001/v1/iserver/account
   ```
   
   If you see JSON with account info, it's working!

3. **Configure `.env.local`:**
   ```env
   TWS_HOST=localhost
   TWS_PORT=4001
   ```

### B. TWS API (Port 7497) - Alternative

If you want to use the traditional TWS API:

1. **Enable TWS API:**
   - In IB Gateway: **Settings** → **API**
   - Enable **ActiveX and Socket Clients**
   - Set **Socket Port** to `7497`
   - Allow connections from **localhost only**
   - Click **Apply** and restart

2. **Configure `.env.local`:**
   ```env
   TWS_HOST=localhost
   TWS_PORT=7497
   ```

**Note:** AOIX-1 primarily uses the Client Portal API (port 4001) for market data.

#### Step 3: Start AOIX-1

```bash
pnpm dev
```

The system will:
- ✅ Automatically detect IB Gateway
- ✅ Connect to port 4001 (Client Portal API)
- ✅ Use real-time market data
- ✅ Get real option Greeks
- ✅ Fall back to Yahoo Finance if Gateway unavailable

---

## Testing Checklist

### Without IB Gateway:
- [ ] System starts without errors
- [ ] Frontend loads at http://localhost:5173
- [ ] Market scanner shows real stocks
- [ ] Opportunities page displays data
- [ ] Auto Trading page works
- [ ] Can start paper trading engine

### With IB Gateway:
- [ ] IB Gateway is running and logged in
- [ ] Gateway connection test passes: `curl http://localhost:4001/v1/iserver/account`
- [ ] System Health page shows "Gateway Connected"
- [ ] Market data updates in real-time
- [ ] Options chains show real Greeks
- [ ] Auto Trading engine can start

---

## What to Test

### 1. Market Scanner
- Go to **Market Opportunities** page
- Should show real stocks with real prices
- Signals should be generated
- Opportunities should be ranked

### 2. Auto Trading
- Go to **Auto Trading** page
- Click **Start Engine**
- Watch it scan markets
- Monitor for trade opportunities
- Check position management

### 3. System Health
- Go to **System Health** page
- Check all components are green
- Verify Gateway status (if using)
- Monitor performance metrics

### 4. Performance Metrics
- Check **Performance** tab
- Verify Sharpe ratio calculation
- Check Max Drawdown calculation
- Monitor win rate and profit factor

---

## Troubleshooting

### Issue: "Gateway not connecting"

**Solution:**
1. Verify IB Gateway is running: `curl http://localhost:4001/v1/iserver/account`
2. Check Gateway is logged in
3. Verify port 4001 is not blocked by firewall
4. Check `.env.local` has correct `TWS_HOST` and `TWS_PORT`
5. System will work without Gateway (uses Yahoo Finance)

### Issue: "No market data"

**Solution:**
1. If using Gateway: Check connection status
2. System automatically falls back to Yahoo Finance
3. Check internet connection
4. Verify symbols are valid (AAPL, MSFT, TSLA, etc.)

### Issue: "Database connection failed"

**Solution:**
1. Check `DATABASE_URL` in `.env.local`
2. Verify database exists
3. Check MySQL is running (if local)
4. Run `pnpm db:push` to create tables

### Issue: "Port already in use"

**Solution:**
1. Change `PORT` in `.env.local` to different port (e.g., 3001)
2. Or kill process using port 3000

---

## Key Points

1. **IB Gateway is OPTIONAL** - System works great without it
2. **Yahoo Finance is default** - Always available, always works
3. **Gateway improves data quality** - But not required for testing
4. **Paper trading is safe** - No real money at risk
5. **All features work** - Advanced signals, sizing, risk management all work

---

## Recommended Testing Flow

### Phase 1: Test Without Gateway (Day 1)
1. Start system without IB Gateway
2. Verify all features work
3. Test market scanner
4. Test auto trading engine
5. Monitor performance

### Phase 2: Add Gateway (Day 2)
1. Install and configure IB Gateway
2. Connect to Gateway
3. Compare data quality
4. Test with real-time data
5. Validate all features still work

### Phase 3: Paper Trading (Week 1)
1. Run paper trading for 1 week
2. Monitor performance metrics
3. Check win rate, Sharpe ratio
4. Validate risk management
5. Fine-tune parameters

### Phase 4: Live Trading (After Validation)
1. Only after paper trading validation
2. Start with reduced position sizes
3. Monitor closely
4. Gradually increase size

---

## What I Need From You

To help you test locally, tell me:

1. **Do you have IB Gateway?**
   - [ ] Yes, installed and ready
   - [ ] No, want to test without it first
   - [ ] Need help installing

2. **What's your current status?**
   - [ ] Haven't started yet
   - [ ] Installing dependencies
   - [ ] Configuring environment
   - [ ] Trying to start system
   - [ ] System running, testing features

3. **Any errors?**
   - Paste error messages
   - I'll help fix them

4. **What do you want to test?**
   - [ ] Just verify it runs
   - [ ] Test market scanner
   - [ ] Test auto trading
   - [ ] Test with IB Gateway
   - [ ] Full end-to-end test

---

## Quick Start Commands

```bash
# 1. Install
pnpm install

# 2. Setup database
pnpm db:push

# 3. Verify
pnpm verify

# 4. Start
pnpm dev

# 5. Access
# Frontend: http://localhost:5173
# API: http://localhost:3000
```

---

**Ready to test?** Start with Option 1 (without Gateway) - it's the easiest way to get started! 🚀
