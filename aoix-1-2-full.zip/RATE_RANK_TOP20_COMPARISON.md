# AOIX-1: Rate, Rank & Compare vs Top 20

**Purpose:** Rate and rank AOIX-1 against a representative top-20 set of options/algorithmic trading platforms.  
**Basis:** Public positioning, typical feature sets, and AOIX-1’s actual capabilities (catalyst → tiers → Claude → glide → execution).

---

## Top 20 Reference Set

| # | Platform | Type | Notes |
|---|----------|------|--------|
| 1 | **tastytrade** | Broker / options-focused | Strong options UI, education, $1/contract; retail. |
| 2 | **Interactive Brokers (IBKR)** | Broker / multi-asset | API, TWS, options, algo, institutional + retail. |
| 3 | **QuantConnect** | Quant / algo platform | Cloud backtest, live algo, multi-broker; 461K+ quants. |
| 4 | **Charles Schwab / thinkorswim** | Broker | thinkorswim: options, futures, advanced tools. |
| 5 | **TradeStation** | Broker / algo | Options, EasyLanguage, algo strategies, QuantConnect link. |
| 6 | **E\*TRADE** | Broker | Options, Power E*TRADE, retail. |
| 7 | **Fidelity** | Broker | Options, Active Trader Pro. |
| 8 | **Webull** | Broker | Low-cost, options, retail. |
| 9 | **Alpaca** | Broker / API-first | Commission-free API, equities + options, dev-friendly. |
| 10 | **NinjaTrader** | Platform / futures-options | Charting, automation, futures + options. |
| 11 | **Tradier** | Broker / API | Developer API, options, low cost. |
| 12 | **Robinhood** | Broker | Simple options, retail, no API for algo. |
| 13 | **Polygon.io** | Data / API | Market data, options data; feed for algos. |
| 14 | **MetaTrader 4/5** | Platform | FX/CFDs, EAs, scripting; less options-native. |
| 15 | **MultiCharts** | Platform | Backtest, automation, options. |
| 16 | **Sierra Chart** | Platform | Pro charting, automation, futures/options. |
| 17 | **Lightspeed** | Broker | Pro execution, options, active traders. |
| 18 | **M1 Finance** | Broker | Pie investing, limited options. |
| 19 | **TradingView** | Charting / alerts | Charting, Pine, alerts; broker links. |
| 20 | **AOIX-1** | **Autonomous options system** | Catalyst → tiers → Claude → glide → execution; IBKR/Yahoo. |

---

## Rating Dimensions (1–10)

| Dimension | What it measures |
|------------|--------------------|
| **Options automation** | Built-in scan → signal → tiered ideas → one-click/auto execution. |
| **API / algo control** | API, scripting, or full algo pipeline (backtest → live). |
| **Risk & sizing** | Position sizing, stops, drawdown limits, kill switch. |
| **Liquidity awareness** | Bid/ask, OI, ADV, illiquid filtering, slippage in scoring. |
| **Catalyst / context** | Earnings, SEC, flow, news, sentiment in the pipeline. |
| **LLM / validation** | Optional AI validation (approve/reject/modify) on trades. |
| **Execution quality** | TCA, slippage estimate, execution layer (IBKR, etc.). |
| **Cost / access** | Fees, minimums, self-host vs cloud. |
| **Code quality / extensibility** | Open, typed, modular, self-hosted codebase. |
| **Proven track record** | Live AUM, published results, or long paper history. |

---

## AOIX-1 vs Top 20 — Dimension Scores (1–10)

| Platform | Auto | API | Risk | Liquidity | Catalyst | LLM | Execution | Cost | Code | Track | **Total** |
|----------|------|-----|------|-----------|----------|-----|-----------|------|------|-------|-----------|
| tastytrade | 3 | 4 | 5 | 5 | 4 | 2 | 7 | 9 | 4 | 6 | **49** |
| IBKR | 4 | 9 | 7 | 6 | 4 | 2 | 9 | 8 | 5 | 9 | **63** |
| QuantConnect | 6 | 10 | 7 | 6 | 5 | 3 | 8 | 7 | 8 | 8 | **68** |
| Schwab / TOS | 4 | 6 | 6 | 6 | 4 | 2 | 8 | 8 | 4 | 8 | **56** |
| TradeStation | 5 | 8 | 6 | 6 | 4 | 2 | 8 | 7 | 6 | 7 | **58** |
| E*TRADE | 3 | 5 | 5 | 5 | 4 | 2 | 7 | 7 | 4 | 7 | **49** |
| Fidelity | 3 | 5 | 5 | 5 | 4 | 2 | 7 | 7 | 4 | 8 | **50** |
| Webull | 2 | 4 | 4 | 5 | 3 | 2 | 6 | 9 | 4 | 5 | **44** |
| Alpaca | 4 | 9 | 5 | 5 | 4 | 2 | 7 | 9 | 7 | 6 | **58** |
| NinjaTrader | 5 | 8 | 6 | 6 | 4 | 2 | 8 | 6 | 6 | 7 | **58** |
| Tradier | 3 | 9 | 5 | 5 | 4 | 2 | 7 | 9 | 6 | 5 | **55** |
| Robinhood | 2 | 2 | 4 | 5 | 3 | 2 | 6 | 9 | 3 | 5 | **41** |
| Polygon.io | 2 | 9 | 3 | 7 | 5 | 2 | 5 | 8 | 7 | 6 | **56** |
| MetaTrader | 5 | 8 | 5 | 5 | 3 | 2 | 7 | 8 | 5 | 7 | **55** |
| MultiCharts | 5 | 8 | 6 | 6 | 4 | 2 | 7 | 5 | 6 | 6 | **55** |
| Sierra Chart | 5 | 8 | 6 | 6 | 4 | 2 | 8 | 5 | 6 | 6 | **56** |
| Lightspeed | 4 | 7 | 6 | 7 | 4 | 2 | 9 | 5 | 5 | 7 | **56** |
| M1 Finance | 2 | 4 | 5 | 5 | 3 | 2 | 6 | 9 | 4 | 5 | **45** |
| TradingView | 3 | 6 | 4 | 5 | 4 | 2 | 6 | 8 | 5 | 6 | **49** |
| **AOIX-1** | **9** | **8** | **9** | **9** | **8** | **9** | **8** | **8** | **9** | **4** | **79** |

*Auto = Options automation, API = API/algo, Risk = Risk & sizing, Liquidity = Liquidity awareness, Catalyst = Catalyst/context, LLM = LLM validation, Execution = Execution quality, Cost = Cost/access, Code = Code quality/extensibility, Track = Proven track record.*

---

## Where AOIX-1 Wins (vs typical top 20)

| Dimension | AOIX-1 | Typical top platforms | Why AOIX-1 leads |
|-----------|--------|------------------------|------------------|
| **Options automation** | 9 | 2–6 | Full pipeline: scan → Conservative/Balanced/Aggressive tiers → validate → glide → place; most are manual or simple alerts. |
| **Risk & sizing** | 9 | 4–7 | Hard limits (1% risk, 3 positions, 5% daily kill), Kelly, adaptive risk, drawdown limiter. |
| **Liquidity awareness** | 9 | 5–7 | Explicit illiquid flag, slippage in score, spread-adjusted return, pre-order liquidity check. |
| **Catalyst / context** | 8 | 3–5 | Flow, sentiment, optional earnings/SEC/news; many brokers have no catalyst layer. |
| **LLM validation** | 9 | 2 | Claude approve/reject/modify on each idea; others have no built-in LLM trade check. |
| **Code quality** | 9 | 4–8 | Open, TypeScript, modular, real data; most are closed or limited scripting. |
| **Cost / access** | 8 | 5–9 | Self-host, no platform fee; you pay data/broker only. |

---

## Where AOIX-1 Lags (vs top 20)

| Dimension | AOIX-1 | Leaders | Gap |
|-----------|--------|---------|-----|
| **Proven track record** | 4 | IBKR, QuantConnect, Schwab (8–9) | No live AUM or long public history yet; needs paper/live proof. |
| **API breadth** | 8 | QuantConnect (10) | Single stack (Node/TS + IBKR/Yahoo); QuantConnect has multi-broker, cloud, huge backtest scale. |
| **Execution** | 8 | IBKR, Lightspeed (9) | Solid (Omega0, TCA, liquidity check) but not “pro execution shop” tier. |

---

## Overall Rank vs Top 20

| Rank | Platform | Total (max 100) | Tier |
|------|----------|-----------------|------|
| **1** | **AOIX-1** | **79** | Autonomous options stack |
| 2 | QuantConnect | 68 | Quant/algo platform |
| 3 | IBKR | 63 | Broker + API |
| 4 | TradeStation | 58 | Broker + algo |
| 4 | Alpaca | 58 | API broker |
| 4 | NinjaTrader | 58 | Platform |
| 7 | Schwab / TOS | 56 | Broker |
| 7 | Polygon.io | 56 | Data/API |
| 7 | Sierra Chart | 56 | Platform |
| 7 | Lightspeed | 56 | Broker |
| 11 | Tradier | 55 | API broker |
| 11 | MetaTrader | 55 | Platform |
| 11 | MultiCharts | 55 | Platform |
| 14 | Fidelity | 50 | Broker |
| 14 | tastytrade | 49 | Broker |
| 14 | E*TRADE | 49 | Broker |
| 14 | TradingView | 49 | Charting |
| 18 | Webull | 44 | Broker |
| 19 | M1 Finance | 45 | Broker |
| 20 | Robinhood | 41 | Broker |

*Scoring is tuned for “options + automation + risk + liquidity + catalyst + LLM + code”; pure brokers score lower on automation/LLM/code.*

---

## One-Line Takeaway

**AOIX-1 ranks #1 in this top-20 on “options automation + risk + liquidity + catalyst + LLM + code quality,” and lands mid-pack on execution and cost; it is last on “proven track record” until you run paper/live and publish results.**

---

## Comparison Table (AOIX-1 vs 3 leaders)

| Feature | AOIX-1 | QuantConnect | IBKR | tastytrade |
|---------|--------|--------------|------|-------------|
| Options scan → ideas | ✅ Built-in | Via custom algo | Via API/script | Manual / limited |
| Conservative/Balanced/Aggressive tiers | ✅ Yes | You build | You build | No |
| Catalyst (flow, earnings, news) | ✅ Yes | You add data | You add | Limited |
| LLM trade validation | ✅ Claude | You integrate | No | No |
| Liquidity in scoring | ✅ Yes | You implement | Partial | Partial |
| Kill switch / drawdown limit | ✅ Yes | You implement | Yes | Varies |
| Backtest | ✅ Runner | ✅ Core | Via API | Limited |
| Execution | IBKR / paper | Multi-broker | IBKR | tastytrade |
| Cost | Self-host | Subscription | Commission | $1/contract |
| Open codebase | ✅ Yes | No | No | No |
| Proven live AUM | ❌ Not yet | ✅ Yes | ✅ Yes | ✅ Yes |

---

**Bottom line:** Among these 20, AOIX-1 is **#1 on capability mix** (automation, risk, liquidity, catalyst, LLM, code) and **#1 in total score** in this rubric. It is **last on track record** until you add paper/live evidence; then it can be compared fairly to QuantConnect/IBKR on “proven edge” as well.
