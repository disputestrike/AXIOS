# AOIX-1 Market Regimes — Exhaustive Reference

**Do not change** the backtest regime→action logic or the app regime→structure mappings without **explicit user confirmation**. This document is the single source of truth for regimes and appropriate actions.

---

## Exhaustive List of Regimes (11 total)

The system uses **exactly** these eleven regimes. They are defined in:

- Type: `server/services.ts` → `RegimeType` / `RegimeAnalysis["regime"]`
- Classification (live): `server/services.ts` → `analyzeRegime()`, `server/market-scanner.ts`, `server/advanced-signals.ts` → `determineRegime()`
- Backtest: `server/backtest-runner.ts` (trend + volPct → regime)

| # | Regime ID | Description |
|---|-----------|-------------|
| 1 | `bull_vol_compression` | Bullish trend, low/decreasing volatility |
| 2 | `bull_vol_expansion` | Bullish trend, high/increasing volatility |
| 3 | `bear_vol_compression` | Bearish trend, low/decreasing volatility |
| 4 | `bear_vol_expansion` | Bearish trend, high/increasing volatility |
| 5 | `mean_reverting` | Neutral trend, low vol; price tends to stay in range (chop) |
| 6 | `chaotic` | Unstable; high vol, unclear trend, high liquidity stress (LSI > 0.7) |
| 7 | `crisis` | Extreme stress; LSI > 0.85 (or very high vol in scanner) |
| 8 | `liquidity_drought` | Very low liquidity (orderBookDepth < 50 in services; volumeRatio < 0.5 in scanner) |
| 9 | `trending_bull` | Strong upward momentum; |trend| > 5% |
| 10 | `trending_bear` | Strong downward momentum; |trend| > 5% |
| 11 | `sector_rotation` | Sector leadership rotating; set when sector data available (placeholder) |

**We use all 11 regimes** for classification (backtest and live). The backtest *filter* (which regimes are allowed to take a trade) defaults to **3**: `bull_vol_compression`, `mean_reverting`, `trending_bull`. That default is permanent in `scripts/run-full-backtest.ts` unless you set `BACKTEST_REGIMES=` (empty = all directions) or override with a custom list.

---

## Will More Regimes Help Make Money?

**Yes, if we use them correctly.**

- **Crisis / liquidity_drought:** Cut size and avoid illiquid names → **protect capital** in stress and thin markets. That directly helps avoid blow-ups.
- **Trending (momentum):** Size up slightly in strong trends and use directional structures (call/put spreads) → **capture more when we’re right** without over-trading chop.
- **Sector_rotation:** When we have sector leadership data, we can favor structures in leading sectors and stay neutral in rotating chop → **better allocation**.

So: **crisis** and **liquidity_drought** help **preserve** money; **trending** and **sector_rotation** (with data) help **capture** more. The edge comes from (1) clear rules, (2) distinct actions (sizing + structure), and (3) **backtesting and monitoring** to confirm they improve risk-adjusted returns. Adding regimes alone doesn’t guarantee profit—we have to validate with data.

---

## What We Do Appropriately (By Context)

### 1. Backtest (historical simulation)

Used in `server/backtest-runner.ts`. Simulates **option-style P&L** per regime:

| Regime | Simulated action | Rationale |
|--------|------------------|-----------|
| `crisis` | **Long put** | Defensive; protect in extreme vol |
| `trending_bull` | **Sell put** | Premium collection in strong up trend |
| `trending_bear` | **Long put** | Directional downside |
| `bull_vol_compression` | **Sell put** | Premium collection; profit when put expires worthless (flat/up) |
| `mean_reverting` | **Sell put** | Same; premium selling in calm range |
| `bear_vol_compression` | **Long put** | Directional downside |
| `bear_vol_expansion` | **Long put** | Directional downside |
| `bull_vol_expansion` | **Long call** | Directional upside in vol expansion |
| `chaotic` | **Long call** | Simplified; in practice could be long straddle or reduced size |

- **Sell-premium regimes** (for backtest): `bull_vol_compression`, `mean_reverting`, `trending_bull`.
- **liquidity_drought / sector_rotation:** Not classified in backtest (no liquidity/sector data in historical series); in live they reduce size and use neutral structures.
- **Filtering:** Backtest uses **all 11 regimes** for classification; which bars we *take* is controlled by `BACKTEST_REGIMES`. **Default (permanent):** `bull_vol_compression`, `mean_reverting`, `trending_bull` (best Sharpe/P&L). Set `BACKTEST_REGIMES=` (empty) to trade all 11 regimes / all directions. Set to a comma list to override (e.g. only bull, or custom).
- **Optimization:** Run `pnpm backtest:optimal` to grid-search hold days (3–7), risk (0.8–2%), and regime on/off. **Default backtest** uses **hold 5 days**, **risk 1%** for higher total return. For best risk-adjusted (Sharpe, low DD) set `BACKTEST_HOLD_DAYS=3` and `BACKTEST_RISK_PER_TRADE=0.008`.

### 2. Strategy types vs structure types (truth)

- **4 strategy types** (engine modes): `wheel`, `short_term`, `iron_condor`, `adaptive`. These are the only “strategies” the engine supports; they are not “the best” from backtest — they are the app’s strategy set.
- **12+ structure types** (what gets recommended per opportunity): iron_condor, iron_butterfly, vertical_call_spread, vertical_put_spread, calendar_spread, straddle, strangle, butterfly, cash_secured_put, covered_call, diagonal_spread, etc. The app recommends **structures** (iron condor, butterfly, vertical spread, etc.); variety comes from regime + symbol in `selectOptimalStructure(regime, conf, ..., symbolHint)` so you see iron condors, butterflies, verticals, CSPs, calendars — not only vertical spread.

### 3. App / Scanner (live structure selection)

Used in `server/services.ts` → `selectOptimalStructure(regime, ..., symbolHint)`. Picks **option structures** per regime (and symbol for variety):

| Regime | Typical structures (examples) |
|--------|-------------------------------|
| `bull_vol_compression` | vertical_call_spread, covered_call, cash_secured_put |
| `bull_vol_expansion` | vertical_call_spread, straddle, strangle |
| `bear_vol_compression` | vertical_put_spread, iron_condor |
| `bear_vol_expansion` | iron_condor, vertical_put_spread, iron_butterfly |
| `mean_reverting` | iron_condor, iron_butterfly, calendar_spread |
| `chaotic` | calendar_spread, iron_condor, strangle |
| `crisis` | vertical_put_spread, calendar_spread, iron_condor (defensive) |
| `liquidity_drought` | calendar_spread, iron_condor (small size) |
| `trending_bull` | vertical_call_spread, cash_secured_put |
| `trending_bear` | vertical_put_spread, iron_condor |
| `sector_rotation` | iron_condor, calendar_spread |

Exact choices vary by hash(regime + ivPercentile + confidence) to get variety across symbols.

### 3. Strategy–regime fit (engine)

Used in `server/strategy-types.ts` → `isRegimeFavorableForStrategy()`, `getPreferredStructureForRegime()`:

- **Wheel / short_term:** favored in bull and trending_bull regimes.
- **Iron_condor / short_term:** favored in bear, mean_reverting, chaotic, crisis, liquidity_drought, sector_rotation, trending_bear.
- **Adaptive:** uses `selectOptimalStructure` as-is (regime-based).

### 5. Risk / sizing (adaptive-risk)

- **crisis:** risk ×0.25, position size 15%.
- **liquidity_drought:** risk ×0.5, position size 40%.
- **trending_bear / bear_vol_expansion / chaotic:** risk reduced, position size 25%.
- **trending_bull:** position size 120% (conviction).
- **bull_vol_compression:** position size 150% (hedge fund style).

---

## Summary Table (Exhaustive)

| Regime | Backtest action | App structures (representative) |
|--------|-----------------|---------------------------------|
| crisis | Long put | Put spread, calendar, iron condor |
| liquidity_drought | (not in backtest) | Calendar, iron condor |
| trending_bull | Sell put | Call spread, CSP |
| trending_bear | Long put | Put spread, iron condor |
| sector_rotation | (not in backtest) | Iron condor, calendar |
| bull_vol_compression | Sell put | CSP, covered call, vertical call spread |
| bull_vol_expansion | Long call | Vertical call spread, straddle, strangle |
| bear_vol_compression | Long put | Vertical put spread, iron condor |
| bear_vol_expansion | Long put | Iron condor, vertical put spread, iron butterfly |
| mean_reverting | Sell put | Iron condor, iron butterfly, calendar spread |
| chaotic | Long call (simplified) | Calendar spread, iron condor, strangle |

---

**Do not change the above mappings or backtest logic without explicit user confirmation.**
