/**
 * Risk Metrics — Max loss, max profit, breakevens for options structures.
 * Used by omega0 for estimateOrderCost and UI risk display.
 */

const W = 5; // strike width for spreads

export function getMaxLossEstimate(
  structureType: string,
  center: number,
  estimatedCost: number,
  quantity: number
): number {
  const norm = (structureType || "").toLowerCase().replace(/\s+/g, "_");
  const q = Math.max(1, quantity);
  if (norm.includes("cash_secured_put") || norm === "csp") {
    return center * 100 * q + Math.min(0, estimatedCost);
  }
  if (norm.includes("covered_call")) return 0;
  if (norm.includes("vertical_call") || norm.includes("vertical_put")) {
    return W * 100 * q + Math.min(0, estimatedCost);
  }
  if (norm.includes("iron_condor") || norm.includes("iron_butterfly")) {
    return 2 * W * 100 * q + Math.min(0, estimatedCost);
  }
  if (norm.includes("butterfly") && !norm.includes("iron")) {
    return Math.max(0, estimatedCost);
  }
  if (norm.includes("straddle") || norm.includes("strangle")) {
    return Math.max(0, estimatedCost);
  }
  if (norm.includes("calendar") || norm.includes("diagonal")) {
    return Math.max(0, estimatedCost);
  }
  return Math.abs(estimatedCost);
}

export function getMaxProfitEstimate(
  structureType: string,
  center: number,
  estimatedCost: number,
  quantity: number
): number {
  const norm = (structureType || "").toLowerCase().replace(/\s+/g, "_");
  const q = Math.max(1, quantity);
  const credit = -Math.min(0, estimatedCost);
  const debit = Math.max(0, estimatedCost);
  if (norm.includes("cash_secured_put") || norm === "csp") {
    return credit;
  }
  if (norm.includes("covered_call")) return 0;
  if (norm.includes("vertical_call") || norm.includes("vertical_put")) {
    return credit;
  }
  if (norm.includes("iron_condor") || norm.includes("iron_butterfly")) {
    return credit;
  }
  if (norm.includes("butterfly") && !norm.includes("iron")) {
    return W * 100 * q - debit;
  }
  if (norm.includes("straddle") || norm.includes("strangle")) {
    return Infinity;
  }
  if (norm.includes("calendar") || norm.includes("diagonal")) {
    return Infinity;
  }
  return Math.max(0, credit);
}

/** Breakeven price(s) at expiration. Returns array (one or two values). */
export function getBreakevens(
  structureType: string,
  center: number,
  estimatedCost: number
): number[] {
  const norm = (structureType || "").toLowerCase().replace(/\s+/g, "_");
  const credit = -Math.min(0, estimatedCost) / 100;
  const debit = Math.max(0, estimatedCost) / 100;
  if (norm.includes("vertical_call_spread")) {
    const low = center;
    const high = center + W;
    return [low + debit, high - credit];
  }
  if (norm.includes("vertical_put_spread")) {
    const low = center - W;
    const high = center;
    return [low + credit, high - debit];
  }
  if (norm.includes("iron_condor") || norm.includes("iron_butterfly")) {
    const putShort = center - W;
    const callShort = center + W;
    return [putShort - credit, callShort + credit];
  }
  if (norm.includes("butterfly") && !norm.includes("iron")) {
    const mid = center;
    const wing = W;
    return [mid - wing + debit, mid + wing - debit];
  }
  if (norm.includes("straddle") || norm.includes("strangle")) {
    const mid = center;
    return [mid - debit, mid + debit];
  }
  return [];
}
