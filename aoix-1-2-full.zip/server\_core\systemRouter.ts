import { z } from "zod";
import { notifyOwner } from "./notification";
import { adminProcedure, publicProcedure, router } from "./trpc";
import * as db from "../db";
import { getAutoTradingEngine } from "../auto-trading-engine";
import { getMarketScanner } from "../market-scanner";
import { checkTWSConnection } from "../tws-market-data";
import { runSystemAudit, type AuditTradeInput } from "../system-audit";
import { getLiquidityForAudit } from "../liquidity-for-audit";
import { runRegimeStrategyDiagnostic } from "../regime-strategy-diagnostic";

interface HealthComponent {
  component: string;
  status: 'healthy' | 'warning' | 'error';
  lastCheck: number;
  responseTimeMs?: number;
  error?: string;
  details?: Record<string, any>;
}

// ============================================================================
// CORE INFRASTRUCTURE CHECKS
// ============================================================================

async function checkDatabase(): Promise<HealthComponent> {
  const startTime = Date.now();
  const urlSet = !!(process.env.DATABASE_URL && process.env.DATABASE_URL.trim().length > 0);
  try {
    const dbInstance = await db.getDb();
    const responseTime = Date.now() - startTime;

    if (dbInstance) {
      return {
        component: 'Database',
        status: 'healthy',
        lastCheck: Date.now(),
        responseTimeMs: responseTime,
        details: { connected: true },
      };
    }
    if (urlSet) {
      return {
        component: 'Database',
        status: 'warning',
        lastCheck: Date.now(),
        responseTimeMs: responseTime,
        error: 'MySQL connection failed. Check: (1) MySQL is running, (2) user/password/database in .env.local are correct, (3) stop the server (Ctrl+C) and run pnpm dev again.',
        details: { connected: false, mode: 'fallback', hint: 'Restart the server after fixing .env.local' },
      };
    }
    return {
      component: 'Database',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      error: 'DATABASE_URL not set. Add DATABASE_URL=mysql://user:password@localhost:3306/aoix1 to .env.local (same folder as package.json), then stop the server (Ctrl+C) and run pnpm dev again.',
      details: { connected: false, mode: 'fallback', hint: 'File must be named .env.local in the project root' },
    };
  } catch (error) {
    return {
      component: 'Database',
      status: 'error',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkAPIServer(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const responseTime = Date.now() - startTime;
    return {
      component: 'API Server',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: {
        port: process.env.PORT || 3000,
        nodeEnv: process.env.NODE_ENV || 'development',
      },
    };
  } catch (error) {
    return {
      component: 'API Server',
      status: 'error',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkAuthentication(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { sdk } = await import("./sdk");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Authentication Service',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Authentication Service',
      status: 'error',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

// ============================================================================
// TRADING ENGINE CHECKS
// ============================================================================

async function checkTradingEngine(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const engine = getAutoTradingEngine();
    const state = engine.getState();
    const responseTime = Date.now() - startTime;
    
    return {
      component: 'Auto Trading Engine',
      status: state.isRunning ? 'healthy' : 'warning',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: {
        isRunning: state.isRunning,
        cycleCount: state.cycleCount,
        activePositions: state.positions.filter(p => p.status === 'open').length,
        currentRegime: state.currentRegime,
        accountBalance: state.accountBalance,
      },
    };
  } catch (error) {
    return {
      component: 'Auto Trading Engine',
      status: 'error',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkEnhancedTradingEngine(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { EnhancedTradingEngine } = await import("../enhanced-trading-engine");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Enhanced Trading Engine',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Enhanced Trading Engine',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

// ============================================================================
// MARKET DATA CHECKS
// ============================================================================

async function checkMarketData(): Promise<HealthComponent> {
  const startTime = Date.now();
  const port = process.env.TWS_PORT || '5000';
  const gatewayUrl = `http://localhost:${port}`;
  try {
    const { getIBMarketData, checkIBGatewayConnection } = await import('../ib-market-data');
    const { getDataQuality } = await import('../real-market-data');
    const connected = await checkIBGatewayConnection();
    if (!connected) {
      return {
        component: 'Market Data (IBKR)',
        status: 'warning',
        lastCheck: Date.now(),
        responseTimeMs: Date.now() - startTime,
        error: `IB Gateway not connected. Connect at ${gatewayUrl}`,
        details: { port, gatewayUrl },
      };
    }
    const testData = await getIBMarketData('SPY');
    const responseTime = Date.now() - startTime;
    const dataQuality = getDataQuality();

    if (testData?.price > 0) {
      return {
        component: 'Market Data (IBKR)',
        status: dataQuality.isStale ? 'warning' : 'healthy',
        lastCheck: Date.now(),
        responseTimeMs: responseTime,
        details: {
          provider: 'ibkr',
          testSymbol: 'SPY',
          testPrice: testData.price,
          cacheTtlMs: dataQuality.cacheTtlMs,
          priceCacheCount: dataQuality.priceCacheCount,
          optionsCacheCount: dataQuality.optionsCacheCount,
          maxAgeMs: dataQuality.maxAgeMs,
          isStale: dataQuality.isStale,
        },
      };
    }
    return {
      component: 'Market Data (IBKR)',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      error: `No SPY price from IB. Connect Gateway at ${gatewayUrl}`,
      details: { port, gatewayUrl, dataQuality: getDataQuality() },
    };
  } catch (error) {
    return {
      component: 'Market Data (IBKR)',
      status: 'error',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
      details: { port, gatewayUrl },
    };
  }
}

async function checkMarketDataService(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const marketDataService = await import("../marketDataService");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Market Data Service',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Market Data Service',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkMarketScanner(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const scanner = getMarketScanner();
    const opportunities = scanner.getTopOpportunities(1);
    const responseTime = Date.now() - startTime;
    
    const engine = getAutoTradingEngine();
    const state = engine.getState();
    
    return {
      component: 'Market Scanner',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: {
        cachedOpportunities: opportunities.length,
        lastScan: state.lastScanTime ? new Date(state.lastScanTime).toISOString() : 'Never',
        opportunitiesFound: state.lastOpportunities.length,
      },
    };
  } catch (error) {
    return {
      component: 'Market Scanner',
      status: 'error',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkMarketUtils(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { getRealVIX } = await import("../market-utils");
    const vix = await getRealVIX().catch(() => null);
    const responseTime = Date.now() - startTime;
    return {
      component: 'Market Utils',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { vixAvailable: vix !== null },
    };
  } catch (error) {
    return {
      component: 'Market Utils',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

// ============================================================================
// IBKR/TWS CHECKS
// ============================================================================

async function checkTWSConnectionHealth(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const connected = await checkTWSConnection();
    const responseTime = Date.now() - startTime;
    const host = process.env.TWS_HOST || 'localhost';
    const port = parseInt(process.env.TWS_PORT || '5000', 10);

    return {
      component: 'TWS/IB Gateway',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: {
        connected,
        host,
        port,
        note: connected ? 'Connected' : 'IB Gateway required',
      },
      error: undefined,
    };
  } catch (error) {
    return {
      component: 'TWS/IB Gateway',
      status: 'error',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkTWSAPIClient(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { TWSAPIClient } = await import("../tws-api-client");
    const responseTime = Date.now() - startTime;
    return {
      component: 'TWS API Client',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'TWS API Client',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkIBKRService(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { Omega0Engine } = await import("../ibkr");
    const responseTime = Date.now() - startTime;
    return {
      component: 'IBKR Service (Omega-0)',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'IBKR Service (Omega-0)',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkGatewayAdapter(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { getGatewayAdapter } = await import("../gateway-adapter");
    const { getAutoTradingEngine } = await import("../auto-trading-engine");
    const engine = getAutoTradingEngine();
    const adapter = getGatewayAdapter(engine);
    const responseTime = Date.now() - startTime;
    
    const isLive = adapter?.isLiveMode?.() || false;

    return {
      component: 'Gateway Adapter',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: {
        available: true,
        liveMode: isLive,
        mode: isLive ? 'Live' : 'Paper trading',
      },
      error: undefined,
    };
  } catch (error) {
    return {
      component: 'Gateway Adapter',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
      details: { available: false },
    };
  }
}

// ============================================================================
// SIGNAL & ANALYSIS CHECKS
// ============================================================================

async function checkAdvancedSignals(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { generateAdvancedSignal } = await import("../advanced-signals");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Advanced Signals',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Advanced Signals',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkAdaptiveRisk(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { calculateAdaptiveRisk } = await import("../adaptive-risk");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Adaptive Risk Management',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Adaptive Risk Management',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkRiskManager(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const engine = getAutoTradingEngine();
    const state = engine.getState();
    const riskMetrics = state.riskMetrics;
    const responseTime = Date.now() - startTime;
    
    return {
      component: 'Risk Manager',
      status: riskMetrics.killSwitchActive ? 'error' : 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: {
        killSwitchActive: riskMetrics.killSwitchActive,
        currentExposure: riskMetrics.currentExposure,
        dailyLossLimit: riskMetrics.dailyLossLimit,
        currentDailyLoss: riskMetrics.currentDailyLoss,
        positionCount: riskMetrics.positionCount,
        maxPositions: riskMetrics.maxPositions,
      },
      error: riskMetrics.killSwitchActive ? 'Kill switch is active' : undefined,
    };
  } catch (error) {
    return {
      component: 'Risk Manager',
      status: 'error',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkMultiTimeframe(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { analyzeMultiTimeframe } = await import("../multi-timeframe");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Multi-Timeframe Analysis',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Multi-Timeframe Analysis',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkPositionSizing(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { calculateOptimalPositionSize } = await import("../position-sizing");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Position Sizing',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Position Sizing',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkDynamicExits(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { determineExitStrategy } = await import("../dynamic-exits");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Dynamic Exit Strategy',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Dynamic Exit Strategy',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkCoreServices(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const services = await import("../services");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Core Services',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { 
        available: true,
        hasRegimeAnalysis: typeof services.analyzeRegime === 'function',
        hasSignalGeneration: typeof services.generateMomentumSignal === 'function',
      },
    };
  } catch (error) {
    return {
      component: 'Core Services',
      status: 'error',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

// ============================================================================
// DATA & STORAGE CHECKS
// ============================================================================

async function checkDataCache(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { getDataCache } = await import("../data-cache");
    const cache = getDataCache();
    const responseTime = Date.now() - startTime;
    return {
      component: 'Data Cache',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Data Cache',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkStorage(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const storage = await import("../storage");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Storage Service',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Storage Service',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkTradeHistoryService(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { tradeHistoryService } = await import("../trade-history-service");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Trade History Service',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Trade History Service',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkDatabaseTradeService(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { DatabaseTradeService } = await import("../db-trade-service");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Database Trade Service',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Database Trade Service',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

// ============================================================================
// REALTIME & NOTIFICATION CHECKS
// ============================================================================

async function checkRealtimeService(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { RealtimeService } = await import("../realtimeService");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Realtime Service',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Realtime Service',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkNotificationService(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { notifyOwner } = await import("./notification");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Notification Service',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Notification Service',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

// ============================================================================
// VALIDATION & MIDDLEWARE CHECKS
// ============================================================================

async function checkDataValidation(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const validation = await import("../data-validation");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Data Validation',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Data Validation',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkPaperTradingValidator(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const validator = await import("../paperTradingValidator");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Paper Trading Validator',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Paper Trading Validator',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

async function checkMiddleware(): Promise<HealthComponent> {
  const startTime = Date.now();
  try {
    const { healthCheckMiddleware } = await import("../middleware");
    const responseTime = Date.now() - startTime;
    return {
      component: 'Middleware',
      status: 'healthy',
      lastCheck: Date.now(),
      responseTimeMs: responseTime,
      details: { available: true },
    };
  } catch (error) {
    return {
      component: 'Middleware',
      status: 'warning',
      lastCheck: Date.now(),
      responseTimeMs: Date.now() - startTime,
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

// ============================================================================
// MAIN HEALTH CHECK
// ============================================================================

export const systemRouter = router({
  health: publicProcedure
    .input(
      z.object({
        timestamp: z.number().min(0, "timestamp cannot be negative").optional(),
      }).optional()
    )
    .query(async () => {
      try {
        // Check all system components in parallel
        const components = await Promise.all([
        // Core Infrastructure
        checkDatabase(),
        checkAPIServer(),
        checkAuthentication(),
        
        // Trading Engines
        checkTradingEngine(),
        checkEnhancedTradingEngine(),
        
        // Market Data
        checkMarketData(),
        checkMarketDataService(),
        checkMarketScanner(),
        checkMarketUtils(),
        
        // IBKR/TWS
        checkTWSConnectionHealth(),
        checkTWSAPIClient(),
        checkIBKRService(),
        checkGatewayAdapter(),
        
        // Signal & Analysis
        checkAdvancedSignals(),
        checkAdaptiveRisk(),
        checkRiskManager(),
        checkMultiTimeframe(),
        checkPositionSizing(),
        checkDynamicExits(),
        checkCoreServices(),
        
        // Data & Storage
        checkDataCache(),
        checkStorage(),
        checkTradeHistoryService(),
        checkDatabaseTradeService(),
        
        // Realtime & Notifications
        checkRealtimeService(),
        checkNotificationService(),
        
        // Validation & Middleware
        checkDataValidation(),
        checkPaperTradingValidator(),
        checkMiddleware(),
      ]);

        // Determine overall status
        const hasError = components.some(c => c.status === 'error');
        const hasWarning = components.some(c => c.status === 'warning');
        const overallStatus = hasError ? 'error' : hasWarning ? 'warning' : 'healthy';

        // Ready for trade: healthy overall and critical path (market data, scanner, API) not error
        const criticalNames = ['API Server', 'Market Data (IBKR)', 'Market Scanner', 'Database'];
        const critical = components.filter(c => criticalNames.includes(c.component));
        const criticalOk = critical.every(c => c.status !== 'error');
        const readyForTrade = overallStatus === 'healthy' && criticalOk;

        console.log(`[SystemHealth] Returning ${components.length} components, overall status: ${overallStatus}, readyForTrade: ${readyForTrade}`);

        return {
          ok: overallStatus === 'healthy',
          status: overallStatus,
          readyForTrade,
          components,
          timestamp: Date.now(),
        };
      } catch (error) {
        console.error('[SystemHealth] Error checking health:', error);
        return {
          ok: false,
          status: 'error',
          components: [{
            component: 'Health Check System',
            status: 'error',
            lastCheck: Date.now(),
            error: error instanceof Error ? error.message : String(error),
          }],
          timestamp: Date.now(),
        };
      }
    }),

  notifyOwner: adminProcedure
    .input(
      z.object({
        title: z.string().min(1, "title is required"),
        content: z.string().min(1, "content is required"),
      })
    )
    .mutation(async ({ input }) => {
      const delivered = await notifyOwner(input);
      return {
        success: delivered,
      } as const;
    }),

  /** System audit report (Sections 1–7) for reliability/risk applicability. Optionally fetch liquidity (bid/ask, OI, volume) from chain. */
  getAuditReport: publicProcedure
    .input(
      z.object({
        topN: z.number().min(1).max(50).default(10),
        fetchLiquidity: z.boolean().default(false),
      }).optional()
    )
    .query(async ({ input }) => {
      const topN = input?.topN ?? 10;
      const fetchLiquidity = input?.fetchLiquidity ?? false;
      const scanner = getMarketScanner();
      const opportunities = scanner.getTopOpportunities(topN);
      const trades: AuditTradeInput[] = opportunities.map((opp) => ({
        symbol: opp.symbol,
        structureType: (opp.structure?.type ?? "vertical_call_spread").toString().replace(/\s+/g, "_").toLowerCase(),
        optionType: "C",
        action: "BUY",
        quantity: 1,
        entryPrice: 2,
        strike: Math.round(opp.currentPrice ?? 100),
        score: opp.opportunity?.score ?? 0,
        confidence: opp.signal?.confidence ?? 0.7,
        expectedReturn: opp.opportunity?.expectedReturn ?? 0,
        winProbability: opp.opportunity?.winProbability ?? 0.5,
        regime: opp.regime ?? "neutral",
        impliedVolatility: opp.impliedVolatility ?? 25,
        greeks: opp.greeks,
        spreadWidth: 5,
        netCreditPerContract: 150,
      }));
      let liquidityBySymbol: Record<string, { bidAskSpreadPct?: number; openInterest?: number; avgVolume?: number }> | undefined;
      if (fetchLiquidity && trades.length > 0) {
        const symbols = trades.map((t) => t.symbol);
        liquidityBySymbol = await getLiquidityForAudit(symbols);
      }
      if (trades.length === 0) {
        return runSystemAudit({
          trades: [{ symbol: "SPY", structureType: "vertical_call_spread", regime: "neutral" }],
          liquidityBySymbol,
        });
      }
      return runSystemAudit({ trades, liquidityBySymbol });
    }),

  /** Regime and strategy coverage diagnostic (top N opportunities): by regime, by strategy, summary table + JSON. */
  getRegimeStrategyDiagnostic: publicProcedure
    .input(
      z.object({
        topN: z.number().min(1).max(200).default(100),
      }).optional()
    )
    .query(({ input }) => {
      const topN = input?.topN ?? 100;
      return runRegimeStrategyDiagnostic(topN);
    }),
});
