/**
 * Walk-forward backtest — multi-window walk-forward, collapse ratio.
 * Run: pnpm test -- --grep "walk.*forward"
 */
import { describe, it, expect } from "vitest";
import { runWalkForward, runMultiWindowWalkForward, type WalkForwardConfig, type MultiWindowWalkForwardConfig } from "./backtest-runner";

describe("walk forward — single window", () => {
  it("walk forward: runWalkForward returns result with train/test metrics", async () => {
    const config: WalkForwardConfig = {
      symbol: "SPY",
      trainDays: 60,
      testDays: 21,
      stepDays: 21,
      strategy: "adaptive",
      initialCapital: 100_000,
      holdDays: 5,
    };
    const result = await runWalkForward(config);
    expect(result).toBeDefined();
    expect(typeof result.avgSharpe).toBe("number");
    expect(typeof result.avgWinRate).toBe("number");
    expect(typeof result.message).toBe("string");
    expect(typeof result.durationMs).toBe("number");
    if (result.success) {
      expect(typeof result.inSampleSharpe).toBe("number");
      expect(typeof result.outOfSampleSharpe).toBe("number");
      expect(typeof result.inSampleTrades).toBe("number");
      expect(typeof result.outOfSampleTrades).toBe("number");
    }
  });
});

describe("walk forward — multi-window", () => {
  it("walk forward: runMultiWindowWalkForward returns windows and aggregate metrics", async () => {
    const config: MultiWindowWalkForwardConfig = {
      symbol: "SPY",
      numWindows: 2,
      trainDays: 126,
      testDays: 42,
      stepDays: 42,
    };
    const result = await runMultiWindowWalkForward(config);
    expect(result).toBeDefined();
    expect(result.symbol).toBe("SPY");
    expect(Array.isArray(result.windows)).toBe(true);
    expect(typeof result.meanTrainSharpe).toBe("number");
    expect(typeof result.meanTestSharpe).toBe("number");
    expect(typeof result.avgCollapseRatio).toBe("number");
    expect(["excellent", "good", "fair", "poor"]).toContain(result.robustness);
  });

  it("walk forward: collapse ratio is testSharpe/trainSharpe when trainSharpe > 0", async () => {
    const config: MultiWindowWalkForwardConfig = {
      symbol: "SPY",
      numWindows: 1,
      trainDays: 126,
      testDays: 42,
    };
    const result = await runMultiWindowWalkForward(config);
    if (result.windows.length > 0 && result.windows[0]!.trainSharpe > 0.01) {
      const expected = result.windows[0]!.testSharpe / result.windows[0]!.trainSharpe;
      expect(result.windows[0]!.collapseRatio).toBeCloseTo(expected, 4);
    }
  });

  it("walk forward: robustness classification from avgCollapseRatio", async () => {
    const result = await runMultiWindowWalkForward({ symbol: "SPY", numWindows: 1, trainDays: 100, testDays: 30 });
    if (result.avgCollapseRatio >= 0.8) expect(result.robustness).toBe("excellent");
    else if (result.avgCollapseRatio >= 0.6) expect(result.robustness).toBe("good");
    else if (result.avgCollapseRatio >= 0.4) expect(result.robustness).toBe("fair");
    else expect(result.robustness).toBe("poor");
  });

  it("walk forward: result has durationMs", async () => {
    const result = await runMultiWindowWalkForward({ symbol: "SPY", numWindows: 1, trainDays: 80, testDays: 20 });
    expect(result.durationMs).toBeGreaterThanOrEqual(0);
  });
});
