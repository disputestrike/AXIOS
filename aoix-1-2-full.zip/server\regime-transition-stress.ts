/**
 * Regime transition stress — find regime flips and test strategy performance around them.
 * Used to validate robustness when market regime changes (e.g. bull → bear).
 */

export interface RegimeFlip {
  date: Date;
  fromRegime: string;
  toRegime: string;
  probability: number;
}

export interface RegimeFlipStress {
  flip: RegimeFlip;
  preSharpe: number;
  postSharpe: number;
  perfDropPercent: number;
  recoveryDays: number;
}

interface PriceBar {
  date: Date;
  close: number;
}

/** Compute regime from trend and vol (same logic as backtest-runner). */
function regimeFromTrendVol(trend: number, volPct: number): string {
  if (volPct > 5) return "crisis";
  if (trend > 0.05) return "trending_bull";
  if (trend < -0.05) return "trending_bear";
  if (trend > 0.02 && volPct < 2) return "bull_vol_compression";
  if (trend > 0.02 && volPct >= 2) return "bull_vol_expansion";
  if (trend < -0.02 && volPct < 2) return "bear_vol_compression";
  if (trend < -0.02 && volPct >= 2) return "bear_vol_expansion";
  if (Math.abs(trend) < 0.01) return "mean_reverting";
  return "chaotic";
}

/** Build regime history from price bars (same lookback as backtest). */
export function buildRegimeHistory(quotes: PriceBar[], lookback = 20): Array<{ date: Date; regime: string }> {
  const result: Array<{ date: Date; regime: string }> = [];
  for (let i = lookback; i < quotes.length; i++) {
    const trend = (quotes[i].close - quotes[i - lookback].close) / (quotes[i - lookback].close || 1);
    const returns: number[] = [];
    for (let j = i - lookback + 1; j <= i; j++) {
      if (quotes[j - 1].close > 0) returns.push((quotes[j].close - quotes[j - 1].close) / quotes[j - 1].close);
    }
    const volPct = returns.length > 0
      ? Math.sqrt(returns.reduce((s, r) => s + r * r, 0) / returns.length) * 100
      : 0;
    result.push({ date: quotes[i].date, regime: regimeFromTrendVol(trend, volPct) });
  }
  return result;
}

/** Find dates where regime changed (flip). */
export function findRegimeFlips(
  regimeHistory: Array<{ date: Date; regime: string }>,
  threshold = 0.7
): RegimeFlip[] {
  const flips: RegimeFlip[] = [];
  for (let i = 1; i < regimeHistory.length; i++) {
    const prev = regimeHistory[i - 1];
    const curr = regimeHistory[i];
    if (prev.regime !== curr.regime) {
      flips.push({
        date: curr.date,
        fromRegime: prev.regime,
        toRegime: curr.regime,
        probability: threshold,
      });
    }
  }
  return flips;
}

/** Fetch historical chart for a symbol. IB only: use IB historical API. */
export async function getHistoricalPriceData(
  _symbol: string,
  _startDate: Date,
  _endDate: Date
): Promise<PriceBar[]> {
  throw new Error("Historical data requires IB API (no third-party source)");
}

/** Compute Sharpe from daily returns (annualized). */
function sharpeFromReturns(returns: number[], annFactor = 252): number {
  if (returns.length < 2) return 0;
  const mean = returns.reduce((a, b) => a + b, 0) / returns.length;
  const variance = returns.reduce((s, r) => s + (r - mean) ** 2, 0) / (returns.length - 1);
  const std = Math.sqrt(variance);
  return std > 0 ? (mean / std) * Math.sqrt(annFactor) : 0;
}

/** Stress-test strategy performance around each regime flip (pre vs post window). */
export async function stressTestRegimeTransitions(
  symbol: string,
  flips: RegimeFlip[],
  lookbackDays = 30,
  lookforwardDays = 30
): Promise<RegimeFlipStress[]> {
  const results: RegimeFlipStress[] = [];
  for (const flip of flips) {
    const preStart = new Date(flip.date);
    preStart.setDate(preStart.getDate() - lookbackDays);
    const postEnd = new Date(flip.date);
    postEnd.setDate(postEnd.getDate() + lookforwardDays);
    let quotes: PriceBar[];
    try {
      quotes = await getHistoricalPriceData(symbol, preStart, postEnd);
    } catch {
      results.push({
        flip,
        preSharpe: 0,
        postSharpe: 0,
        perfDropPercent: 0,
        recoveryDays: lookforwardDays,
      });
      continue;
    }
    if (quotes.length < lookbackDays + lookforwardDays) {
      results.push({
        flip,
        preSharpe: 0,
        postSharpe: 0,
        perfDropPercent: 0,
        recoveryDays: lookforwardDays,
      });
      continue;
    }
    const flipIdx = quotes.findIndex((q) => q.date >= flip.date);
    if (flipIdx < lookbackDays || flipIdx + lookforwardDays > quotes.length) {
      results.push({
        flip,
        preSharpe: 0,
        postSharpe: 0,
        perfDropPercent: 0,
        recoveryDays: lookforwardDays,
      });
      continue;
    }
    const preReturns: number[] = [];
    for (let i = flipIdx - lookbackDays + 1; i < flipIdx; i++) {
      if (quotes[i - 1].close > 0) preReturns.push((quotes[i].close - quotes[i - 1].close) / quotes[i - 1].close);
    }
    const postReturns: number[] = [];
    for (let i = flipIdx + 1; i < Math.min(flipIdx + lookforwardDays, quotes.length); i++) {
      if (quotes[i - 1].close > 0) postReturns.push((quotes[i].close - quotes[i - 1].close) / quotes[i - 1].close);
    }
    const preSharpe = sharpeFromReturns(preReturns);
    const postSharpe = sharpeFromReturns(postReturns);
    const perfDropPercent =
      preSharpe > 0 ? ((preSharpe - postSharpe) / preSharpe) * 100 : 0;
    let recoveryDays = lookforwardDays;
    let cum = 1;
    const preAvgRet = preReturns.length ? preReturns.reduce((a, b) => a + b, 0) / preReturns.length : 0;
    for (let i = 0; i < postReturns.length; i++) {
      cum *= 1 + postReturns[i];
      if (cum >= 1 + preAvgRet * 5) {
        recoveryDays = i + 1;
        break;
      }
    }
    results.push({
      flip,
      preSharpe,
      postSharpe,
      perfDropPercent,
      recoveryDays,
    });
  }
  return results;
}
