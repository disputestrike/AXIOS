@echo off
title AOIX-1 - Start All
cd /d "%~dp0"

REM Gateway folder (same parent as this project - edit if yours is elsewhere)
set "GATEWAY_DIR=%~dp0..\clientportal.gw"
for %%I in ("%GATEWAY_DIR%") do set "GATEWAY_DIR=%%~fI"

echo.
echo ============================================
echo   AOIX-1 - Starting Gateway + App + Browser
echo ============================================
echo.
echo One-time: If TWS never connects, right-click ALLOW_JAVA_FIREWALL.bat
echo           and "Run as administrator", then run this again.
echo.

REM 1) Start Client Portal Gateway in a new window
if exist "%GATEWAY_DIR%\START_IB_GATEWAY.bat" (
    echo [1/4] Starting IBKR Client Portal Gateway...
    start "IBKR Client Portal Gateway" cmd /k "cd /d ""%GATEWAY_DIR%"" && START_IB_GATEWAY.bat"
    timeout /t 5 /nobreak >nul
) else (
    echo [1/4] Gateway folder not found: %GATEWAY_DIR%
    echo       Edit START_EVERYTHING.bat and set GATEWAY_DIR to your clientportal.gw path.
    timeout /t 3 /nobreak >nul
)

REM 2) Start AOIX-1 app in a new window
echo [2/4] Starting AOIX-1 app...
start "AOIX-1 App" cmd /k "cd /d ""%~dp0"" && pnpm dev"
timeout /t 8 /nobreak >nul

REM 3) Open browser: gateway login then app
echo [3/4] Opening browser...
start "" "http://localhost:5000"
timeout /t 2 /nobreak >nul
start "" "http://localhost:3000/auto-trading"

echo [4/4] Done.
echo.
echo - Log in at http://localhost:5000 (gateway) if prompted.
echo - In the app, click Connect or "I'm logged in at the gateway, confirm connection".
echo - Leave both gateway and app windows open.
echo.
pause
