/**
 * Anthropic Claude API — used for trade validation in the Catalyst layer.
 * Set ANTHROPIC_API_KEY in .env.local to enable.
 */

import { ENV } from "./env";

const ANTHROPIC_BASE = "https://api.anthropic.com/v1";
const DEFAULT_MODEL = "claude-sonnet-4-20250514";
const DEFAULT_MAX_TOKENS = 4096;

export type ClaudeMessage = {
  role: "user" | "assistant";
  content: string | Array<{ type: "text"; text: string }>;
};

export type ClaudeInvokeParams = {
  messages: ClaudeMessage[];
  system?: string;
  model?: string;
  max_tokens?: number;
  /** Timeout in ms (e.g. 2500 for intent step). No timeout if omitted. */
  timeoutMs?: number;
};

export type ClaudeInvokeResult = {
  id: string;
  type: "message";
  role: "assistant";
  content: Array<{ type: string; text?: string }>;
  stop_reason: string | null;
  usage: {
    input_tokens: number;
    output_tokens: number;
  };
};

function getApiKey(): string {
  const key = ENV.anthropicApiKey?.trim();
  if (!key) {
    throw new Error("ANTHROPIC_API_KEY is not set. Add it to .env.local for Claude validation.");
  }
  return key;
}

/**
 * Call Anthropic Messages API. Use for trade validation and other Catalyst-layer reasoning.
 */
export async function invokeClaude(params: ClaudeInvokeParams): Promise<ClaudeInvokeResult> {
  const key = getApiKey();
  const {
    messages,
    system,
    model = DEFAULT_MODEL,
    max_tokens = DEFAULT_MAX_TOKENS,
    timeoutMs,
  } = params;

  const body: Record<string, unknown> = {
    model,
    max_tokens,
    messages: messages.map((m) => ({
      role: m.role,
      content: typeof m.content === "string" ? m.content : m.content,
    })),
  };
  if (system && system.trim().length > 0) {
    body.system = system.trim();
  }

  const ms = timeoutMs ?? 0;
  const controller = ms > 0 ? new AbortController() : null;
  const timeoutId = controller ? setTimeout(() => controller.abort(), ms) : undefined;
  const fetchOpts: RequestInit = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": key,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify(body),
  };
  if (controller) fetchOpts.signal = controller.signal;

  const response = await fetch(`${ANTHROPIC_BASE}/messages`, fetchOpts);
  if (timeoutId) clearTimeout(timeoutId);

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(
      `Claude API error: ${response.status} ${response.statusText} – ${errText}`
    );
  }

  return (await response.json()) as ClaudeInvokeResult;
}

/**
 * Extract plain text from Claude response (first text block).
 */
export function getClaudeText(result: ClaudeInvokeResult): string {
  if (!result.content || !Array.isArray(result.content)) return "";
  const textBlock = result.content.find(
    (b): b is { type: "text"; text: string } => b.type === "text" && "text" in b
  );
  return textBlock?.text ?? "";
}

/**
 * Check if Claude is configured (for conditional validation).
 */
export function isClaudeConfigured(): boolean {
  return Boolean(ENV.anthropicApiKey?.trim());
}
