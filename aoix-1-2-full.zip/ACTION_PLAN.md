# Action Plan: Trading App — What's Done, What's Next

**Last updated:** Today  
**Status:** Core app working; paper trading + execution functional; ready for next phase  
**Audience:** Team leads, developers, stakeholders

---

## TL;DR

✅ **App runs and works** — `npm run dev` → paper trading → Execution dashboard  
✅ **All critical features done** — market scan, paper trade, auto-trading engine, system health  
⚠️ **Known limitation:** TWS disconnects without IB Gateway (expected; paper trading works fine)  
📋 **Next steps depend on your goal** — see section 4 below

---

## 1. What's Actually Done (Status Report)

| Component | Status | Details |
|-----------|--------|---------|
| **App startup** | ✅ Done | `npm run dev` starts Express + Vite on same port (3000). No separate API. |
| **Authentication** | ✅ Done | Demo login via `auth.login`. Session cookie. Works. |
| **Market scanning** | ✅ Done | Yahoo Finance data. Click "Scan Market" or loads on mount. |
| **Paper trading (Omega-0)** | ✅ Done | Place order → set contracts → appears on Execution. Close positions work. P&L calcs. |
| **Execution dashboard** | ✅ Done | Shows open positions + recent trades. Manual + engine trades both visible. Close buttons functional. |
| **Auto-trading engine** | ✅ Done | Start/stop on Auto Trading page. Positions/trades appear on Execution. Performance metrics, unrealized P&L. |
| **System Health** | ✅ Done | Component status page. All readouts working; `getDataCache` fixed. |
| **TWS/IB Gateway** | ✅ Done | Configure + connect works. Shows "Disconnected" if Gateway not running (expected). Paper trading unaffected. |
| **Database (Drizzle/SQLite)** | ✅ Done | Optional. Trades persist. Schema in `drizzle/`. Migrations via `npx drizzle-kit push` or `pnpm db:push`. |
| **API routers** | ✅ Done | All 16 routers exist (auth, market, regime, signals, structures, risk, execution, trades, omega0, autoTrading, gateway, marketScanner, twsConnection, metaIntelligence, failures, shadowSystem, correlations, system). |

**Known issues (fixed in this codebase):**
- ~~Trade Now dialog missing~~ → Added
- ~~Option P&L used wrong price~~ → Uses premium now
- ~~$NaN in P&L~~ → safeNum/fmtMoney applied
- ~~getDataCache not exported~~ → Fixed
- ~~TWS Configure not saving~~ → Uses TWS_HOST/TWS_PORT env

---

## 2. Quick Start (Anyone Can Do This)

```bash
# 1. Install
npm install

# 2. Run
npm run dev

# 3. Open browser
# http://localhost:3000 → Log in (demo user)

# 4. Test paper trading
# Market Opportunities → Trade Now → Place order → Check Execution

# 5. (Optional) Start auto-trading
# Auto Trading → Start engine → Execution shows engine positions
```

**Time:** 5–10 minutes. No TWS, no IB Gateway needed.

---

## 3. Next Steps by Goal

### **Goal A: Deploy to Production**

| Step | Do this |
|------|---------|
| 1 | Run `npm run build` (creates dist/) |
| 2 | Set env: `PORT=3000` (or your port), `NODE_ENV=production` |
| 3 | Start: `npm start` or `node dist/index.js` |
| 4 | Verify: `GET /api/health` returns `{ ok: true }` |
| 5 | (Optional) Set `TWS_HOST` and `TWS_PORT` env if you have IB Gateway |
| 6 | Deploy container/server with built app |

**Checklist:**
- [ ] Build passes
- [ ] No hardcoded secrets (use env vars)
- [ ] Port configurable
- [ ] CORS tightened for your domain
- [ ] Health endpoint responds
- [ ] Database (if using) migrated

---

### **Goal B: Populate Empty Dashboards (Regime, Signals, etc.)**

These pages exist but show empty data because the DB or services aren't populated.

| Dashboard | What it needs | How to fix |
|-----------|---------------|-----------|
| **Regime** | DB market regime data | Seed `regimeData` table or wire `regime.getLatest` to real service |
| **Signals** | DB signal data | Populate `signals` table or integrate signal generator |
| **Structures** | DB trade structure recommendations | Seed `structures` table |
| **Risk** | DB risk metrics | Seed `riskMetrics` table |
| **Meta-Intelligence** | DB intelligence data | Seed `metaIntelligence` table |
| **Failures** | DB trade failure logs | Failures auto-log when trades close; check `tradeFailures` table |
| **Shadow System** | DB simulation reports | Run shadow system simulations; save reports |
| **Correlations** | DB correlation data | Calculate and seed `correlations` table |

**Quick way to test:** Add a seed script in `drizzle/seed.ts` or create sample data in DB directly.

---

### **Goal C: Connect IB Gateway (Live Option Data)**

1. **Install** IB Gateway on your machine (or remote host)
2. **Start** IB Gateway (runs on default port 4001 or your choice)
3. **In the app:**
   - Go to **Auto Trading** → **TWS card** → gear icon
   - Enter Host (e.g. `localhost`) + Port (e.g. `4001`)
   - Click **Configure & Connect**
4. **Verify:** TWS card shows "Connected" (green)

**Note:** Paper trading and market scan (Yahoo) work without this. TWS is for live option chains only.

---

### **Goal D: Write User Guides / Docs**

| For whom | Give them |
|----------|-----------|
| **End users** | QUICKSTART.md (how to scan, place trade, see positions) + this doc's section 2 |
| **Developers** | ROUTERS_AND_ENDPOINTS.md (api structure) + DEVELOPER_QUESTIONS.md (current state) + this doc |
| **Stakeholders** | This doc (status + next steps) + feature inventory (below, section 1) |

---

### **Goal E: Troubleshoot When Things Break**

Use this flowchart:

```
Problem?
  ├─ App won't start
  │   → Check port (PORT env), npm install, Node version
  │
  ├─ Trade Now fails / errors
  │   → Browser console + Network tab (omega0.placeOrder)
  │   → Log in again (session cookie)
  │
  ├─ $NaN or wrong P&L
  │   → Check System Health
  │   → Option price must use premium (not underlying)
  │
  ├─ No opportunities showing
  │   → Click "Scan Market" button
  │   → Check Yahoo Finance data in network tab
  │
  ├─ Execution page empty
  │   → Place a trade first (Trade Now dialog)
  │   → Or start engine (Auto Trading page)
  │
  ├─ TWS won't connect
  │   → Is IB Gateway actually running?
  │   → Paper trading works without it
  │
  └─ System Health shows errors
      → Check server logs
      → See ROUTERS_AND_ENDPOINTS.md §10–11
```

---

## 4. Feature Inventory (What's Implemented)

| Feature | Status | Owner | Notes |
|---------|--------|-------|-------|
| **Login / Auth** | ✅ Done | Backend (auth router) | Demo user; session cookie |
| **Market scan** | ✅ Done | Backend (marketScanner) | Yahoo Finance; real data |
| **Paper trading** | ✅ Done | Backend (omega0) | In-memory + optional DB persist |
| **Trade Now dialog** | ✅ Done | Frontend + Backend | Contracts → Place order |
| **Execution dashboard** | ✅ Done | Frontend + Backend | Positions, trades, Close buttons |
| **Auto-trading engine** | ✅ Done | Backend (auto-trading-engine) | Start/stop, positions, P&L |
| **System Health** | ✅ Done | Backend (system) | All components visible |
| **TWS connection** | ✅ Done | Backend (twsConnection, ib-market-data) | Configure host/port; connect/disconnect |
| **API routers (16 total)** | ✅ Done | Backend | All exist; some may return empty if DB unpopulated |
| **Frontend routes** | ✅ Done | Frontend | Home, Market Opportunities, Execution, Auto Trading, System Health, Regime, Signals, Structures, Risk, Meta-Intelligence, Failures, Shadow System, Correlations, Execution Interface, 404 |
| **Database schema** | ✅ Done | Backend (Drizzle) | Users, trades, optional persist |
| **Production build** | ✅ Done | Build system | `npm run build` + `npm start` |
| **Deployment ready** | ⚠️ Partial | Team | Build works; env/secrets need setup |
| **Automated tests** | ⚠️ Partial | Team | Some server tests; E2E tests recommended |
| **User documentation** | ⚠️ Partial | Team | QUICKSTART exists; may need expansion |
| **Live IB trading** | ⏳ Optional | Team | Requires IB Gateway + enable live mode in code |

---

## 5. Decisions You Need to Make

| Decision | Options | Recommendation |
|----------|---------|-----------------|
| **Deploy now or wait?** | Deploy now (paper trading works) / Wait for more features | Deploy now if paper trading is your goal; add features post-launch |
| **Database?** | Use SQLite (default) / Skip it | Use it if you need trade history across restarts |
| **IB Gateway?** | Set up now / Later | Later (not blocking); paper trading sufficient for MVP |
| **Empty dashboards?** | Populate now / Stub out / Remove | Populate if they're part of MVP; stub if not critical |
| **User docs?** | Write full guide / Just QUICKSTART / None | At minimum, QUICKSTART; full guide if for non-technical users |

---

## 6. What to Do Right Now

**Pick one:**

1. **"I just want to run it"** → Do section 2 (Quick Start) above. Done in 5 min.

2. **"I need to deploy"** → Do section 3, Goal A. Takes 1–2 hours depending on your infra.

3. **"I need dashboards working"** → Do section 3, Goal B. Estimate 2–4 hours for seeding data.

4. **"I need IB Gateway"** → Do section 3, Goal C. Takes 30 min if you have IB account.

5. **"Something is broken"** → Use section 3, Goal E flowchart above to debug.

6. **"I need to explain this to my team"** → Share this doc + ROUTERS_AND_ENDPOINTS.md + DEVELOPER_QUESTIONS.md.

---

## 7. Files to Refer To

| File | Purpose |
|------|---------|
| **ROUTERS_AND_ENDPOINTS.md** | Complete API map; what exists, where things connect, how to use each endpoint |
| **DEVELOPER_QUESTIONS.md** | Q&A about app state, infrastructure, known issues, unfinished work |
| **WHAT_YOU_NEED_NEXT.md** | Quick start, deployment checklist, troubleshooting, feature inventory by goal |
| **QUICKSTART.md** | User guide; how to use the app |
| **package.json** | Scripts: `npm run dev`, `npm run build`, `npm start` |
| **server/_core/index.ts** | Express entry point; all routers wired here |
| **client/src** | React frontend; pages, components, tRPC queries |
| **.env** / **.env.local** | Port, TWS_HOST, TWS_PORT, DB path, secrets (not in repo) |

---

## 8. Success Criteria

You'll know you're ready when:

- [ ] `npm run dev` starts without errors
- [ ] You can log in
- [ ] You can scan markets and see opportunities
- [ ] You can place a paper trade and see it on Execution
- [ ] You can close a position
- [ ] Auto-trading engine can start/stop
- [ ] System Health shows all green (or expected warnings like "TWS Disconnected")
- [ ] Build passes: `npm run build`
- [ ] You've decided: deploy now, or wait for more features?

---

## Next Steps

1. **Read this doc** (you're doing it)
2. **Run quick start** (section 2) — 5 min
3. **Pick your next goal** (section 3) — deploy? populate dashboards? connect IB?
4. **Execute** — let me know what you need help with

**Questions? Ask below or refer to ROUTERS_AND_ENDPOINTS.md + DEVELOPER_QUESTIONS.md.**
