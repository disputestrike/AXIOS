/**
 * Liquidity / Execution Realism — Fully wired.
 * Live bid/ask, OI, ADV → slippage-aware scoring, auto-reject illiquid, spread-adjusted expected return.
 */

import { getLiquidityFromChain, type LiquidityMetrics } from "./liquidity-for-audit";
import { getExecutionCost } from "./execution-cost-model";

const LIQUIDITY_CACHE = new Map<string, { data: LiquidityExecutionResult; ts: number }>();
const LIQUIDITY_TTL_MS = 120_000; // 2 min

/** Thresholds: above/below = illiquid (auto-reject). Env overrides. */
const MAX_SPREAD_PCT_ILLIQUID = Number(process.env.LIQUIDITY_MAX_SPREAD_PCT) || 5;
const MIN_OI_ILLIQUID = Number(process.env.LIQUIDITY_MIN_OI) || 50;
const MIN_ADV_ILLIQUID = Number(process.env.LIQUIDITY_MIN_ADV) || 100;

export interface LiquidityExecutionResult {
  metrics: LiquidityMetrics;
  /** True → auto-reject structure / order. */
  isIlliquid: boolean;
  /** Multiplier for opportunity score (0.7–1.0). Slippage-aware scoring. */
  slippageScoreMultiplier: number;
  /** Multiplier for expected return (0.85–1.0). Spread-adjusted expected return = raw * this. */
  spreadAdjustedReturnMultiplier: number;
  /** For composite ranker P8 (execution cost). */
  executionCostMultiplier: number;
  /** Reason (e.g. "wide spread 6%") when penalized. */
  reason?: string;
}

/**
 * Return true if metrics indicate illiquid (auto-reject).
 */
export function isIlliquid(metrics: LiquidityMetrics): boolean {
  if (metrics.bidAskSpreadPct >= MAX_SPREAD_PCT_ILLIQUID) return true;
  if (metrics.openInterest != null && metrics.openInterest < MIN_OI_ILLIQUID) return true;
  if (metrics.avgVolume != null && metrics.avgVolume < MIN_ADV_ILLIQUID) return true;
  return false;
}

/**
 * Slippage-aware score multiplier from spread and ADV. 0.7–1.0.
 */
function slippageScoreMultiplier(metrics: LiquidityMetrics): number {
  let mult = 1.0;
  if (metrics.bidAskSpreadPct > 2) {
    mult *= Math.max(0.7, 1 - (metrics.bidAskSpreadPct - 2) * 0.05);
  }
  if (metrics.avgVolume != null && metrics.avgVolume < 500) {
    mult *= Math.max(0.75, metrics.avgVolume / 500);
  }
  return Math.max(0.7, Math.min(1, mult));
}

/**
 * Spread-adjusted expected return multiplier. Uses execution cost model.
 * entryPricePerContract = option mid * 100 (e.g. 2.50 → 250).
 */
function spreadAdjustedReturnMultiplier(
  metrics: LiquidityMetrics,
  entryPricePerContract: number,
  quantity: number
): number {
  const adv = metrics.avgVolume ?? 500;
  const res = getExecutionCost(
    entryPricePerContract,
    quantity,
    metrics.bidAskSpreadPct,
    adv,
    true,
    new Date().getUTCHours(),
    new Date().getUTCMinutes()
  );
  return res.expectedReturnMultiplier;
}

/**
 * Get liquidity + execution result for a symbol (cached). Used by scanner and order validation.
 * On fetch failure returns null so caller can skip liquidity (no live data).
 */
export async function getLiquidityForScoring(
  symbol: string,
  options?: {
    /** Option mid price for spread-adjusted return (e.g. 2.50). Used to derive entryPricePerContract = mid * 100. */
    optionMidPrice?: number;
    /** Quantity for market impact. Default 1. */
    quantity?: number;
  }
): Promise<LiquidityExecutionResult | null> {
  const cacheKey = `${symbol}_${options?.optionMidPrice ?? 0}_${options?.quantity ?? 1}`;
  const cached = LIQUIDITY_CACHE.get(cacheKey);
  if (cached && Date.now() - cached.ts < LIQUIDITY_TTL_MS) return cached.data;

  const metrics = await getLiquidityFromChain(symbol);
  if (!metrics) return null;

  const illiquid = isIlliquid(metrics);
  const slippageMult = slippageScoreMultiplier(metrics);
  const entryPricePerShare = options?.optionMidPrice ?? 2;
  const qty = options?.quantity ?? 1;
  const returnMult = spreadAdjustedReturnMultiplier(metrics, entryPricePerShare, qty);
  const executionCostMult = Math.min(1, returnMult * 1.02);

  const reasons: string[] = [];
  if (metrics.bidAskSpreadPct >= MAX_SPREAD_PCT_ILLIQUID) reasons.push(`spread ${metrics.bidAskSpreadPct}%`);
  if (metrics.openInterest != null && metrics.openInterest < MIN_OI_ILLIQUID) reasons.push(`OI ${metrics.openInterest}`);
  if (metrics.avgVolume != null && metrics.avgVolume < MIN_ADV_ILLIQUID) reasons.push(`ADV ${metrics.avgVolume}`);

  const result: LiquidityExecutionResult = {
    metrics,
    isIlliquid: illiquid,
    slippageScoreMultiplier: slippageMult,
    spreadAdjustedReturnMultiplier: returnMult,
    executionCostMultiplier: executionCostMult,
    reason: reasons.length > 0 ? reasons.join(", ") : undefined,
  };

  LIQUIDITY_CACHE.set(cacheKey, { data: result, ts: Date.now() });
  return result;
}

/**
 * Spread-adjusted expected return: rawExpectedReturn (e.g. %) * multiplier.
 */
export function applySpreadAdjustedReturn(
  rawExpectedReturnPercent: number,
  spreadAdjustedReturnMultiplier: number
): number {
  return rawExpectedReturnPercent * Math.max(0.85, Math.min(1, spreadAdjustedReturnMultiplier));
}

/**
 * Check symbol liquidity for order validation. Returns { allowed, reason }.
 * Use before placeOrder to auto-reject illiquid.
 */
export async function checkLiquidityForOrder(symbol: string): Promise<{ allowed: boolean; reason?: string }> {
  const res = await getLiquidityForScoring(symbol);
  if (!res) return { allowed: true };
  if (res.isIlliquid) return { allowed: false, reason: `Illiquid: ${res.reason ?? "spread/OI/ADV below threshold"}` };
  return { allowed: true };
}
