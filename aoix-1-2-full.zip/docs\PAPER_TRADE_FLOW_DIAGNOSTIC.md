# Paper Trade Flow — What Should Happen vs What We Have

This doc maps the logical paper-trading flow to the AOIX-1 codebase and calls out what works vs what’s missing or broken.

---

## How It SHOULD Work (Paper Trading)

```
1. You click "TRADE" on an opportunity
   ↓
2. App fetches REAL live data from IB Gateway:
   - Current stock price
   - Real option chain (all strikes, prices, bid/ask)
   - IV, Greeks, etc.
   ↓
3. App calculates the best option combo (e.g., call spread, iron condor)
   ↓
4. App shows YOU:
   - Which strikes to buy/sell
   - Real market prices (bid/ask)
   - Risk/reward ratio (you can adjust limits)
   - Volatility assumptions
   ↓
5. You confirm or adjust
   ↓
6. App sends ORDER to IB Gateway
   ↓
7. IB Gateway → Interactive Brokers servers → Paper trading account
   ↓
8. Order gets filled (instantly on paper, or waits for market on live)
   ↓
9. Position shows in your account with P&L
```

---

## What We Actually Have (Source-Code Mapping)

### 1. Orders **are** sent to IB

- **UI:** Today’s Opportunity and Recommendations call `trpc.omega0.placeOrder.useMutation()`; button label is “Place order” / “Executing…”.
- **Backend:** `server/routers/omega0.ts` → `placeOrder` mutation:
  - Single-leg: calls `placeIBOptionOrder()` when Gateway is connected.
  - Multi-leg: loops over legs and calls `placeIBOptionOrder()` for each.
- **IB layer:** `server/ib-orders.ts` → `placeIBOptionOrder()`:
  - Resolves option `conid` via `getIBOptionsChain(symbol, [expiry])`.
  - **POSTs to** `GET /v1/api/iserver/account/{accountId}/orders` with `{ orders: [{ acctId, conid, secType: "OPT", orderType, side, quantity, tif: "DAY", ticker }] }`.
- **So:** The “send to IB” path exists and is used. If trades don’t show in paper account, the next checks are: Gateway connected + logged in, correct account ID, and any error returned by IB (see “What to check” below).

### 2. Real strike/price display — **partially missing**

- **Backend** uses real IB data when available:
  - `getFillPriceForLeg()` in `omega0.ts` uses `getIBOptionsChain()` and takes mid(bid, ask) or last for the chosen strike/expiry/type.
  - `estimateOrderCost` uses the same for max loss/profit/breakevens.
- **UI (Today’s Opportunity trade dialog):**
  - **Strike:** Shown as “Strike (approx)” = `Math.round(currentPrice / 5) * 5` — **computed**, not chosen from the live chain.
  - **Expiry:** Comes from `getExpiryAndStrike()` → “next Friday” (YYYYMMDD), also **computed**, not from IB expiries.
  - **No list of real strikes with bid/ask** in the trade dialog; no dropdown/table of “all available strikes with live bid/ask”.
- **Conclusion:** We do **not** show the actual market strikes/prices in the trade UI. We show one derived strike/expiry and risk metrics (max loss, max profit, breakevens) from the backend, which *are* based on real IB data for that derived strike/expiry.

### 3. Risk/reward controls — **partial**

- **We have:** Max loss, max profit, breakevens (from `omega0.estimateOrderCost`), and contract quantity in the dialog.
- **We don’t have in the dialog:**
  - Per-leg “Buy this call at $X, sell that call at $Y” (only aggregate risk metrics).
  - Limit price / order type (MKT vs LMT). Backend supports `orderType` and `limitPrice`; Today’s Opportunity doesn’t pass them (so always MKT).
  - User-adjustable strikes or expiries (no picker from real chain).

### 4. Speed/latency

- Each `placeOrder` (and `estimateOrderCost`) can trigger multiple `getIBOptionsChain()` / `getIBMarketData()` calls. No in-UI caching of option chain per symbol/expiry, so repeated clicks or multiple legs can feel slow and hit IB rate limits if many symbols are used.
- Paper fills are still immediate once IB accepts the order; slowness is in our app and Gateway response time, not fill speed.

---

## Direct Answers to Your Questions

| Question | Answer |
|----------|--------|
| **Does it send through the terminal to IB and make the trade?** | **Yes.** The code path is: “Place order” → `omega0.placeOrder` → `placeIBOptionOrder()` → POST to `/iserver/account/{accountId}/orders`. So it *does* send to IB. If you don’t see a fill, see “What to check” below. |
| **Why isn’t it doing that?** | If it’s not working: (1) Gateway not connected or session expired, (2) `getIBAccountId()` returns null (not logged in at Gateway), (3) IB returns an error (e.g. no option chain, invalid conid, margin). Check server logs and the `placeOrder` error message (e.g. toast “Order failed: …”). |
| **Should we be able to see strike prices in real market?** | **Yes.** Right now we don’t: the UI shows a single “Strike (approx)” and no table of real strikes with bid/ask. Adding a step that fetches `getIBOptionsChain(symbol)` (or equivalent) and displays strikes + bid/ask would fix this. |
| **When we place a trade, does it even get filled if it’s slow?** | **Paper: yes.** Slowness is in our/API latency; paper fills are effectively instant once IB accepts. For live, slow could mean worse fill, but that’s separate. |
| **With paper account, should we be able to make changes as many times as possible?** | **Yes.** No extra restriction in our code; paper accounts allow that. |

---

## What to Check When “Place order” Doesn’t Result in a Trade

1. **Browser (F12)**
   - Network: request to `omega0.placeOrder` — status 200 vs 4xx/5xx.
   - Response body or toast: error message (e.g. “Connect IBKR Gateway”, “No option chain for …”, “IBKR order failed: …”).

2. **Server logs**
   - `[IB Orders] placeIBOptionOrder failed:` or Gateway HTTP errors.
   - `checkIBGatewayConnection` / `getIBAccountId` — if Gateway is down or not logged in, we throw before sending.

3. **Gateway**
   - Logged in at `http://localhost:5000` (or your `IB_GATEWAY_URL`).
   - Paper account selected if you use paper.

4. **Liquidity / pre-flight**
   - We reject with “Order rejected: Illiquid symbol” or “Pre-flight validation failed” (slippage/cost). That happens *before* calling IB; you’d see that in the toast/response.

---

## Implemented (P1–P3)

1. **Real option chain in trade dialog (P1)**  
   - `omega0.getOptionChainForTrade(symbol)` returns expirations, strikes, and options with bid/ask.  
   - Today’s Opportunity trade dialog: when opened, fetches chain; shows **Expiration** dropdown and **Strike** table (Call bid/ask, Put bid/ask). User picks expiry and strike; selection is sent to `placeOrder`. Fallback to computed strike/expiry when chain isn’t loaded (e.g. Gateway off).

2. **Show what was sent to IB (P2)**  
   - Before place: **Legs (what will be sent to IB)** shows per-leg “BUY 455C @ $X, SELL 460C @ $Y” from `estimateOrderCost` breakdown.  
   - After place: success toast shows server message (includes order id) and “Check your IB account to confirm fill.”

3. **No option chain handled (P3)**  
   - If `getOptionChainForTrade` returns no options: dialog shows “No options available for {symbol}. Try a different symbol or expiry. Ensure IB Gateway is connected.” and lists available expirations when present. **Place order** is disabled.

## Remaining / Optional

- **Confirm “Place order” actually hits IB**  
  Place one trade and check browser response, server logs, and IB account as in the checklist above.

- **Optional: limit orders**  
  Add MKT/LMT and limit price to the dialog and pass through to `omega0.placeOrder`.

- **Optional: “Check order status”**  
  Poll IB for fill status (would require an IB order-status API).

- **Optional: caching**  
  Cache option chain per symbol to reduce latency and rate-limit risk.

---

## Summary

- **Sending orders to IB:** Implemented; “Place order” → `omega0.placeOrder` → `placeIBOptionOrder` → POST to IB Gateway. If you don’t see fills, debug Gateway connection, account, and IB error messages.
- **Real strike/price display:** Backend uses real IB data for pricing and for placing the order, but the **UI does not** show the real option chain (all strikes, bid/ask); it shows a single computed strike/expiry and risk metrics. Adding a real chain fetch + display and using selected strike/expiry in `placeOrder` would match “what should happen.”
- **Risk/reward:** We show max loss, max profit, breakevens, and quantity; we don’t show per-leg prices or limit order in the Today’s Opportunity dialog.
- **Paper trading:** Fills are immediate on paper; “unlimited” changes are allowed; slowness is app/Gateway latency, not fill delay.
