/**
 * Options Generation — Conservative / Balanced / Aggressive from catalysts + scan.
 * Blueprint: when IntentDecision is provided, filter by strategy compatibility law (intent ∩ regime).
 */

import { getMarketScanner, type MarketOpportunity } from "./market-scanner";
import type { CatalystEvent } from "./catalyst-detection";
import { getCatalystsForSymbol } from "./catalyst-detection";
import { getUnusualFlow } from "./options-flow";
import type { TradeDecision, MarketContext } from "./claude-trade-decision";
import { generateIntentDecision } from "./claude-trade-decision";
import { ALL_STRUCTURE_TYPES } from "./strategy-types";
import {
  filterStrategies,
  normalizeRegimeToCanonical,
  getStructuresForClass,
  type IntentDecision,
} from "./intent-governance";
import { calibrateConfidence } from "./calibration-job";

export type TradeTier = "conservative" | "balanced" | "aggressive";

/** Structure id → direction/action for Claude-first filtering. (11 strategies from strategy-types.) */
const STRUCTURE_DIRECTION_ACTION: Record<string, { direction: "BULLISH" | "BEARISH" | "NEUTRAL"; action: "BUY_PREMIUM" | "SELL_PREMIUM" }> = {
  iron_condor: { direction: "NEUTRAL", action: "SELL_PREMIUM" },
  iron_butterfly: { direction: "NEUTRAL", action: "SELL_PREMIUM" },
  vertical_call_spread: { direction: "BULLISH", action: "SELL_PREMIUM" },
  vertical_put_spread: { direction: "BEARISH", action: "SELL_PREMIUM" },
  calendar_spread: { direction: "NEUTRAL", action: "SELL_PREMIUM" },
  diagonal_spread: { direction: "NEUTRAL", action: "SELL_PREMIUM" },
  straddle: { direction: "NEUTRAL", action: "BUY_PREMIUM" },
  strangle: { direction: "NEUTRAL", action: "BUY_PREMIUM" },
  butterfly: { direction: "NEUTRAL", action: "SELL_PREMIUM" },
  cash_secured_put: { direction: "BULLISH", action: "SELL_PREMIUM" },
  covered_call: { direction: "BULLISH", action: "SELL_PREMIUM" },
};

function filterStrategiesByDecision(decision: TradeDecision): string[] {
  const allowed = ALL_STRUCTURE_TYPES.filter((s) => s.id !== "any").map((s) => s.id);
  const compatible: string[] = [];
  for (const id of allowed) {
    const meta = STRUCTURE_DIRECTION_ACTION[id];
    if (!meta) continue;
    if (decision.direction !== "NEUTRAL" && meta.direction !== "NEUTRAL" && decision.direction !== meta.direction) continue;
    if (decision.action !== "UNDEFINED" && decision.action !== meta.action) continue;
    compatible.push(id);
  }
  const ordered: string[] = [];
  if (compatible.includes(decision.recommendedStructure)) ordered.push(decision.recommendedStructure);
  for (const alt of decision.alternateStructures) {
    if (compatible.includes(alt) && !ordered.includes(alt)) ordered.push(alt);
  }
  for (const id of compatible) {
    if (!ordered.includes(id)) ordered.push(id);
  }
  return ordered;
}

function decisionDirectionToSignal(direction: TradeDecision["direction"]): string {
  if (direction === "BULLISH") return "bullish";
  if (direction === "BEARISH") return "bearish";
  return "neutral";
}

/** True if structure direction is compatible with intent direction (no bullish/bearish mismatch). */
function structureDirectionMatchesIntent(
  structureId: string,
  intentDirection: IntentDecision["direction"]
): boolean {
  const meta = STRUCTURE_DIRECTION_ACTION[structureId];
  if (!meta) return true;
  if (intentDirection === "NEUTRAL") return true;
  if (meta.direction === "NEUTRAL") return true;
  return meta.direction === intentDirection;
}

/** Intent picks the best: allowed structure ids from intent, filtered by direction (no bearish for bullish intent). */
function getAllowedStructureIdsFromIntent(intent: IntentDecision, regimeRaw: string): string[] {
  const regime = normalizeRegimeToCanonical(regimeRaw);
  const allowedClasses = filterStrategies(intent, regime);
  const ids = allowedClasses.flatMap((c) => getStructuresForClass(c));
  const byClass = Array.from(new Set(ids));
  return byClass.filter((id) => structureDirectionMatchesIntent(id, intent.direction));
}

/** Build MarketContext from a scanner opportunity (catalysts + flow fetched here). */
export async function buildMarketContext(opportunity: MarketOpportunity): Promise<MarketContext> {
  const symbol = opportunity.symbol;
  const catalysts = await getCatalystsForSymbol(symbol);
  const flow = await getUnusualFlow(
    symbol,
    undefined,
    opportunity.impliedVolatility ?? 0.25
  );
  const impliedMovePercent = flow.impliedMovePercent ?? (opportunity.impliedVolatility ?? 0.25) * 100 * 0.4;
  const ivRank = opportunity.ivRank ?? 50;
  const historicalMovePercent = (ivRank / 100) * 15 + 5;
  const signal = opportunity.signal;
  const dir = (signal?.direction ?? "").toLowerCase();
  let sentiment = 50;
  if (dir === "bullish") sentiment = 60 + (signal?.confidence ?? 0.5) * 25 + (ivRank - 50) * 0.1;
  else if (dir === "bearish") sentiment = 40 - (signal?.confidence ?? 0.5) * 25 + (ivRank - 50) * 0.08;
  sentiment = Math.round(Math.max(5, Math.min(95, sentiment)));
  const catalystSummary =
    catalysts.length > 0
      ? catalysts.slice(0, 3).map((c) => `${c.type}: ${c.title}`).join("; ")
      : "No catalysts (market/options data)";

  let vix = 0;
  try {
    const { getVIX } = await import("./ib-market-data");
    vix = await getVIX();
  } catch {
    /* VIX optional */
  }

  return {
    symbol,
    regime: opportunity.regime ?? "unknown",
    sentiment,
    impliedMovePercent,
    historicalMovePercent,
    ivPercentile: opportunity.ivRank ?? 50,
    ivRank: opportunity.ivRank ?? 50,
    vix,
    currentPrice: opportunity.currentPrice,
    catalystSummary,
    flowSignal: signal?.direction ? `${signal.direction} (${(signal.confidence * 100).toFixed(0)}%)` : undefined,
    technicalSignal: signal?.class,
    regimeStability: opportunity.regimeStability,
    signalClass: signal?.class,
    signalConfidence: signal?.confidence,
  };
}

export interface GeneratedTradeOption {
  tier: TradeTier;
  symbol: string;
  structureType: string;
  direction: string;
  /** Suggested DTE band for this tier */
  suggestedExpiryDays: { min: number; max: number };
  /** Strike offset as multiple of implied move (e.g. 0.5 = tighter, 1.5 = wider) */
  strikeMultiplier: number;
  impliedMovePercent: number;
  historicalMovePercent: number;
  /** "implied_above_historical" | "implied_below_historical" | "aligned" */
  moveComparison: string;
  catalystSummary: string;
  catalysts: CatalystEvent[];
  /** Score 0–100 for this tier */
  tierScore: number;
  /** From scan */
  winProbability: number;
  /** Rough proxy: 1 - winProb (prob of any loss); some losses are partial */
  probMaxLoss?: number;
  expectedReturn: number;
  currentPrice: number;
  regime: string;
  timestamp: number;
  /** Earnings date before expiry (YYYY-MM-DD) if any */
  earningsBeforeExpiration?: string;
  /** Price vs 52w range: 0–100 (0 = at low, 100 = at high) */
  priceVs52wPercent?: number;
}

/**
 * Generate Conservative, Balanced, Aggressive trade options for one opportunity.
 * Uses catalysts + options flow implied move; historical move from IV/regime proxy.
 */
export async function generateTradeOptions(
  opportunity: MarketOpportunity
): Promise<GeneratedTradeOption[]> {
  const symbol = opportunity.symbol;
  const catalysts = await getCatalystsForSymbol(symbol);
  const flow = await getUnusualFlow(
    symbol,
    undefined,
    opportunity.impliedVolatility ?? 0.25
  );

  const impliedMovePercent = flow.impliedMovePercent ?? (opportunity.impliedVolatility ?? 0.25) * 100 * 0.4;
  // Historical proxy: from IV rank / regime (low IV rank => smaller historical; high => larger)
  const ivRank = opportunity.ivRank ?? 50;
  const historicalMovePercent = (ivRank / 100) * 15 + 5; // ~5–20% band

  const moveComparison =
    impliedMovePercent > historicalMovePercent * 1.2
      ? "implied_above_historical"
      : impliedMovePercent < historicalMovePercent * 0.8
        ? "implied_below_historical"
        : "aligned";

  const catalystSummary =
    catalysts.length > 0
      ? catalysts
          .slice(0, 3)
          .map((c) => `${c.type}: ${c.title}`)
          .join("; ")
      : "No catalysts (market/options data)";

  const baseScore = opportunity.opportunity?.score ?? 50;
  const winProb = opportunity.opportunity?.winProbability ?? 0.5;
  const expReturn = opportunity.opportunity?.expectedReturn ?? 0;

  const tiers: TradeTier[] = ["conservative", "balanced", "aggressive"];
  const options: GeneratedTradeOption[] = tiers.map((tier) => {
    let suggestedExpiryDays: { min: number; max: number };
    let strikeMultiplier: number;
    let tierScore: number;

    switch (tier) {
      case "conservative":
        suggestedExpiryDays = { min: 14, max: 30 };
        strikeMultiplier = 0.6;
        tierScore = Math.min(100, baseScore * 0.9 + winProb * 25 + (moveComparison === "implied_below_historical" ? 5 : 0));
        break;
      case "balanced":
        suggestedExpiryDays = { min: 7, max: 21 };
        strikeMultiplier = 1.0;
        tierScore = Math.min(100, baseScore + winProb * 20 + (moveComparison === "aligned" ? 5 : 0));
        break;
      case "aggressive":
        suggestedExpiryDays = { min: 3, max: 14 };
        strikeMultiplier = 1.4;
        tierScore = Math.min(100, baseScore * 1.05 + expReturn * 0.5 + (moveComparison === "implied_above_historical" ? 5 : 0));
        break;
      default:
        suggestedExpiryDays = { min: 7, max: 21 };
        strikeMultiplier = 1.0;
        tierScore = baseScore;
    }

    const expApprox = new Date();
    expApprox.setDate(expApprox.getDate() + suggestedExpiryDays.min);
    const expStr = expApprox.toISOString().slice(0, 10);
    const earningsEvent = catalysts.find((c) => c.type === "earnings" && c.date && c.date <= expStr);
    const earningsBeforeExpiration = earningsEvent?.date ?? undefined;

    const high = opportunity.high52Week ?? opportunity.currentPrice * 1.2;
    const low = opportunity.low52Week ?? opportunity.currentPrice * 0.8;
    const priceVs52wPercent =
      high > low
        ? Math.round(Math.max(0, Math.min(100, ((opportunity.currentPrice - low) / (high - low)) * 100)))
        : undefined;

    return {
      tier,
      symbol: opportunity.symbol,
      structureType: opportunity.structure?.type ?? "vertical_spread",
      direction: opportunity.structure?.direction ?? opportunity.signal?.direction ?? "bullish",
      suggestedExpiryDays,
      strikeMultiplier,
      impliedMovePercent: Math.round(impliedMovePercent * 100) / 100,
      historicalMovePercent: Math.round(historicalMovePercent * 100) / 100,
      moveComparison,
      catalystSummary,
      catalysts,
      tierScore: Math.round(tierScore),
      winProbability: winProb,
      probMaxLoss: Math.round((1 - winProb) * 100),
      expectedReturn: expReturn,
      currentPrice: opportunity.currentPrice,
      regime: opportunity.regime ?? "unknown",
      timestamp: Date.now(),
      earningsBeforeExpiration,
      priceVs52wPercent,
    };
  });

  return options;
}

/**
 * Generate 3 options (Conservative/Balanced/Aggressive). Intent picks the best; full universe when intent allows.
 * Same thesis; differ by risk (tight/medium/wide), DTE, capital.
 */
export async function generateTradeOptionsWithIntent(
  opportunity: MarketOpportunity,
  intent: IntentDecision
): Promise<GeneratedTradeOption[]> {
  const allowedIds = getAllowedStructureIdsFromIntent(intent, opportunity.regime ?? "");
  const directionDefault =
    intent.direction === "BEARISH"
      ? "vertical_put_spread"
      : intent.direction === "NEUTRAL"
        ? "iron_condor"
        : "vertical_call_spread";
  // When intent is directional, Conservative MUST get the direction-matching structure (no thesis/display contradiction).
  let structurePool = allowedIds.length > 0 ? allowedIds : [directionDefault];
  if (intent.direction === "BULLISH" || intent.direction === "BEARISH") {
    const hasDefault = structurePool.includes(directionDefault);
    if (hasDefault && structurePool[0] !== directionDefault) {
      structurePool = [directionDefault, ...structurePool.filter((id) => id !== directionDefault)];
    }
  }
  const symbol = opportunity.symbol;
  const regimeRaw = opportunity.regime ?? "";
  const rotateBy =
    structurePool.length > 1 && intent.direction === "NEUTRAL"
      ? Math.abs(
          (symbol + regimeRaw).split("").reduce((h, c) => ((h << 5) - h + c.charCodeAt(0)) | 0, 0)
        ) % structurePool.length
      : 0;
  const catalysts = await getCatalystsForSymbol(symbol);
  const flow = await getUnusualFlow(
    symbol,
    undefined,
    opportunity.impliedVolatility ?? 0.25
  );
  const impliedMovePercent = flow.impliedMovePercent ?? (opportunity.impliedVolatility ?? 0.25) * 100 * 0.4;
  const ivRank = opportunity.ivRank ?? 50;
  const historicalMovePercent = (ivRank / 100) * 15 + 5;
  const moveComparison =
    impliedMovePercent > historicalMovePercent * 1.2
      ? "implied_above_historical"
      : impliedMovePercent < historicalMovePercent * 0.8
        ? "implied_below_historical"
        : "aligned";
  const catalystSummary =
    catalysts.length > 0
      ? catalysts.slice(0, 3).map((c) => `${c.type}: ${c.title}`).join("; ")
      : "No catalysts (market/options data)";
  const baseScore = opportunity.opportunity?.score ?? 50;
  const winProb = opportunity.opportunity?.winProbability ?? 0.5;
  const expReturn = opportunity.opportunity?.expectedReturn ?? 0;

  const regimeStability = opportunity.regimeStability ?? 0.8;
  const confidenceForRanking =
    process.env.ENABLE_CONFIDENCE_CALIBRATION === "true"
      ? calibrateConfidence(intent.confidence, opportunity.regime ?? "")
      : intent.confidence;
  const expReturnNorm = Math.min((expReturn ?? 0) / 20, 10);
  const rankingScore = expReturnNorm * 0.35 + winProb * 0.35 + confidenceForRanking * 0.15 + regimeStability * 0.15;

  const tiers: TradeTier[] = ["conservative", "balanced", "aggressive"];
  const result: GeneratedTradeOption[] = tiers.map((tier, i) => {
    let suggestedExpiryDays: { min: number; max: number };
    let strikeMultiplier: number;
    const structureType = structurePool[(i + rotateBy) % structurePool.length] ?? structurePool[0];
    switch (tier) {
      case "conservative":
        suggestedExpiryDays = { min: 14, max: 30 };
        strikeMultiplier = 0.6;
        break;
      case "balanced":
        suggestedExpiryDays = { min: 7, max: 21 };
        strikeMultiplier = 1.0;
        break;
      case "aggressive":
        suggestedExpiryDays = { min: 3, max: 14 };
        strikeMultiplier = 1.4;
        break;
      default:
        suggestedExpiryDays = { min: 7, max: 21 };
        strikeMultiplier = 1.0;
    }
    const tierBias = tier === "conservative" ? -2 : tier === "aggressive" ? 2 : 0;
    const tierScore = Math.round(Math.min(100, Math.max(0, rankingScore * 100 + tierBias)));
    const directionFromIntent =
      intent.direction === "BULLISH" ? "bullish" : intent.direction === "BEARISH" ? "bearish" : "neutral";

    const expApprox = new Date();
    expApprox.setDate(expApprox.getDate() + suggestedExpiryDays.min);
    const expStr = expApprox.toISOString().slice(0, 10);
    const earningsEvent = catalysts.find((c) => c.type === "earnings" && c.date && c.date <= expStr);
    const earningsBeforeExpiration = earningsEvent?.date ?? undefined;

    const high = opportunity.high52Week ?? opportunity.currentPrice * 1.2;
    const low = opportunity.low52Week ?? opportunity.currentPrice * 0.8;
    const priceVs52wPercent =
      high > low
        ? Math.round(Math.max(0, Math.min(100, ((opportunity.currentPrice - low) / (high - low)) * 100)))
        : undefined;

    return {
      tier,
      symbol: opportunity.symbol,
      structureType,
      direction: directionFromIntent,
      suggestedExpiryDays,
      strikeMultiplier,
      impliedMovePercent: Math.round(impliedMovePercent * 100) / 100,
      historicalMovePercent: Math.round(historicalMovePercent * 100) / 100,
      moveComparison,
      catalystSummary,
      catalysts,
      tierScore,
      winProbability: winProb,
      probMaxLoss: Math.round((1 - winProb) * 100),
      expectedReturn: expReturn,
      currentPrice: opportunity.currentPrice,
      regime: opportunity.regime ?? "unknown",
      timestamp: Date.now(),
      earningsBeforeExpiration,
      priceVs52wPercent,
    };
  });
  return result;
}

/**
 * Get today's best opportunity + generated options (Conservative/Balanced/Aggressive).
 * Uses scanner's top pick; optionally run scan if empty.
 * If useIntentGovernance is true, uses blueprint flow: intent → strategy filter → 3 options.
 */
export async function getTodayOpportunityOptions(
  runScanIfEmpty = false,
  useIntentGovernance = true
): Promise<{
  opportunity: MarketOpportunity | null;
  options: GeneratedTradeOption[];
  catalystsBySymbol: Map<string, CatalystEvent[]>;
  intent?: IntentDecision;
}> {
  const scanner = getMarketScanner();
  if (runScanIfEmpty && scanner.getStatus().totalOpportunities === 0) {
    await scanner.scan();
  }
  const top = scanner.getHighestExplosiveSetup();
  if (!top) {
    return { opportunity: null, options: [], catalystsBySymbol: new Map() };
  }
  if (useIntentGovernance) {
    const ctx = await buildMarketContext(top);
    const intent = await generateIntentDecision(ctx);
    const options = await generateTradeOptionsWithIntent(top, intent);
    const catalystsBySymbol = new Map<string, CatalystEvent[]>();
    options[0]?.catalysts && catalystsBySymbol.set(top.symbol, options[0].catalysts);
    return { opportunity: top, options, catalystsBySymbol, intent };
  }
  const options = await generateTradeOptions(top);
  const catalystsBySymbol = new Map<string, CatalystEvent[]>();
  options[0]?.catalysts && catalystsBySymbol.set(top.symbol, options[0].catalysts);
  return { opportunity: top, options, catalystsBySymbol };
}

/** Default number of top opportunities to return when asking for "today's opportunities". */
const DEFAULT_TOP_N = 15;

/**
 * Get top N opportunities + generated options for each. Use for "Today's Opportunity" showing multiple picks.
 * If useIntentGovernance is true, each row includes intent (Market Thesis); one intent call per symbol.
 */
export async function getTodayOpportunitiesOptions(
  runScanIfEmpty = false,
  topN = DEFAULT_TOP_N,
  useIntentGovernance = true
): Promise<{
  opportunities: Array<{
    opportunity: MarketOpportunity;
    options: GeneratedTradeOption[];
    intent?: IntentDecision;
  }>;
  timestamp: number;
  vix?: number;
}> {
  let vixLevel = 0;
  try {
    const { getVIX } = await import("./ib-market-data");
    vixLevel = await getVIX();
  } catch {
    /* VIX optional */
  }

  const scanner = getMarketScanner();
  if (runScanIfEmpty && scanner.getStatus().totalOpportunities === 0) {
    await scanner.scan();
  }
  let list = scanner.getTopOpportunities(Math.min(topN, 20));
  if (list.length < topN) {
    const withIlliquid = scanner.getTopOpportunities(Math.min(topN * 2, 40), { includeIlliquid: true });
    const seen = new Set(list.map((o) => o.symbol));
    for (const o of withIlliquid) {
      if (seen.has(o.symbol)) continue;
      list = [...list, o];
      seen.add(o.symbol);
      if (list.length >= topN) break;
    }
  }
  const opportunities: Array<{ opportunity: MarketOpportunity; options: GeneratedTradeOption[]; intent?: IntentDecision }> = [];
  for (const opp of list) {
    if (useIntentGovernance) {
      const ctx = await buildMarketContext(opp);
      const intent = await generateIntentDecision(ctx);
      const options = await generateTradeOptionsWithIntent(opp, intent);
      opportunities.push({ opportunity: opp, options, intent });
    } else {
      const options = await generateTradeOptions(opp);
      opportunities.push({ opportunity: opp, options });
    }
  }
  return { opportunities, timestamp: Date.now(), vix: vixLevel > 0 ? vixLevel : undefined };
}

/**
 * Generate options for one symbol using intent (Claude or enhanced fallback). Full-time intent path.
 * Use for generateOptionsForSymbol so all option generation is intent-governed.
 */
export async function getOptionsForSymbolWithIntent(symbol: string): Promise<{
  success: true;
  options: GeneratedTradeOption[];
  opportunity: MarketOpportunity;
  intent: IntentDecision;
} | { success: false; options: GeneratedTradeOption[]; message: string }> {
  const scanner = getMarketScanner();
  const opp = scanner.getOpportunity(symbol);
  if (!opp) {
    return {
      success: false,
      options: [],
      message: "Symbol not in scan. Run market scan first.",
    };
  }
  const ctx = await buildMarketContext(opp);
  const intent = await generateIntentDecision(ctx);
  const options = await generateTradeOptionsWithIntent(opp, intent);
  return { success: true, options, opportunity: opp, intent };
}
