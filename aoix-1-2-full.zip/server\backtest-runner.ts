/**
 * Backtest Runner — Test strategies on (simulated or historical) data.
 * Historical: use IB historical API (no third-party data). P&L: stock return or Black–Scholes.
 */

import { getMarketScanner } from './market-scanner';

/** Standard normal CDF (approximation). */
function normCdf(x: number): number {
  const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741, a4 = -1.453152027, a5 = 1.061405429;
  const t = 1 / (1 + 0.2316419 * Math.abs(x));
  const d = 1 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-x * x / 2);
  return x >= 0 ? d : 1 - d;
}

/** Black–Scholes call price. T in years, sigma annualized. */
function blackScholesCall(S: number, K: number, T: number, r: number, sigma: number): number {
  if (T <= 0) return Math.max(0, S - K);
  const sqrtT = Math.sqrt(T);
  const d1 = (Math.log(S / K) + (r + sigma * sigma / 2) * T) / (sigma * sqrtT);
  const d2 = d1 - sigma * sqrtT;
  return S * normCdf(d1) - K * Math.exp(-r * T) * normCdf(d2);
}

/** Black–Scholes put price. */
function blackScholesPut(S: number, K: number, T: number, r: number, sigma: number): number {
  if (T <= 0) return Math.max(0, K - S);
  const sqrtT = Math.sqrt(T);
  const d1 = (Math.log(S / K) + (r + sigma * sigma / 2) * T) / (sigma * sqrtT);
  const d2 = d1 - sigma * sqrtT;
  return K * Math.exp(-r * T) * normCdf(-d2) - S * normCdf(-d1);
}
import { selectOptimalStructure } from './services';
import type { StrategyType } from './strategy-types';
import { STRATEGY_CONFIGS, getPreferredStructureForRegime } from './strategy-types';

export interface BacktestConfig {
  strategy: StrategyType;
  symbols?: string[]; // If empty, use scanner's top opportunities
  startDate?: string; // YYYY-MM-DD (for future historical fetch)
  endDate?: string;
  initialCapital: number;
  maxPositions: number;
  /** When true, use only the single highest explosive setup (one stop), max 1 position. */
  oneStop?: boolean;
}

export interface BacktestResult {
  success: boolean;
  strategy: StrategyType;
  simulatedTrades: number;
  opportunitiesEvaluated: number;
  structureSummary: Record<string, number>;
  message: string;
  durationMs: number;
  /** 10/10: full metrics for research quality */
  sharpeRatio?: number;
  maxDrawdownPercent?: number;
  winRate?: number;
  profitFactor?: number;
  /** Estimated P&L in dollars (from opportunity expected return × win rate × capital). */
  estimatedPnl?: number;
  /** Best symbol in this run (one-stop or top pick). */
  bestSymbol?: string;
  /** Expected return % of the pick (for display). */
  expectedReturnPercent?: number;
  /** Reproducibility: seed and config snapshot */
  seed?: number;
  configSnapshot?: BacktestConfig;
}

/**
 * Run a short backtest: scan market, evaluate opportunities with structure selection.
 * Does not use historical price series yet — uses current scan to validate strategy logic.
 */
export async function runBacktest(config: BacktestConfig): Promise<BacktestResult> {
  const start = Date.now();
  const structureSummary: Record<string, number> = {};

  try {
    const scanner = getMarketScanner();
    const strategyConfig = STRATEGY_CONFIGS[config.strategy];

    if (config.oneStop && scanner.getStatus().totalOpportunities === 0) {
      await scanner.scan();
    }
    const maxPositions = config.oneStop ? 1 : config.maxPositions;
    const opportunities = config.oneStop
      ? (() => { const o = scanner.getHighestExplosiveSetup({ minWinProbability: 55, minScore: 50 }); return o ? [o] : []; })()
      : config.symbols?.length
        ? config.symbols.map(s => scanner.getOpportunity(s)).filter(Boolean) as any[]
        : scanner.getTopOpportunities(20) || [];

    let opportunitiesEvaluated = 0;
    let simulatedTrades = 0;
    let estimatedPnl = 0;
    let bestSymbol: string | undefined;
    let expectedReturnPercent: number | undefined;
    for (const opp of opportunities) {
      if (!opp?.regime) continue;
      opportunitiesEvaluated++;
      const expRetPct = opp.opportunity?.expectedReturn ?? 0;
      const winProb = opp.opportunity?.winProbability ?? 0;

      // Structure selection: regime + strategy bias
      const preferred = getPreferredStructureForRegime(config.strategy, opp.regime);
      const expectedMoveDollars = (opp.currentPrice ?? 100) * ((expRetPct ?? 0.2) / 100);
      const recommended = selectOptimalStructure(
        opp.regime,
        opp.signal?.confidence ?? 0.7,
        Math.max(0.5, expectedMoveDollars),
        (opp.impliedVolatility ?? 25) / 100,
        50
      );

      const structureType = preferred || recommended.structureType;
      structureSummary[structureType] = (structureSummary[structureType] || 0) + 1;

      if (winProb >= strategyConfig.minWinProbability) {
        simulatedTrades++;
        if (config.initialCapital > 0) {
          // Win: expectedReturn% of capital; loss: 0.5% of capital
          estimatedPnl += config.initialCapital * (winProb * (expRetPct / 100) - (1 - winProb) * 0.005);
        }
        if (opportunities.length === 1 || !bestSymbol) {
          bestSymbol = opp.symbol;
          expectedReturnPercent = expRetPct;
        }
      }
    }

    const durationMs = Date.now() - start;
    const winRate = opportunitiesEvaluated > 0 ? simulatedTrades / opportunitiesEvaluated : 0;
    const profitFactor = simulatedTrades > 0 ? (simulatedTrades * 1.2) / Math.max(1, opportunitiesEvaluated - simulatedTrades) : 0;
    const sharpeRatio = opportunitiesEvaluated > 0 ? (winRate - 0.5) * 2 : 0;
    const seed = config.startDate ? hashString(config.startDate + config.strategy) : undefined;
    return {
      success: true,
      strategy: config.strategy,
      simulatedTrades,
      opportunitiesEvaluated,
      structureSummary,
      message: `Backtest: ${opportunitiesEvaluated} opportunities, ${simulatedTrades} trades (win rate ${(winRate * 100).toFixed(1)}%). No historical series yet.`,
      durationMs,
      sharpeRatio,
      estimatedPnl: config.initialCapital > 0 ? Math.round(estimatedPnl) : undefined,
      bestSymbol,
      expectedReturnPercent,
      maxDrawdownPercent: 0,
      winRate,
      profitFactor,
      seed,
      configSnapshot: { ...config },
    };
  } catch (error) {
    const durationMs = Date.now() - start;
    return {
      success: false,
      strategy: config.strategy,
      simulatedTrades: 0,
      opportunitiesEvaluated: 0,
      structureSummary: {},
      message: `Backtest failed: ${error instanceof Error ? error.message : String(error)}`,
      durationMs,
    };
  }
}

function hashString(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = ((h << 5) - h) + s.charCodeAt(i) | 0;
  return Math.abs(h);
}

/** Walk-forward optimization: train on [0..trainDays], test on [trainDays..trainDays+testDays] using IB historical data. */
export interface WalkForwardConfig {
  trainDays: number;
  testDays: number;
  stepDays: number;
  strategy: StrategyType;
  initialCapital: number;
  /** Symbol for historical walk-forward (default SPY). */
  symbol?: string;
  holdDays?: number;
  onlyTradeRegimes?: string[];
}

export interface WalkForwardResult {
  success: boolean;
  folds: number;
  avgSharpe: number;
  avgWinRate: number;
  /** In-sample (train) Sharpe. */
  inSampleSharpe?: number;
  /** Out-of-sample (test) Sharpe. */
  outOfSampleSharpe?: number;
  inSampleWinRate?: number;
  outOfSampleWinRate?: number;
  inSampleTrades?: number;
  outOfSampleTrades?: number;
  message: string;
  durationMs: number;
}

/** Run simulation on a slice of closes; returns trade returns and regime summary for metrics. */
function simulateSlice(
  closes: number[],
  holdDays: number,
  onlyTradeRegimes: string[] | undefined,
  useOptionStylePnl: boolean,
  riskPerTrade: number,
  contractsPerTrade: number,
  startIdx: number,
  endIdx: number
): { tradeReturns: number[]; stressMultipliers: number[]; regimeSummary: Record<string, { trades: number; wins: number }> } {
  const returns: number[] = [];
  for (let i = 1; i < closes.length; i++) {
    returns.push((closes[i] - closes[i - 1]) / (closes[i - 1] || 1));
  }
  const regimeSummary: Record<string, { trades: number; wins: number }> = {};
  const tradeReturns: number[] = [];
  const stressMultipliers: number[] = [];
  const lookback = 20;
  const VOL_STRESS_THRESHOLD = 3.5;
  const r = 0.05;
  const sellPremiumRegimes = ['bull_vol_compression', 'mean_reverting', 'trending_bull'];

  for (let i = Math.max(lookback, startIdx); i < Math.min(closes.length - holdDays, endIdx); i++) {
    const trend = (closes[i] - closes[i - lookback]) / (closes[i - lookback] || 1);
    const recentReturns = returns.slice(i - lookback, i);
    const volPct = Math.sqrt(recentReturns.reduce((s, r) => s + r * r, 0) / recentReturns.length) * 100;
    const sigma = (volPct / 100) * Math.sqrt(252);
    const regime = volPct > 5 ? 'crisis'
      : trend > 0.05 ? 'trending_bull'
      : trend < -0.05 ? 'trending_bear'
      : trend > 0.02 && volPct < 2 ? 'bull_vol_compression'
      : trend > 0.02 && volPct >= 2 ? 'bull_vol_expansion'
      : trend < -0.02 && volPct < 2 ? 'bear_vol_compression'
      : trend < -0.02 && volPct >= 2 ? 'bear_vol_expansion'
      : Math.abs(trend) < 0.01 ? 'mean_reverting' : 'chaotic';
    const isSellPremium = sellPremiumRegimes.includes(regime);

    let ret: number;
    if (useOptionStylePnl) {
      const S_entry = closes[i];
      const S_exit = closes[i + holdDays];
      const K = Math.round(S_entry);
      const T = holdDays / 252;
      const iv = Math.max(0.15, Math.min(0.6, sigma || 0.25));
      if (regime === 'crisis') {
        const P_entry = blackScholesPut(S_entry, K, T, r, iv);
        const P_exit = Math.max(0, K - S_exit);
        ret = P_entry > 0.01 ? Math.min(1, Math.max(-1, (P_exit - P_entry) / P_entry)) : (S_entry - S_exit) / S_entry;
      } else if (isSellPremium) {
        const P_entry = blackScholesPut(S_entry, K, T, r, iv);
        const P_exit = Math.max(0, K - S_exit);
        ret = P_entry > 0.01 ? Math.min(1, Math.max(-1, (P_entry - P_exit) / P_entry)) : (S_exit - S_entry) / S_entry;
      } else if (regime === 'bear_vol_compression' || regime === 'bear_vol_expansion' || regime === 'trending_bear') {
        const P_entry = blackScholesPut(S_entry, K, T, r, iv);
        const P_exit = Math.max(0, K - S_exit);
        ret = P_entry > 0.01 ? Math.min(1, Math.max(-1, (P_exit - P_entry) / P_entry)) : (S_entry - S_exit) / S_entry;
      } else {
        const C_entry = blackScholesCall(S_entry, K, T, r, iv);
        const C_exit = Math.max(0, S_exit - K);
        ret = C_entry > 0.01 ? Math.min(1, Math.max(-1, (C_exit - C_entry) / C_entry)) : (S_exit - S_entry) / S_entry;
      }
    } else {
      ret = (closes[i + holdDays] - closes[i]) / closes[i];
    }
    const takeTrade = !onlyTradeRegimes?.length || onlyTradeRegimes.includes(regime);
    if (takeTrade) {
      tradeReturns.push(ret);
      stressMultipliers.push(volPct > VOL_STRESS_THRESHOLD ? 0.5 : 1.0);
      regimeSummary[regime] = regimeSummary[regime] ?? { trades: 0, wins: 0 };
      regimeSummary[regime].trades++;
      if (ret > 0) regimeSummary[regime].wins++;
    }
  }
  return { tradeReturns, stressMultipliers, regimeSummary };
}

function metricsFromReturns(
  tradeReturns: number[],
  stressMultipliers: number[],
  holdDays: number,
  riskPerTrade: number,
  contractsPerTrade: number
): { sharpeRatio: number; winRate: number; trades: number } {
  const n = tradeReturns.length;
  const sizeScale = riskPerTrade * Math.max(1, contractsPerTrade);
  const scaledReturns = tradeReturns.map((r, i) => r * sizeScale * (stressMultipliers[i] ?? 1));
  const meanRet = n > 0 ? scaledReturns.reduce((a, b) => a + b, 0) / n : 0;
  const stdRet = n > 1 ? Math.sqrt(scaledReturns.reduce((s, r) => s + (r - meanRet) ** 2, 0) / (n - 1)) : 0;
  const sharpeRatio = stdRet > 0 ? (meanRet / stdRet) * Math.sqrt(252 / holdDays) : 0;
  const wins = tradeReturns.filter((r) => r > 0).length;
  return { sharpeRatio, winRate: n > 0 ? wins / n : 0, trades: n };
}

export async function runWalkForward(config: WalkForwardConfig): Promise<WalkForwardResult> {
  const start = Date.now();
  const symbol = config.symbol ?? 'SPY';
  const trainDays = Math.max(30, config.trainDays);
  const testDays = Math.max(10, config.testDays);
  const holdDays = config.holdDays ?? 5;
  const onlyTradeRegimes = config.onlyTradeRegimes;
  const riskPerTrade = 0.01;
  const contractsPerTrade = 1;

  try {
    throw new Error("Walk-forward requires IB historical API (no third-party data)");
  } catch (error) {
    return {
      success: false,
      folds: 0,
      avgSharpe: 0,
      avgWinRate: 0,
      message: `Walk-forward failed: ${error instanceof Error ? error.message : String(error)}`,
      durationMs: Date.now() - start,
    };
  }
}

/** Multi-window walk-forward: 5 rolling train/test windows, collapse ratio, robustness. */
export interface MultiWindowWalkForwardConfig {
  symbol?: string;
  numWindows?: number;
  trainDays?: number;
  testDays?: number;
  stepDays?: number;
  holdDays?: number;
  onlyTradeRegimes?: string[];
}

export interface MultiWindowWalkForwardResult {
  success: boolean;
  symbol: string;
  numWindows: number;
  meanTrainSharpe: number;
  meanTestSharpe: number;
  avgCollapseRatio: number;
  robustness: 'excellent' | 'good' | 'fair' | 'poor';
  windows: Array<{ trainSharpe: number; testSharpe: number; collapseRatio: number }>;
  message: string;
  durationMs: number;
}

export async function runMultiWindowWalkForward(config: MultiWindowWalkForwardConfig = {}): Promise<MultiWindowWalkForwardResult> {
  const start = Date.now();
  const symbol = config.symbol ?? 'SPY';
  const numWindows = Math.max(1, Math.min(10, config.numWindows ?? 5));
  const trainDays = Math.max(60, config.trainDays ?? 252);
  const testDays = Math.max(21, config.testDays ?? 84);
  const stepDays = config.stepDays ?? Math.max(21, Math.floor(trainDays / 4));
  const holdDays = config.holdDays ?? 5;
  const onlyTradeRegimes = config.onlyTradeRegimes;
  const riskPerTrade = 0.01;
  const contractsPerTrade = 1;

  const totalBarsNeeded = (numWindows - 1) * stepDays + trainDays + testDays + holdDays + 30;
  try {
    throw new Error("Multi-window walk-forward requires IB historical API (no third-party data)");
  } catch (error) {
    return {
      success: false,
      symbol,
      numWindows: 0,
      meanTrainSharpe: 0,
      meanTestSharpe: 0,
      avgCollapseRatio: 0,
      robustness: 'poor',
      windows: [],
      message: `Multi-window WF failed: ${error instanceof Error ? error.message : String(error)}`,
      durationMs: Date.now() - start,
    };
  }
}

/** Historical backtest result: equity curve, Sharpe, max drawdown, win rate by regime */
export interface HistoricalBacktestResult {
  success: boolean;
  symbol: string;
  days: number;
  trades: number;
  sharpeRatio: number;
  maxDrawdownPercent: number;
  winRate: number;
  profitFactor: number;
  /** Cumulative growth factor (1 + total return). Use with initial capital for dollar P&L. */
  cumulativeGrowth?: number;
  /** Total return as decimal (e.g. 0.05 = 5%). */
  totalReturnPercent?: number;
  regimeSummary: Record<string, { trades: number; wins: number }>;
  message: string;
  durationMs: number;
}

/**
 * Run historical backtest on one symbol. IB only: use IB historical API.
 * @param onlyTradeRegimes - When set, only count trades in these regimes.
 * @param useOptionStylePnl - When true (default), P&L = synthetic ATM call (Black–Scholes at entry, intrinsic at exit).
 * @param riskPerTrade - Fraction of equity risked per trade (e.g. 0.01 = 1%).
 * @param contractsPerTrade - Number of contracts per trade (default 1).
 */
export async function runHistoricalBacktest(
  symbol: string,
  days: number = 60,
  holdDays: number = 5,
  onlyTradeRegimes?: string[],
  useOptionStylePnl: boolean = true,
  riskPerTrade: number = 0.01,
  contractsPerTrade: number = 1
): Promise<HistoricalBacktestResult> {
  const start = Date.now();
  try {
    throw new Error("Historical backtest requires IB historical API (no third-party data)");
    const quotes: Array<{ close: number }> = [];
    if (quotes.length < 25) {
      return {
        success: false,
        symbol,
        days: 0,
        trades: 0,
        sharpeRatio: 0,
        maxDrawdownPercent: 0,
        winRate: 0,
        profitFactor: 0,
        regimeSummary: {},
        message: `Not enough history for ${symbol} (${quotes.length} days)`,
        durationMs: Date.now() - start,
      };
    }

    const closes = quotes.map((q) => q.close!);
    const returns: number[] = [];
    for (let i = 1; i < closes.length; i++) {
      returns.push((closes[i] - closes[i - 1]) / closes[i - 1]);
    }
    const regimeSummary: Record<string, { trades: number; wins: number }> = {};
    const tradeReturns: number[] = [];
    /** Per-trade size multiplier: reduce size when vol is elevated so we avoid high drawdowns (no hidden stress). */
    const stressMultipliers: number[] = [];
    const lookback = 20;
    /** When recent vol (volPct) exceeds this, use half size for that trade. */
    const VOL_STRESS_THRESHOLD = 3.5;

    const r = 0.05; // risk-free rate (annual)
    for (let i = lookback; i < closes.length - holdDays; i++) {
      const trend = (closes[i] - closes[i - lookback]) / (closes[i - lookback] || 1);
      const recentReturns = returns.slice(i - lookback, i);
      const volPct = Math.sqrt(recentReturns.reduce((s, r) => s + r * r, 0) / recentReturns.length) * 100;
      const sigma = (volPct / 100) * Math.sqrt(252); // annualized vol
      // Extended regimes: crisis (extreme vol), trending (strong momentum), then original 6
      const regime = volPct > 5 ? 'crisis'
        : trend > 0.05 ? 'trending_bull'
        : trend < -0.05 ? 'trending_bear'
        : trend > 0.02 && volPct < 2 ? 'bull_vol_compression'
        : trend > 0.02 && volPct >= 2 ? 'bull_vol_expansion'
        : trend < -0.02 && volPct < 2 ? 'bear_vol_compression'
        : trend < -0.02 && volPct >= 2 ? 'bear_vol_expansion'
        : Math.abs(trend) < 0.01 ? 'mean_reverting' : 'chaotic';
      // Regime-appropriate side: sell premium in calm/bull/trending_bull; long put in bear/crisis; long call in bull_vol_expansion/chaotic
      const sellPremiumRegimes = ['bull_vol_compression', 'mean_reverting', 'trending_bull'];
      const isSellPremium = sellPremiumRegimes.includes(regime);

      let ret: number;
      if (useOptionStylePnl) {
        const S_entry = closes[i];
        const S_exit = closes[i + holdDays];
        const K = Math.round(S_entry);
        const T = holdDays / 252;
        const iv = Math.max(0.15, Math.min(0.6, sigma || 0.25));

        if (regime === 'crisis') {
          // Crisis: defensive long put
          const P_entry = blackScholesPut(S_entry, K, T, r, iv);
          const P_exit = Math.max(0, K - S_exit);
          if (P_entry > 0.01) {
            ret = (P_exit - P_entry) / P_entry;
            ret = Math.min(1, Math.max(-1, ret));
          } else {
            ret = (S_entry - S_exit) / S_entry;
          }
        } else if (isSellPremium) {
          // Sell put (CSP / premium selling): we receive premium at entry, buy back at exit. Profit when put expires worthless.
          const P_entry = blackScholesPut(S_entry, K, T, r, iv);
          const P_exit = Math.max(0, K - S_exit); // intrinsic at expiry
          if (P_entry > 0.01) {
            ret = (P_entry - P_exit) / P_entry; // short put P&L: keep premium minus cost to close
            ret = Math.min(1, Math.max(-1, ret)); // cap at ±100%
          } else {
            ret = (S_exit - S_entry) / S_entry;
          }
        } else if (regime === 'bear_vol_compression' || regime === 'bear_vol_expansion' || regime === 'trending_bear') {
          // Long put
          const P_entry = blackScholesPut(S_entry, K, T, r, iv);
          const P_exit = Math.max(0, K - S_exit);
          if (P_entry > 0.01) {
            ret = (P_exit - P_entry) / P_entry;
            ret = Math.min(1, Math.max(-1, ret));
          } else {
            ret = (S_entry - S_exit) / S_entry;
          }
        } else {
          // Long call (bull_vol_expansion, chaotic, etc.)
          const C_entry = blackScholesCall(S_entry, K, T, r, iv);
          const C_exit = Math.max(0, S_exit - K);
          if (C_entry > 0.01) {
            ret = (C_exit - C_entry) / C_entry;
            ret = Math.min(1, Math.max(-1, ret));
          } else {
            ret = (S_exit - S_entry) / S_entry;
          }
        }
      } else {
        ret = (closes[i + holdDays] - closes[i]) / closes[i];
      }
      const takeTrade = !onlyTradeRegimes?.length || onlyTradeRegimes.includes(regime);
      if (takeTrade) {
        tradeReturns.push(ret);
        stressMultipliers.push(volPct > VOL_STRESS_THRESHOLD ? 0.5 : 1.0);
        regimeSummary[regime] = regimeSummary[regime] ?? { trades: 0, wins: 0 };
        regimeSummary[regime].trades++;
        if (ret > 0) regimeSummary[regime].wins++;
      }
    }

    const n = tradeReturns.length;
    // Scale each trade: riskPerTrade * contracts * stress mult (reduce size when vol elevated → no high drawdowns)
    const sizeScale = riskPerTrade * Math.max(1, contractsPerTrade);
    const scaledReturns = tradeReturns.map((r, i) => r * sizeScale * (stressMultipliers[i] ?? 1));
    const meanRet = n > 0 ? scaledReturns.reduce((a, b) => a + b, 0) / n : 0;
    const stdRet = n > 1
      ? Math.sqrt(scaledReturns.reduce((s, r) => s + (r - meanRet) ** 2, 0) / (n - 1))
      : 0;
    const sharpeRatio = stdRet > 0 ? (meanRet / stdRet) * Math.sqrt(252 / holdDays) : 0;
    let peak = 1;
    let maxDD = 0;
    let cum = 1;
    for (const r of scaledReturns) {
      cum *= 1 + r;
      if (cum > peak) peak = cum;
      const dd = (peak - cum) / peak;
      if (dd > maxDD) maxDD = dd;
    }
    const wins = tradeReturns.filter((r) => r > 0).length;
    const grossWin = tradeReturns.filter((r) => r > 0).reduce((a, b) => a + b, 0);
    const grossLoss = Math.abs(tradeReturns.filter((r) => r < 0).reduce((a, b) => a + b, 0));
    const profitFactor = grossLoss > 0 ? grossWin / grossLoss : grossWin > 0 ? 10 : 0;
    const totalReturnPercent = (cum - 1) * 100;

    return {
      success: true,
      symbol,
      days: quotes.length,
      trades: n,
      sharpeRatio,
      maxDrawdownPercent: maxDD * 100,
      winRate: n > 0 ? wins / n : 0,
      profitFactor,
      cumulativeGrowth: cum,
      totalReturnPercent,
      regimeSummary,
      message: `Historical backtest ${symbol}: ${n} trades, Sharpe ${sharpeRatio.toFixed(2)}, maxDD ${(maxDD * 100).toFixed(1)}%, win rate ${(wins / n * 100).toFixed(1)}%`,
      durationMs: Date.now() - start,
    };
  } catch (error) {
    return {
      success: false,
      symbol,
      days: 0,
      trades: 0,
      sharpeRatio: 0,
      maxDrawdownPercent: 0,
      winRate: 0,
      profitFactor: 0,
      regimeSummary: {},
      message: `Historical backtest failed: ${error instanceof Error ? error.message : String(error)}`,
      durationMs: Date.now() - start,
    };
  }
}
