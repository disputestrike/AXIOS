/**
 * AOIX-1 Autonomous Trading Engine
 * 
 * IB only.
 * - All market data from IB Gateway
 * - Auto-scan every 30 seconds
 * - Auto-execute trades on top opportunities
 * - Auto-take-profit at +30%
 * - Auto-stop-loss at -20%
 * - Auto-trailing-stop at 10% after +15% gain
 * - Max 3 positions, 1% risk per trade, 5% daily loss limit
 */

import { getMarketScanner, type MarketOpportunity } from './market-scanner';
import { getRealOptionsData, type RealMarketData, type RealOptionsData } from './real-market-data';
import { generateAdvancedSignal } from './advanced-signals';
import { calculateOptimalPositionSize, calculatePortfolioAwareSize, getConfidenceMultiplier } from './position-sizing';
import { analyzeMultiTimeframe } from './multi-timeframe';
import { calculateAdaptiveRisk, calculatePerformanceMetrics, determineMarketConditions, getRegimeRiskMultiplier, getRegimePositionSizeMultiplier } from './adaptive-risk';
import { getAggressionTier } from './aggression-tier';
import { getExitParams, isRegimeFavorableForStrategy, isStructurePreferredForStrategy } from './strategy-types';
import type { StrategyType } from './strategy-types';
import { determineExitStrategy } from './dynamic-exits';
import { calculatePortfolioCorrelation, getOptionDelta, getRealVIX, getOptionGreeks } from './market-utils';
import { computeEntryProbability, shouldEnterByProbability, ENTRY_PROBABILITY_THRESHOLD } from './ml-entry-probability';

// ============================================================================
// TYPES & INTERFACES
// ============================================================================

export interface Position {
  id: string;
  symbol: string;
  optionType: 'call' | 'put';
  strike: number;
  expiry: string;
  quantity: number;
  entryPrice: number;
  currentPrice: number;
  entryTime: number;
  unrealizedPnL: number;
  unrealizedPnLPercent: number;
  regime: string;
  signalClass: string;
  takeProfitPrice: number;
  stopLossPrice: number;
  trailingStopPrice: number | null;
  highWaterMark: number;
  status: 'open' | 'closed';
  exitReason?: string;
  exitPrice?: number;
  exitTime?: number;
  realizedPnL?: number;
  dataSource: string;
}

export interface Trade {
  id: string;
  positionId: string;
  action: 'open' | 'close';
  symbol: string;
  optionType: 'call' | 'put';
  strike: number;
  expiry: string;
  quantity: number;
  price: number;
  timestamp: number;
  regime: string;
  signalClass: string;
  reason: string;
  dataSource: string;
}

export interface TradingState {
  isRunning: boolean;
  accountBalance: number;
  totalEquity: number;
  dayPnL: number;
  totalPnL: number;
  positions: Position[];
  trades: Trade[];
  currentRegime: string;
  lastScanTime: number;
  lastOpportunities: MarketOpportunity[];
  riskMetrics: RiskMetrics;
  lastUpdate: number;
  cycleCount: number;
  autoTradeLog: string[];
  signalQueue: MarketOpportunity[];
  /** Aggression tier 1–5: more aggressive as system proves itself */
  aggressionTier?: number;
  /** Named strategy: wheel | short_term | iron_condor | adaptive */
  strategyType?: string;
  /** Regime risk overlay rationale for logging */
  regimeRationale?: string;
}

export interface RiskMetrics {
  maxRiskPerTrade: number;
  currentExposure: number;
  dailyLossLimit: number;
  currentDailyLoss: number;
  ruinProbability: number;
  killSwitchActive: boolean;
  positionCount: number;
  maxPositions: number;
}

// ============================================================================
// TRADING ENGINE CLASS
// ============================================================================

class AutoTradingEngine {
  private state: TradingState;
  private intervalId: NodeJS.Timeout | null = null;
  
  // Configuration
  private readonly INITIAL_BALANCE = 100000; // $100k paper trading account
  private readonly MAX_RISK_PER_TRADE = 0.01; // 1% max risk per trade
  private readonly TAKE_PROFIT_PERCENT = 0.30; // +30% take profit
  private readonly STOP_LOSS_PERCENT = 0.20; // -20% stop loss
  private readonly MOMENTUM_GLIDE_THRESHOLD = 0.15; // Start trailing at +15%
  private readonly TRAILING_STOP_PERCENT = 0.10; // 10% trailing stop
  private readonly DAILY_LOSS_LIMIT = 0.05; // 5% daily loss limit
  private readonly RUIN_PROBABILITY_THRESHOLD = 0.10; // 10% ruin probability kill switch
  private readonly MAX_POSITIONS = 3; // Max concurrent positions
  private readonly CHECK_INTERVAL_MS = 30000; // Check every 30 seconds
  private readonly MIN_SCORE_THRESHOLD = 70; // Minimum opportunity score to trade (relaxed from 85)
  private readonly MIN_WIN_PROBABILITY = 0.55; // Minimum win probability (relaxed from 60%)
  private readonly MIN_REGIME_CONFIDENCE = 0.55; // Regime/signal confidence (relaxed from 85%)
  
  // Advanced features - will be calculated dynamically
  private adaptiveRiskMultiplier: number = 1.0;
  private adaptiveMaxPositions: number = 3;
  private adaptiveMinScore: number = 70;

  constructor() {
    this.state = this.initializeState();
    this.log('Engine initialized with REAL IBKR-only data integration');
  }

  private initializeState(): TradingState {
    return {
      isRunning: false,
      accountBalance: this.INITIAL_BALANCE,
      totalEquity: this.INITIAL_BALANCE,
      dayPnL: 0,
      totalPnL: 0,
      positions: [],
      trades: [],
      currentRegime: 'unknown',
      lastScanTime: 0,
      lastOpportunities: [],
      riskMetrics: {
        maxRiskPerTrade: this.INITIAL_BALANCE * this.MAX_RISK_PER_TRADE,
        currentExposure: 0,
        dailyLossLimit: this.INITIAL_BALANCE * this.DAILY_LOSS_LIMIT,
        currentDailyLoss: 0,
        ruinProbability: 0,
        killSwitchActive: false,
        positionCount: 0,
        maxPositions: this.MAX_POSITIONS,
      },
      lastUpdate: Date.now(),
      cycleCount: 0,
      autoTradeLog: [],
      signalQueue: [],
      aggressionTier: 1,
      strategyType: 'adaptive',
    };
  }

  private log(message: string): void {
    const timestamp = new Date().toISOString();
    const logEntry = `[${timestamp}] ${message}`;
    console.log(`[AutoTrading] ${message}`);
    this.state.autoTradeLog.push(logEntry);
    // Keep only last 100 log entries
    if (this.state.autoTradeLog.length > 100) {
      this.state.autoTradeLog = this.state.autoTradeLog.slice(-100);
    }
  }

  // ============================================================================
  // ENGINE CONTROL
  // ============================================================================

  public start(): void {
    if (this.state.isRunning) {
      this.log('Engine already running');
      return;
    }

    this.log('🚀 STARTING AUTONOMOUS TRADING ENGINE');
    this.log('Configuration:');
    this.log(`  - Max Risk Per Trade: ${this.MAX_RISK_PER_TRADE * 100}%`);
    this.log(`  - Take Profit: +${this.TAKE_PROFIT_PERCENT * 100}%`);
    this.log(`  - Stop Loss: -${this.STOP_LOSS_PERCENT * 100}%`);
    this.log(`  - Trailing Stop: ${this.TRAILING_STOP_PERCENT * 100}% after +${this.MOMENTUM_GLIDE_THRESHOLD * 100}%`);
    this.log(`  - Max Positions: ${this.MAX_POSITIONS}`);
    this.log(`  - Min Score: ${this.MIN_SCORE_THRESHOLD}`);
    this.log(`  - Scan Interval: ${this.CHECK_INTERVAL_MS / 1000}s`);
    
    this.state.isRunning = true;
    
    // Run immediately, then on interval
    this.runTradingCycle();
    this.intervalId = setInterval(() => this.runTradingCycle(), this.CHECK_INTERVAL_MS);
    
    this.log('Engine started - autonomous trading active');
  }

  public stop(): void {
    if (!this.state.isRunning) {
      this.log('Engine not running');
      return;
    }

    this.log('⏹️ STOPPING AUTONOMOUS TRADING ENGINE');
    this.state.isRunning = false;
    
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    
    this.log('Engine stopped - positions remain open');
  }

  public getState(): TradingState {
    return { ...this.state };
  }

  public resetAccount(): void {
    this.stop();
    this.state = this.initializeState();
    this.log('Account reset to initial state');
  }

  // ============================================================================
  // MAIN TRADING CYCLE
  // ============================================================================

  private async runTradingCycle(): Promise<void> {
    this.state.cycleCount++;
    const cycleNum = this.state.cycleCount;
    
    try {
      this.log(`━━━ CYCLE #${cycleNum} START ━━━`);
      
      // 1. Check kill switch
      if (this.state.riskMetrics.killSwitchActive) {
        this.log('⛔ Kill switch active - skipping cycle');
        return;
      }

      // 2. Scan market for REAL opportunities (10/10: retry up to 2 times on transient failure)
      this.log('📡 Scanning market with IBKR...');
      const scanner = getMarketScanner();
      const maxScanRetries = 2;
      let opportunities: MarketOpportunity[] = [];
      let lastScanError: Error | null = null;
      for (let attempt = 0; attempt <= maxScanRetries; attempt++) {
        try {
          opportunities = await scanner.scan();
          lastScanError = null;
          break;
        } catch (err) {
          lastScanError = err instanceof Error ? err : new Error(String(err));
          this.log(`⚠️ Scan attempt ${attempt + 1}/${maxScanRetries + 1} failed: ${lastScanError.message}`);
          if (attempt < maxScanRetries) await new Promise(r => setTimeout(r, 2000));
        }
      }
      if (lastScanError) {
        this.log(`❌ Scan failed after ${maxScanRetries + 1} attempts: ${lastScanError.message}`);
        return;
      }

      this.state.lastScanTime = Date.now();
      this.state.lastOpportunities = opportunities;
      
      this.log(`Found ${opportunities.length} opportunities from REAL market data`);
      
      // 3. Update regime from top opportunity (single source of truth — same as Regime dashboard)
      const currentRegime = opportunities.length > 0 ? opportunities[0].regime : 'unknown';
      const leadSignalConfidence = opportunities.length > 0 ? (opportunities[0].signal?.confidence ?? 0) : 0;
      this.state.currentRegime = currentRegime;
      this.log(`   Regime: ${currentRegime} | Lead confidence: ${(leadSignalConfidence * 100).toFixed(1)}%`);
      
      // 4. Update existing positions with REAL prices
      await this.updatePositions();
      
      // 5. Performance from CLOSED positions (realized P&L) — own the metrics
      const closedPositionsForPerf = this.state.positions.filter(
        p => p.status === 'closed' && p.realizedPnL !== undefined
      );
      const performance = calculatePerformanceMetrics(
        closedPositionsForPerf.map(p => ({
          pnl: p.realizedPnL ?? 0,
          pnlPercent: p.entryPrice ? ((p.realizedPnL ?? 0) / (p.entryPrice * p.quantity * 100)) : 0,
          entryTime: p.entryTime,
          exitTime: p.exitTime ?? p.entryTime,
          status: 'closed' as const,
        })),
        this.state.totalEquity,
        this.INITIAL_BALANCE
      );

      // Fetch real VIX for market conditions
      let realVIX = 20; // Default fallback
      try {
        realVIX = await getRealVIX();
      } catch (error) {
        this.log(`⚠️ Failed to fetch VIX, using default: ${error}`);
      }
      const marketTrend = opportunities.length > 0 ? opportunities[0].priceChangePercent : 0;

      const marketConditions = determineMarketConditions(
        realVIX, // REAL VIX
        marketTrend,
        this.state.positions.filter(p => p.status === 'open').map(p => ({ symbol: p.symbol }))
      );

      const riskAdjustment = calculateAdaptiveRisk(performance, marketConditions);
      const closedCount = closedPositionsForPerf.length;
      const aggression = getAggressionTier(performance, closedCount);
      this.state.aggressionTier = aggression.tier;
      let riskMultiplierWithAggression = riskAdjustment.riskMultiplier * aggression.riskMultiplier;
      let maxPositionsWithAggression = Math.min(
        this.MAX_POSITIONS + 2,
        riskAdjustment.maxPositions + aggression.maxPositionBonus
      );
      let minScoreWithAggression = Math.max(65, riskAdjustment.minScoreThreshold - aggression.minScoreReduction);

      // 6. Regime overlay — OWN THE REGIME (bear = tighter, bull + high conf = no extra cut)
      const regimeOverlay = getRegimeRiskMultiplier(currentRegime, leadSignalConfidence);
      riskMultiplierWithAggression *= regimeOverlay.riskMultiplier;
      maxPositionsWithAggression = Math.max(1, maxPositionsWithAggression + regimeOverlay.maxPositionAdjustment);
      this.adaptiveRiskMultiplier = riskMultiplierWithAggression;
      this.adaptiveMaxPositions = maxPositionsWithAggression;
      this.adaptiveMinScore = minScoreWithAggression;
      this.log(`📊 Risk: ${(riskMultiplierWithAggression * 100).toFixed(0)}% risk, ${maxPositionsWithAggression} max pos, min score ${minScoreWithAggression} | Aggression tier ${aggression.tier} (${aggression.rationale})`);
      this.log(`   Adaptive: ${riskAdjustment.rationale} | Regime: ${regimeOverlay.rationale}`);
      this.state.regimeRationale = regimeOverlay.rationale;
      
      // 7. Tradable opportunities: regime confidence + strategy–regime alignment (optimize everything)
      const strategyType = (this.state.strategyType || 'adaptive') as StrategyType;
      const oneStop = process.env.TRADE_ONE_STOP === '1';
      if (oneStop) {
        maxPositionsWithAggression = 1;
        this.adaptiveMaxPositions = 1;
      }
      // Correlation drag: pass existing positions so ranking downweights highly correlated new opportunities
      const openPositionsForRanking = this.state.positions.filter(p => p.status === 'open');
      const existingPositionsForRanking: { symbol: string; delta?: number }[] = openPositionsForRanking.length > 0
        ? await Promise.all(openPositionsForRanking.map(async (p) => {
            try {
              const greeks = await getOptionGreeks(p.symbol, p.strike, p.expiry, p.optionType);
              return { symbol: p.symbol, delta: greeks?.delta };
            } catch {
              return { symbol: p.symbol };
            }
          }))
        : [];
      // IBKR only
      let tradableOpportunities = oneStop
        ? (() => { const o = scanner.getHighestExplosiveSetup({ minWinProbability: 55, minScore: 50, existingPositions: existingPositionsForRanking }); return o ? [o] : []; })()
        : opportunities
            .filter(opp => opp.opportunity.score >= this.adaptiveMinScore)
            .filter(opp => opp.opportunity.winProbability >= this.MIN_WIN_PROBABILITY)
            .filter(opp => opp.dataSource === 'ibkr')
            .filter(opp => (opp.signal?.confidence ?? 0) >= this.MIN_REGIME_CONFIDENCE)
            .sort((a, b) => (a.dataSource === 'ibkr' && b.dataSource !== 'ibkr' ? -1 : b.dataSource === 'ibkr' && a.dataSource !== 'ibkr' ? 1 : 0));
      if (!oneStop && strategyType !== 'adaptive') {
        tradableOpportunities = tradableOpportunities
          .filter(opp => isStructurePreferredForStrategy(strategyType, opp.structure?.type ?? ''))
          .sort((a, b) => {
            const aFav = isRegimeFavorableForStrategy(strategyType, a.regime) ? 1 : 0;
            const bFav = isRegimeFavorableForStrategy(strategyType, b.regime) ? 1 : 0;
            return bFav - aFav; // Favorable first
          });
      }
      if (!oneStop) tradableOpportunities = tradableOpportunities.slice(0, 5);

      const ibkrCount = tradableOpportunities.filter(o => o.dataSource === 'ibkr').length;
      if (ibkrCount > 0) {
        this.log(`Using IBKR data for ${ibkrCount} of ${tradableOpportunities.length} tradable opportunities`);
      }

      const effectiveRisk = oneStop ? { ...riskAdjustment, maxPositions: 1 } : riskAdjustment;
      if (oneStop && tradableOpportunities.length > 0) {
        this.log(`One stop: trading only highest explosive setup — ${tradableOpportunities[0].symbol} (win ${((tradableOpportunities[0].opportunity?.winProbability ?? 0) * 100).toFixed(0)}%, score ${tradableOpportunities[0].opportunity?.score ?? 0})`);
      }
      this.log(`${tradableOpportunities.length} opportunities meet criteria (score >= ${this.adaptiveMinScore}, win prob >= ${(this.MIN_WIN_PROBABILITY * 100).toFixed(0)}%, regime conf >= ${(this.MIN_REGIME_CONFIDENCE * 100).toFixed(0)}%${strategyType !== 'adaptive' ? `, ${strategyType} structure+regime` : ''}${oneStop ? ', one stop' : ''})`);
      if (tradableOpportunities.length === 0 && opportunities.length > 0) {
        const top = opportunities[0];
        this.log(`   Top scan pick: ${top.symbol} score=${top.opportunity?.score ?? 0} win=${((top.opportunity?.winProbability ?? 0) * 100).toFixed(0)}% conf=${((top.signal?.confidence ?? 0) * 100).toFixed(0)}% — adjust thresholds if too strict`);
      }
      
      // 8. Execute trades on top opportunities with advanced analysis
      for (const opp of tradableOpportunities) {
        await this.evaluateAndTradeAdvanced(opp, effectiveRisk);
      }
      
      // 9. Update risk metrics
      this.updateRiskMetrics();
      
      this.state.lastUpdate = Date.now();
      
      const openPositions = this.state.positions.filter(p => p.status === 'open');
      this.log(`━━━ CYCLE #${cycleNum} END ━━━`);
      this.log(`Open positions: ${openPositions.length}/${this.MAX_POSITIONS}`);
      this.log(`Account: $${this.state.accountBalance.toFixed(2)} | Day P&L: $${this.state.dayPnL.toFixed(2)} | Total P&L: $${this.state.totalPnL.toFixed(2)}`);
      
    } catch (error) {
      this.log(`❌ Error in cycle #${cycleNum}: ${error}`);
    }
  }

  // ============================================================================
  // TRADE EVALUATION & EXECUTION
  // ============================================================================

  private async evaluateAndTrade(opportunity: MarketOpportunity): Promise<void> {
    // Legacy method - kept for compatibility
    await this.evaluateAndTradeAdvanced(opportunity, {
      riskMultiplier: 1.0,
      maxPositions: this.MAX_POSITIONS,
      minScoreThreshold: this.MIN_SCORE_THRESHOLD,
      takeProfitMultiplier: 1.0,
      stopLossMultiplier: 1.0,
      rationale: 'Default risk settings',
    });
  }

  /**
   * Advanced trade evaluation with all improvements integrated
   */
  private async evaluateAndTradeAdvanced(
    opportunity: MarketOpportunity,
    riskAdjustment: { riskMultiplier: number; maxPositions: number; minScoreThreshold: number; takeProfitMultiplier: number; stopLossMultiplier: number; rationale: string }
  ): Promise<void> {
    const openPositions = this.state.positions.filter(p => p.status === 'open');
    
    // Check if we already have a position in this symbol
    if (openPositions.some(p => p.symbol === opportunity.symbol)) {
      this.log(`Already have position in ${opportunity.symbol} - skipping`);
      return;
    }
    
    // Check if we can open new positions (using adaptive limit)
    if (openPositions.length >= riskAdjustment.maxPositions) {
      this.log(`Max positions (${riskAdjustment.maxPositions}) reached - skipping ${opportunity.symbol}`);
      return;
    }
    
    try {
      // 1. Get price from IB only
      const { getIBMarketData, getIBOptionsChain } = await import('./ib-market-data');
      const ibPrice = await getIBMarketData(opportunity.symbol);
      if (!ibPrice || ibPrice.price <= 0) {
        this.log(`No IBKR price for ${opportunity.symbol} - skipping`);
        return;
      }
      const priceData: RealMarketData = {
        symbol: opportunity.symbol,
        price: ibPrice.price,
        previousClose: ibPrice.price,
        change: 0,
        changePercent: 0,
        volume: ibPrice.volume ?? 0,
        avgVolume: ibPrice.volume ?? 0,
        high: ibPrice.price,
        low: ibPrice.price,
        open: ibPrice.price,
        marketCap: 0,
        fiftyTwoWeekHigh: ibPrice.price * 1.1,
        fiftyTwoWeekLow: ibPrice.price * 0.9,
        timestamp: Date.now(),
      };
      let optionsData: RealOptionsData | null = null;
      const chain = await getIBOptionsChain(opportunity.symbol);
      if (chain?.options?.length) {
        const opts = chain.options;
        let totalIV = 0, ivCount = 0, callVol = 0, putVol = 0;
        for (const o of opts) {
          if (o.impliedVolatility != null) { totalIV += o.impliedVolatility; ivCount++; }
          if (o.right === 'C') callVol += o.volume ?? 0; else putVol += o.volume ?? 0;
        }
        const avgIV = ivCount > 0 ? totalIV / ivCount : (opportunity.impliedVolatility ?? 0.25);
        optionsData = {
          symbol: opportunity.symbol,
          impliedVolatility: avgIV,
          historicalVolatility: avgIV * 0.9,
          ivRank: opportunity.ivRank ?? 50,
          putCallRatio: callVol > 0 ? putVol / callVol : 1,
          optionsVolume: callVol + putVol,
        };
      }
      if (!optionsData) {
        optionsData = {
          symbol: opportunity.symbol,
          impliedVolatility: opportunity.impliedVolatility ?? 0.25,
          historicalVolatility: 0.25,
          ivRank: opportunity.ivRank ?? 50,
          putCallRatio: 1,
          optionsVolume: 0,
        };
      }

      const advancedSignal = await generateAdvancedSignal(
        opportunity.symbol,
        priceData,
        optionsData,
        [] // Historical data
      );

      if (!advancedSignal || advancedSignal.confidenceScore < 0.50) {
        this.log(`Advanced signal confidence too low for ${opportunity.symbol}: ${advancedSignal?.confidenceScore || 0}`);
        return;
      }

      // 2. Multi-timeframe analysis
      const timeframeAnalysis = await analyzeMultiTimeframe(opportunity.symbol);
      
      if (!timeframeAnalysis || timeframeAnalysis.overallConfidence < 0.45) {
        this.log(`Timeframe alignment too low for ${opportunity.symbol}: ${timeframeAnalysis?.alignment || 0}`);
        return;
      }

      if (timeframeAnalysis.alignment < 0.45) {
        this.log(`Timeframes not aligned for ${opportunity.symbol}: ${timeframeAnalysis.alignment}`);
        return;
      }

      // 3. Check risk-adjusted threshold
      if (advancedSignal.confidenceScore * 100 < riskAdjustment.minScoreThreshold) {
        this.log(`Risk-adjusted threshold not met for ${opportunity.symbol}: ${advancedSignal.confidenceScore * 100} < ${riskAdjustment.minScoreThreshold}`);
        return;
      }

      // 4. Calculate optimal position size using Kelly Criterion
      const timeToExpiry = 14 / 365;
      const optionPrice = opportunity.currentPrice * ((opportunity.impliedVolatility || 25) / 100) * Math.sqrt(timeToExpiry) * 0.4;
      
      // Calculate real performance metrics with actual PnL
      const closedTrades = this.state.positions
        .filter(p => p.status === 'closed' && p.realizedPnL !== undefined)
        .map(p => ({
          pnl: p.realizedPnL || 0,
          pnlPercent: p.realizedPnL && p.entryPrice ? (p.realizedPnL / (p.entryPrice * p.quantity * 100)) : 0,
          entryTime: p.entryTime,
          exitTime: p.exitTime || p.entryTime,
          status: 'closed' as const,
        }));
      
      const performance = calculatePerformanceMetrics(
        closedTrades,
        this.state.totalEquity,
        this.INITIAL_BALANCE
      );

      // Calculate real correlation with existing positions
      const existingSymbols = openPositions.map(p => p.symbol);
      const realCorrelation = existingSymbols.length > 0
        ? await calculatePortfolioCorrelation(existingSymbols, opportunity.symbol)
        : 0;

      // Get real deltas for existing positions
      const positionsWithDeltas = await Promise.all(
        openPositions.map(async (p) => {
          const greeks = await getOptionGreeks(p.symbol, p.strike, p.expiry, p.optionType);
          return {
            symbol: p.symbol,
            quantity: p.quantity,
            delta: greeks.delta,
          };
        })
      );

      let maxRiskPerTrade = this.MAX_RISK_PER_TRADE * riskAdjustment.riskMultiplier;
      if (process.env.ENABLE_CONFIDENCE_SIZING === 'true') {
        const { getRegimeRiskMultiplierForSizing, normalizeRegimeToCanonical } = await import('./intent-governance');
        const regimeMultiplier = getRegimeRiskMultiplierForSizing(normalizeRegimeToCanonical(opportunity.regime ?? ''));
        const confidenceMultiplier = getConfidenceMultiplier(advancedSignal?.confidenceScore);
        maxRiskPerTrade *= regimeMultiplier * confidenceMultiplier;
      }
      const positionSize = calculatePortfolioAwareSize(
        {
          accountBalance: this.state.accountBalance,
          winProbability: advancedSignal.winProbability,
          avgWinSize: advancedSignal.expectedMove / 100,
          avgLossSize: advancedSignal.expectedMove * 0.4 / 100,
          currentDrawdown: performance.currentDrawdown,
          volatility: optionsData.impliedVolatility || 0.25,
          correlation: realCorrelation, // REAL correlation
          maxRiskPerTrade,
          optionPrice,
          strike: opportunity.currentPrice,
          currentPrice: opportunity.currentPrice,
        },
        positionsWithDeltas // REAL deltas
      );

      if (positionSize.quantity < 1) {
        this.log(`Position size too small for ${opportunity.symbol} after risk adjustments`);
        return;
      }

      // 6. Execute the trade with advanced features
      await this.openPositionAdvanced(opportunity, advancedSignal, timeframeAnalysis, positionSize, riskAdjustment);
      
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error);
      const errorStack = error instanceof Error ? error.stack : undefined;
      this.log(`❌ Error evaluating ${opportunity.symbol}: ${errorMessage}`);
      if (errorStack) {
        console.error(`[AutoTradingEngine] Stack trace for ${opportunity.symbol}:`, errorStack);
      }
      // Don't throw - continue with next opportunity
    }
  }

  private async openPosition(opportunity: MarketOpportunity): Promise<void> {
    // Legacy method — IB only
    const { getIBMarketData, getIBOptionsChain } = await import('./ib-market-data');
    const ibPrice = await getIBMarketData(opportunity.symbol);
    if (!ibPrice || ibPrice.price <= 0) return;
    const priceData: RealMarketData = {
      symbol: opportunity.symbol,
      price: ibPrice.price,
      previousClose: ibPrice.price,
      change: 0,
      changePercent: 0,
      volume: ibPrice.volume ?? 0,
      avgVolume: ibPrice.volume ?? 0,
      high: ibPrice.price,
      low: ibPrice.price,
      open: ibPrice.price,
      marketCap: 0,
      fiftyTwoWeekHigh: ibPrice.price * 1.1,
      fiftyTwoWeekLow: ibPrice.price * 0.9,
      timestamp: Date.now(),
    };
    let optionsData: RealOptionsData | null = await getRealOptionsData(opportunity.symbol);
    if (!optionsData) {
      const chain = await getIBOptionsChain(opportunity.symbol);
      const iv = chain?.options?.[0]?.impliedVolatility ?? opportunity.impliedVolatility ?? 0.25;
      optionsData = {
        symbol: opportunity.symbol,
        impliedVolatility: typeof iv === 'number' ? iv : 0.25,
        historicalVolatility: 0.25,
        ivRank: opportunity.ivRank ?? 50,
        putCallRatio: 1,
        optionsVolume: 0,
      };
    }
    if (!optionsData) return;

    const advancedSignal = await generateAdvancedSignal(opportunity.symbol, priceData, optionsData, []);
    const timeframeAnalysis = await analyzeMultiTimeframe(opportunity.symbol);
    
    if (!advancedSignal || !timeframeAnalysis) return;

    const timeToExpiry = 14 / 365;
    const optionPrice = opportunity.currentPrice * ((opportunity.impliedVolatility || 25) / 100) * Math.sqrt(timeToExpiry) * 0.4;
    
    const performance = calculatePerformanceMetrics([], this.state.totalEquity, this.INITIAL_BALANCE);
    const positionSize = calculateOptimalPositionSize({
      accountBalance: this.state.accountBalance,
      winProbability: advancedSignal.winProbability,
      avgWinSize: advancedSignal.expectedMove / 100,
      avgLossSize: advancedSignal.expectedMove * 0.4 / 100,
      currentDrawdown: performance.currentDrawdown,
      volatility: optionsData.impliedVolatility || 0.25,
      correlation: 0.5,
      maxRiskPerTrade: this.MAX_RISK_PER_TRADE,
      optionPrice,
      strike: opportunity.currentPrice,
      currentPrice: opportunity.currentPrice,
    });

    await this.openPositionAdvanced(
      opportunity,
      advancedSignal,
      timeframeAnalysis,
      positionSize,
      { riskMultiplier: 1.0, maxPositions: this.MAX_POSITIONS, minScoreThreshold: this.MIN_SCORE_THRESHOLD, takeProfitMultiplier: 1.0, stopLossMultiplier: 1.0, rationale: 'Default' }
    );
  }

  /**
   * Advanced position opening with all improvements
   */
  private async openPositionAdvanced(
    opportunity: MarketOpportunity,
    advancedSignal: any,
    timeframeAnalysis: any,
    positionSize: any,
    riskAdjustment: { riskMultiplier: number; maxPositions: number; minScoreThreshold: number; takeProfitMultiplier: number; stopLossMultiplier: number; rationale: string }
  ): Promise<void> {
    // Determine option type based on regime and timeframe signal
    const isBullish = opportunity.regime.includes('bull') || timeframeAnalysis.overallSignal.includes('buy');
    const optionType: 'call' | 'put' = isBullish ? 'call' : 'put';
    
    // Use timeframe analysis for strike selection
    const strike = Math.round(opportunity.currentPrice * (isBullish ? 1.02 : 0.98));
    
    // Calculate option price (simplified - use IV to estimate)
    const timeToExpiry = 14 / 365;
    const optionPrice = opportunity.currentPrice * ((opportunity.impliedVolatility || 25) / 100) * Math.sqrt(timeToExpiry) * 0.4;
    
    // Use optimal position size from Kelly Criterion
    const quantity = positionSize.quantity;
    
    // Calculate entry price with slippage
    const slippage = optionPrice * 0.005;
    const entryPrice = optionPrice + slippage;
    
    // Strategy-specific or default take profit/stop loss (Bun-system style)
    const strategyType = (this.state.strategyType || 'adaptive') as StrategyType;
    const strategyExit = strategyType !== 'adaptive' ? getExitParams(strategyType) : null;
    const takeProfitPercent = strategyExit
      ? strategyExit.takeProfitPercent * riskAdjustment.takeProfitMultiplier
      : this.TAKE_PROFIT_PERCENT * riskAdjustment.takeProfitMultiplier;
    const stopLossPercent = strategyExit
      ? Math.min(strategyExit.stopLossPercent, 0.99) * riskAdjustment.stopLossMultiplier // cap SL so we don't use 1.0 as 100% loss
      : this.STOP_LOSS_PERCENT * riskAdjustment.stopLossMultiplier;
    
    // Use exit criteria from advanced signal if available (overrides strategy defaults)
    const takeProfitPrice = advancedSignal?.exitCriteria?.takeProfit 
      ? entryPrice * (1 + advancedSignal.exitCriteria.takeProfit / 100)
      : entryPrice * (1 + takeProfitPercent);
    
    const stopLossPrice = advancedSignal?.exitCriteria?.stopLoss
      ? entryPrice * (1 - advancedSignal.exitCriteria.stopLoss / 100)
      : entryPrice * (1 - stopLossPercent);
    
    const expiry = this.getNextExpiry(advancedSignal?.expectedTimeframe || 14);
    // Place order via IBKR Gateway (paper and live both through Gateway)
    try {
      const { checkIBGatewayConnection, getIBAccountId, placeIBOptionOrder } = await import('./ib-orders');
      if (!(await checkIBGatewayConnection())) {
        this.log(`   IBKR Gateway not connected — connect Gateway to place real orders. Skipping position.`);
        return;
      }
      const accountId = await getIBAccountId();
      if (!accountId) {
        this.log(`   IBKR account not available — connect Gateway and log in. Skipping position.`);
        return;
      }
      const expiryIB = expiry.replace(/-/g, ''); // YYYYMMDD for IB options chain
      const ibResult = await placeIBOptionOrder({
        accountId,
        symbol: opportunity.symbol,
        expiry: expiryIB,
        strike,
        optionType: optionType === 'call' ? 'C' : 'P',
        side: 'BUY',
        quantity,
        orderType: 'MKT',
      });
      if (!ibResult.success) {
        this.log(`   IBKR order failed: ${ibResult.error ?? 'Unknown'} — skipping position.`);
        return;
      }
      this.log(`   IBKR order placed: ${ibResult.orderId ?? 'submitted'}`);
    } catch (err) {
      this.log(`   IBKR order error: ${err instanceof Error ? err.message : String(err)} — skipping position.`);
      return;
    }

    // Create position (only after IBKR order placed)
    const position: Position = {
      id: `pos-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      symbol: opportunity.symbol,
      optionType,
      strike,
      expiry,
      quantity,
      entryPrice,
      currentPrice: entryPrice,
      entryTime: Date.now(),
      unrealizedPnL: 0,
      unrealizedPnLPercent: 0,
      regime: opportunity.regime,
      signalClass: advancedSignal.signalClass || opportunity.signal.class,
      takeProfitPrice,
      stopLossPrice,
      trailingStopPrice: null,
      highWaterMark: entryPrice,
      status: 'open',
      dataSource: opportunity.dataSource,
    };
    
    // Create trade record
    const trade: Trade = {
      id: `trade-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      positionId: position.id,
      action: 'open',
      symbol: position.symbol,
      optionType,
      strike,
      expiry: position.expiry,
      quantity,
      price: entryPrice,
      timestamp: Date.now(),
      regime: opportunity.regime,
      signalClass: advancedSignal.signalClass || opportunity.signal.class,
      reason: `Advanced Signal: ${advancedSignal.signalType} (${advancedSignal.signalClass}) | Confidence: ${(advancedSignal.confidenceScore * 100).toFixed(1)}% | Timeframe: ${(timeframeAnalysis.overallConfidence * 100).toFixed(1)}% | ${positionSize.sizingMethod} sizing`,
      dataSource: opportunity.dataSource,
    };
    
    // Update state
    this.state.positions.push(position);
    this.state.trades.push(trade);
    this.state.accountBalance -= entryPrice * quantity * 100;
    this.state.riskMetrics.positionCount = this.state.positions.filter(p => p.status === 'open').length;
    this.state.riskMetrics.currentExposure += quantity * entryPrice * 100;

    // Persist to database (userId 1 for autonomous engine)
    try {
      const { dbTradeService } = await import('./db-trade-service');
      const now = Date.now();
      await dbTradeService.saveTradeRecord(
        {
          id: position.id,
          symbol: position.symbol,
          assetType: 'option',
          entryPrice: position.entryPrice,
          entryTime: position.entryTime,
          quantity: position.quantity,
          direction: opportunity.regime.includes('bull') ? 'long' : 'short',
          structureType: 'vertical_call_spread',
          status: 'open',
          createdAt: now,
          updatedAt: now,
        },
        1
      );
    } catch (err) {
      console.warn('[AutoTradingEngine] Failed to persist trade open (non-fatal):', err);
    }

    this.log(`🟢 OPENED: ${quantity}x ${opportunity.symbol} ${strike}${optionType.toUpperCase()} @ $${entryPrice.toFixed(2)}`);
    this.log(`   Advanced Signal: ${advancedSignal.signalType} (${advancedSignal.signalClass}) | Confidence: ${(advancedSignal.confidenceScore * 100).toFixed(1)}%`);
    this.log(`   Timeframe: ${(timeframeAnalysis.overallConfidence * 100).toFixed(1)}% confidence, ${(timeframeAnalysis.alignment * 100).toFixed(1)}% alignment`);
    this.log(`   Position Size: ${quantity} (${positionSize.sizingMethod}) | ${positionSize.rationale}`);
    this.log(`   Win Prob: ${(advancedSignal.winProbability * 100).toFixed(0)}% | Expected Move: ${advancedSignal.expectedMove.toFixed(1)}%`);
    this.log(`   Take Profit: $${position.takeProfitPrice.toFixed(2)} | Stop Loss: $${position.stopLossPrice.toFixed(2)}`);
  }

  private getNextExpiry(daysOut: number): string {
    const date = new Date();
    date.setDate(date.getDate() + daysOut);
    // Find next Friday
    while (date.getDay() !== 5) {
      date.setDate(date.getDate() + 1);
    }
    return date.toISOString().split('T')[0];
  }

  private getTimeOfDay(): 'pre_market' | 'market_open' | 'mid_day' | 'market_close' | 'after_hours' {
    const now = new Date();
    const hour = now.getHours();
    const minute = now.getMinutes();
    const time = hour * 60 + minute;
    
    // Pre-market: 4:00 AM - 9:30 AM ET
    if (time >= 240 && time < 570) return 'pre_market';
    // Market open: 9:30 AM - 11:00 AM ET
    if (time >= 570 && time < 660) return 'market_open';
    // Mid-day: 11:00 AM - 2:00 PM ET
    if (time >= 660 && time < 840) return 'mid_day';
    // Market close: 2:00 PM - 4:00 PM ET
    if (time >= 840 && time < 960) return 'market_close';
    // After hours: 4:00 PM - 8:00 PM ET
    if (time >= 960 && time < 1200) return 'after_hours';
    
    return 'mid_day'; // Default
  }

  // ============================================================================
  // POSITION MANAGEMENT
  // ============================================================================

  private async updatePositions(): Promise<void> {
    const openPositions = this.state.positions.filter(p => p.status === 'open');

    for (const position of openPositions) {
      try {
        const { getIBMarketData } = await import('./ib-market-data');
        const ibData = await getIBMarketData(position.symbol);
        const price = ibData?.price;
        const marketData = ibData != null && price != null && price > 0
          ? {
              symbol: position.symbol,
              price,
              changePercent: 0,
              volume: ibData.volume ?? 0,
              avgVolume: 0,
              previousClose: price,
              change: 0,
              high: price,
              low: price,
              open: price,
              marketCap: 0,
              fiftyTwoWeekHigh: price,
              fiftyTwoWeekLow: price,
              timestamp: Date.now(),
            }
          : null;
        if (marketData) {
          // Update position with real price movement using real delta
          const stockPriceChange = marketData.changePercent / 100;
          const greeks = await getOptionGreeks(
            position.symbol,
            position.strike,
            position.expiry,
            position.optionType
          );
          const optionDelta = greeks.delta;
          const optionPriceChange = stockPriceChange * optionDelta * 2; // Leverage
          
          position.currentPrice = position.entryPrice * (1 + optionPriceChange);
          position.currentPrice = Math.max(0.01, position.currentPrice);
          
          // Update high water mark
          if (position.currentPrice > position.highWaterMark) {
            position.highWaterMark = position.currentPrice;
          }
          
          // Calculate P&L
          position.unrealizedPnL = (position.currentPrice - position.entryPrice) * position.quantity * 100;
          position.unrealizedPnLPercent = (position.currentPrice - position.entryPrice) / position.entryPrice;
          
          // Check exit conditions
          await this.checkExitConditions(position);
        }
      } catch (error) {
        this.log(`Error updating ${position.symbol}: ${error}`);
      }
    }
    
    // Update total equity
    const totalUnrealizedPnL = this.state.positions
      .filter(p => p.status === 'open')
      .reduce((sum, p) => sum + p.unrealizedPnL, 0);
    
    this.state.totalEquity = this.state.accountBalance + totalUnrealizedPnL;
  }

  private async checkExitConditions(position: Position): Promise<void> {
    // Use dynamic exit strategy with all advanced features
    try {
      // Calculate real performance metrics
      const closedTrades = this.state.positions
        .filter(p => p.status === 'closed' && p.realizedPnL !== undefined)
        .map(p => ({
          pnl: p.realizedPnL || 0,
          pnlPercent: p.realizedPnL && p.entryPrice ? (p.realizedPnL / (p.entryPrice * p.quantity * 100)) : 0,
          entryTime: p.entryTime,
          exitTime: p.exitTime || p.entryTime,
          status: 'closed' as const,
        }));
      
      const performance = calculatePerformanceMetrics(
        closedTrades,
        this.state.totalEquity,
        this.INITIAL_BALANCE
      );

      // Fetch real VIX and market data from IB only (no prior close for trend, use 0)
      const realVIX = await getRealVIX();
      const marketTrend = 0;

      // Get real option Greeks for volatility
      const greeks = await getOptionGreeks(
        position.symbol,
        position.strike,
        position.expiry,
        position.optionType
      );

      const marketConditions = determineMarketConditions(
        realVIX, // REAL VIX
        marketTrend,
        this.state.positions.filter(p => p.status === 'open').map(p => ({ symbol: p.symbol }))
      );

      const daysToExpiry = (new Date(position.expiry).getTime() - Date.now()) / (1000 * 60 * 60 * 24);
      
      const exitDecision = determineExitStrategy(
        {
          symbol: position.symbol,
          entryPrice: position.entryPrice,
          currentPrice: position.currentPrice,
          entryTime: position.entryTime,
          currentTime: Date.now(),
          takeProfitPrice: position.takeProfitPrice,
          stopLossPrice: position.stopLossPrice,
          trailingStopPrice: position.trailingStopPrice,
          highWaterMark: position.highWaterMark,
          unrealizedPnL: position.unrealizedPnL,
          unrealizedPnLPercent: position.unrealizedPnLPercent,
          optionType: position.optionType,
          daysToExpiry,
          regime: position.regime,
          signalClass: position.signalClass,
          volatility: greeks.iv, // REAL IV
          volume: 1000000,
          avgVolume: 1000000,
        },
        {
          vix: realVIX, // REAL VIX
          marketTrend,
          regime: position.regime,
          timeOfDay: this.getTimeOfDay(),
        },
        {
          winRate: performance.winRate,
          profitFactor: performance.profitFactor,
          recentPerformance: performance.recentPerformance,
        }
      );

      // Execute exit if needed
      if (exitDecision.action !== 'hold') {
        // Update trailing stop if needed
        if (exitDecision.action === 'trailing_stop' && exitDecision.exitPrice !== position.trailingStopPrice) {
          position.trailingStopPrice = exitDecision.exitPrice;
          this.log(`📈 ${exitDecision.reason}`);
          return; // Don't exit yet, just update trailing stop
        }
        
        // Close position
        await this.closePosition(position, exitDecision.action.toUpperCase().replace('_', '_'));
        this.log(`🔴 EXIT: ${position.symbol} - ${exitDecision.reason}`);
      }
    } catch (error) {
      // Fallback to basic exit logic if dynamic exits fail
      this.log(`Error in dynamic exit check, using basic logic: ${error}`);
      
      // Basic exits as fallback
      if (position.currentPrice >= position.takeProfitPrice) {
        await this.closePosition(position, 'TAKE_PROFIT');
        return;
      }
      
      if (position.currentPrice <= position.stopLossPrice) {
        await this.closePosition(position, 'STOP_LOSS');
        return;
      }
      
      if (position.trailingStopPrice && position.currentPrice <= position.trailingStopPrice) {
        await this.closePosition(position, 'TRAILING_STOP');
        return;
      }
      
      const daysToExpiry = (new Date(position.expiry).getTime() - Date.now()) / (1000 * 60 * 60 * 24);
      if (daysToExpiry <= 2) {
        await this.closePosition(position, 'TIME_DECAY_EXIT');
        return;
      }
    }
  }

  private async closePosition(position: Position, reason: string): Promise<void> {
    // Calculate exit price with slippage
    const slippage = position.currentPrice * 0.005;
    const exitPrice = position.currentPrice - slippage;
    
    // Calculate realized P&L
    const realizedPnL = (exitPrice - position.entryPrice) * position.quantity * 100;
    
    // Update position
    position.status = 'closed';
    position.exitReason = reason;
    position.exitPrice = exitPrice;
    position.exitTime = Date.now();
    position.realizedPnL = realizedPnL;
    
    // Create trade record
    const trade: Trade = {
      id: `trade-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      positionId: position.id,
      action: 'close',
      symbol: position.symbol,
      optionType: position.optionType,
      strike: position.strike,
      expiry: position.expiry,
      quantity: position.quantity,
      price: exitPrice,
      timestamp: Date.now(),
      regime: this.state.currentRegime,
      signalClass: position.signalClass,
      reason,
      dataSource: position.dataSource,
    };
    
    this.state.trades.push(trade);

    // Persist close to database
    try {
      const { dbTradeService } = await import('./db-trade-service');
      await dbTradeService.updateTradeRecord({
        id: position.id,
        symbol: position.symbol,
        assetType: 'option',
        entryPrice: position.entryPrice,
        entryTime: position.entryTime,
        exitPrice: position.exitPrice,
        exitTime: position.exitTime ?? Date.now(),
        quantity: position.quantity,
        direction: position.regime.includes('bull') ? 'long' : 'short',
        structureType: 'vertical_call_spread',
        status: 'closed',
        pnl: position.realizedPnL,
        pnlPercent: position.entryPrice ? (position.realizedPnL! / (position.entryPrice * position.quantity * 100)) * 100 : 0,
        createdAt: position.entryTime,
        updatedAt: Date.now(),
      });
    } catch (err) {
      console.warn('[AutoTradingEngine] Failed to persist trade close (non-fatal):', err);
    }

    // Update account balance
    this.state.accountBalance += exitPrice * position.quantity * 100;
    this.state.dayPnL += realizedPnL;
    this.state.totalPnL += realizedPnL;

    // Update risk metrics
    this.state.riskMetrics.currentExposure -= position.quantity * position.entryPrice * 100;
    this.state.riskMetrics.positionCount = this.state.positions.filter(p => p.status === 'open').length;

    const emoji = realizedPnL >= 0 ? '🟢' : '🔴';
    this.log(`${emoji} CLOSED: ${position.symbol} - ${reason} - P&L: $${realizedPnL.toFixed(2)} (${(position.unrealizedPnLPercent * 100).toFixed(1)}%)`);

    // Outcome log + calibration (automatic rollout)
    try {
      const exitTime = position.exitTime ?? Date.now();
      const durationDays = (exitTime - position.entryTime) / (24 * 60 * 60 * 1000);
      const { buildOutcomeFromClose } = await import('./outcome-log');
      const { appendOutcomeAndMaybeCalibrate } = await import('./calibration-job');
      const outcome = buildOutcomeFromClose({
        symbol: position.symbol,
        regime: position.regime ?? this.state.currentRegime,
        pnl: realizedPnL,
        durationDays: Math.max(0, durationDays),
        exitReason: reason,
        structureType: 'vertical_call_spread',
        closedAt: exitTime,
        maxDrawdown: 0,
      });
      await appendOutcomeAndMaybeCalibrate(outcome);
    } catch (err) {
      console.warn('[AutoTradingEngine] Outcome log/calibration (non-fatal):', err);
    }
  }

  // ============================================================================
  // RISK MANAGEMENT
  // ============================================================================

  private updateRiskMetrics(): void {
    const openPositions = this.state.positions.filter(p => p.status === 'open');
    
    // Calculate current exposure
    this.state.riskMetrics.currentExposure = openPositions.reduce(
      (sum, p) => sum + p.quantity * p.currentPrice * 100,
      0
    );
    
    // Update position count
    this.state.riskMetrics.positionCount = openPositions.length;
    
    // Calculate ruin probability
    const closedPositions = this.state.positions.filter(p => p.status === 'closed');
    if (closedPositions.length > 0) {
      const wins = closedPositions.filter(p => (p.realizedPnL || 0) > 0).length;
      const winRate = wins / closedPositions.length;
      const avgWin = 0.30;
      const avgLoss = 0.20;
      const edge = winRate * avgWin - (1 - winRate) * avgLoss;
      this.state.riskMetrics.ruinProbability = edge < 0 ? Math.min(1, Math.abs(edge) * 2) : Math.max(0, 0.1 - edge);
    }
    
    // Check kill switch conditions
    const shouldActivateKillSwitch = 
      this.state.riskMetrics.ruinProbability >= this.RUIN_PROBABILITY_THRESHOLD ||
      this.state.dayPnL <= -this.state.riskMetrics.dailyLossLimit ||
      this.state.totalEquity <= this.INITIAL_BALANCE * 0.8;
    
    if (shouldActivateKillSwitch && !this.state.riskMetrics.killSwitchActive) {
      this.log('⛔ KILL SWITCH ACTIVATED - Closing all positions');
      this.state.riskMetrics.killSwitchActive = true;
      this.closeAllPositions('KILL_SWITCH');
    }
  }

  private async closeAllPositions(reason: string): Promise<void> {
    for (const position of this.state.positions) {
      if (position.status === 'open') {
        await this.closePosition(position, reason);
      }
    }
  }

  /** Close a single position by id (e.g. from Execution page). */
  public async closePositionById(positionId: string, reason: string = "MANUAL_CLOSE"): Promise<boolean> {
    const position = this.state.positions.find(p => p.id === positionId && p.status === "open");
    if (!position) return false;
    await this.closePosition(position, reason);
    return true;
  }

  /** Set named strategy: wheel | short_term | iron_condor | adaptive */
  public setStrategyType(strategyType: string): void {
    this.state.strategyType = strategyType;
  }

  // ============================================================================
  // STATISTICS
  // ============================================================================

  public getPerformanceMetrics(): {
    totalTrades: number;
    winRate: number;
    profitFactor: number;
    sharpeRatio: number;
    maxDrawdown: number;
    avgWin: number;
    avgLoss: number;
    expectancy: number;
  } {
    const closedPositions = this.state.positions.filter(p => p.status === 'closed');
    
    if (closedPositions.length === 0) {
      return {
        totalTrades: 0,
        winRate: 0,
        profitFactor: 0,
        sharpeRatio: 0,
        maxDrawdown: 0,
        avgWin: 0,
        avgLoss: 0,
        expectancy: 0,
      };
    }
    
    const wins = closedPositions.filter(p => (p.realizedPnL || 0) > 0);
    const losses = closedPositions.filter(p => (p.realizedPnL || 0) <= 0);
    
    const totalWins = wins.reduce((sum, p) => sum + (p.realizedPnL || 0), 0);
    const totalLosses = Math.abs(losses.reduce((sum, p) => sum + (p.realizedPnL || 0), 0));
    
    const avgWin = wins.length > 0 ? totalWins / wins.length : 0;
    const avgLoss = losses.length > 0 ? totalLosses / losses.length : 0;
    
    const winRate = wins.length / closedPositions.length;
    const profitFactor = totalLosses > 0 ? totalWins / totalLosses : totalWins > 0 ? Infinity : 0;
    
    // Simplified Sharpe calculation
    const returns = closedPositions.map(p => (p.realizedPnL || 0) / this.INITIAL_BALANCE);
    const avgReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
    const stdDev = Math.sqrt(returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length);
    const sharpeRatio = stdDev > 0 ? (avgReturn * Math.sqrt(252)) / stdDev : 0;
    
    // Max drawdown
    let peak = this.INITIAL_BALANCE;
    let maxDrawdown = 0;
    let equity = this.INITIAL_BALANCE;
    for (const pos of closedPositions) {
      equity += pos.realizedPnL || 0;
      if (equity > peak) peak = equity;
      const drawdown = (peak - equity) / peak;
      if (drawdown > maxDrawdown) maxDrawdown = drawdown;
    }
    
    const expectancy = winRate * avgWin - (1 - winRate) * avgLoss;
    
    return {
      totalTrades: closedPositions.length,
      winRate,
      profitFactor,
      sharpeRatio,
      maxDrawdown,
      avgWin,
      avgLoss,
      expectancy,
    };
  }
}

// ============================================================================
// SINGLETON INSTANCE
// ============================================================================

let engineInstance: AutoTradingEngine | null = null;

export function getAutoTradingEngine(): AutoTradingEngine {
  if (!engineInstance) {
    engineInstance = new AutoTradingEngine();
  }
  return engineInstance;
}

export function resetAutoTradingEngine(): void {
  if (engineInstance) {
    engineInstance.stop();
    engineInstance = null;
  }
}

export { AutoTradingEngine };
