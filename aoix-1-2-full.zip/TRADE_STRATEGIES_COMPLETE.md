# All Trade Strategies — Complete Reference (Production-Accurate)

This document lists **every** trade strategy in AOIX-1 with **real-market accuracy**: named strategies, option structures (legs), how they are chosen, and how exits work. Corrections applied for calendar/diagonal pricing, wheel stop-loss meaning, iron condor leg order, regime→structure mapping, and TP/SL context.

---

## Part 1: Named Strategies (Engine / Style)

| Strategy | Preferred structures (order) | Max hold | Min win prob | Take profit | Stop loss | Reality check |
|----------|------------------------------|----------|--------------|-------------|-----------|---------------|
| **Adaptive** | Regime-driven (see Part 2) | Regime default | 60% | 30% of max profit | 20% of max risk | Regime picks structure; straddle only for vol expansion, not mean-reversion. |
| **Wheel** | CSP, covered call, vertical put/call spreads | 45 DTE | 70% | 50% of credit received | 2× credit received (or 50% of max risk) | CSP max loss = (strike × 100) − premium. Never "100% of capital." |
| **Short-term** | Vertical spreads, straddle, iron condor | 7 DTE | 60% | 25% of max profit | 25% of max risk | Tight stops realistic for day/swing. |
| **Iron condor** | Iron condor, iron butterfly, calendar, verticals | 30 DTE | 65% | 50% of credit received | 100% of credit (or close at 2× credit) | Standard for range-bound markets. |

**Take-profit / stop-loss context**

- **Take profit %** = % of **max profit** (for debit spreads) or % of **credit received** (for credit spreads), depending on structure.
- **Stop loss** = % of **max risk** (e.g. 50% of max risk = close when loss reaches half of worst-case). For Wheel, "100%" in code means *wide*; in practice use **2× credit received** or **50% of max risk** so you don’t hold to assignment without a defined exit.

---

## Part 2: Regime-Based Structure Selection (Scanner / Adaptive)

When the **scanner** or **adaptive** strategy picks a structure, it uses **regime + signal confidence** (`services.selectOptimalStructure`):

| Regime | Structure chosen | Why |
|--------|-------------------|-----|
| **Bull vol compression** (conf > 65%) | **Vertical call spread** | Directional upside with defined risk. |
| **Bear vol expansion** (conf > 60%) | **Iron condor** | Collect theta, manage tail risk. |
| **Mean-reverting** | **Iron condor** | Profits from time decay in range-bound markets. Straddle would **lose** here (vol crush). |
| **Vol expansion / breakout** (future) | **Straddle / strangle** | Needs big move; loses in mean-reversion. |
| **Other / low confidence** | **Calendar spread** | Theta decay, minimal directional risk. |

**Critical fix:** Mean-reverting → **iron condor** (or calendar), **not** straddle. Straddles are for **vol expansion/breakout**; in mean-reversion they lose to vol crush.

---

## Part 3: All Option Structures (Legs)

`center` = ATM strike; `w` = 5 (strike width). Expiry is one date unless noted.

### Single-leg (income / wheel)

| Structure | Legs | Max loss / cost |
|-----------|------|------------------|
| **Cash secured put (CSP)** | 1 leg: SELL put @ center | Max loss = (strike × 100) − premium received (e.g. sell $100 put for $2 → max loss $9,800 per contract if assigned). |
| **Covered call** | 1 leg: SELL call @ center | Upside capped at center; keep premium. |

### Vertical spreads

| Structure | Legs (bullish) | Legs (bearish) | How it works |
|-----------|----------------|----------------|---------------|
| **Vertical call spread** | BUY call @ center, SELL call @ center+w | SELL call @ center, BUY call @ center+w | Bullish: debit. Bearish: credit. |
| **Vertical put spread** | SELL put @ center, BUY put @ center−w | BUY put @ center−w, SELL put @ center | Bullish: credit. Bearish: debit. |

### Condor / butterfly (symmetric wings)

| Structure | Legs (standard order) | How it works |
|-----------|------------------------|--------------|
| **Iron condor** | BUY put @ center−2w, SELL put @ center−w, SELL call @ center+w, BUY call @ center+2w | Put credit spread + call credit spread. Width between short strikes = 2w; wings = w each side. **Credit.** |
| **Iron butterfly** | BUY put @ center−w, SELL put @ center, SELL call @ center, BUY call @ center+w | Short straddle (SELL put/call @ center) + long wings. **Credit**; max profit at center. |
| **Long butterfly** | BUY 1 call @ center−w, SELL 2 calls @ center, BUY 1 call @ center+w | **Debit**; max profit at center. |

### Straddle / strangle (volatility — long optionality)

| Structure | Legs | How it works |
|-----------|------|----------------|
| **Straddle** | BUY call @ center, BUY put @ center | **Debit.** Profit from large move either way (vol expansion). Loses in mean-reversion (vol crush). |
| **Strangle** | BUY put @ center−w, BUY call @ center+w | **Debit.** Cheaper than straddle; needs bigger move. |

### Time spreads (two expirations)

| Structure | Legs | Cost / risk |
|-----------|------|-------------|
| **Calendar spread** | SELL near-term @ center, BUY far-term @ center (same strike, different expiries) | **Net debit always** (far-dated option costs more). Example: SELL Feb 7 $345C @ $3.66, BUY Feb 14 $345C @ $4.20 → net debit $0.54/spread ($270 for 5 contracts). **Never $0.00** in real markets. |
| **Diagonal spread** | **True diagonal:** SELL near-term @ strike A, BUY far-term @ strike B (**different strikes and expiries**). | Different risk profile than calendar (directional bias). **Code:** `getLegsForStructure(..., { diagonalFarStrikeOffset })` uses far strike = center + offset when provided; API can add this param for true diagonal. Default (no offset) = calendar-style same strike. |

**Aliases:** `csp` → cash_secured_put, `cc` → covered_call, `call_spread` → vertical_call_spread, `put_spread` → vertical_put_spread, `calendar` → calendar_spread, `diagonal` → diagonal_spread.

**Code reference (single source of truth):** Leg generation: `server/routers/omega0.ts` — `getLegsForStructure(structureType, center, direction, inputExpiry, { diagonalFarStrikeOffset? })`. Strategy configs: `server/strategy-types.ts` — `STRATEGY_CONFIGS`, `ALL_STRUCTURE_TYPES`, `ALL_REGIMES`. API: `docs/API_REFERENCE.md`.

---

## Part 4: Exit Strategies (Dynamic Exits)

| Exit type | When it triggers | Note |
|-----------|-------------------|------|
| **Stop loss** | Price ≤ stop-loss level | Level = % of max risk or 2× credit, per strategy. |
| **Take profit** | Price ≥ take-profit level | Level = % of max profit or % of credit received. |
| **Dynamic take profit** | Level depends on win rate, profit factor, VIX | Earlier when stats weak; let winners run when strong. |
| **Trailing stop** | Price ≤ trailing level | Protects profits. |
| **Time stop** | Days to expiry < 3 and P&L% > 10% | Avoid time decay. |
| **Regime exit** | Regime changed and P&L% > 5% | Take profits when regime no longer supports trade. |
| **Vol crush exit** | IV < 15%, P&L% > 15%, held > 3 days | **Only for long volatility positions** (straddles/strangles). Short premium (iron condor, CSP) **wants** vol crush. |
| **High vol lock-in** | VIX > 30 and P&L% > 20% | Lock in gains in stressed markets. |
| **Hold** | None of the above | Keep position. |

---

## Part 5: Corrected Quick Reference

| If you want… | Use strategy | Typical structures |
|--------------|--------------|---------------------|
| Income, sell premium, roll/assign | **Wheel** | CSP, covered call, put/call spreads. SL = 2× credit or 50% max risk. |
| Fast trades, small targets | **Short-term** | Vertical spreads, iron condor. 25% TP / 25% max risk. |
| Theta, range-bound, both sides | **Iron condor** | Iron condor, iron butterfly. 50% of credit TP. |
| Let regime pick structure | **Adaptive** | Bull → call spread; bear → iron condor; mean-revert → iron condor; low conf → calendar. Straddle only for vol expansion. |

---

## File References

- **Named strategies & config:** `server/strategy-types.ts`
- **Regime → structure (adaptive):** `server/services.ts` → `selectOptimalStructure`
- **Structure → legs (execution):** `server/routers/omega0.ts` → `getLegsForStructure`
- **Exit logic:** `server/dynamic-exits.ts` → `determineExitStrategy`
- **Engine:** `server/auto-trading-engine.ts`

---

## Summary of Fixes Applied

1. **Calendar spread:** Net debit always; example and "never $0" stated.
2. **Wheel stop loss:** Clarified as 2× credit or 50% of max risk; CSP max loss formula stated. **API:** `getStrategyConfigs` returns `stopLossDescription` (e.g. Wheel: "Close at 2× credit received OR 50% of max risk. CSP max loss = (strike × 100) − premium.") so UI never shows misleading "100% SL."
3. **Iron condor legs:** Standard order and symmetric wings; code updated.
4. **Iron butterfly vs long butterfly:** Both defined; iron = credit, long butterfly = debit.
5. **Diagonal:** True diagonal supported in code via `getLegsForStructure(..., { diagonalFarStrikeOffset })`; API can add optional param when needed. Default = calendar-style same strike.
6. **Regime → structure:** Mean-reverting → iron condor (code and doc); straddle only for vol expansion/breakout.
7. **TP/SL context:** All TP/SL expressed as % of max profit, % of credit, or % of max risk. Strategy configs include `takeProfitDescription` and `stopLossDescription` for UI.
8. **Vol crush exit:** Only for long vol positions; short premium wants vol crush.
9. **Position sizing:** `SizingInputs.maxRiskPerTrade` comment states that for options, max risk should reflect max loss per structure (e.g. width×100 − credit for spreads, strike×100 − premium for CSP).

---

## Remaining Issues (Production Risk)

| Issue | Risk | Status |
|-------|------|--------|
| **Diagonal spread in API** | Medium | **Done:** `placeOrder` and `estimateOrderCost` accept optional `diagonalFarStrikeOffset` for true diagonal (far strike = center + offset). Default = calendar-style same strike. |
| **Wheel stop-loss in UI** | High | **Done:** `getStrategyConfigs` returns `stopLossDescription`; Auto Trading page shows TP/SL descriptions (e.g. "Close at 2× credit received OR 50% of max risk"). |
| **Straddle in mean-reversion** | Critical | **Fixed:** Regime mean-reverting → iron condor in code; docs/UI should not suggest straddles for range-bound. |
| **Cost display** | Low | Estimated + actual cost shown; verify multi-leg net debit/credit math against broker (e.g. TastyTrade, IBKR) before live. |
| **Position sizing** | Medium | Comment added that max risk should reflect max loss per structure; engine uses portfolio-aware sizing. |

---

## Production Checklist (Before Live Trading)

- [x] Calendar spreads **never show $0 cost** — always net debit (doc + estimateOrderCost uses real fill prices).
- [x] Wheel CSP: max loss = `(strike × 100) − premium` documented; strategy config returns clear `stopLossDescription`.
- [x] Mean-reversion trades **never suggest straddles** — regime → iron condor in code.
- [x] Diagonal: code supports true diagonal (optional `diagonalFarStrikeOffset`); API can add param when needed.
- [x] All TP/SL % specify **% of what** (credit / max profit / max risk) in doc and in `getStrategyConfigs` descriptions.
- [x] Vol crush exit **only triggers for long vol positions** (comment in dynamic-exits; doc).
- [x] **UI:** Show `stopLossDescription` / `takeProfitDescription` from `autoTrading.getStrategyConfigs` on Auto Trading page (Engine Status → Strategy).
- [x] **Max loss estimate:** `estimateOrderCost` returns `maxLossEstimate`; Recommendations Place order dialog shows "Max loss (est.): $X".
- [ ] **Backtest:** Verify iron condor outperforms straddle in mean-reversion regime.
- [ ] **Broker:** Verify leg syntax and net cost vs TastyTrade/IBKR for multi-leg orders (recommended before live).

---

## Remaining Polish (Not Critical Risk) — Status

| Item | Status | Why it's safe |
|------|--------|----------------|
| **UI display of TP/SL descriptions** | ✅ Done | Auto Trading → Engine Status shows Strategy with TP/SL from `getStrategyConfigs` (e.g. "Close at 2× credit" instead of raw "100%"). |
| **True diagonal API parameter** | ✅ Done | `placeOrder` and `estimateOrderCost` accept optional `diagonalFarStrikeOffset`. Default = calendar-style (safe). |
| **Broker validation** | ⚠️ Recommended | Multi-leg cost math not yet verified vs TastyTrade/IBKR. Low risk — net debit/credit logic is standard. |
| **Max loss calculator UI** | ✅ Done | `estimateOrderCost` returns `maxLossEstimate`; Place order dialog shows "Max loss (est.): $X". Formulas in code/docs. | *(Recommended before live: multi-leg net debit/credit logic is standard; validate against broker confirmations.)*
