import axios from 'axios';

/**
 * IB Gateway Market Data Connector
 * Connects to Interactive Brokers Gateway (default port 4002 for paper/simulated)
 * Fetches real-time market data, options chains, and Greeks
 */

interface IBContract {
  conid: number;
  symbol: string;
  secType: string;
  exchange: string;
  currency: string;
}

interface IBMarketData {
  symbol: string;
  price: number;
  bid: number;
  ask: number;
  volume: number;
  change?: number;
  changePercent?: number;
  iv?: number;
  bidSize?: number;
  askSize?: number;
  lastTradeTime?: number;
}

interface IBOption {
  conid: number;
  symbol: string;
  strike: number;
  right: 'C' | 'P';
  expiry: string;
  bid: number;
  ask: number;
  last: number;
  volume: number;
  openInterest: number;
  impliedVolatility: number;
  delta: number;
  gamma: number;
  theta: number;
  vega: number;
}

interface IBOptionsChain {
  underlying: string;
  underlyingPrice: number;
  expirations: string[];
  strikes: number[];
  options: IBOption[];
}

/** Client Portal Gateway base URL: /v1/api (REST API). Use IB_GATEWAY_URL, or build from TWS_HOST/TWS_PORT. */
function getIBGatewayUrl(): string {
  if (process.env.IB_GATEWAY_URL) return process.env.IB_GATEWAY_URL;
  const host = (process.env.TWS_HOST || 'localhost').trim() || 'localhost';
  const port = (process.env.TWS_PORT || '5000').trim() || '5000';
  return `http://${host}:${port}/v1/api`;
}

/** Throttle IB connection failure logs to once per 60s */
let lastIBConnectionLog = 0;
const IB_CONNECTION_LOG_INTERVAL_MS = 60_000;

/** After a 429, don't call the Gateway again for this long (so we stop hammering it from multiple tabs/polling) */
const GATEWAY_429_COOLDOWN_MS = 120_000; // 2 min
let lastGateway429Time = 0;

/** Set 429 cooldown when any gateway request returns 429. Call from catch blocks. */
function set429Cooldown(): void {
  lastGateway429Time = Date.now();
}

/** Axios config for all Client Portal Gateway requests. Uses IB_GATEWAY_COOKIE if set (e.g. api=xxx from browser after login). */
function gatewayRequestConfig() {
  const headers: Record<string, string> = {
    Host: process.env.TWS_HOST || 'localhost',
    'User-Agent': 'AOIX-1/1.0',
    Accept: '*/*',
    Connection: 'keep-alive',
  };
  const cookie = process.env.IB_GATEWAY_COOKIE?.trim();
  if (cookie) headers['Cookie'] = cookie;
  return { timeout: 10000, headers };
}

/** Call /tickle to keep IB Gateway session alive. Run every 45s when cookie is set. */
async function callTickle(): Promise<boolean> {
  if (!process.env.IB_GATEWAY_COOKIE?.trim()) return false;
  const now = Date.now();
  if (now - lastGateway429Time < GATEWAY_429_COOLDOWN_MS) return false;
  try {
    const res = await axios.get(`${getIBGatewayUrl()}/tickle`, {
      ...gatewayRequestConfig(),
      validateStatus: () => true,
    });
    if (res.status === 429) {
      set429Cooldown();
      return false;
    }
    return res.status === 200;
  } catch {
    return false;
  }
}

let tickleIntervalId: ReturnType<typeof setInterval> | null = null;

/** Start periodic /tickle to keep IB session alive. Call once at server startup. */
export function startIBSessionKeepAlive(): void {
  if (tickleIntervalId) return;
  if (!process.env.IB_GATEWAY_COOKIE?.trim()) return;
  const TICKLE_MS = 45_000; // IB recommends pinging to keep session open
  tickleIntervalId = setInterval(async () => {
    const ok = await callTickle();
    if (!ok && process.env.NODE_ENV !== 'test') {
      // Log only occasionally to avoid spam
    }
  }, TICKLE_MS);
  if (process.env.NODE_ENV !== 'test') {
    console.log('[IB] Session keep-alive started (tickle every 45s)');
  }
}

/**
 * Get contract ID (conid) for a stock/ETF symbol.
 * Uses GET /trsrv/stocks (Security Stocks by Symbol) first, then /iserver/secdef/search as fallback.
 */
async function getContractIdForSymbol(symbol: string): Promise<number | null> {
  if (Date.now() - lastGateway429Time < GATEWAY_429_COOLDOWN_MS) return null;
  const base = getIBGatewayUrl();
  const sym = symbol.toUpperCase();

  // 1) GET /trsrv/stocks - "Security Stocks by Symbol" (returns { "SPY": [{ conid, name, ... }] })
  try {
    const res = await axios.get(`${base}/trsrv/stocks`, {
      ...gatewayRequestConfig(),
      params: { symbols: sym },
    });
    const data = res.data;
    const arr = data?.[sym] ?? data?.[symbol] ?? (Array.isArray(data) ? data : null);
    const contract = Array.isArray(arr) && arr.length > 0 ? (arr[0] as { conid?: number }) : null;
    if (contract?.conid != null) return Number(contract.conid);
  } catch (e) {
    if (axios.isAxiosError(e) && e.response?.status === 429) set429Cooldown();
    if (axios.isAxiosError(e) && e.response?.status !== 404) {
      console.warn(`[IB] trsrv/stocks failed for ${symbol}:`, e.response?.status ?? e.message);
    }
  }

  // 2) Fallback: POST /iserver/secdef/search
  try {
    const cfg = gatewayRequestConfig();
    const searchRes = await axios.post(
      `${base}/iserver/secdef/search?symbol=${encodeURIComponent(sym)}&sectype=STK`,
      { symbol: sym, name: false },
      { ...cfg, headers: { ...cfg.headers, 'Content-Type': 'application/json' } }
    );
    const data = searchRes.data;
    if (Array.isArray(data) && data.length > 0) {
      const first = data[0] as { conid?: number };
      if (first?.conid != null) return Number(first.conid);
    }
    if (data && typeof data === 'object' && 'conid' in (data as object)) {
      return Number((data as { conid: number }).conid);
    }
  } catch (e) {
    if (axios.isAxiosError(e) && e.response?.status === 429) set429Cooldown();
    if (axios.isAxiosError(e) && e.response?.status !== 404) {
      console.warn(`[IB] secdef/search failed for ${symbol}:`, e.response?.status ?? e.message);
    }
  }
  return null;
}

/**
 * Get market data for a symbol
 */
export async function getIBMarketData(symbol: string): Promise<IBMarketData | null> {
  try {
    if (Date.now() - lastGateway429Time < GATEWAY_429_COOLDOWN_MS) return null;
    const conid = await getContractIdForSymbol(symbol);
    if (!conid) {
      console.warn(`[IB] No contract for ${symbol} – trsrv/stocks and secdef/search both returned no conid`);
      return null;
    }

    // Client Portal API: 31=last, 82=change, 83=change%, 84=bid, 85=bidSize, 86=ask, 87=volume, 88=askSize
    const fields = '31,82,83,84,85,86,87,88';
    let raw: Record<string, string | number> = {};
    for (let attempt = 0; attempt < 2; attempt++) {
      const marketRes = await axios.get(`${getIBGatewayUrl()}/iserver/marketdata/snapshot`, {
        ...gatewayRequestConfig(),
        params: { conids: String(conid), fields },
      });
      if (!marketRes.data) {
        if (attempt === 1) {
          console.warn(`[IB] No market data for ${symbol}`);
          return null;
        }
        await new Promise((r) => setTimeout(r, 400));
        continue;
      }
      const res = marketRes.data;
      // Response can be single object or array of one object
      raw = Array.isArray(res) ? (res[0] as Record<string, string | number>) || {} : (res as Record<string, string | number>) || {};
      const last = raw['31'];
      if (last != null && String(last).length > 0 && !Number.isNaN(Number(last))) break;
      if (attempt === 1) break;
      await new Promise((r) => setTimeout(r, 400));
    }

    const num = (v: string | number | undefined): number => {
      if (v == null) return 0;
      const n = typeof v === 'string' ? parseFloat(String(v).replace(/,/g, '')) : Number(v);
      return Number.isFinite(n) ? n : 0;
    };
    const price = num(raw['31']) || num(raw['86']) || num(raw['84']) || 0;
    const bid = num(raw['84']) || 0;
    const ask = num(raw['86']) || 0;
    const volume = num(raw['87']) || 0;
    const change = raw['82'] != null ? num(raw['82']) : undefined;
    const changePercent = raw['83'] != null ? num(raw['83']) : undefined;

    if (price <= 0) {
      const keys = Object.keys(raw).filter((k) => k !== '_updated').slice(0, 15);
      console.warn(`[IB] No price in snapshot for ${symbol} – keys:`, keys.join(', ') || '(none)');
      return null;
    }

    return {
      symbol,
      price,
      bid: bid || price,
      ask: ask || price,
      volume,
      change,
      changePercent,
      iv: undefined,
      bidSize: raw['85'] != null ? num(raw['85']) : undefined,
      askSize: raw['88'] != null ? num(raw['88']) : undefined,
      lastTradeTime: raw['_updated'] != null ? Number(raw['_updated']) : undefined,
    };
  } catch (error) {
    if (axios.isAxiosError(error) && error.response?.status === 429) set429Cooldown();
    console.error(`[IB] Error fetching market data for ${symbol}:`, error);
    return null;
  }
}

/** YYYYMMDD → MMMYY (e.g. 20260130 → JAN26) for /iserver/secdef. */
function yyyymmddToMmmYY(s: string): string {
  const y = s.slice(0, 4);
  const m = parseInt(s.slice(4, 6), 10);
  const mon = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"][m - 1] ?? "JAN";
  return `${mon}${y.slice(2, 4)}`;
}

/** Fallback: use /iserver/secdef/search → strikes → info (IB recommended flow). */
async function getOptionsViaIserverSecdef(
  symbol: string,
  underConid: number,
  underlyingPrice: number,
  expiryFilter: string[]
): Promise<IBOptionsChain | null> {
  const wantNorm = String(expiryFilter[0] ?? "").replace(/[-/\s]/g, "").slice(0, 8);
  if (wantNorm.length < 8) return null;
  const month = yyyymmddToMmmYY(wantNorm);
  const parseNum = (v: unknown): number => (v != null && !Number.isNaN(Number(v)) ? Number(String(v).replace(/,/g, "")) : 0);

  try {
    const strikesRes = await axios.get(`${getIBGatewayUrl()}/iserver/secdef/strikes`, {
      ...gatewayRequestConfig(),
      params: { conid: underConid, secType: "OPT", month },
    });
    const putStrikes = strikesRes.data?.put as number[] | undefined;
    const callStrikes = strikesRes.data?.call as number[] | undefined;
    const strikes = [...new Set([...(putStrikes ?? []), ...(callStrikes ?? [])])].filter(
      (s) => Math.abs(s - underlyingPrice) <= underlyingPrice * 0.5
    );
    if (strikes.length === 0) return null;

    const options: IBOption[] = [];
    for (const right of ["C", "P"] as const) {
      for (const strike of strikes.slice(0, 15)) {
        try {
          const infoRes = await axios.get(`${getIBGatewayUrl()}/iserver/secdef/info`, {
            ...gatewayRequestConfig(),
            params: { conid: underConid, secType: "OPT", month, strike, right, exchange: "SMART" },
          });
          const arr = Array.isArray(infoRes.data) ? infoRes.data : [];
          for (const c of arr) {
            const mat = String(c.maturityDate ?? "").replace(/[-/\s]/g, "").slice(0, 8);
            if (mat !== wantNorm) continue;
            const conid = c.conid;
            let bid = 0, ask = 0, last = 0;
            try {
              const snap = await axios.get(`${getIBGatewayUrl()}/iserver/marketdata/snapshot`, {
                ...gatewayRequestConfig(),
                params: { conids: String(conid), fields: "31,84,86" },
              });
              const d = Array.isArray(snap.data) ? snap.data[0] : snap.data;
              bid = parseNum((d as Record<string, unknown>)?.["84"]) || 0;
              ask = parseNum((d as Record<string, unknown>)?.["86"]) || 0;
              last = parseNum((d as Record<string, unknown>)?.["31"]) || bid || ask || 0;
            } catch { /* optional */ }
            options.push({
              conid,
              symbol: `${symbol} ${wantNorm} ${strike} ${right}`,
              strike: Number(strike),
              right,
              expiry: wantNorm,
              bid,
              ask,
              last: last || bid || ask || 0,
              volume: 0,
              openInterest: 0,
              impliedVolatility: 0,
              delta: 0,
              gamma: 0,
              theta: 0,
              vega: 0,
            });
          }
        } catch { /* skip strike */ }
      }
    }
    if (options.length === 0) {
      console.warn(`[IB] iserver/secdef fallback for ${symbol} ${wantNorm}: strikes/info returned no options.`);
      return null;
    }
    return {
      underlying: symbol,
      underlyingPrice,
      expirations: [wantNorm],
      strikes: [...new Set(options.map((o) => o.strike))].sort((a, b) => a - b),
      options,
    };
  } catch (e) {
    console.warn(`[IB] iserver/secdef fallback for ${symbol} ${expiryFilter[0]}:`, e instanceof Error ? e.message : e);
    return null;
  }
}

/**
 * Get options chain for a symbol
 */
export async function getIBOptionsChain(symbol: string, expiryFilter?: string[]): Promise<IBOptionsChain | null> {
  try {
    if (Date.now() - lastGateway429Time < GATEWAY_429_COOLDOWN_MS) {
      console.warn(`[IB] Option chain skipped: in 429 cooldown (wait ~2 min). Symbol: ${symbol}`);
      return null;
    }
    const conid = await getContractIdForSymbol(symbol);
    if (!conid) {
      console.warn(`[IB] No contract found for ${symbol} — trsrv/stocks and secdef/search returned no conid.`);
      return null;
    }

    // Get market data for underlying (Client Portal uses string keys: 31=last, 84=bid, 86=ask)
    const underlyingRes = await axios.get(`${getIBGatewayUrl()}/iserver/marketdata/snapshot`, {
      ...gatewayRequestConfig(),
      params: { conids: String(conid), fields: '31,84,86' },
    });
    const underRaw = Array.isArray(underlyingRes.data) ? underlyingRes.data[0] : underlyingRes.data;
    const parseNum = (v: unknown): number => (v != null && !Number.isNaN(Number(v)) ? Number(String(v).replace(/,/g, '')) : 0);
    const underlyingPrice = parseNum((underRaw as Record<string, unknown>)?.['31']) || parseNum((underRaw as Record<string, unknown>)?.['86']) || parseNum((underRaw as Record<string, unknown>)?.['84']) || 0;

    // Get option chains (trsrv/secdef/schedule — different from scanner API)
    let rawExps: string[] = [];
    try {
      const chainRes = await axios.get(`${getIBGatewayUrl()}/trsrv/secdef/schedule`, {
        ...gatewayRequestConfig(),
        params: { conid, secType: 'OPT' },
        validateStatus: (s) => s === 200 || s === 400,
      });
      if (chainRes.data?.expirations) {
        rawExps = chainRes.data.expirations as string[];
      }
      if (rawExps.length === 0) {
        console.warn(`[IB] trsrv/secdef/schedule for ${symbol} (conid ${conid}): no expirations. Status=${chainRes.status}. Trying iserver fallback if expiryFilter set.`);
      }
    } catch (scheduleErr) {
      const status = axios.isAxiosError(scheduleErr) ? scheduleErr.response?.status : '';
      if (status === 429) set429Cooldown();
      console.warn(`[IB] trsrv/secdef/schedule failed for ${symbol}:`, status || (scheduleErr instanceof Error ? scheduleErr.message : scheduleErr));
    }

    if (rawExps.length === 0 && expiryFilter?.length) {
      const allOptions: IBOption[] = [];
      const allExpirations = new Set<string>();
      const allStrikes = new Set<number>();
      for (const exp of expiryFilter.slice(0, 5)) {
        const chain = await getOptionsViaIserverSecdef(symbol, conid, underlyingPrice, [exp]);
        if (chain?.options?.length) {
          chain.options.forEach((o) => {
            allOptions.push(o);
            allExpirations.add(o.expiry);
            allStrikes.add(o.strike);
          });
        }
      }
      if (allOptions.length > 0) {
        console.warn(`[IB] Option chain for ${symbol} via iserver/secdef fallback: ${allOptions.length} options, expirations ${[...allExpirations].join(", ")}.`);
        return {
          underlying: symbol,
          underlyingPrice,
          expirations: [...allExpirations].sort(),
          strikes: [...allStrikes].sort((a, b) => a - b),
          options: allOptions,
        };
      }
      console.warn(`[IB] Option chain for ${symbol}: iserver fallback for expiries ${expiryFilter.slice(0, 3).join(", ")} returned no options.`);
    }
    if (rawExps.length === 0) {
      console.warn(`[IB] Option chain for ${symbol}: no expirations from schedule and no iserver result. Returning empty.`);
      return { underlying: symbol, underlyingPrice, expirations: [], strikes: [], options: [] };
    }

    const toYyyymmdd = (s: string): string => {
      const x = String(s || "").replace(/[-/\s]/g, "");
      if (/^\d{8}$/.test(x)) return x;
      const d = new Date(s);
      if (!Number.isNaN(d.getTime())) {
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, "0");
        const day = String(d.getDate()).padStart(2, "0");
        return `${y}${m}${day}`;
      }
      return x;
    };

    const expirations =
      expiryFilter && expiryFilter.length > 0
        ? rawExps.filter((exp) => {
            const expNorm = toYyyymmdd(exp);
            return expiryFilter.some((f) => toYyyymmdd(f) === expNorm);
          })
        : rawExps;

    if (expiryFilter?.length && expirations.length === 0) {
      const wantNorm = expiryFilter.map(toYyyymmdd)[0];
      const closest = rawExps.find((e) => toYyyymmdd(e) === wantNorm) ?? rawExps.find((e) => toYyyymmdd(e).startsWith(wantNorm.slice(0, 6)));
      if (closest) {
        expirations.push(closest);
      } else {
        // Schedule didn't list it; try requested expiry directly (IB accepts YYYYMMDD)
        expirations.push(wantNorm);
      }
    }

    // Get strikes for each expiration
    const strikes = new Set<number>();
    const options: IBOption[] = [];

    for (const expiry of expirations.slice(0, 5)) {
      // Limit to first 5 expirations
      try {
        const strikeRes = await axios.get(`${getIBGatewayUrl()}/trsrv/secdef`, {
          ...gatewayRequestConfig(),
          params: {
            symbol: `${symbol} ${expiry}`,
            secType: 'OPT',
          },
        });

        if (strikeRes.data && Array.isArray(strikeRes.data)) {
          for (const optContract of strikeRes.data) {
            strikes.add(optContract.strike);

            // Get market data for this option
            try {
              const optMarketRes = await axios.get(`${getIBGatewayUrl()}/iserver/marketdata/snapshot`, {
                ...gatewayRequestConfig(),
                params: {
                  conids: String(optContract.conid),
                  fields: '31,84,85,86,88,106,107,108,109,110',
                },
              });

              if (optMarketRes.data) {
                const d = (Array.isArray(optMarketRes.data) ? optMarketRes.data[0] : optMarketRes.data) as Record<string, unknown>;
                const p = (k: string) => (d?.[k] != null && !Number.isNaN(Number(d[k])) ? Number(String(d[k]).replace(/,/g, '')) : 0);
                options.push({
                  conid: optContract.conid,
                  symbol: `${symbol} ${expiry} ${optContract.strike} ${optContract.right}`,
                  strike: optContract.strike,
                  right: optContract.right,
                  expiry,
                  bid: p('84') || 0,
                  ask: p('86') || 0,
                  last: p('31') || p('86') || p('84') || 0,
                  volume: p('87') || 0,
                  openInterest: p('27') || 0,
                  impliedVolatility: p('106') || 0,
                  delta: p('107') || 0,
                  gamma: p('108') || 0,
                  theta: p('109') || 0,
                  vega: p('110') || 0,
                });
              }
            } catch (e) {
              console.warn(`[IB] Error fetching option market data for ${optContract.conid}`);
            }
          }
        }
      } catch (e) {
        console.warn(`[IB] Error fetching options for ${symbol} ${expiry}`);
      }
    }

    return {
      underlying: symbol,
      underlyingPrice,
      expirations,
      strikes: Array.from(strikes).sort((a, b) => a - b),
      options,
    };
  } catch (error) {
    if (axios.isAxiosError(error) && error.response?.status === 429) set429Cooldown();
    console.error(`[IB] Error fetching options chain for ${symbol}:`, error);
    return null;
  }
}

/** Cached VIX level (5 min TTL). VIX = ^VIX or VIX in IB. */
let vixCache: { level: number; ts: number } | null = null;
const VIX_CACHE_TTL_MS = 300_000;

/** Get VIX level for vol regime context. Returns 0 when unavailable. */
export async function getVIX(): Promise<number> {
  const now = Date.now();
  if (vixCache && now - vixCache.ts < VIX_CACHE_TTL_MS) return vixCache.level;
  try {
    const vix1 = await getIBMarketData('VIX');
    const vix2 = vix1 ?? await getIBMarketData('^VIX');
    const level = vix2?.price ?? 0;
    if (level > 0) vixCache = { level, ts: now };
    return level;
  } catch {
    return 0;
  }
}

/**
 * Get market data for multiple symbols
 */
export async function getIBMarketDataBatch(symbols: string[]): Promise<Map<string, IBMarketData>> {
  const results = new Map<string, IBMarketData>();

  for (const symbol of symbols) {
    const data = await getIBMarketData(symbol);
    if (data) {
      results.set(symbol, data);
    }
  }

  return results;
}

const IB_CONNECT_RETRIES = 3;
const IB_CONNECT_RETRY_DELAY_MS = 1500;

export interface IBGatewayCheckResult {
  connected: boolean;
  error?: string;
  errorCode?: string;
}

/**
 * Check if IB Gateway is connected; returns reason when not (401, ECONNREFUSED, etc.).
 * Client Portal Gateway uses browser cookies; set IB_GATEWAY_COOKIE=api=YOUR_VALUE in .env.local (copy from browser DevTools after login) if Connect fails with 401.
 */
export async function checkIBGatewayConnectionWithReason(): Promise<IBGatewayCheckResult> {
  const now = Date.now();
  if (now - lastGateway429Time < GATEWAY_429_COOLDOWN_MS) {
    return {
      connected: false,
      error: '429 cooldown – wait ' + Math.ceil((GATEWAY_429_COOLDOWN_MS - (now - lastGateway429Time)) / 1000) + 's then try Connect once. Set IB_GATEWAY_COOKIE in .env.local and restart if you have not.',
      errorCode: 'HTTP_429',
    };
  }
  const url = `${getIBGatewayUrl()}/iserver/accounts`;
  let lastError: string | undefined;
  let lastCode: string | undefined;
  for (let attempt = 1; attempt <= IB_CONNECT_RETRIES; attempt++) {
    try {
      const res = await axios.get(url, {
        ...gatewayRequestConfig(),
        validateStatus: () => true,
      });
      if (res.status === 200) {
        lastGateway429Time = 0; // clear cooldown on success
        return { connected: true };
      }
      if (res.status === 401 || res.status === 302) {
        lastError = '401 Unauthorized – Gateway session required. Log in at http://localhost:5000 in your browser, or set IB_GATEWAY_COOKIE=api=YOUR_VALUE in .env.local (copy cookie from DevTools → Application → Cookies → localhost:5000 → api) and restart the server.';
        lastCode = '401';
        if (attempt === IB_CONNECT_RETRIES) {
          console.warn('[IB] Gateway 401/302. Open http://localhost:5000, log in, or set IB_GATEWAY_COOKIE in .env.local');
        }
        await new Promise((r) => setTimeout(r, IB_CONNECT_RETRY_DELAY_MS));
        continue;
      }
      if (res.status === 400) {
        lastError = '400 Bad Request – Gateway session not ready. Open http://localhost:5000 in your browser, log in fully (including 2FA), wait until the Client Portal loads, then click Connect here. Or set IB_GATEWAY_COOKIE=api=YOUR_VALUE in .env.local (copy the "api" cookie from DevTools after logging in) and restart the server.';
        lastCode = '400';
        if (attempt === IB_CONNECT_RETRIES) {
          console.warn('[IB] Gateway 400. Log in at http://localhost:5000 and wait for the portal to load, or set IB_GATEWAY_COOKIE.');
        }
        await new Promise((r) => setTimeout(r, IB_CONNECT_RETRY_DELAY_MS));
        continue;
      }
      if (res.status === 429) {
        lastGateway429Time = Date.now();
        lastError = '429 Too Many Requests – Gateway rate limit. Wait 1–2 minutes, then click Connect again. Ensure you are logged in at http://localhost:5000.';
        lastCode = 'HTTP_429';
        if (attempt === IB_CONNECT_RETRIES) {
          console.warn('[IB] Gateway 429 – cooldown 2 min. Set IB_GATEWAY_COOKIE in .env.local, restart server, wait 2 min, then Connect once.');
        }
        await new Promise((r) => setTimeout(r, 3000));
        continue;
      }
      lastError = `Gateway returned HTTP ${res.status}. Ensure you are logged in at http://localhost:5000.`;
      lastCode = `HTTP_${res.status}`;
      await new Promise((r) => setTimeout(r, IB_CONNECT_RETRY_DELAY_MS));
    } catch (error: unknown) {
      const err = error as { code?: string; message?: string };
      lastCode = err.code ?? 'UNKNOWN';
      if (err.code === 'ECONNREFUSED') {
        lastError = 'Connection refused – is the Client Portal Gateway running? Start it and open http://localhost:5000 to log in.';
      } else if (err.code === 'ECONNABORTED' || err.message?.includes('timeout')) {
        lastError = 'Connection timed out – Gateway may be busy or not responding.';
      } else {
        lastError = err.message || String(error) || 'Connection failed.';
      }
      if (attempt === IB_CONNECT_RETRIES && err.code === 'ECONNREFUSED') {
        const now = Date.now();
        if (now - lastIBConnectionLog >= IB_CONNECTION_LOG_INTERVAL_MS) {
          lastIBConnectionLog = now;
          console.warn('[IB] Gateway not reachable. Is Client Portal Gateway running? Start it and open http://localhost:5000');
        }
      }
      if (attempt < IB_CONNECT_RETRIES) {
        await new Promise((r) => setTimeout(r, IB_CONNECT_RETRY_DELAY_MS));
      }
    }
  }
  return { connected: false, error: lastError, errorCode: lastCode };
}

/**
 * Check if IB Gateway is connected (boolean only).
 */
export async function checkIBGatewayConnection(): Promise<boolean> {
  const r = await checkIBGatewayConnectionWithReason();
  return r.connected;
}

export interface IBGatewayDiagnostic {
  gatewayUrl: string;
  cookieSet: boolean;
  accountsStatus: number | string;
  fixSteps: string[];
}

/**
 * One-shot diagnostic for Gateway: URL, cookie set, and /iserver/accounts status.
 * Use this to show the user exactly why Connect fails and what to do.
 */
export async function getIBGatewayDiagnostic(): Promise<IBGatewayDiagnostic> {
  const gatewayUrl = getIBGatewayUrl();
  const cookieSet = !!process.env.IB_GATEWAY_COOKIE?.trim();
  let accountsStatus: number | string = 0;
  const fixSteps: string[] = [];

  try {
    const res = await axios.get(`${gatewayUrl}/iserver/accounts`, {
      ...gatewayRequestConfig(),
      validateStatus: () => true,
      timeout: 8000,
    });
    accountsStatus = res.status;

    if (res.status === 200) {
      lastGateway429Time = 0; // clear cooldown on success
      fixSteps.push('Gateway is reachable and authenticated. Click Connect.');
      return { gatewayUrl, cookieSet, accountsStatus, fixSteps };
    }
    if (res.status === 401 || res.status === 302) {
      fixSteps.push('If the login page shows "Authentication failed": that is IB rejecting your credentials (username, password, or 2FA). Use correct IB login, request a fresh 2FA code, and ensure Paper/Live matches your account. After several failures IB may lock temporarily — wait 15–30 min. Use "Problem with logging in?" on the Gateway page for password reset.');
      fixSteps.push('1. Open http://localhost:5000 in your browser and log in (complete 2FA if asked).');
      fixSteps.push('2. Get the cookie: F12 → Application → Cookies → http://localhost:5000 → copy the "api" value; or if Gateway has Settings → API, copy the api= value from there.');
      fixSteps.push('3. In your project root, open or create .env.local and add: IB_GATEWAY_COOKIE=api=PASTE_THE_VALUE_HERE');
      fixSteps.push('4. Restart the server (Ctrl+C, then pnpm dev), wait 1–2 minutes, then click Connect here.');
      if (!cookieSet) {
        fixSteps.unshift('The server cannot use your browser login. You must give the server the Gateway cookie:');
      } else {
        fixSteps.unshift('Cookie may be wrong or expired. Get a fresh cookie and update .env.local:');
      }
    } else if (res.status === 429) {
      lastGateway429Time = Date.now();
      fixSteps.push('Gateway rate limit. Server will not call Gateway again for 2 min. Set IB_GATEWAY_COOKIE in .env.local, restart server, wait 2 min, then click Connect once.');
    } else if (res.status === 400) {
      fixSteps.push('Gateway session not ready. Log in at http://localhost:5000, wait for the portal to fully load.');
      fixSteps.push('Then set IB_GATEWAY_COOKIE=api=... in .env.local (copy "api" cookie from DevTools) and restart the server.');
    } else {
      fixSteps.push(`Gateway returned HTTP ${res.status}. Ensure you are logged in at http://localhost:5000.`);
      if (!cookieSet) fixSteps.push('Set IB_GATEWAY_COOKIE in .env.local (copy "api" cookie from browser after login) and restart.');
    }
  } catch (err: unknown) {
    const e = err as { code?: string; message?: string };
    accountsStatus = e.code ?? e.message ?? 'UNKNOWN';
    if (e.code === 'ECONNREFUSED') {
      fixSteps.push('Client Portal Gateway is not running or not reachable.');
      fixSteps.push('1. Start the Client Portal Gateway app (from Interactive Brokers).');
      fixSteps.push('2. Open http://localhost:5000 in your browser and log in.');
      fixSteps.push('3. Then set IB_GATEWAY_COOKIE=api=... in .env.local and restart the server.');
    } else if (e.code === 'ECONNABORTED' || e.message?.includes('timeout')) {
      fixSteps.push('Gateway timed out. Check that it is running at ' + gatewayUrl + ' and try again.');
    } else {
      fixSteps.push(String(e.message ?? err));
    }
  }

  return { gatewayUrl, cookieSet, accountsStatus, fixSteps };
}

/**
 * Get account information
 */
export async function getIBAccountInfo(): Promise<any> {
  try {
    const res = await axios.get(`${getIBGatewayUrl()}/iserver/accounts`, gatewayRequestConfig());
    return res.data;
  } catch (error) {
    console.error('[IB] Error fetching account info:', error);
    return null;
  }
}
