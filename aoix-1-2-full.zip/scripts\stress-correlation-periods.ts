/**
 * High-correlation period stress — identify when cross-asset correlation is high.
 * Run: pnpm tsx scripts/stress-correlation-periods.ts
 * Writes: backtest-results/correlation-stress.json
 */
import { identifyHighCorrelationPeriods } from "../server/correlation-stress";
import { runHistoricalBacktest } from "../server/backtest-runner";
import { mkdir, writeFile } from "fs/promises";
import { join } from "path";

const SYMBOLS = (process.env.STRESS_SYMBOLS ?? "SPY,QQQ,IWM").split(",").map((s) => s.trim());
const START_YEARS_AGO = 4;
const OUT_DIR = process.env.BACKTEST_RESULTS_DIR ?? join(process.cwd(), "backtest-results");
const OUT_FILE = join(OUT_DIR, "correlation-stress.json");

async function main() {
  const endDate = new Date();
  const startDate = new Date();
  startDate.setFullYear(startDate.getFullYear() - START_YEARS_AGO);
  console.log("[Correlation Stress] Identifying correlation regimes:", SYMBOLS.join(", "));

  const corrRegimes = await identifyHighCorrelationPeriods(SYMBOLS, startDate, endDate, 20);
  const highPeriods: Array<{ start: Date; end: Date }> = [];
  let currentStart: Date | null = null;
  for (const r of corrRegimes) {
    if (r.regime === "high") {
      if (!currentStart) currentStart = r.date;
    } else {
      if (currentStart) {
        highPeriods.push({ start: currentStart, end: r.date });
        currentStart = null;
      }
    }
  }
  if (currentStart) highPeriods.push({ start: currentStart, end: endDate });
  console.log("[Correlation Stress] Found", highPeriods.length, "high-correlation periods");

  const results: Array<{ period: { start: string; end: string }; symbol: string; sharpe: number; winRate: number; maxDrawdown: number }> = [];
  const primarySymbol = SYMBOLS[0];
  for (const period of highPeriods.slice(-5)) {
    const days = Math.ceil((period.end.getTime() - period.start.getTime()) / (1000 * 86400));
    if (days < 10) continue;
    try {
      const result = await runHistoricalBacktest(primarySymbol, days, 5, undefined, true, 0.01, 1);
      results.push({
        period: { start: period.start.toISOString().slice(0, 10), end: period.end.toISOString().slice(0, 10) },
        symbol: primarySymbol,
        sharpe: result.sharpeRatio ?? 0,
        winRate: (result.winRate ?? 0) * 100,
        maxDrawdown: result.maxDrawdownPercent ?? 0,
      });
      console.log(
        "[Correlation Stress]",
        period.start.toISOString().slice(0, 10),
        "→",
        period.end.toISOString().slice(0, 10),
        "Sharpe:",
        (result.sharpeRatio ?? 0).toFixed(2)
      );
    } catch (e) {
      console.warn("[Correlation Stress] Backtest failed for period:", e);
    }
  }
  const avgSharpe = results.length ? results.reduce((s, r) => s + r.sharpe, 0) / results.length : 0;
  console.log("[Correlation Stress] Avg Sharpe in high-corr periods:", avgSharpe.toFixed(2));

  await mkdir(OUT_DIR, { recursive: true });
  await writeFile(
    OUT_FILE,
    JSON.stringify(
      {
        symbols: SYMBOLS,
        highPeriodsCount: highPeriods.length,
        backtestResults: results,
        avgSharpeInHighCorr: avgSharpe,
        timestamp: new Date().toISOString(),
      },
      null,
      2
    ),
    "utf-8"
  );
  console.log("[Correlation Stress] Output:", OUT_FILE);
  process.exit(0);
}

main().catch((e) => {
  console.error("[Correlation Stress] Error:", e);
  process.exit(1);
});
