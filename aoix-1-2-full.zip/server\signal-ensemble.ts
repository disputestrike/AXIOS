/**
 * A+++ Pillar 1: Signal confidence & multi-TF validation.
 * Multi-TF alignment (15m/1h/4h/daily), signal agreement (advanced + 2+ simple), regime-signal affinity.
 */

export type SignalClass = 'A' | 'B' | 'C' | 'D';

export interface SimpleSignal {
  type: string;
  class: SignalClass;
  confidence: number;
  direction: 'bullish' | 'bearish';
}

export interface SignalEnsembleInput {
  advancedConfidence: number;
  advancedDirection: 'bullish' | 'bearish';
  /** Daily trend direction (e.g. from 20d MA). */
  dailyDirection: 'bullish' | 'bearish';
  /** Intraday direction (e.g. from price change). */
  intradayDirection: 'bullish' | 'bearish';
  /** Dealer, flow, momentum (or subset). */
  simpleSignals: SimpleSignal[];
  regime: string;
  signalClass: string;
}

export interface SignalEnsembleResult {
  /** Base confidence 0–1 (advanced or best simple). */
  baseConfidence: number;
  /** Multi-TF alignment bonus: +0.10 if daily == intraday == advanced. */
  multiTFBonus: number;
  /** Signal agreement bonus: +0.08 if advanced + avg(simple) > 1.5. */
  signalAgreementBonus: number;
  /** Regime-signal affinity already applied in ranking-utils; here 0–0.05 extra. */
  regimeSupportBonus: number;
  /** Final confidence capped 0.95. */
  adjustedConfidence: number;
}

/**
 * Compute multi-TF and signal-agreement adjusted confidence (Pillar 1).
 */
export function computeSignalEnsemble(input: SignalEnsembleInput): SignalEnsembleResult {
  const { advancedConfidence, advancedDirection, dailyDirection, intradayDirection, simpleSignals, regime } = input;
  const baseConfidence = advancedConfidence;
  let multiTFBonus = 0;
  if (dailyDirection === intradayDirection && intradayDirection === advancedDirection) {
    multiTFBonus = 0.10;
  }
  let signalAgreementBonus = 0;
  if (simpleSignals.length >= 2) {
    const avgSimple = simpleSignals.reduce((s, x) => s + x.confidence, 0) / simpleSignals.length;
    if (advancedConfidence + avgSimple > 1.5) signalAgreementBonus = 0.08;
  }
  const r = (regime || '').toLowerCase();
  let regimeSupportBonus = 0;
  if (r.includes('mean_reverting') || r === 'chaotic') regimeSupportBonus = 0.02;
  if (r === 'trending_bull') regimeSupportBonus = 0.02;
  const adjustedConfidence = Math.min(0.95, baseConfidence + multiTFBonus + signalAgreementBonus + regimeSupportBonus);
  return {
    baseConfidence,
    multiTFBonus,
    signalAgreementBonus,
    regimeSupportBonus,
    adjustedConfidence,
  };
}
