/**
 * A+++ Pillar 8: Execution cost & slippage.
 * Bid/ask spread cost, market impact (qty^0.5 vs ADV), commission (IB $0.65/contract), time-of-day.
 */

/** Cost components in $ and as % of notional. */
export interface ExecutionCostResult {
  /** Spread cost: (spread_pct × entry) / 2 per contract. */
  spreadCostPerContract: number;
  /** Market impact: qty^0.5 vs ADV, capped 5%. */
  marketImpactPct: number;
  /** Commission: IB $0.65/contract, spreads 2–4×. */
  commissionPerContract: number;
  /** Time-of-day factor: 1.0 = optimal (14:30–15:00 EST), &lt;1 = penalize AH. */
  timeOfDayFactor: number;
  /** Total cost per contract (spread + commission). */
  totalCostPerContract: number;
  /** Expected return drag (multiplier 0.95–1.0). */
  expectedReturnMultiplier: number;
}

const COMMISSION_PER_CONTRACT = 0.65;
const SPREAD_MULTIPLIER = 2; // 2–4× for spreads (2 legs)

/**
 * Compute execution cost and expected return multiplier.
 * Prefer 14:30–15:00 EST; penalize AH.
 */
export function getExecutionCost(
  entryPricePerContract: number,
  quantity: number,
  spreadPct: number,
  avgDailyVolume: number,
  isSpread: boolean = false,
  hourUTC: number = new Date().getUTCHours(),
  minuteUTC: number = new Date().getUTCMinutes()
): ExecutionCostResult {
  const spreadCostPerContract = (spreadPct / 100) * entryPricePerContract * 100 / 2;
  const commissionPerContract = isSpread ? COMMISSION_PER_CONTRACT * SPREAD_MULTIPLIER : COMMISSION_PER_CONTRACT;
  let marketImpactPct = 0;
  if (avgDailyVolume > 0 && quantity > 0) {
    const impact = Math.sqrt(quantity) / Math.sqrt(avgDailyVolume) * 2;
    marketImpactPct = Math.min(5, impact * 100);
  }
  const estUTC = hourUTC + minuteUTC / 60;
  const estEST = (estUTC - 5 + 24) % 24;
  let timeOfDayFactor = 1.0;
  if (estEST >= 14.5 && estEST <= 15) timeOfDayFactor = 1.0;
  else if (estEST >= 9.5 && estEST < 16) timeOfDayFactor = 0.98;
  else timeOfDayFactor = 0.92;
  const totalCostPerContract = spreadCostPerContract + commissionPerContract;
  const costAsPct = entryPricePerContract * 100 > 0 ? totalCostPerContract / (entryPricePerContract * 100) : 0;
  const expectedReturnMultiplier = Math.max(0.95, 1 - costAsPct * 2);
  return {
    spreadCostPerContract,
    marketImpactPct,
    commissionPerContract,
    timeOfDayFactor,
    totalCostPerContract,
    expectedReturnMultiplier: expectedReturnMultiplier * timeOfDayFactor,
  };
}
