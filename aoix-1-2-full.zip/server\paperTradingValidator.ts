/**
 * Paper Trading Validator
 * Validates Omega-0 execution logic with IBKR paper account
 * Tracks performance metrics and validates all exit logic
 */

import { getDb } from "./db";
import { trades, metaIntelligence } from "../drizzle/schema";
import { eq, and, gte, lte } from "drizzle-orm";

export interface PaperTradingMetrics {
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRate: number;
  profitFactor: number;
  avgWin: number;
  avgLoss: number;
  largestWin: number;
  largestLoss: number;
  totalProfit: number;
  totalLoss: number;
  netProfit: number;
  maxDrawdown: number;
  sharpeRatio: number;
  validationPeriodDays: number;
  startDate: Date;
  endDate: Date;
  exitLogicValidated: boolean;
  slippageAccuracy: number;
  edgeHalfLife: number;
}

export class PaperTradingValidator {
  private startDate: Date;
  private endDate: Date;
  private trades: any[] = [];
  private cumulativeProfit: number = 0;
  private maxCumulativeProfit: number = 0;
  private maxDrawdown: number = 0;

  constructor(validationPeriodDays: number = 14) {
    this.endDate = new Date();
    this.startDate = new Date(this.endDate.getTime() - validationPeriodDays * 24 * 60 * 60 * 1000);
  }

  /**
   * Load trades from database for validation period
   */
  async loadTrades(): Promise<void> {
    const db = await getDb();
    if (!db) {
      throw new Error("Database not available");
    }

    const results = await db
      .select()
      .from(trades)
      .where(
        and(
          gte(trades.createdAt, this.startDate),
          lte(trades.createdAt, this.endDate),
          eq(trades.status, "closed")
        )
      );

    this.trades = results;
  }

  /**
   * Calculate comprehensive performance metrics
   */
  calculateMetrics(): PaperTradingMetrics {
    const winningTrades = this.trades.filter((t) => t.pnl > 0);
    const losingTrades = this.trades.filter((t) => t.pnl < 0);

    const totalWins = winningTrades.reduce((sum, t) => sum + t.pnl, 0);
    const totalLosses = Math.abs(losingTrades.reduce((sum, t) => sum + t.pnl, 0));
    const netProfit = totalWins - totalLosses;

    const avgWin = winningTrades.length > 0 ? totalWins / winningTrades.length : 0;
    const avgLoss = losingTrades.length > 0 ? totalLosses / losingTrades.length : 0;

    const profitFactor = totalLosses > 0 ? totalWins / totalLosses : totalWins > 0 ? Infinity : 0;

    // Calculate Sharpe Ratio
    const returns = this.trades.map((t) => t.pnl);
    const meanReturn = returns.reduce((a, b) => a + b, 0) / returns.length || 0;
    const variance =
      returns.reduce((sum, r) => sum + Math.pow(r - meanReturn, 2), 0) / returns.length || 0;
    const stdDev = Math.sqrt(variance);
    const sharpeRatio = stdDev > 0 ? meanReturn / stdDev : 0;

    // Calculate max drawdown
    this.calculateMaxDrawdown();

    // Validate exit logic
    const exitLogicValidated = this.validateExitLogic();

    // Calculate slippage accuracy
    const slippageAccuracy = this.calculateSlippageAccuracy();

    // Calculate edge half-life
    const edgeHalfLife = this.calculateEdgeHalfLife();

    return {
      totalTrades: this.trades.length,
      winningTrades: winningTrades.length,
      losingTrades: losingTrades.length,
      winRate: this.trades.length > 0 ? winningTrades.length / this.trades.length : 0,
      profitFactor,
      avgWin,
      avgLoss,
      largestWin: Math.max(...winningTrades.map((t) => t.pnl), 0),
      largestLoss: Math.min(...losingTrades.map((t) => t.pnl), 0),
      totalProfit: totalWins,
      totalLoss: totalLosses,
      netProfit,
      maxDrawdown: this.maxDrawdown,
      sharpeRatio,
      validationPeriodDays: Math.round(
        (this.endDate.getTime() - this.startDate.getTime()) / (24 * 60 * 60 * 1000)
      ),
      startDate: this.startDate,
      endDate: this.endDate,
      exitLogicValidated,
      slippageAccuracy,
      edgeHalfLife,
    };
  }

  /**
   * Validate that exit logic is working correctly
   */
  private validateExitLogic(): boolean {
    // Check that all trades have proper exit reasons
    const validExitReasons = ["take_profit", "stop_loss", "manual_exit", "time_exit"];

    const allValidExits = this.trades.every((t) => {
      if (!t.exitReason) return false;
      return validExitReasons.includes(t.exitReason);
    });

    // Check that take profit exits are around +30%
    const tpTrades = this.trades.filter((t) => t.exitReason === "take_profit");
    const tpValidation = tpTrades.every((t) => {
      const returnPct = (t.pnl / (t.entryPrice * t.quantity)) * 100;
      return returnPct >= 25 && returnPct <= 35; // Allow 25-35% range
    });

    // Check that stop loss exits are around -20%
    const slTrades = this.trades.filter((t) => t.exitReason === "stop_loss");
    const slValidation = slTrades.every((t) => {
      const returnPct = (t.pnl / (t.entryPrice * t.quantity)) * 100;
      return returnPct >= -25 && returnPct <= -15; // Allow -25% to -15% range
    });

    return allValidExits && tpValidation && slValidation;
  }

  /**
   * Calculate slippage accuracy vs. modeled slippage
   */
  private calculateSlippageAccuracy(): number {
    if (this.trades.length === 0) return 0;

    let accuracySum = 0;

    for (const trade of this.trades) {
      // Expected slippage based on order size
      const expectedSlippage = this.calculateExpectedSlippage(trade.quantity);

      // Actual slippage
      const actualSlippage = Math.abs(trade.entryPrice - trade.midPrice) || 0;

      // Accuracy: how close actual is to expected (0-100%)
      const accuracy = Math.max(0, 100 - Math.abs(expectedSlippage - actualSlippage) * 100);
      accuracySum += accuracy;
    }

    return accuracySum / this.trades.length;
  }

  /**
   * Calculate expected slippage based on order size
   */
  private calculateExpectedSlippage(quantity: number): number {
    // Small orders: 0.05%
    // Medium orders: 0.10%
    // Large orders: 0.20%
    if (quantity < 10) return 0.0005;
    if (quantity < 50) return 0.001;
    return 0.002;
  }

  /**
   * Calculate edge half-life (how long the edge remains profitable)
   */
  private calculateEdgeHalfLife(): number {
    if (this.trades.length < 2) return 0;

    // Sort trades by creation time
    const sortedTrades = [...this.trades].sort(
      (a, b) => a.createdAt.getTime() - b.createdAt.getTime()
    );

    // Calculate rolling win rate
    const windowSize = Math.ceil(sortedTrades.length / 4);
    let halfLifeTrades = 0;
    let profitableWindows = 0;

    for (let i = 0; i < sortedTrades.length - windowSize; i++) {
      const window = sortedTrades.slice(i, i + windowSize);
      const wins = window.filter((t) => t.pnl > 0).length;
      const winRate = wins / window.length;

      if (winRate > 0.5) {
        profitableWindows++;
      }
      halfLifeTrades++;
    }

    // Half-life is when profitability drops to 50%
    return profitableWindows > 0
      ? Math.round((profitableWindows / halfLifeTrades) * this.trades.length)
      : 0;
  }

  /**
   * Calculate maximum drawdown
   */
  private calculateMaxDrawdown(): void {
    this.maxDrawdown = 0;
    this.cumulativeProfit = 0;
    this.maxCumulativeProfit = 0;

    for (const trade of this.trades) {
      this.cumulativeProfit += trade.pnl;

      if (this.cumulativeProfit > this.maxCumulativeProfit) {
        this.maxCumulativeProfit = this.cumulativeProfit;
      }

      const drawdown = this.maxCumulativeProfit - this.cumulativeProfit;
      if (drawdown > this.maxDrawdown) {
        this.maxDrawdown = drawdown;
      }
    }
  }

  /**
   * Generate validation report
   */
  async generateReport(): Promise<string> {
    await this.loadTrades();
    const metrics = this.calculateMetrics();

    const report = `
PAPER TRADING VALIDATION REPORT - AOIX-1 + Omega-0

VALIDATION PERIOD: ${metrics.startDate.toISOString().split("T")[0]} to ${metrics.endDate.toISOString().split("T")[0]} (${metrics.validationPeriodDays} days)

TRADE STATISTICS
Total Trades: ${metrics.totalTrades}
Winning Trades: ${metrics.winningTrades}
Losing Trades: ${metrics.losingTrades}
Win Rate: ${(metrics.winRate * 100).toFixed(2)}%
Profit Factor: ${metrics.profitFactor.toFixed(2)}x

PROFITABILITY METRICS
Total Profit: $${metrics.totalProfit.toFixed(2)}
Total Loss: $${metrics.totalLoss.toFixed(2)}
Net Profit: $${metrics.netProfit.toFixed(2)}
Average Win: $${metrics.avgWin.toFixed(2)}
Average Loss: $${metrics.avgLoss.toFixed(2)}
Largest Win: $${metrics.largestWin.toFixed(2)}
Largest Loss: $${metrics.largestLoss.toFixed(2)}

RISK METRICS
Maximum Drawdown: $${metrics.maxDrawdown.toFixed(2)}
Sharpe Ratio: ${metrics.sharpeRatio.toFixed(2)}
Edge Half-Life: ${metrics.edgeHalfLife} trades

VALIDATION RESULTS
Exit Logic Validated: ${metrics.exitLogicValidated ? "PASS" : "FAIL"}
Slippage Accuracy: ${metrics.slippageAccuracy.toFixed(2)}%

RECOMMENDATIONS
${this.generateRecommendations(metrics)}
`;

    return report;
  }

  /**
   * Generate recommendations based on metrics
   */
  private generateRecommendations(metrics: PaperTradingMetrics): string {
    const recommendations: string[] = [];

    if (metrics.winRate < 0.5) {
      recommendations.push("Win rate below 50% - Consider adjusting entry signals");
    }

    if (metrics.profitFactor < 1.5) {
      recommendations.push("Profit factor below 1.5x - Risk/reward ratio needs improvement");
    }

    if (metrics.maxDrawdown > metrics.netProfit * 0.5) {
      recommendations.push("Drawdown exceeds 50% of profits - Increase position sizing discipline");
    }

    if (metrics.sharpeRatio < 1) {
      recommendations.push("Sharpe ratio below 1.0 - Returns not adequately compensating for risk");
    }

    if (!metrics.exitLogicValidated) {
      recommendations.push("EXIT LOGIC VALIDATION FAILED - Do not trade live until fixed");
    }

    if (metrics.slippageAccuracy < 80) {
      recommendations.push("Slippage modeling accuracy below 80% - Recalibrate slippage model");
    }

    if (metrics.edgeHalfLife < metrics.totalTrades * 0.5) {
      recommendations.push("Edge half-life short - Monitor for edge degradation in live trading");
    }

    if (recommendations.length === 0) {
      recommendations.push("All validation checks passed - Ready for live trading");
    }

    return recommendations.map((r) => `  - ${r}`).join("\n");
  }
}

/**
 * Run paper trading validation
 */
export async function runPaperTradingValidation(
  validationPeriodDays: number = 14
): Promise<string> {
  const validator = new PaperTradingValidator(validationPeriodDays);
  return validator.generateReport();
}


/**
 * Unit tests for paper trading validator
 */
export const paperTradingValidatorTests = {
  testMetricsCalculation: () => {
    const validator = new PaperTradingValidator(7);
    validator["trades"] = [
      { pnl: 100, quantity: 1, entryPrice: 100, midPrice: 99.95, exitReason: "take_profit" },
      { pnl: -50, quantity: 1, entryPrice: 100, midPrice: 100.05, exitReason: "stop_loss" },
      { pnl: 150, quantity: 1, entryPrice: 100, midPrice: 99.90, exitReason: "take_profit" },
    ];

    const metrics = validator.calculateMetrics();
    return (
      metrics.totalTrades === 3 &&
      metrics.winningTrades === 2 &&
      metrics.losingTrades === 1 &&
      metrics.winRate === 2 / 3
    );
  },

  testExitLogicValidation: () => {
    const validator = new PaperTradingValidator(7);
    validator["trades"] = [
      { pnl: 100, quantity: 1, entryPrice: 100, midPrice: 99.95, exitReason: "take_profit" },
      { pnl: -50, quantity: 1, entryPrice: 100, midPrice: 100.05, exitReason: "stop_loss" },
    ];

    const metrics = validator.calculateMetrics();
    return metrics.exitLogicValidated === true;
  },

  testDrawdownCalculation: () => {
    const validator = new PaperTradingValidator(7);
    validator["trades"] = [
      { pnl: 100, quantity: 1, entryPrice: 100, midPrice: 99.95, exitReason: "take_profit" },
      { pnl: -200, quantity: 1, entryPrice: 100, midPrice: 100.05, exitReason: "stop_loss" },
      { pnl: 150, quantity: 1, entryPrice: 100, midPrice: 99.90, exitReason: "take_profit" },
    ];

    const metrics = validator.calculateMetrics();
    return metrics.maxDrawdown >= 0;
  },
};
