/**
 * Options generation: intent direction must match structure direction (no bearish for bullish intent).
 */
import { describe, it, expect } from "vitest";
import { generateTradeOptionsWithIntent } from "./catalyst-options-generation";
import type { MarketOpportunity } from "./market-scanner";
import type { IntentDecision } from "./intent-governance";

function minimalOpportunity(overrides: Partial<MarketOpportunity> = {}): MarketOpportunity {
  return {
    symbol: "U",
    currentPrice: 100,
    priceChange: 1,
    priceChangePercent: 1,
    volume: 1e6,
    avgVolume: 1e6,
    high52Week: 120,
    low52Week: 80,
    regime: "bull_vol_compression",
    signal: { class: "A", confidence: 0.95, direction: "bullish" },
    opportunity: { score: 85, expectedReturn: 5, riskReward: 2, winProbability: 0.7 },
    structure: { type: "vertical_put_spread", direction: "bearish", expectedValue: 1, cvar: -0.5 },
    timestamp: Date.now(),
    dataSource: "ibkr",
    ...overrides,
  };
}

function bullishIntent(): IntentDecision {
  return {
    direction: "BULLISH",
    volatilityBias: "SELL",
    allowedClasses: ["DIRECTIONAL_DEFINED_RISK", "NEUTRAL_RANGE", "STOCK_ANCHORED"],
    forbiddenClasses: [],
    confidence: 0.8,
    rationale: "Bullish thesis.",
  };
}

function bearishIntent(): IntentDecision {
  return {
    direction: "BEARISH",
    volatilityBias: "SELL",
    allowedClasses: ["DIRECTIONAL_DEFINED_RISK", "NEUTRAL_RANGE"],
    forbiddenClasses: [],
    confidence: 0.7,
    rationale: "Bearish thesis.",
  };
}

describe("catalyst-options-generation: direction filter", () => {
  it("BULLISH intent never returns vertical put spread (bearish structure)", async () => {
    const opp = minimalOpportunity();
    const intent = bullishIntent();
    const options = await generateTradeOptionsWithIntent(opp, intent);
    expect(options.length).toBeGreaterThan(0);
    for (const opt of options) {
      expect(opt.structureType).not.toBe("vertical_put_spread");
      expect(opt.direction).toBe("bullish");
    }
  });

  it("BEARISH intent never returns vertical call spread (bullish structure)", async () => {
    const opp = minimalOpportunity({ regime: "bear_vol_compression", signal: { class: "A", confidence: 0.9, direction: "bearish" } });
    const intent = bearishIntent();
    const options = await generateTradeOptionsWithIntent(opp, intent);
    expect(options.length).toBeGreaterThan(0);
    for (const opt of options) {
      expect(opt.structureType).not.toBe("vertical_call_spread");
      expect(opt.direction).toBe("bearish");
    }
  });

  it("option direction comes from intent, not scanner structure", async () => {
    const opp = minimalOpportunity();
    expect(opp.structure?.type).toBe("vertical_put_spread");
    expect(opp.structure?.direction).toBe("bearish");
    const intent = bullishIntent();
    const options = await generateTradeOptionsWithIntent(opp, intent);
    expect(options.every((o) => o.direction === "bullish")).toBe(true);
    expect(options.some((o) => o.structureType === "vertical_call_spread" || o.structureType === "iron_condor")).toBe(true);
  });
});
