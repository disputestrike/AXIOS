import { describe, it, expect } from "vitest";

const hasIBKRCredentials =
  process.env.IBKR_USERNAME != null &&
  process.env.IBKR_PASSWORD != null &&
  process.env.IBKR_ACCOUNT_ID != null &&
  process.env.IBKR_PAPER_MODE != null;

describe("IBKR Credentials Validation", () => {
  it("should have valid IBKR environment variables configured when set", () => {
    if (!hasIBKRCredentials) {
      return; // skip assertion when env not set (e.g. CI, fresh clone)
    }
    expect(process.env.IBKR_USERNAME).toBeTruthy();
    expect(process.env.IBKR_PASSWORD).toBeTruthy();
    expect(process.env.IBKR_ACCOUNT_ID).toMatch(/^(DU|U)\d+$/);
    expect(process.env.IBKR_PAPER_MODE).toMatch(/^(true|false)$/);
  });

  it("should have all required IBKR credentials when configured", () => {
    if (!hasIBKRCredentials) {
      return;
    }
    const username = process.env.IBKR_USERNAME;
    const password = process.env.IBKR_PASSWORD;
    const accountId = process.env.IBKR_ACCOUNT_ID;
    const paperMode = process.env.IBKR_PAPER_MODE;

    expect(username).toBeDefined();
    expect(password).toBeDefined();
    expect(accountId).toBeDefined();
    expect(paperMode).toBeDefined();
    expect(username).toMatch(/^[a-zA-Z0-9]+$/);
    expect(accountId).toMatch(/^(DU|U)\d+$/);
    expect(paperMode).toMatch(/^(true|false)$/);
  });

  it("should be in paper trading mode when IBKR is configured", () => {
    if (!hasIBKRCredentials) {
      return;
    }
    expect(["true", "false"]).toContain(process.env.IBKR_PAPER_MODE);
  });
});
