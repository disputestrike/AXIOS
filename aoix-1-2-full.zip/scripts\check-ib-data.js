#!/usr/bin/env node
/**
 * IB Data Diagnostic – troubleshoot when no market data is returned.
 * Usage: node scripts/check-ib-data.js
 *
 * Prerequisites:
 * 1. Client Portal Gateway running (bin\run.bat root\conf.yaml)
 * 2. Logged in at http://localhost:5000
 * 3. IB_GATEWAY_COOKIE=api=YOUR_VALUE in .env.local
 */
import { config } from "dotenv";
import { existsSync } from "fs";
import { dirname, join, resolve } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(__dirname, "..");
const envLocalPath = join(projectRoot, ".env.local");

const log = (msg, color = "") => {
  const c = color === "green" ? "\x1b[32m" : color === "red" ? "\x1b[31m" : color === "yellow" ? "\x1b[33m" : "";
  const reset = c ? "\x1b[0m" : "";
  console.log(c + msg + reset);
};

log("\n=== IBKR Data Diagnostic ===\n", "yellow");

if (!existsSync(envLocalPath)) {
  log("ERROR: .env.local not found. Create it and add:", "red");
  log("  TWS_PORT=5000");
  log("  IB_GATEWAY_COOKIE=api=YOUR_VALUE  (from browser after login at http://localhost:5000)\n");
  process.exit(1);
}

config({ path: envLocalPath, override: true });

const port = (process.env.TWS_PORT || "5000").trim();
const host = (process.env.TWS_HOST || "localhost").trim();
const cookie = process.env.IB_GATEWAY_COOKIE?.trim();
const base = `http://${host}:${port}/v1/api`;

log(`Gateway: ${base}`);
log(`Cookie set: ${cookie ? "yes" : "NO (required for data)"}\n`);

const headers = {
  "User-Agent": "AOIX-1-check/1.0",
  Accept: "application/json",
  "Content-Type": "application/json",
};
if (cookie) headers["Cookie"] = cookie;

async function step(name, fn) {
  process.stdout.write(`[ ] ${name}... `);
  try {
    const result = await fn();
    log("OK", "green");
    return result;
  } catch (err) {
    log("FAIL", "red");
    console.log("     ", err.message || err);
    return null;
  }
}

async function main() {
  // 1. Check session
  const accountsOk = await step("Session (/iserver/accounts)", async () => {
    const res = await fetch(`${base}/iserver/accounts`, { headers, redirect: "manual" });
    if (res.status === 401 || res.status === 302) throw new Error("401 – Need to log in at http://localhost:5000 and set IB_GATEWAY_COOKIE");
    if (res.status === 400) throw new Error("400 – Session not ready. Wait for Client Portal to load, then set cookie.");
    if (res.status === 429) throw new Error("429 – Rate limit. Wait 2 minutes.");
    if (res.status !== 200) throw new Error(`HTTP ${res.status}`);
    return true;
  });

  if (!accountsOk) {
    log("\n>>> FIX: Ensure Gateway is running, you're logged in at http://localhost:5000, and IB_GATEWAY_COOKIE is set in .env.local\n", "yellow");
    process.exit(1);
  }

  // 2. Contract lookup – /trsrv/stocks (returns { "SPY": [{ conid, name, ... }] })
  let conid = await step("Contract lookup (/trsrv/stocks for SPY)", async () => {
    const res = await fetch(`${base}/trsrv/stocks?symbols=SPY`, { headers });
    if (res.status !== 200) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const arr = data?.SPY ?? (Array.isArray(data) ? data : null);
    const c = Array.isArray(arr) && arr[0]?.conid ? arr[0].conid : data?.conid ?? data?.contracts?.[0]?.conid;
    if (c) return c;
    throw new Error("No conid in response: " + JSON.stringify(data).slice(0, 120));
  });

  // 3. Fallback contract lookup – secdef/search
  if (!conid) {
    conid = await step("Contract lookup fallback (/iserver/secdef/search)", async () => {
      const res = await fetch(`${base}/iserver/secdef/search?symbol=SPY&sectype=STK`, {
        method: "POST",
        headers,
        body: JSON.stringify({ symbol: "SPY", name: false }),
      });
      if (res.status !== 200) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const c = Array.isArray(data) && data[0]?.conid ? data[0].conid : data?.conid;
      if (c) return c;
      throw new Error("No conid in response");
    });
  }

  if (!conid) {
    log("\n>>> FIX: Contract lookup failing. Ensure Gateway is logged in and market data subscriptions are active.\n", "yellow");
    process.exit(1);
  }

  log(`     conid for SPY: ${conid}`);

  // 4. Market data snapshot (use /iserver/marketdata/snapshot?conids=)
  await step("Market data snapshot (SPY)", async () => {
    const res = await fetch(`${base}/iserver/marketdata/snapshot?conids=${conid}&fields=31,84,86,87`, { headers });
    if (res.status !== 200) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    const raw = Array.isArray(data) ? data[0] : data;
    const last = raw?.["31"];
    const bid = raw?.["84"];
    const ask = raw?.["86"];
    if (last != null && Number(last) > 0) {
      log(`     SPY last=${last} bid=${bid} ask=${ask}`);
      return true;
    }
    if (raw && Object.keys(raw).length > 0) {
      log(`     Snapshot keys: ${Object.keys(raw).join(", ")} (no price yet – may need pre-flight + retry)`);
      return true;
    }
    throw new Error("Empty snapshot – market may be closed or subscription needed");
  });

  log("\n>>> If app still shows 0 opportunities: check server logs for [IB] or [MarketScanner] messages.\n", "green");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
