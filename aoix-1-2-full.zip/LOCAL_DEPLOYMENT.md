# AOIX-1 Local Deployment Guide

## Overview

AOIX-1 is a fully autonomous trading system that connects to Interactive Brokers via TWS API. This guide explains how to run AOIX-1 locally on your machine where IB Gateway is already running.

## Prerequisites

- **Node.js 22+** - Download from https://nodejs.org/
- **pnpm** - Install with `npm install -g pnpm`
- **IB Gateway** - Already running on localhost:4001 with API enabled
- **Database** - MySQL/TiDB connection string (provided in .env)

## Quick Start

### 1. Extract and Install

```bash
# Extract the downloaded AOIX-1 code
cd aoix-1

# Install dependencies
pnpm install
```

### 2. Configure Environment

Create a `.env.local` file in the project root with:

```env
# Database (provided by Manus)
DATABASE_URL=your_database_connection_string

# JWT Secret
JWT_SECRET=your_jwt_secret_key

# OAuth (provided by Manus)
VITE_APP_ID=your_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://oauth.manus.im

# Owner info
OWNER_NAME=Your Name
OWNER_OPEN_ID=your_open_id

# Built-in Forge API (provided by Manus)
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=your_api_key

# Frontend Forge API
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
VITE_FRONTEND_FORGE_API_KEY=your_frontend_key

# TWS Configuration
TWS_HOST=localhost
TWS_PORT=4001

# App Configuration
VITE_APP_TITLE=AOIX-1
VITE_APP_LOGO=/logo.png
```

### 3. Run Locally

```bash
# Development mode with hot reload
pnpm dev

# Production build
pnpm build
pnpm start
```

The application will be available at `http://localhost:5173` (frontend) and `http://localhost:3000` (API).

## How It Works

### Connection Flow

1. **IB Gateway Running** - You have IB Gateway running on localhost:4001 with API enabled
2. **AOIX-1 Starts** - Application connects to IB Gateway automatically
3. **Market Data Streams** - Real-time stock prices, options chains, Greeks
4. **Signals Generated** - System analyzes market data and generates trading signals
5. **Opportunities Identified** - Market scanner identifies profitable trades
6. **Automatic Execution** - Engine executes trades based on signals and risk rules

### Key Features

**Market Scanner**
- Scans 500+ stocks for trading opportunities
- Generates Class A/B/C/D signals based on dealer gamma, flow, momentum
- Ranks opportunities by profit probability (0-100)
- Updates in real-time as market conditions change

**Autonomous Trading Engine**
- Executes trades automatically on Class A/B signals (≥60% confidence)
- Risk management: 1% max risk per trade, 3 max positions, 5% daily loss limit
- Automatic exits: +30% take profit, -20% stop loss, 10% trailing stop
- Kill switch: Stops trading if ruin probability exceeds 10%

**Live Monitoring**
- Auto Trading Dashboard shows engine status, P&L, positions
- System Health Dashboard monitors all components
- Recommendations page shows top opportunities
- Trade history tracks all executed trades

## Dashboard Navigation

### Auto Trading Page
- **Engine Status** - Running/stopped, current regime, active positions
- **TWS Connection** - Shows connection status to IB Gateway
- **Connect/Disconnect** - Manual control of TWS connection
- **Performance** - Win rate, Sharpe ratio, profit factor, max drawdown
- **Positions** - Open positions with P&L
- **Recent Trades** - Last 10 executed trades

### Market Opportunities Page
- **Scan Market** - Triggers market scanner to find opportunities
- **Top 20 Opportunities** - Ranked by profit probability
- **Signal Details** - Class, confidence, direction, regime
- **Structure Details** - Recommended options structure with Greeks
- **Auto-Trade Button** - Execute recommended trade immediately

### System Health Page
- **Component Status** - Health of all system components
- **Response Times** - API latency and performance metrics
- **Error Tracking** - Recent errors and warnings
- **Rate Limiting** - API usage and rate limit status

## Trading Workflow

### Step 1: Verify Connections
1. Open AOIX-1 in browser at http://localhost:5173
2. Go to Auto Trading page
3. Check TWS Connection status - should show "Connected" with green indicator
4. Check Gateway Status - should show "Paper Trading Mode" or "Live Trading"

### Step 2: Monitor Opportunities
1. Go to Market Opportunities page
2. Click "Scan Market" button
3. Wait for scan to complete (30-60 seconds)
4. Review top 20 opportunities
5. Check signal confidence and expected return for each

### Step 3: Start Auto Trading
1. Go to Auto Trading page
2. Click "Start Engine" button
3. Watch as engine automatically executes trades on best opportunities
4. Monitor Performance tab for metrics
5. Check Positions tab for open trades

### Step 4: Risk Management
1. Engine automatically manages risk (1% max per trade, 3 max positions)
2. Kill switch activates if daily loss exceeds 5% or ruin probability > 10%
3. All exits automatic: +30% TP, -20% SL, 10% trailing stop
4. Monitor System Health page for any alerts

## Troubleshooting

### TWS Connection Failed
**Problem:** Dashboard shows "TWS Disconnected"

**Solution:**
1. Verify IB Gateway is running
2. Check API settings: Configuration → API → Settings
3. Verify Socket Port is 4001
4. Verify "Enable ActiveX and Socket Clients" is checked
5. Verify "Allow connections from localhost only" is checked
6. Click "Connect" button in AOIX-1 dashboard

### No Market Data
**Problem:** Market scanner shows no opportunities

**Solution:**
1. Verify TWS connection is active
2. Check that market is open (US market hours: 9:30 AM - 4:00 PM ET)
3. Try clicking "Scan Market" again
4. Check System Health page for errors

### Database Connection Error
**Problem:** Application won't start with database error

**Solution:**
1. Verify DATABASE_URL in .env.local is correct
2. Test connection: `mysql -u user -p -h host database_name`
3. Ensure database is accessible from your machine
4. Check firewall settings if using remote database

### Port Already in Use
**Problem:** Error "Port 3000 already in use"

**Solution:**
```bash
# Find process using port 3000
lsof -i :3000

# Kill the process
kill -9 <PID>

# Or use different port
PORT=3001 pnpm dev
```

## Performance Tips

1. **Market Scanner** - Runs every 5 minutes by default. Adjust frequency in settings.
2. **Position Monitoring** - Checks every 30 seconds. Increase for lower latency requirements.
3. **Database** - Use local MySQL for best performance. Remote databases add latency.
4. **Browser** - Use Chrome/Edge for best performance. Firefox also supported.

## Security Notes

1. **Never share .env.local** - Contains sensitive credentials
2. **Use paper trading first** - Test thoroughly before enabling live trading
3. **Keep IB Gateway secure** - Only allow localhost connections
4. **Monitor regularly** - Check System Health page for anomalies
5. **Backup settings** - Save your configuration regularly

## Next Steps

1. ✅ Extract and install AOIX-1
2. ✅ Configure .env.local with your credentials
3. ✅ Verify IB Gateway is running and configured
4. ✅ Start AOIX-1 with `pnpm dev`
5. ✅ Verify TWS connection in dashboard
6. ✅ Run market scanner to identify opportunities
7. ✅ Start auto trading engine
8. ✅ Monitor performance and adjust risk settings as needed

## Support

For issues or questions:
1. Check System Health page for component status
2. Review logs in `.manus-logs/` directory
3. Verify all prerequisites are installed
4. Ensure IB Gateway is properly configured

Good luck with your autonomous trading! 🚀
