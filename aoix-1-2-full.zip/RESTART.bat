@echo off
title AOIX-1 Restart
cd /d "%~dp0"

echo.
echo ========================================
echo   AOIX-1 - Restart app
echo ========================================
echo.
echo 1. If the app is already running, close that window (or press Ctrl+C there).
echo 2. Press any key here to start the app.
echo.
pause >nul

echo.
echo Starting...
echo.
pnpm dev

pause
