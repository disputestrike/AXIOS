# Regime and Strategy Coverage Diagnostic

**Generated:** 2026-02-01T03:18:38.218Z
**Top N:** 100 | **Total opportunities:** 0

---

## 1. By Regime

### crisis (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### liquidity_drought (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### trending_bull (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### trending_bear (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### bull_vol_expansion (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### bear_vol_expansion (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### bull_vol_compression (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### bear_vol_compression (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### mean_reverting (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### chaotic (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### sector_rotation (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

## 2. By Strategy (structure type)

### iron_condor (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### iron_butterfly (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### vertical_call_spread (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### vertical_put_spread (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### calendar_spread (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### diagonal_spread (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### straddle (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### strangle (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### butterfly (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### cash_secured_put (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

### covered_call (0)
- **Reason if 0:** No opportunities in current scan (run a scan first or check market data).

## 3. Summary Table (Regime × Strategy)

| Regime | Strategy | # Opportunities | Highest Score | Avg Win Prob | Reason if 0 |
|--------|----------|------------------|---------------|--------------|-------------|
| crisis | iron_condor | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| crisis | iron_butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| crisis | vertical_call_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| crisis | vertical_put_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| crisis | calendar_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| crisis | diagonal_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| crisis | straddle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| crisis | strangle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| crisis | butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| crisis | cash_secured_put | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| crisis | covered_call | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| liquidity_drought | iron_condor | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| liquidity_drought | iron_butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| liquidity_drought | vertical_call_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| liquidity_drought | vertical_put_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| liquidity_drought | calendar_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| liquidity_drought | diagonal_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| liquidity_drought | straddle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| liquidity_drought | strangle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| liquidity_drought | butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| liquidity_drought | cash_secured_put | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| liquidity_drought | covered_call | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bull | iron_condor | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bull | iron_butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bull | vertical_call_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bull | vertical_put_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bull | calendar_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bull | diagonal_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bull | straddle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bull | strangle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bull | butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bull | cash_secured_put | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bull | covered_call | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bear | iron_condor | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bear | iron_butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bear | vertical_call_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bear | vertical_put_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bear | calendar_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bear | diagonal_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bear | straddle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bear | strangle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bear | butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bear | cash_secured_put | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| trending_bear | covered_call | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_expansion | iron_condor | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_expansion | iron_butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_expansion | vertical_call_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_expansion | vertical_put_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_expansion | calendar_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_expansion | diagonal_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_expansion | straddle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_expansion | strangle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_expansion | butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_expansion | cash_secured_put | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_expansion | covered_call | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_expansion | iron_condor | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_expansion | iron_butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_expansion | vertical_call_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_expansion | vertical_put_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_expansion | calendar_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_expansion | diagonal_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_expansion | straddle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_expansion | strangle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_expansion | butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_expansion | cash_secured_put | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_expansion | covered_call | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_compression | iron_condor | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_compression | iron_butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_compression | vertical_call_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_compression | vertical_put_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_compression | calendar_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_compression | diagonal_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_compression | straddle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_compression | strangle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_compression | butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_compression | cash_secured_put | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bull_vol_compression | covered_call | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_compression | iron_condor | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_compression | iron_butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_compression | vertical_call_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_compression | vertical_put_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_compression | calendar_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_compression | diagonal_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_compression | straddle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_compression | strangle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_compression | butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_compression | cash_secured_put | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| bear_vol_compression | covered_call | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| mean_reverting | iron_condor | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| mean_reverting | iron_butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| mean_reverting | vertical_call_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| mean_reverting | vertical_put_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| mean_reverting | calendar_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| mean_reverting | diagonal_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| mean_reverting | straddle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| mean_reverting | strangle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| mean_reverting | butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| mean_reverting | cash_secured_put | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| mean_reverting | covered_call | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| chaotic | iron_condor | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| chaotic | iron_butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| chaotic | vertical_call_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| chaotic | vertical_put_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| chaotic | calendar_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| chaotic | diagonal_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| chaotic | straddle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| chaotic | strangle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| chaotic | butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| chaotic | cash_secured_put | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| chaotic | covered_call | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| sector_rotation | iron_condor | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| sector_rotation | iron_butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| sector_rotation | vertical_call_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| sector_rotation | vertical_put_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| sector_rotation | calendar_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| sector_rotation | diagonal_spread | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| sector_rotation | straddle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| sector_rotation | strangle | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| sector_rotation | butterfly | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| sector_rotation | cash_secured_put | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |
| sector_rotation | covered_call | 0 | 0 | 0 | No opportunities in current scan (run a scan first or check market data). |

## 4. Filter Notes

- **Scanner filters:** getTopOpportunities(count, filters) supports: minScore, minWinProbability, structureType, regime, symbolSearch. No filters applied for this diagnostic.
- **Min win probability by engine strategy:** {"wheel":70,"short_term":60,"iron_condor":65,"adaptive":60}

**Possible reasons for zero opportunities:**

- No scan run yet — run market scan first.
- Min score / min win probability filters (see STRATEGY_CONFIGS) may exclude opportunities.
- IV percentile or liquidity thresholds in scoring may drop symbols.
- Market conditions: current regime/vol may not produce certain structure types.
- Symbol universe: only symbols in scanner list are considered.