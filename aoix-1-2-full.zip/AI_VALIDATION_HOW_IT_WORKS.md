# AI Validation ⭐⭐⭐⭐⭐ — Where It Is & How It Works

**Claude reasoning on every trade**  
Checks: *"Is this mispricing real?"*  
Outputs: **APPROVED** / **REJECTED** / **MODIFY**  
Prevents stupid trades automatically.

---

## WHERE TO SEE IT ON THE WEBSITE

1. **Open the app** — e.g. `http://localhost:3001/` (or the port your dev server uses).
2. **In the left sidebar**, click **"Today's Opportunity"** (Crown icon).
3. **Wait for opportunities to load** — if the list is empty, click **"Refresh"** or go to **Market Opportunities** and click **"Scan Market"**, then come back to Today's Opportunity.
4. **On each opportunity card** (e.g. "Top pick: GOOGL", "#2: AAPL"), you’ll see **three tier boxes**: **Conservative**, **Balanced**, **Aggressive**.
5. **In each tier box** there are two buttons:
   - **"Validate with Claude"** (outline, with shield icon) — this is the AI validation.
   - **"Trade now"** (green).

So: **Today's Opportunity** → any card → **Conservative / Balanced / Aggressive** → **"Validate with Claude"** in each tier.

**If you don’t see "Validate with Claude":** The button is always visible now; if it’s **disabled** (greyed out), add **`ANTHROPIC_API_KEY`** to your **`.env.local`** file and restart the server. Then the button becomes clickable.

---

## WHERE IS IT (CODE)?

| Where | Path / Location |
|-------|------------------|
| **Backend logic** | `server/trade-validation-claude.ts` — `validateTradeWithClaude(trade, context)` |
| **Claude API client** | `server/_core/claude.ts` — `invokeClaude()`, `getClaudeText()`, `isClaudeConfigured()` |
| **API endpoint** | `server/routers/opportunity.ts` — **`opportunity.validateTrade`** (tRPC mutation) |
| **UI** | **Today's Opportunity** page (`client/src/pages/TodayOpportunity.tsx`) — **"Validate with Claude"** button on **each tier** (Conservative / Balanced / Aggressive) |
| **Config** | `ANTHROPIC_API_KEY` in **`.env.local`** — if missing, the button is disabled and validation is skipped |

So: **backend** = `trade-validation-claude.ts` + `claude.ts` + `opportunity` router; **UI** = Today's Opportunity → each tier card → **Validate with Claude** button.

---

## HOW DOES IT WORK? (Step by Step)

### 1. You click **"Validate with Claude"** on a tier

- The UI sends the **full trade option** for that tier to the server: symbol, tier (conservative/balanced/aggressive), structure type, direction, **implied move %**, **historical move %**, **move comparison** (e.g. `implied_above_historical`), catalyst summary, win probability, expected return, regime, etc.

### 2. Server builds the **prompt** for Claude

- **System prompt** (fixed):  
  *"You are a risk-aware options trade validator. Review the trade and respond with APPROVE, REJECT, or MODIFY. Consider: regime appropriateness, implied vs historical move alignment, catalyst quality, tier vs risk. Be concise."*

- **User prompt** (per trade) includes:
  - Symbol, tier, structure (e.g. vertical_put_spread, bearish)
  - **Implied move %** vs **Historical proxy %** and **Comparison** (e.g. implied_above_historical) ← **this is the "Is this mispricing real?" input**
  - Win probability (scan), expected return
  - Regime (e.g. crisis, trending_bull)
  - Catalysts summary
  - Optional: context regime, recent P/L

So Claude **explicitly sees** whether the trade is based on implied move above/below historical and can reject if the “mispricing” doesn’t look real.

### 3. Server calls **Claude API**

- `invokeClaude()` in `server/_core/claude.ts`:
  - POST to `https://api.anthropic.com/v1/messages`
  - Uses `ANTHROPIC_API_KEY` from `.env.local`
  - Model: **claude-sonnet-4-20250514** (default)
  - Sends system + user message; max_tokens 1024 for validation

### 4. Claude returns **plain text**

- Claude is instructed to use this format:
  ```
  VERDICT: [APPROVE | REJECT | MODIFY]
  REASON: [One to three sentences.]
  SUGGESTED_CHANGES: [If MODIFY, specific changes.]
  ```

### 5. Server **parses** the response

- `parseValidationResponse()` in `trade-validation-claude.ts`:
  - Finds **VERDICT:** → APPROVE / REJECT / MODIFY
  - Finds **REASON:** → explanation text
  - If MODIFY, finds **SUGGESTED_CHANGES:** → what to change
  - Returns: `{ verdict, reason, suggestedChanges? }`

### 6. UI shows the result and **prevents stupid trades** in practice

- **APPROVE** → Green toast: "Claude: Approved — [reason]". You can proceed to Trade now with confidence.
- **REJECT** → Red toast: "Claude: Rejected — [reason]". You are **discouraged from trading** that idea; the system has flagged it as a bad idea.
- **MODIFY** → Amber toast: "Claude: Modify — [suggested changes]". You can adjust (e.g. longer DTE, conservative tier) before trading.

So: **stupid trades are prevented** by **surfacing REJECT/MODIFY before you place the order**. The system does not auto-block the order (you can still click Trade now), but the validation is **in front of every tier** so you see Claude’s reasoning and choose whether to proceed. If you want **hard** block on REJECT, that would be an extra step (e.g. disable "Trade now" when last validation was REJECT for that tier).

---

## What Claude Actually Checks ("Is this mispricing real?")

The prompt tells Claude to consider:

1. **Regime appropriateness** — Does this structure/direction fit the current regime (e.g. crisis, trending_bull)?
2. **Implied vs historical move alignment** — You pass **implied move %**, **historical proxy %**, and **comparison** (e.g. `implied_above_historical`). So Claude can reject if the “mispricing” (e.g. implied move way above historical) looks unjustified or overdone.
3. **Catalyst quality** — Are the catalysts (flow, sentiment, earnings, etc.) strong enough to support the trade?
4. **Tier vs risk** — Is conservative/balanced/aggressive the right choice for this setup?

So the **"Is this mispricing real?"** check is implemented by giving Claude **implied vs historical move** and **catalyst summary** and asking it to approve/reject/modify. It’s the core of the AI validation.

---

## Flow Diagram (How It Works)

```
[Today's Opportunity]
       │
       ▼
[Click "Validate with Claude" on a tier]
       │
       ▼
[UI] opportunity.validateTrade.mutate({ tier, symbol, structureType, impliedMovePercent, historicalMovePercent, moveComparison, catalystSummary, ... })
       │
       ▼
[Server] opportunity router → validateTradeWithClaude(trade, context)
       │
       ▼
[Server] buildValidationPrompt(trade) → system + user message
       │
       ▼
[Server] invokeClaude({ system, messages }) → Anthropic API
       │
       ▼
[Claude] Reasons about: regime, implied vs historical, catalysts, tier vs risk
       │
       ▼
[Claude] Returns text: VERDICT: APPROVE|REJECT|MODIFY, REASON: ..., SUGGESTED_CHANGES: ...
       │
       ▼
[Server] parseValidationResponse(text) → { verdict, reason, suggestedChanges }
       │
       ▼
[UI] Toast + "Last validation" card: verdict + reason (+ suggested changes if MODIFY)
       │
       ▼
[You] See APPROVE → proceed to Trade now; REJECT → avoid; MODIFY → adjust then trade
```

---

## Summary

| Question | Answer |
|----------|--------|
| **Where is the AI validation?** | Backend: `server/trade-validation-claude.ts` + `server/_core/claude.ts`. API: `opportunity.validateTrade`. UI: **Today's Opportunity** → **Validate with Claude** on each tier. |
| **How does it work?** | You click Validate → server sends trade (incl. implied vs historical move, catalysts, regime) to Claude → Claude returns APPROVE/REJECT/MODIFY + reason (+ suggested changes) → server parses → UI shows toast and last validation. |
| **How does it check "Is this mispricing real?"** | By passing **implied move %**, **historical move %**, and **move comparison** (and catalysts, regime) into the prompt; Claude is instructed to consider implied vs historical alignment and can REJECT or MODIFY if the mispricing doesn’t look real. |
| **How does it prevent stupid trades?** | By **surfacing** REJECT/MODIFY before you place the order, so you see Claude’s reasoning and can skip or adjust. Optionally you could add a hard block (e.g. disable Trade now when last verdict was REJECT for that tier). |

**Config:** Set `ANTHROPIC_API_KEY` in `.env.local` to enable. If not set, validation is skipped and returns approve with "Claude not configured."
