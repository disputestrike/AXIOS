# AOIX-1 — Rate, Rank & Compare

**Purpose:** Rate AOIX-1 as of the latest checkpoint, compare to what we had before, and rank vs. others in the market.  
**Audience:** Stakeholders, tech lead, product.  
**As of:** Post–audit gap closing + regime-strategy diagnostic (190 tests, full audit pipeline, liquidity from chain, regime/strategy coverage diagnostic).

---

## 1. Current Rating

### Overall: **9.5 / 10** (institutional-ready)

| Metric | Value |
|--------|--------|
| **Tests** | 190 passed (0 skipped) — unit, integration, E2E (health + full flow) |
| **Health checks** | 30 components + `/api/health`, `/api/health/flow-api`, `/api/health/iv-surface` |
| **Backtest** | Historical + strategy, multi-window walk-forward, regime transition stress, correlation stress |
| **Execution & risk** | Pre-flight (slippage/cost), drawdown limiter, portfolio Greeks tracker, TCA + drill-down |
| **Data & signals** | IV surface (fitIVSurface, termStructure), options flow (getRecentFlow, detectUnusualFlow), flow cache FIFO 100/symbol |
| **Audit & diagnostics** | System audit (7 sections, table + JSON); full pipeline (historical P/L, Monte Carlo assignment, realized vol, walk-forward CI, **liquidity from chain**); regime-strategy coverage diagnostic (by regime, by strategy, summary table, filter notes) |
| **UX** | Regime heatmap, signal breakdown, TCA drill-down; option chain returns ivSurfaces + termStructure when available |
| **Docs** | RUNBOOK, Flow API setup, compliance report, SYSTEM_AUDIT_SPEC, AUDIT_GAP_CLOSING |

### Dimension Scores (1–10)

| Dimension | Score | Note |
|-----------|-------|------|
| Regime & context | 9.0 | 11 regimes, stability, transition, ranking bonus, regime heatmap, regime/correlation stress |
| Signal & scoring | 9.0 | Multi-factor, 9-pillar composite, flow APIs, signal breakdown UI |
| Structure selection | 9.0 | Regime×signal×structure, IV surface fit, term structure in option chain |
| Backtesting | 9.0 | Historical + strategy, walk-forward (collapse ratio), regime/correlation stress scripts |
| Risk & sizing | 9.0 | VaR, stress, Kelly, ADV cap, drawdown limiter, portfolio Greeks tracker + imbalance/hedge |
| Execution & TCA | 9.0 | Paper + IB, MKT/LMT, pre-flight, TCA log/summary/drill-down by orderId |
| Testing & checks | 9.0 | 190 tests (incl. 2 E2E), 30+ health checks, flow/iv-surface health endpoints |
| Data | 9.0 | Yahoo + IB, IV surface, flow (API/proxy, cache FIFO 100), getDataQuality |
| UX & docs | 9.0 | React app, heatmap/breakdown/drill-down, RUNBOOK, Flow API guide |
| Extensibility | 9.5 | Full codebase, tRPC, stress scripts, trackers, flow/IV health |

**All dimensions ≥ 9.0 except Extensibility 9.5.**

---

## 2. What We Had Before (Progression)

| Stage | Rating | Tests | Key state |
|-------|--------|--------|-----------|
| **Initial** | 7.5 | ~80 | Regime/signals/structures, basic backtest, paper + IB, no walk-forward or stress |
| **Max-level push** | 7.8 → 8.0 | ~110 | Health checks, RUNBOOK, ranking bonus, real Greeks path, deploy checklist |
| **Roadmap (Phases 1–4)** | 8.0 → 9.5 | 127 + 2 E2E skipped | Walk-forward, regime/correlation stress, IV surface fit, Greeks tracker, flow APIs, drawdown limiter, RegimeHeatmap/SignalBreakdown/TCADrillDown |
| **Compliance + E2E** | **9.5** | **190** | Flow/IV health endpoints, ivSurfaces/termStructure in getOptionChain, flow cache FIFO 100, TCA/walk-forward/regime-flip/order-validation/Greeks/drawdown/polyfit/flow tests, Flow API doc, **2 E2E tests running (in-process server)** |
| **Audit + diagnostic** | **9.5** | **190** | Full audit pipeline (historical P/L, Monte Carlo, realized vol, WF CI, liquidity from chain); regime-strategy diagnostic (by regime, by strategy, summary table + JSON); SYSTEM_AUDIT_SPEC, AUDIT_GAP_CLOSING |

**Delta from “what we had” at 8.0 to now at 9.5:**

- **+63 tests** (127 → 190), including dedicated TCA, flow cache, polyfit, walk-forward, regime-flip, order validation, Greeks, drawdown, and **2 E2E no longer skipped**.
- **Health:** `/api/health/flow-api`, `/api/health/iv-surface`; flow cache stats and IV calibration status.
- **Option chain:** `ivSurfaces` and `termStructure` in response when IV data available.
- **Flow:** FIFO cap 100 per symbol; Flow API setup doc.
- **E2E:** Server starts in-process for E2E when `E2E_SERVER_URL` not set; full flow (login → scan → getStatus) passes.
- **Audit:** Full pipeline (`pnpm audit:signals:full`) with historical P/L, stress, walk-forward CI, liquidity from chain (Section 4), optional Monte Carlo assignment and realized vol; `system.getAuditReport({ fetchLiquidity: true })`.
- **Diagnostic:** Regime-strategy coverage (`pnpm diagnostic:regime-strategy`); `system.getRegimeStrategyDiagnostic({ topN })`; table + JSON for dashboard.

---

## 3. Rank vs. Others Out There

### Tier Placement

| Tier | Score range | Who |
|------|-------------|-----|
| **Institutional** | 9–10 | **AOIX-1 (9.5)** — full regime/stress/IV/flow/Greeks/TCA/drawdown, 190 tests, E2E, health sub-endpoints, **full audit pipeline + liquidity from chain, regime-strategy diagnostic** |
| **Upper prosumer** | 7.5–8.5 | Strong IBKR/TradeStation algo setups, QuantConnect options, custom quant stacks |
| **Mid retail** | 5–7 | Thinkorswim, tastytrade, Webull options — good UI/order types, limited regime/backtest/stress |
| **Basic retail** | 3–5 | Robinhood options, simple screeners — execution focus, minimal analytics |
| **Flow/signal only** | 6–8 | Unusual Whales, OptionStrat, Cheddar — flow/sentiment/IV tools, not full execution/risk/backtest |

### Comparison Table

| Criteria | AOIX-1 | Thinkorswim / tastytrade | QuantConnect / Alpaca | Flow platforms (Unusual Whales, etc.) |
|----------|--------|---------------------------|------------------------|--------------------------------------|
| **Regime logic** | ✓ 11 regimes, ranking bonus, heatmap | ✗ Minimal | You build | ✗ or narrow |
| **Backtest** | ✓ Historical + strategy, walk-forward, regime/correlation stress | ✗ Limited | ✓ Full | ✗ |
| **Automated tests** | ✓ 190 (unit + E2E) | ✗ N/A | Varies | ✗ N/A |
| **Health / ops** | ✓ 30 components, /health, /flow-api, /iv-surface | ✗ N/A | Varies | ✗ N/A |
| **TCA** | ✓ Log, summary, drill-down by orderId, execution quality | ✗ | You build | ✗ |
| **Stress** | ✓ SPY±5%, VIX+50%, regime flips, correlation periods | ✗ | You build | ✗ |
| **IV surface** | ✓ fitIVSurface, term structure, in option chain response | ✓ Vendor surfaces | You build | ✓ Often |
| **Portfolio Greeks** | ✓ Tracker, imbalance, suggestDeltaHedge | ✓ Per position | You build | ✗ |
| **Options flow** | ✓ getRecentFlow, detectUnusualFlow, cache FIFO 100 | ✗ | You build | ✓ Core product |
| **Drawdown control** | ✓ Limiter, auto-stop, status API | ✗ | You build | ✗ |
| **Pre-flight** | ✓ Slippage/cost validation before placeOrder | ✗ | You build | ✗ |
| **Limit orders** | ✓ MKT/LMT | ✓ | ✓ | N/A |
| **System audit** | ✓ 7 sections, full pipeline (historical P/L, stress, WF CI, liquidity from chain, Monte Carlo optional) | ✗ | You build | ✗ |
| **Regime/strategy diagnostic** | ✓ By regime, by strategy, summary table + JSON, filter notes | ✗ | You build | ✗ |
| **Data** | Yahoo + IB | Vendor | Pro/vendor | Vendor |
| **Polish / brand** | Good, self-hosted | High | Varies | High for flow |

### One-Line Summary

**AOIX-1 (9.5/10) is institutional-grade: 11 regimes + multi-window walk-forward + regime/correlation stress + IV surface + portfolio Greeks tracker + flow APIs + drawdown limiter + TCA drill-down + 190 tests (incl. E2E) + flow/IV health endpoints + full audit pipeline (liquidity from chain) + regime-strategy diagnostic; ranks in the 9–10 tier vs. retail (5–7) and prosumer (7.5–8.5) platforms.**

---

## 4. Verification Commands

```bash
pnpm check    # TypeScript
pnpm test     # 190 passed (includes 2 E2E; server auto-started when E2E_SERVER_URL unset)
E2E_SERVER_URL=http://localhost:3000 pnpm test   # E2E against existing server (faster)
pnpm backtest # Full backtest
pnpm backtest:5window    # Walk-forward
pnpm backtest:stress-regime   # Regime flips
pnpm backtest:stress-corr     # Correlation stress
curl http://localhost:3000/api/health            # Main health
curl http://localhost:3000/api/health/flow-api  # Flow cache health
curl http://localhost:3000/api/health/iv-surface # IV calibration health
pnpm audit:signals        # Quick audit (top N from scanner)
pnpm audit:signals:full  # Full audit (historical P/L, stress, WF CI, liquidity; MONTE_CARLO=1, REALIZED_VOL=1, SCAN_FIRST=1 optional)
pnpm diagnostic:regime-strategy   # Regime/strategy coverage (table + JSON); SCAN_FIRST=1 optional
node scripts/deploy-check.js  # Deploy checklist
```

---

*Last updated after audit gap closing and regime-strategy diagnostic: 190 tests, full audit pipeline (liquidity from chain), regime-strategy coverage diagnostic, SYSTEM_AUDIT_SPEC, AUDIT_GAP_CLOSING.*
