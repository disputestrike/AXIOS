/**
 * TCA drill-down by order ID — fill details, slippage, execution quality.
 * Uses omega0.getTCADrillDown(orderId). Requires auth.
 */

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Search, RefreshCw } from "lucide-react";

interface TCADrillDownProps {
  orderId: string;
}

export function TCADrillDown({ orderId }: TCADrillDownProps) {
  const { data, isLoading, refetch, isRefetching } = trpc.omega0.getTCADrillDown.useQuery(
    { orderId },
    { enabled: !!orderId?.trim() }
  );

  if (!orderId?.trim()) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="pt-6 py-8 text-center text-slate-400 text-sm">
          Enter an order ID to view TCA drill-down.
        </CardContent>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="pt-6 flex items-center justify-center py-8 text-slate-400">
          <RefreshCw className="h-5 w-5 animate-spin mr-2" />
          Loading TCA for order {orderId}…
        </CardContent>
      </Card>
    );
  }

  if (!data) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Search className="h-5 w-5" />
            TCA Drill-Down — Order #{orderId}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-400">No TCA entries found for this order ID. It may not have been logged yet.</p>
        </CardContent>
      </Card>
    );
  }

  const d = data as {
    orderId: string;
    symbol: string;
    entries: Array<{
      symbol: string;
      side: string;
      quantity: number;
      fillPrice: number;
      intendedPrice: number;
      slippagePerContract: number;
      slippagePercent: number;
      structureType?: string;
    }>;
    totalSlippageDollars: number;
    totalSlippagePercent: number;
    structureType?: string;
    executionQualityScore: number;
  };

  return (
    <Card className="bg-slate-800/50 border-slate-700">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Search className="h-5 w-5" />
              TCA Drill-Down — Order #{d.orderId}
            </CardTitle>
            <CardDescription>
              {d.symbol} · {d.structureType ?? "Single leg"} · Execution quality and cost breakdown.
            </CardDescription>
          </div>
          <button
            type="button"
            onClick={() => refetch()}
            disabled={isRefetching}
            className="text-slate-400 hover:text-white transition-colors p-1 rounded"
            aria-label="Refresh TCA"
          >
            <RefreshCw className={`h-4 w-4 ${isRefetching ? "animate-spin" : ""}`} />
          </button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3 bg-slate-900/50 rounded-lg">
            <div className="text-xs text-slate-400">Total slippage ($)</div>
            <div className="text-lg font-mono font-semibold text-red-400/90">
              ${(d.totalSlippageDollars ?? 0).toFixed(2)}
            </div>
          </div>
          <div className="p-3 bg-slate-900/50 rounded-lg">
            <div className="text-xs text-slate-400">Avg slippage %</div>
            <div
              className="text-lg font-mono font-semibold"
              style={{ color: (d.totalSlippagePercent ?? 0) > 1 ? "#ef4444" : "#22c55e" }}
            >
              {(d.totalSlippagePercent ?? 0).toFixed(2)}%
            </div>
          </div>
          <div className="p-3 bg-slate-900/50 rounded-lg">
            <div className="text-xs text-slate-400">Execution quality</div>
            <div
              className="text-lg font-bold"
              style={{ color: (d.executionQualityScore ?? 0) >= 90 ? "#22c55e" : (d.executionQualityScore ?? 0) >= 70 ? "#eab308" : "#ef4444" }}
            >
              {(d.executionQualityScore ?? 0).toFixed(0)}/100
            </div>
          </div>
          <div className="p-3 bg-slate-900/50 rounded-lg">
            <div className="text-xs text-slate-400">Legs</div>
            <div className="text-lg font-mono">{d.entries?.length ?? 0}</div>
          </div>
        </div>

        {Array.isArray(d.entries) && d.entries.length > 0 && (
          <div>
            <div className="text-sm font-semibold text-slate-300 mb-2">Per-leg details</div>
            <div className="space-y-2">
              {d.entries.map((e, i) => (
                <div key={i} className="p-3 rounded bg-slate-900/50 text-sm">
                  <div className="flex justify-between flex-wrap gap-2">
                    <span className="font-mono">{e.symbol} {e.side} {e.quantity}</span>
                    <span className="text-slate-400">Fill: ${e.fillPrice?.toFixed(2) ?? "—"}</span>
                  </div>
                  <div className="text-xs text-slate-400 mt-1">
                    Slippage: ${(e.slippagePerContract ?? 0).toFixed(2)}/contract ({(e.slippagePercent ?? 0).toFixed(2)}%)
                    {e.structureType && ` · ${e.structureType}`}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
