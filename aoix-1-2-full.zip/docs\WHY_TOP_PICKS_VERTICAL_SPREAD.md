# Strategy Selection: Trade the Truth, Intent Picks the Best

## Principle

The system is a **full organism**: it can trade all strategies and all regimes. There are **no restrictions or limitations** by regime. Governance ensures coherence and the **ability to trade everything we can trade**; **Claude intent** picks the **best** for the thesis.

- **All regimes** can trade **all strategy classes** (directional defined risk, neutral range, volatility, time skew, stock anchored).
- **Intent** (direction, volatility bias, allowed/forbidden classes, confidence, rationale) chooses the best structure for the thesis.
- Regime and signal inform **scoring and ranking** (e.g. which structure fits best), not blocking.

## Where This Is Implemented

| What | File | Detail |
|------|------|--------|
| Full universe per regime | `server/intent-governance.ts` | `ALL_STRATEGY_CLASSES`; `STRATEGY_COMPATIBILITY[regime]` = all classes for every regime |
| Intent filters, regime does not block | `server/intent-governance.ts` | `filterStrategies(intent, regime)` uses intent’s allowed/forbidden; availability is full |
| Option generation | `server/catalyst-options-generation.ts` | `getAllowedStructureIdsFromIntent()` → intent picks; all structures available when intent allows |
| Fallback intent | `server/claude-trade-decision.ts` | When Claude is unavailable, fallback allows full universe |

## Strategy Classes and Structures

- **DIRECTIONAL_DEFINED_RISK**: vertical_call_spread, vertical_put_spread  
- **NEUTRAL_RANGE**: iron_condor, iron_butterfly, butterfly, calendar_spread  
- **VOLATILITY**: straddle, strangle  
- **TIME_SKEW**: diagonal_spread  
- **STOCK_ANCHORED**: cash_secured_put, covered_call  

Intent (from Claude or fallback) specifies allowed and forbidden classes; the system then picks the best from that set using regime and signal for ranking, not for blocking.
