import "dotenv/config";
import { config } from "dotenv";
import { resolve } from "path";

// Load .env.local so DATABASE_URL is available when running pnpm db:push / db:migrate
const envLocal = resolve(process.cwd(), ".env.local");
try {
  config({ path: envLocal, override: true });
} catch {
  // ignore
}

import { defineConfig } from "drizzle-kit";

const connectionString = process.env.DATABASE_URL;
if (!connectionString) {
  throw new Error("DATABASE_URL is required to run drizzle commands");
}

export default defineConfig({
  schema: "./drizzle/schema.ts",
  out: "./drizzle",
  dialect: "mysql",
  dbCredentials: {
    url: connectionString,
  },
});
