# Full System Audit Report (Gap-Closing Pipeline)

**Generated:** 2026-02-01T03:15:34.400Z
**Trades audited:** 2

---

## Section 1 – Trade Risk / Reward Verification

| Trade | Max Risk ($) | Max Profit ($) | Historical P/L | Assignment Risk (%) |
|-------|--------------|----------------|----------------|---------------------|
| SPY | 300 | 200 | 86157.98 | 0 |
| AAPL | 300 | 200 | 61865.12 | 0 |

## Section 2 – Probability Calibration

| Trade | Score | Confidence | Historical Win Rate (%) | Avg Loss ($) | Max Loss ($) | Regime |
|-------|-------|-------------|--------------------------|--------------|--------------|--------|
| SPY | 0 | 0.7 | 0.7 | 146 | 2000 | trending_bull |
| AAPL | 0 | 0.7 | 0.9 | 31 | 2000 | mean_reverting |

## Section 3 – Volatility and IV Analysis

| Trade | IV Start | IV Exit | P/L @ IV−20% | P/L @ IV−50% | Delta | Gamma | Vega | Theta |
|-------|----------|---------|--------------|--------------|-------|-------|------|-------|
| SPY | 18 | 16.2 | -0.04 | -0.1 | 0.3 | 0 | 0 | -0.01 |
| AAPL | 22 | 19.8 | -0.04 | -0.1 | -0.3 | 0 | 0 | -0.01 |

## Section 4 – Execution Realism

| Trade | Bid/Ask Spread | Filled vs Theoretical | Open Interest | Avg Volume |
|-------|----------------|------------------------|---------------|------------|
| SPY | 63.43% | No fills yet; pre-trade estimate 0.5% per leg | 1268 | 6944 |
| AAPL | 73.92% | No fills yet; pre-trade estimate 0.5% per leg | 727 | 3216 |

## Section 5 – Portfolio Risk / Correlation

**Total dollar risk (VaR99):** 0 | **VaR95:** 0 | **Max drawdown:** 6.345946451100158%

| Trade Pair | Correlation | Combined Max Risk ($) |
|------------|-------------|------------------------|
| SPY / AAPL | 0.3 | 600 |

## Section 6 – Stress-Test / Crisis Simulation

| Trade | Event | P/L | Margin Calls | Realized vs Theoretical |
|-------|-------|-----|--------------|---------------------------|
| SPY | Mar 2020 crash | -0.15 | 0 | Insufficient data |
| SPY | Feb 2022 vol spike | -0.15 | 0 | Insufficient data |
| AAPL | Mar 2020 crash | -0.15 | 0 | Insufficient data |
| AAPL | Feb 2022 vol spike | -0.15 | 0 | Insufficient data |

## Section 7 – Explainability / Transparency

| Trade | Score Reasoning | Expected Return Assumptions | Confidence Interval |
|-------|-----------------|-----------------------------|---------------------|
| SPY | Regime: trending_bull; structure vertical_call_spread; composite score from 9-pillar ranker (regime–signal–structure alignment, IV/DTE, flow). | Point estimate from signal expected return × regime multiplier; win probability 50%. OOS confidence from multi-window walk-forward when run. | Sharpe 95% CI: [0, 0]; mean OOS Sharpe 0; robustness poor |
| AAPL | Regime: mean_reverting; structure vertical_put_spread; composite score from 9-pillar ranker (regime–signal–structure alignment, IV/DTE, flow). | Point estimate from signal expected return × regime multiplier; win probability 50%. OOS confidence from multi-window walk-forward when run. | Sharpe 95% CI: [0, 0]; mean OOS Sharpe 0; robustness poor |

---

## Methodology

Max risk/profit from structure type and spread width (default $5) when option chain not loaded. Greeks from portfolio-risk estimates or chain. Historical P/L and win rate from backtest-runner (Yahoo daily + Black–Scholes option P&L) when provided. Stress from regime-transition-stress and stress-regime-transitions scripts. TCA from logged fills.

## Data Sources

- Yahoo Finance (daily OHLC)
- IBKR Gateway (options chain, Greeks when connected)
- execution-cost-model (spread, commission)
- portfolio-risk (Greeks, VaR)
- tca (logged fills)
- backtest-runner (historical, walk-forward, regime stress)

## Assumptions

- Default spread width $5 for vertical spreads when not from chain.
- Assignment risk proxy: short-option ITM probability from Black–Scholes.
- IV at exit: proxy from realized vol when historical option IV not available.
- Correlation: symbol–symbol from historical returns when not provided.
- Stress P/L: run pnpm backtest:stress-regime and pass stressResults for actual crisis dates.