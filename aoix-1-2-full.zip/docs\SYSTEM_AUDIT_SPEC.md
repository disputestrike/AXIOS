# System Audit Specification — Reliability, Risk, Real-World Applicability

**Objective:** Evaluate the reliability, risk, and real-world applicability of all current trading signals. Provide full transparency, historical backtesting, and stress-test simulations.

**Audience:** Auditors, risk, compliance.  
**Output:** All sections in **tables or structured JSON**; all assumptions, data sources, and methodology documented.

---

## Section 1 – Trade Risk / Reward Verification

| Requirement | System capability | Data source | Gap / note |
|-------------|-------------------|-------------|------------|
| Max $ risk per contract | ✓ Derived from structure (spread width × 100 − credit; CSP = strike×100 − premium) | `omega0` placeOrder pre-flight, `position-sizing` | When option chain not loaded: use default width (e.g. $5) and estimated credit from scanner/IV. |
| Max $ profit per contract | ✓ Same (credit for credit spreads; width−debit for debit) | Same | |
| Historical P/L (12 months, real prices, slippage, spreads, commissions) | ✓ Backtest with Yahoo daily + Black–Scholes option P&L; execution cost model (spread, commission) | `backtest-runner` (runHistoricalBacktest), `execution-cost-model`, `run-full-backtest` | Daily data only; intraday slippage is estimated (e.g. 0.5% per leg). |
| Probability of assignment, margin call, or forced exit | ⚠ Partial | — | **Gap:** No explicit assignment probability. Proxy: short-option ITM probability from Black–Scholes (normCdf). Margin/forced exit: drawdown limiter exists; no historical % of margin calls. |

**Output format:**  
| Trade | Max Risk ($) | Max Profit ($) | Historical P/L | Assignment Risk (%) |

---

## Section 2 – Probability Calibration

| Requirement | System capability | Data source | Gap / note |
|-------------|-------------------|-------------|------------|
| Historical win rate by score/confidence | ✓ Walk-forward and backtest return win rate by regime | `backtest-runner` (simulateSlice regimeSummary, runWalkForward, runMultiWindowWalkForward) | Win rate is by **regime**, not by exact score bucket; score alignment used in scanner. |
| Avg and max loss for failed trades | ✓ From backtest trade returns (losses only) | simulateSlice tradeReturns | Per-symbol/slice; not per “trade id” in UI. |
| Breakdown by regime (Crisis, Trending, Neutral) | ✓ regimeSummary in simulateSlice; stress by regime flip | `backtest-runner`, `regime-transition-stress` | Regimes include crisis, trending_bull/bear, mean_reverting, etc. |

**Output format:**  
| Trade | Score | Confidence | Historical Win Rate (%) | Avg Loss ($) | Max Loss ($) | Regime |

---

## Section 3 – Volatility and IV Analysis

| Requirement | System capability | Data source | Gap / note |
|-------------|-------------------|-------------|------------|
| IV at initiation | ✓ Scanner / opportunity; option chain when available | `market-scanner` (impliedVolatility), `omega0.getOptionChain` (ivSurfaces) | |
| IV at exit (historical) | ⚠ Proxy | — | **Gap:** No historical option IV series. Proxy: realized vol from Yahoo daily returns over hold period. |
| P/L under IV −20%, −50%, +20%, +50% | ✓ Portfolio stress (SPY±5%, VIX+50%); per-trade vega sensitivity can be derived | `portfolio-risk` (stress), `portfolio-greeks-tracker`, `greeks-engine` | Add explicit IV shock scenarios per trade (vega × ΔIV). |
| Delta, gamma, vega, theta per trade | ✓ From chain or estimatePositionGreeks | `portfolio-risk`, `portfolio-greeks-tracker`, `greeks-engine`, `omega0.getOptionChain` | |

**Output format:**  
| Trade | IV Start | IV Exit | P/L @ IV−20% | P/L @ IV−50% | Delta | Gamma | Vega | Theta |

---

## Section 4 – Execution Realism

| Requirement | System capability | Data source | Gap / note |
|-------------|-------------------|-------------|------------|
| Bid/ask spread at initiation | ✓ From option chain or microstructure signal (spreadPct) | `omega0` getOptionChain, `microstructure-signals`, `strike-expiry-selector` | When no chain: use spreadPct default or 0.15. |
| Filled vs theoretical price | ✓ TCA log (intendedPrice, fillPrice, slippagePerContract, slippagePercent) | `tca` (logTCA, getTCASummary, getTCADrillDown) | Post-trade only. Pre-trade: estimated slippage in pre-flight. |
| Open interest, ADV, ability to scale | ✓ Liquidity score (spread, OI when from chain); getMaxOrderSize (ADV cap) | `option-combination-scanner`, `strike-expiry-selector`, `market-impact` | OI/ADV from chain or market data when available. |

**Output format:**  
| Trade | Bid/Ask Spread | Filled vs Theoretical | Open Interest | Avg Volume |

---

## Section 5 – Portfolio Risk / Correlation

| Requirement | System capability | Data source | Gap / note |
|-------------|-------------------|-------------|------------|
| Total $ risk (top 10 trades together) | ✓ Sum of position risks; VaR 95/99 from aggregate Greeks | `portfolio-risk` (aggregatePortfolioRisk), `portfolio-greeks-tracker` | |
| Correlation matrix between trades | ✓ Correlation stress script (historical correlation periods) | `correlation-stress`, `portfolio-optimizer` | Matrix: symbol vs symbol from historical returns (Yahoo). |
| Max portfolio drawdown (historical) | ✓ Drawdown limiter + getDrawdownMetrics; backtest maxDrawdownPercent | `drawdown-limiter`, `auto-trading` getDrawdownMetrics, `backtest-runner` | |

**Output format:**  
| Trade Pair | Correlation | Combined Max Risk ($) |

---

## Section 6 – Stress-Test / Crisis Simulation

| Requirement | System capability | Data source | Gap / note |
|-------------|-------------------|-------------|------------|
| March 2020 crash | ✓ Regime stress (crisis regime); can filter flips by date | `regime-transition-stress`, `stress-regime-transitions` | Run stress over 2020-02–2020-04; report P/L and Sharpe drop. |
| Feb 2022 volatility spike | ✓ Same (vol spike → crisis or bear_vol_expansion) | Same | Run stress over 2022-01–2022-03. |
| Other crises (10 years) | ✓ Same; multi-window walk-forward includes various periods | Same + `run-5window-walkforward` | |
| Margin calls, forced exits, realized vs theoretical | ✓ Drawdown auto-stop; TCA realized vs intended | `drawdown-limiter`, `tca` | No explicit “margin call” event; we have auto-stop on drawdown. |

**Output format:**  
| Trade | Event | P/L | Margin Calls | Realized vs Theoretical |

---

## Section 7 – Explainability / Transparency

| Requirement | System capability | Data source | Gap / note |
|-------------|-------------------|-------------|------------|
| Why trade scored highly (technical, fundamental, IV, flow) | ✓ Composite ranker (9 pillars); regime–signal–structure alignment; signal breakdown UI | `composite-ranker`, `ranking-utils`, `market-scanner` (getAPlusRank), SignalBreakdown component | |
| Confidence intervals or assumptions for expected return | ⚠ Partial | — | **Gap:** No explicit confidence interval. Win probability and expected return are point estimates; can add ± from historical OOS stdev. |

**Output format:**  
| Trade | Score Reasoning | Expected Return Assumptions | Confidence Interval |

---

## Critical Instructions (System Behavior)

1. **All outputs** in tables or structured JSON for audit.
2. **Include** assumptions, historical data sources, methodology in every run (see `methodology` and `dataSources` in audit JSON).
3. **Do not skip** trades—include all dashboard opportunities (or top N); flag high-IV or extreme expected return as “review” rather than omit.
4. **Include** both success and failure examples (e.g. backtest wins vs losses; stress periods with negative P/L).

---

## Implementation

- **Audit module:** `server/system-audit.ts` — builds Sections 1–7 from scanner, backtest, portfolio-risk, execution-cost, TCA, stress; outputs structured JSON + markdown tables.
- **Script:** `pnpm audit:signals` or `tsx scripts/run-system-audit.ts` — runs audit (use `SCAN_FIRST=1` to run market scan first), writes `backtest-results/system-audit-YYYY-MM-DD.json` and `system-audit-YYYY-MM-DD.md`.
- **tRPC:** `system.getAuditReport({ topN?: number })` — returns full audit report for dashboard (top N opportunities from scanner).

**Data sources (summary):**  
Yahoo Finance (daily OHLC, historical); IBKR Gateway (when connected: options chain, Greeks, fill prices); execution-cost-model (spread, commission, time-of-day); TCA (logged fills); backtest-runner (historical + walk-forward + regime stress); portfolio-risk (Greeks, VaR, stress); correlation-stress (symbol correlation); drawdown-limiter (equity curve, auto-stop).

*Last updated: System Audit Package.*
