/**
 * Regime transition stress test — find flips and measure pre/post Sharpe.
 * Run: pnpm tsx scripts/stress-regime-transitions.ts
 * Writes: backtest-results/regime-transition-stress.json
 */
import {
  getHistoricalPriceData,
  buildRegimeHistory,
  findRegimeFlips,
  stressTestRegimeTransitions,
} from "../server/regime-transition-stress";
import { mkdir, writeFile } from "fs/promises";
import { join } from "path";

const SYMBOL = process.env.STRESS_SYMBOL ?? "SPY";
const START_YEARS_AGO = 4;
const OUT_DIR = process.env.BACKTEST_RESULTS_DIR ?? join(process.cwd(), "backtest-results");
const OUT_FILE = join(OUT_DIR, "regime-transition-stress.json");

async function main() {
  const endDate = new Date();
  const startDate = new Date();
  startDate.setFullYear(startDate.getFullYear() - START_YEARS_AGO);
  console.log("[Regime Stress] Loading history:", SYMBOL, startDate.toISOString().slice(0, 10), "→", endDate.toISOString().slice(0, 10));

  const quotes = await getHistoricalPriceData(SYMBOL, startDate, endDate);
  if (quotes.length < 60) {
    console.error("[Regime Stress] Not enough data:", quotes.length, "bars");
    process.exit(1);
  }
  const regimeHistory = buildRegimeHistory(quotes);
  const flips = findRegimeFlips(regimeHistory);
  console.log("[Regime Stress] Found", flips.length, "regime flips");

  const stressResults = await stressTestRegimeTransitions(SYMBOL, flips, 30, 30);
  const avgDrop =
    stressResults.length > 0
      ? stressResults.reduce((s, r) => s + r.perfDropPercent, 0) / stressResults.length
      : 0;
  const avgRecovery =
    stressResults.length > 0
      ? stressResults.reduce((s, r) => s + r.recoveryDays, 0) / stressResults.length
      : 0;
  const worstDrop = stressResults.length > 0 ? Math.max(...stressResults.map((r) => r.perfDropPercent)) : 0;

  console.log("[Regime Stress] Avg Sharpe drop:", avgDrop.toFixed(1), "%");
  console.log("[Regime Stress] Avg recovery days:", avgRecovery.toFixed(0));
  console.log("[Regime Stress] Worst single drop:", worstDrop.toFixed(1), "%");

  await mkdir(OUT_DIR, { recursive: true });
  await writeFile(
    OUT_FILE,
    JSON.stringify(
      {
        symbol: SYMBOL,
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
        flipsCount: flips.length,
        avgDropPercent: avgDrop,
        avgRecoveryDays: avgRecovery,
        worstDropPercent: worstDrop,
        results: stressResults,
        timestamp: new Date().toISOString(),
      },
      null,
      2
    ),
    "utf-8"
  );
  console.log("[Regime Stress] Output:", OUT_FILE);
  process.exit(0);
}

main().catch((e) => {
  console.error("[Regime Stress] Error:", e);
  process.exit(1);
});
