/**
 * AOIX-1 Blueprint: Persistent outcome store (SQLite).
 * Append-only; no deletes; never mutate historical outcomes.
 * Enable with OUTCOME_STORE=sqlite. Requires better-sqlite3.
 */

import type { TradeOutcome } from "./outcome-log";
import type { OutcomeStore } from "./outcome-log";
import type { IntentDecision } from "./intent-governance";
import path from "node:path";
import fs from "node:fs";

const DEFAULT_DB_PATH = path.join(process.cwd(), "data", "trade_outcomes.sqlite");

function ensureDataDir(dbPath: string): void {
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

/** Build minimal IntentDecision from stored confidence + rationale. */
function intentFromStored(confidence: number, rationale: string): IntentDecision {
  return {
    direction: "NEUTRAL",
    volatilityBias: "NEUTRAL",
    allowedClasses: [],
    forbiddenClasses: [],
    confidence,
    rationale: rationale || "",
  };
}

/** Minimal type for better-sqlite3 Database (optional dep). */
export interface SQLiteDb {
  exec(sql: string): unknown;
  prepare(sql: string): { run(...args: unknown[]): unknown; get(...args: unknown[]): unknown; all(...args: unknown[]): unknown[] };
}

export interface SQLiteOutcomeStoreOptions {
  dbPath?: string;
}

/**
 * SQLite outcome store. Uses better-sqlite3 when available; otherwise throws at construction.
 */
export class SQLiteOutcomeStore implements OutcomeStore {
  private dbPath: string;
  private db: SQLiteDb | null = null;
  private initPromise: Promise<void> | null = null;

  constructor(options: SQLiteOutcomeStoreOptions = {}) {
    this.dbPath = options.dbPath ?? DEFAULT_DB_PATH;
    ensureDataDir(this.dbPath);
  }

  private async init(): Promise<void> {
    if (this.db) return;
    if (this.initPromise) return this.initPromise;
    this.initPromise = (async () => {
      const mod = await import("better-sqlite3");
      const Database = mod.default as new (path: string) => SQLiteDb;
      const db = new Database(this.dbPath);
      this.db = db;
      db.exec(`
        CREATE TABLE IF NOT EXISTS trade_outcomes (
          id TEXT PRIMARY KEY,
          symbol TEXT NOT NULL,
          regime TEXT NOT NULL,
          strategy_class TEXT NOT NULL,
          intent_confidence REAL NOT NULL,
          intent_rationale TEXT,
          pnl REAL NOT NULL,
          max_drawdown REAL NOT NULL,
          duration_days INTEGER NOT NULL,
          exit_reason TEXT NOT NULL,
          created_at INTEGER NOT NULL
        );
      `);
      db.exec("CREATE INDEX IF NOT EXISTS idx_outcomes_created_at ON trade_outcomes(created_at)");
      db.exec("CREATE INDEX IF NOT EXISTS idx_outcomes_regime ON trade_outcomes(regime)");
    })();
    return this.initPromise;
  }

  private getDb(): SQLiteDb {
    if (!this.db) throw new Error("SQLiteOutcomeStore not initialized");
    return this.db;
  }

  async append(outcome: TradeOutcome): Promise<void> {
    await this.init();
    const id = `outcome_${outcome.closedAt}_${outcome.symbol}_${Math.random().toString(36).slice(2, 10)}`;
    const stmt = this.getDb().prepare(`
      INSERT INTO trade_outcomes (id, symbol, regime, strategy_class, intent_confidence, intent_rationale, pnl, max_drawdown, duration_days, exit_reason, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    stmt.run(
      id,
      outcome.symbol,
      outcome.regime,
      outcome.strategyClass,
      outcome.intent.confidence,
      outcome.intent.rationale ?? "",
      outcome.pnl,
      outcome.maxDrawdown,
      outcome.durationDays,
      outcome.exitReason,
      outcome.closedAt
    );
  }

  async fetchRecent(limit: number): Promise<TradeOutcome[]> {
    await this.init();
    const stmt = this.getDb().prepare(`
      SELECT symbol, regime, strategy_class, intent_confidence, intent_rationale, pnl, max_drawdown, duration_days, exit_reason, created_at
      FROM trade_outcomes ORDER BY created_at DESC LIMIT ?
    `);
    const rows = stmt.all(limit) as Array<{
      symbol: string;
      regime: string;
      strategy_class: string;
      intent_confidence: number;
      intent_rationale: string;
      pnl: number;
      max_drawdown: number;
      duration_days: number;
      exit_reason: string;
      created_at: number;
    }>;
    return rows.reverse().map((r) => ({
      symbol: r.symbol,
      regime: r.regime as TradeOutcome["regime"],
      intent: intentFromStored(r.intent_confidence, r.intent_rationale ?? ""),
      strategyClass: r.strategy_class as TradeOutcome["strategyClass"],
      pnl: r.pnl,
      maxDrawdown: r.max_drawdown,
      durationDays: r.duration_days,
      exitReason: r.exit_reason as TradeOutcome["exitReason"],
      closedAt: r.created_at,
    }));
  }

  /** Sync; returns [] if not yet initialized (init is async). */
  getAll(): TradeOutcome[] {
    if (!this.db) return [];
    const stmt = this.getDb().prepare(`
      SELECT symbol, regime, strategy_class, intent_confidence, intent_rationale, pnl, max_drawdown, duration_days, exit_reason, created_at
      FROM trade_outcomes ORDER BY created_at ASC
    `);
    const rows = stmt.all() as Array<{
      symbol: string;
      regime: string;
      strategy_class: string;
      intent_confidence: number;
      intent_rationale: string;
      pnl: number;
      max_drawdown: number;
      duration_days: number;
      exit_reason: string;
      created_at: number;
    }>;
    return rows.map((r) => ({
      symbol: r.symbol,
      regime: r.regime as TradeOutcome["regime"],
      intent: intentFromStored(r.intent_confidence, r.intent_rationale ?? ""),
      strategyClass: r.strategy_class as TradeOutcome["strategyClass"],
      pnl: r.pnl,
      maxDrawdown: r.max_drawdown,
      durationDays: r.duration_days,
      exitReason: r.exit_reason as TradeOutcome["exitReason"],
      closedAt: r.created_at,
    }));
  }

  /** Sync; returns 0 if not yet initialized. */
  getCount(): number {
    if (!this.db) return 0;
    const row = this.getDb().prepare("SELECT COUNT(*) as c FROM trade_outcomes").get() as { c: number };
    return row?.c ?? 0;
  }
}

/** Create SQLite store if OUTCOME_STORE=sqlite and better-sqlite3 is available; else null. */
export async function createSQLiteOutcomeStoreIfRequested(dbPath?: string): Promise<SQLiteOutcomeStore | null> {
  if (process.env.OUTCOME_STORE !== "sqlite") return null;
  try {
    const store = new SQLiteOutcomeStore({ dbPath });
    await store.fetchRecent(1);
    return store;
  } catch (e) {
    console.warn("[OutcomeStore] SQLite not available, using memory:", e);
    return null;
  }
}
