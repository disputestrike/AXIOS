# If Nothing Works – IB Gateway

When Connect never succeeds and you see 429 / cookie not set / TWS Disconnected, use this.

## Step 1: Run the diagnostic

In the project folder (where `package.json` is), run:

```bash
pnpm run check:gateway
```

Or:

```bash
node scripts/check-ib-gateway.js
```

The script will print:

- Whether `.env.local` exists and where it is
- Whether `IB_GATEWAY_COOKIE` is set (yes/no, not the value)
- The Gateway URL it’s using
- The **exact** response from the Gateway (200, 401, 429, 400, or “cannot reach”)

Then it tells you **what to do** for that result.

## Step 2: Do what the script says

- **“.env.local not found”** → Create `.env.local` in the project root (same folder as `package.json`). Copy from `.env.local.example` and add at least:
  - `TWS_PORT=5000`
  - `IB_GATEWAY_COOKIE=api=YOUR_VALUE` (get the value in Step 3)

- **“IB_GATEWAY_COOKIE set: false”** → You haven’t set the cookie. Do Step 3.

- **“401 Unauthorized”** → Gateway needs your session cookie. Set `IB_GATEWAY_COOKIE` (Step 3), then **restart the app** (Ctrl+C, then `pnpm dev`). Run `pnpm run check:gateway` again to confirm 200.

- **“429 Rate limit”** → Stop clicking Connect. Wait **2 full minutes**. Run `pnpm run check:gateway` again. If you still get 429, wait another 2 minutes. Set the cookie and restart the app so the next Connect has a valid session.

- **“Cannot reach Gateway”** → The Client Portal Gateway app is not running or not on port 5000. Start the Gateway (from Interactive Brokers), open http://localhost:5000 in your browser, log in, then run the script again.

## Step 3: Get the cookie (for 401 or “cookie not set”)

1. Start the **Client Portal Gateway** app (from Interactive Brokers). Leave it running.
2. In your browser open **http://localhost:5000** and log in (username, password, 2FA if asked).
3. When the Client Portal page has loaded:
   - Press **F12** → **Application** (or **Storage**) → **Cookies** → **http://localhost:5000**
   - Find the cookie named **`api`**
   - Copy its **Value** (the long string)
4. Open **`.env.local`** in the project root and add or update:
   ```bash
   TWS_PORT=5000
   IB_GATEWAY_COOKIE=api=PASTE_THE_VALUE_YOU_COPIED
   ```
   Example: `IB_GATEWAY_COOKIE=api=Ab3xYz...` (no spaces around `=`).
5. Save the file. **Restart the app**: in the terminal where it runs, press **Ctrl+C**, then run **`pnpm dev`** again.
6. Run **`pnpm run check:gateway`** again. You should see **Gateway response: 200**. Then in the app, click **Connect** once.

## Step 4: After it shows 200

- In the app, go to **Auto Trading** and click **Connect** once.
- If the app was already running, you must have restarted it after editing `.env.local`; otherwise the server never loads the new cookie.

## Still not working?

1. **Run `pnpm run check:gateway` again** and read the output. It reflects what the server would see.
2. **Check the server terminal** when you start `pnpm dev`. You should see:
   - `[Env] .env.local loaded successfully`
   - `[Env] IB_GATEWAY_COOKIE present: true`
   If you see `IB_GATEWAY_COOKIE present: false`, the server did not get the cookie (wrong file, wrong variable name, or you didn’t restart after editing).
3. **Cookie format**: In `.env.local` use one line, no quotes around the value:  
   `IB_GATEWAY_COOKIE=api=YourLongCookieValue`
4. **Login at 5000**: “Authentication failed” on the Gateway login page is from Interactive Brokers (username/password/2FA). See **IB_GATEWAY_SETUP.md** → “Login page shows Authentication failed”.
