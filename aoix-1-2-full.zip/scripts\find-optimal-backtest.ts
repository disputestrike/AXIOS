/**
 * Find optimal backtest settings by grid search over riskPerTrade, holdDays, regime filter.
 * Runs on multiple symbols over 12 months. Uses a "no hidden stress" score so we don't pick
 * params that look good on average but hide one symbol with huge drawdown or low win rate.
 * Run: pnpm backtest:optimal
 *
 * robustScore = avgSharpe - 0.15*avgMaxDD - penalty if any symbol has maxDD > 15% or winRate < 55%.
 */

import { runHistoricalBacktest } from '../server/backtest-runner';

/** More symbols = less overfitting, more robust optimal. */
const OPTIMIZE_SYMBOLS = ['SPY', 'QQQ', 'IWM', 'AAPL', 'GOOGL', 'JNJ', 'NVDA', 'MSFT'];
const DAYS = 252; // 12 months
const DEFAULT_REGIMES: string[] = ['bull_vol_compression', 'mean_reverting', 'trending_bull'];

const RISK_OPTS = [0.008, 0.01, 0.012, 0.015, 0.02];
const HOLD_OPTS = [3, 4, 5, 6, 7];

/** Penalize configs where any symbol has hidden stress (extreme DD or low win rate). */
const MAX_DD_STRESS = 15;   // % — if any symbol > this, penalize
const MIN_WIN_RATE_STRESS = 55; // % — if any symbol < this, penalize
const PENALTY_DD = 0.8;     // score penalty when worst symbol exceeds MAX_DD_STRESS
const PENALTY_WIN = 0.4;    // score penalty when worst symbol below MIN_WIN_RATE_STRESS

interface Trial {
  riskPerTrade: number;
  holdDays: number;
  regimeFilter: boolean;
  avgSharpe: number;
  avgMaxDD: number;
  avgWinRate: number;
  avgReturnPct: number;
  totalTrades: number;
  score: number;
  robustScore: number; // score minus hidden-stress penalties
  worstSymbolMaxDD: number;
  worstSymbolWinRate: number;
  bySymbol: { symbol: string; sharpe: number; maxDD: number; returnPct: number; winRate: number }[];
}

async function main() {
  console.log('Optimizing backtest (multi-symbol, 12 months)...');
  console.log(`  Symbols: ${OPTIMIZE_SYMBOLS.join(', ')}`);
  console.log(`  Grid: risk ${RISK_OPTS.map((r) => (r * 100).toFixed(1) + '%').join(' ')} | hold ${HOLD_OPTS.join(', ')}d\n`);

  const trials: Trial[] = [];

  for (const riskPerTrade of RISK_OPTS) {
    for (const holdDays of HOLD_OPTS) {
      for (const regimeOn of [true, false]) {
        const regimes = regimeOn ? DEFAULT_REGIMES : undefined;
        const bySymbol: Trial['bySymbol'] = [];
        let totalTrades = 0;

        for (const symbol of OPTIMIZE_SYMBOLS) {
          const r = await runHistoricalBacktest(symbol, DAYS, holdDays, regimes, true, riskPerTrade, 1);
          if (!r.success) continue;
          bySymbol.push({
            symbol,
            sharpe: r.sharpeRatio,
            maxDD: r.maxDrawdownPercent,
            returnPct: r.totalReturnPercent ?? 0,
            winRate: r.winRate * 100,
          });
          totalTrades += r.trades;
        }

        if (bySymbol.length === 0) continue;

        const avgSharpe = bySymbol.reduce((s, x) => s + x.sharpe, 0) / bySymbol.length;
        const avgMaxDD = bySymbol.reduce((s, x) => s + x.maxDD, 0) / bySymbol.length;
        const avgWinRate = bySymbol.reduce((s, x) => s + x.winRate, 0) / bySymbol.length;
        const avgReturnPct = bySymbol.reduce((s, x) => s + x.returnPct, 0) / bySymbol.length;

        const worstSymbolMaxDD = Math.max(...bySymbol.map((x) => x.maxDD));
        const worstSymbolWinRate = Math.min(...bySymbol.map((x) => x.winRate));

        const score = avgSharpe - 0.15 * (avgMaxDD / 100);
        let robustScore = score;
        if (worstSymbolMaxDD > MAX_DD_STRESS) robustScore -= PENALTY_DD;
        if (worstSymbolWinRate < MIN_WIN_RATE_STRESS) robustScore -= PENALTY_WIN;

        trials.push({
          riskPerTrade,
          holdDays,
          regimeFilter: regimeOn,
          avgSharpe,
          avgMaxDD,
          avgWinRate,
          avgReturnPct,
          totalTrades,
          score,
          robustScore,
          worstSymbolMaxDD,
          worstSymbolWinRate,
          bySymbol,
        });
      }
    }
  }

  trials.sort((a, b) => b.robustScore - a.robustScore);
  const best = trials[0];
  if (!best) {
    console.log('No successful trials.');
    return;
  }

  console.log('Top 8 settings (robustScore = score - penalty if any symbol has maxDD > 15% or win < 55%):');
  console.log('─'.repeat(110));
  for (let i = 0; i < Math.min(8, trials.length); i++) {
    const t = trials[i];
    const stress = t.worstSymbolMaxDD > MAX_DD_STRESS || t.worstSymbolWinRate < MIN_WIN_RATE_STRESS ? ' [stress]' : '';
    console.log(
      `  ${i + 1}. risk=${(t.riskPerTrade * 100).toFixed(1)}% hold=${t.holdDays}d regime=${t.regimeFilter} → avgSharpe=${t.avgSharpe.toFixed(2)} avgMaxDD=${t.avgMaxDD.toFixed(1)}% worstDD=${t.worstSymbolMaxDD.toFixed(1)}% worstWin=${t.worstSymbolWinRate.toFixed(0)}% robustScore=${t.robustScore.toFixed(2)}${stress}`
    );
  }

  console.log('\nOptimal settings (no hidden stress — use in .env or run):');
  console.log(`  BACKTEST_RISK_PER_TRADE=${best.riskPerTrade}`);
  console.log(`  BACKTEST_HOLD_DAYS=${best.holdDays}`);
  console.log(`  BACKTEST_REGIMES=${best.regimeFilter ? DEFAULT_REGIMES.join(',') : ''} (regime filter ${best.regimeFilter ? 'ON' : 'OFF'})`);
  console.log(`  → avg Sharpe ${best.avgSharpe.toFixed(2)}, avg maxDD ${best.avgMaxDD.toFixed(1)}%, worst symbol maxDD ${best.worstSymbolMaxDD.toFixed(1)}%, worst win ${best.worstSymbolWinRate.toFixed(0)}%, avg return ${best.avgReturnPct.toFixed(1)}%`);
  console.log('\nPer-symbol (best run):');
  for (const b of best.bySymbol) {
    console.log(`  ${b.symbol}: Sharpe=${b.sharpe.toFixed(2)} maxDD=${b.maxDD.toFixed(1)}% win=${b.winRate.toFixed(1)}% return=${b.returnPct.toFixed(1)}%`);
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
