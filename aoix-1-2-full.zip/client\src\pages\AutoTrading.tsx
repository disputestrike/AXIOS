import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Play, 
  Pause, 
  RefreshCw, 
  AlertTriangle, 
  TrendingUp, 
  TrendingDown,
  Activity,
  Shield,
  Target,
  Zap,
  DollarSign,
  Clock,
  BarChart3,
  Wifi,
  WifiOff,
  Settings
} from "lucide-react";

export default function AutoTrading() {
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedAsset, setSelectedAsset] = useState('SPX');
  const [showTWSConfig, setShowTWSConfig] = useState(false);
  const [twsHost, setTwsHost] = useState('localhost');
  const [twsPort, setTwsPort] = useState('5000');
  
  // tRPC queries - with more frequent polling for real-time updates
  const { data: state, refetch: refetchState, isLoading: stateLoading, error: stateError } = trpc.autoTrading.getState.useQuery(undefined, {
    refetchInterval: 2000, // Poll every 2 seconds for real-time feel
    enabled: true,
  });
  
  const { data: performance, refetch: refetchPerformance, isLoading: perfLoading } = trpc.autoTrading.getPerformance.useQuery(undefined, {
    refetchInterval: 5000, // Poll every 5 seconds
    enabled: true,
  });
  
  const { data: positions, refetch: refetchPositions } = trpc.autoTrading.getPositions.useQuery(undefined, {
    refetchInterval: 3000, // Poll every 3 seconds
    enabled: true,
  });
  
  const { data: recentTrades, refetch: refetchTrades } = trpc.autoTrading.getTrades.useQuery({ limit: 10 }, {
    refetchInterval: 5000, // Poll every 5 seconds
    enabled: true,
  });

  // Engine logs for debugging
  const { data: engineLogs } = trpc.autoTrading.getLogs.useQuery({ limit: 20 }, {
    refetchInterval: 3000, // Poll every 3 seconds
    enabled: true,
  });

  // Last opportunities found
  const { data: lastOpportunities } = trpc.autoTrading.getLastOpportunities.useQuery(undefined, {
    refetchInterval: 5000, // Poll every 5 seconds
    enabled: true,
  });

  // Strategy configs (human-readable TP/SL — e.g. "Close at 2× credit" instead of raw "100%")
  const { data: strategyConfigs } = trpc.autoTrading.getStrategyConfigs.useQuery(undefined, { enabled: true });
  const currentStrategyConfig = strategyConfigs?.find((c: { type: string }) => c.type === (state?.strategyType ?? "adaptive"));
  
  // Gateway queries
  const { data: gatewayStatus, refetch: refetchGateway } = trpc.gateway.getStatus.useQuery(undefined, {
    refetchInterval: 5000,
  });
  
  const { data: gatewayMode } = trpc.gateway.isLiveMode.useQuery(undefined, {
    refetchInterval: 5000,
  });

  // TWS connection queries — back off polling when we get 429 to avoid hammering the Gateway
  const { data: twsStatus, refetch: refetchTWS } = trpc.twsConnection.getStatus.useQuery(undefined, {
    refetchInterval: 5000,
  });
  const { data: gatewayDiagnostic, refetch: refetchDiagnostic } = trpc.twsConnection.getDiagnostic.useQuery(undefined, {
    enabled: !twsStatus?.connected,
    refetchInterval: 15_000,
  });

  const twsConnectMutation = trpc.twsConnection.connect.useMutation({
    onSuccess: () => {
      refetchTWS();
      refetchDiagnostic();
    },
  });

  const twsDisconnectMutation = trpc.twsConnection.disconnect.useMutation({
    onSuccess: () => refetchTWS(),
  });

  const twsConfigureMutation = trpc.twsConnection.configure.useMutation({
    onSuccess: () => {
      refetchTWS();
      setShowTWSConfig(false);
    },
  });

  const confirmBrowserConnectionMutation = trpc.twsConnection.confirmBrowserConnection.useMutation({
    onSuccess: () => refetchTWS(),
  });
  
  // Mutations
  const startMutation = trpc.autoTrading.start.useMutation({
    onSuccess: () => refetchState(),
  });
  
  const stopMutation = trpc.autoTrading.stop.useMutation({
    onSuccess: () => refetchState(),
  });
  
  const resetMutation = trpc.autoTrading.reset.useMutation({
    onSuccess: () => {
      refetchState();
      refetchPerformance();
    },
  });
  
  const enableGatewayMutation = trpc.gateway.enable.useMutation({
    onSuccess: () => refetchGateway(),
  });
  
  const disableGatewayMutation = trpc.gateway.disable.useMutation({
    onSuccess: () => refetchGateway(),
  });

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await Promise.all([
      refetchState(), 
      refetchPerformance(), 
      refetchPositions(),
      refetchTrades(),
      refetchGateway(), 
      refetchTWS()
    ]);
    setIsRefreshing(false);
  };

  /** Check IB Client Portal Gateway from this browser (cookie is sent). If OK, confirm connection on server. */
  const checkGatewayFromBrowser = async (host: string, port: number): Promise<boolean> => {
    const base = `http://${host || 'localhost'}:${port}`;
    const url = `${base}/v1/api/iserver/accounts`;
    try {
      const res = await fetch(url, { method: 'GET', credentials: 'include', mode: 'cors' });
      if (res.ok) {
        await confirmBrowserConnectionMutation.mutateAsync();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const [twsConnecting, setTwsConnecting] = useState(false);

  const handleConnectTWS = async () => {
    const host = twsStatus?.host ?? twsHost ?? 'localhost';
    const port = (twsStatus?.port ?? parseInt(twsPort, 10)) || 5000;
    setTwsConnecting(true);
    try {
      const browserOk = await checkGatewayFromBrowser(host, port);
      if (browserOk) {
        await refetchTWS();
        setTwsConnecting(false);
        return;
      }
      twsConnectMutation.mutate(undefined, {
        onSettled: () => { refetchTWS(); },
      });
    } finally {
      setTwsConnecting(false);
    }
  };

  const handleConfigureTWS = async () => {
    if (!twsHost || !twsPort) return;
    const port = parseInt(twsPort, 10);
    twsConfigureMutation.mutate({ host: twsHost, port }, {
      onSuccess: async () => {
        const browserOk = await checkGatewayFromBrowser(twsHost, port);
        if (browserOk) await refetchTWS();
      },
    });
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    }).format(value);
  };

  const formatPercent = (value: number) => {
    return `${(value * 100).toFixed(2)}%`;
  };

  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Zap className="h-8 w-8 text-yellow-500" />
            Autonomous Trading Engine
          </h1>
          <p className="text-slate-400 mt-2">
            Fully automatic trading with regime-based signals and risk management
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <label className="text-sm text-slate-400">Asset:</label>
            <Select value={selectedAsset} onValueChange={setSelectedAsset}>
              <SelectTrigger className="w-24">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="SPX">SPX</SelectItem>
                <SelectItem value="QQQ">QQQ</SelectItem>
                <SelectItem value="SPY">SPY</SelectItem>
                <SelectItem value="IWM">IWM</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={isRefreshing}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          {state?.isRunning ? (
            <Button
              variant="destructive"
              onClick={() => stopMutation.mutate()}
              disabled={stopMutation.isPending}
            >
              <Pause className="h-4 w-4 mr-2" />
              Stop Engine
            </Button>
          ) : (
            <Button
              variant="default"
              className="bg-green-600 hover:bg-green-700"
              onClick={() => startMutation.mutate()}
              disabled={startMutation.isPending}
            >
              <Play className="h-4 w-4 mr-2" />
              Start Engine
            </Button>
          )}
        </div>
      </div>

      {/* Connection Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* TWS Connection Status */}
        <Card className={`border ${twsStatus?.connected ? 'border-green-500 bg-green-500/5' : 'border-slate-700'}`}>
          <CardContent className="pt-6">
            <div className="flex flex-col gap-3">
              <div className="flex items-center justify-between gap-4 min-w-0">
                <div className="flex items-center gap-3 min-w-0">
                  {twsStatus?.connected ? (
                    <Wifi className="h-5 w-5 shrink-0 text-green-500 animate-pulse" />
                  ) : (
                    <WifiOff className="h-5 w-5 shrink-0 text-slate-500" />
                  )}
                  <div className="min-w-0">
                    <p className="font-medium">
                      {twsStatus?.connected ? 'TWS Connected' : 'TWS Disconnected'}
                    </p>
                    <p className="text-xs text-slate-400">
                      {twsStatus?.host}:{twsStatus?.port}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <Dialog open={showTWSConfig} onOpenChange={setShowTWSConfig}>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-blue-500 hover:text-blue-600"
                        title="Configure host/port"
                      >
                        <Settings className="h-4 w-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Configure TWS Connection</DialogTitle>
                        <DialogDescription>
                          Host and port for IB Gateway (leave host blank for localhost).
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="tws-host">Host</Label>
                          <Input
                            id="tws-host"
                            placeholder="localhost or e.g. X.tcp.ngrok.io"
                            value={twsHost}
                            onChange={(e) => setTwsHost(e.target.value)}
                          />
                        </div>
                        <div>
                          <Label htmlFor="tws-port">Port</Label>
                          <Input
                            id="tws-port"
                            type="number"
                            placeholder="5000"
                            value={twsPort}
                            onChange={(e) => setTwsPort(e.target.value)}
                          />
                        </div>
                        <Button
                          onClick={handleConfigureTWS}
                          disabled={twsConfigureMutation.isPending}
                          className="w-full"
                        >
                          {twsConfigureMutation.isPending ? 'Configuring...' : 'Configure & Connect'}
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                  {twsStatus?.connected ? (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => twsDisconnectMutation.mutate()}
                      disabled={twsDisconnectMutation.isPending}
                      className="text-red-500 hover:text-red-600"
                    >
                      Disconnect
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      onClick={handleConnectTWS}
                      disabled={twsConnecting || twsConnectMutation.isPending}
                      className="bg-green-600 hover:bg-green-700 text-white shrink-0"
                    >
                      {twsConnecting || twsConnectMutation.isPending ? 'Connecting...' : 'Connect'}
                    </Button>
                  )}
                </div>
              </div>
              {!twsStatus?.connected && (
                <div className="text-xs text-slate-500 space-y-2 mt-2">
                  {twsStatus?.error && (
                    <p className="text-amber-300 font-medium">
                      {twsStatus.error}
                    </p>
                  )}
                  {gatewayDiagnostic && gatewayDiagnostic.accountsStatus !== 200 && (
                    <div className="rounded-md bg-slate-800/80 border border-slate-600 p-3 space-y-2">
                      <p className="text-slate-300 font-medium">
                        Status {String(gatewayDiagnostic.accountsStatus)}. Cookie in .env.local: {gatewayDiagnostic.cookieSet ? 'set' : 'not set'}.
                      </p>
                      <p className="text-amber-300 font-medium">Do this:</p>
                      <ol className="list-decimal list-inside space-y-1 text-amber-200/90 text-xs">
                        <li>Wait 2 minutes without clicking Connect (polling is slowed so the Gateway can recover).</li>
                        <li>Log in at <strong>http://localhost:5000</strong>. Get the <code className="bg-slate-700 px-1 rounded">api</code> cookie: F12 → Application → Cookies → localhost:5000, or Gateway Settings → API.</li>
                        <li>Add <code className="bg-slate-700 px-1 rounded">IB_GATEWAY_COOKIE=api=YOUR_VALUE</code> to <code className="bg-slate-700 px-1 rounded">.env.local</code> in the project root.</li>
                        <li>Restart the server (Ctrl+C, then <code className="bg-slate-700 px-1 rounded">pnpm dev</code>). Wait 2 minutes, then click Connect once.</li>
                      </ol>
                    </div>
                  )}
                  {(twsStatus?.errorCode === '401' || twsStatus?.errorCode === '400') && !gatewayDiagnostic && (
                    <p className="text-amber-400/90">
                      <strong>Cookie required:</strong> The server cannot use your browser login. Log in at <strong>http://localhost:5000</strong>, copy the <code className="bg-slate-800 px-1 rounded">api</code> cookie (DevTools → Application → Cookies → localhost:5000), add <code className="bg-slate-800 px-1 rounded">IB_GATEWAY_COOKIE=api=YOUR_VALUE</code> to <code className="bg-slate-800 px-1 rounded">.env.local</code>, then restart the server.
                    </p>
                  )}
                  {twsStatus?.errorCode === 'HTTP_429' && !gatewayDiagnostic?.fixSteps?.length && (
                    <p className="text-amber-400/90">
                      <strong>Rate limit (429):</strong> Wait 1–2 minutes, then click <strong>Connect</strong> again.
                    </p>
                  )}
                  <p className="text-slate-500">Optional: run IB Gateway on the host:port above, or use the gear to change it. Paper trading works without TWS.</p>
                  <p className="text-slate-500 mt-1">If nothing works: in the project folder run <code className="bg-slate-800 px-1 rounded">pnpm run check:gateway</code> — it prints exactly what’s wrong and what to do. See <strong>IF_NOTHING_WORKS.md</strong>.</p>
                  <p className="text-slate-500 mt-1">Check the terminal where <code className="bg-slate-800 px-1 rounded">pnpm dev</code> runs for <code className="bg-slate-800 px-1 rounded">[IB]</code> and <code className="bg-slate-800 px-1 rounded">[Env] IB_GATEWAY_COOKIE present:</code>.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Gateway Status Card */}
        <Card className={`border ${gatewayMode?.isLiveMode ? 'border-green-500 bg-green-500/5' : 'border-slate-700'}`}>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {gatewayMode?.isLiveMode ? (
                  <Wifi className="h-5 w-5 text-green-500 animate-pulse" />
                ) : (
                  <WifiOff className="h-5 w-5 text-slate-500" />
                )}
                <div>
                  <p className="font-medium">
                    {gatewayMode?.isLiveMode ? 'Live Trading' : 'Paper Trading'}
                  </p>
                  <p className="text-xs text-slate-400">
                    {gatewayStatus?.isConnected ? 'Gateway Connected' : 'Simulation Mode'}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {gatewayMode?.isLiveMode ? (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => disableGatewayMutation.mutate()}
                    disabled={disableGatewayMutation.isPending}
                  >
                    Disable
                  </Button>
                ) : (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => enableGatewayMutation.mutate()}
                    disabled={enableGatewayMutation.isPending}
                  >
                    Enable
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Engine Status */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Engine Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-sm text-slate-400">Status</p>
              <Badge className={state?.isRunning ? 'bg-green-600' : 'bg-red-600'}>
                {state?.isRunning ? 'Running' : 'Stopped'}
              </Badge>
            </div>
            <div>
              <p className="text-sm text-slate-400">Strategy</p>
              <p className="text-lg font-semibold capitalize">{(state?.strategyType ?? "adaptive").replace(/_/g, " ")}</p>
              {currentStrategyConfig && (
                <div className="text-xs text-slate-400 mt-1 space-y-0.5">
                  <p><span className="text-slate-500">TP:</span> {currentStrategyConfig.takeProfitDescription}</p>
                  <p><span className="text-slate-500">SL:</span> {currentStrategyConfig.stopLossDescription}</p>
                </div>
              )}
            </div>
            <div>
              <p className="text-sm text-slate-400">Current Regime</p>
              <p className="text-lg font-semibold">{state?.currentRegime || 'N/A'}</p>
              {state?.cycleCount !== undefined && (
                <p className="text-xs text-slate-500 mt-1">Cycles: {state.cycleCount}</p>
              )}
            </div>
            <div>
              <p className="text-sm text-slate-400">Active Positions</p>
              <p className="text-lg font-semibold">{state?.positions?.filter((p: any) => p.status === 'open')?.length || positions?.length || 0}</p>
            </div>
            <div>
              <p className="text-sm text-slate-400">Daily P&L (realized)</p>
              <p className={`text-lg font-semibold ${(state?.dayPnL || 0) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {formatCurrency(state?.dayPnL ?? 0)}
              </p>
            </div>
            <div>
              <p className="text-sm text-slate-400">Unrealized P&L</p>
              <p className={`text-lg font-semibold ${(state?.unrealizedPnL ?? 0) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {formatCurrency(state?.unrealizedPnL ?? 0)}
              </p>
            </div>
            <div>
              <p className="text-sm text-slate-400">Total P&L</p>
              <p className={`text-lg font-semibold ${((state?.totalPnL ?? 0) + (state?.unrealizedPnL ?? 0)) >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {formatCurrency((state?.totalPnL ?? 0) + (state?.unrealizedPnL ?? 0))}
              </p>
              {state?.lastUpdate && (
                <p className="text-xs text-slate-500 mt-1">
                  Updated: {new Date(state.lastUpdate).toLocaleTimeString()}
                </p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs for detailed views */}
      <Tabs defaultValue="performance" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="positions">Positions</TabsTrigger>
          <TabsTrigger value="trades">Recent Trades</TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="space-y-4">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle>Performance Metrics</CardTitle>
              <CardDescription>
                {performance?.totalTrades ? `From ${performance.totalTrades} closed trade(s).` : "No closed trades yet — metrics update when positions close."}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <p className="text-sm text-slate-400">Closed Trades</p>
                  <p className="text-2xl font-bold">{performance?.totalTrades ?? 0}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-400">Win Rate</p>
                  <p className="text-2xl font-bold text-green-400">{formatPercent(performance?.winRate ?? 0)}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-400">Sharpe Ratio</p>
                  <p className="text-2xl font-bold">{(performance?.sharpeRatio ?? 0).toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-400">Profit Factor</p>
                  <p className="text-2xl font-bold text-blue-400">{(performance?.profitFactor ?? 0).toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-sm text-slate-400">Max Drawdown</p>
                  <p className="text-2xl font-bold text-red-400">{formatPercent(performance?.maxDrawdown ?? 0)}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="positions" className="space-y-4">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle>Open Positions</CardTitle>
              <CardDescription>
                Autonomous engine positions. Start the engine to see trades here; they also appear on the Execution page.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {positions && positions.length > 0 ? (
                <div className="space-y-2">
                  {positions.map((pos: any, idx: number) => (
                    <div key={pos.id || idx} className="flex justify-between items-center p-3 bg-slate-700 rounded">
                      <div>
                        <span className="font-medium">{pos.symbol}</span>
                        <span className="text-slate-400 ml-2">{pos.strike} {pos.optionType} x{pos.quantity}</span>
                        <span className="text-slate-500 ml-2">@ {formatCurrency(pos.entryPrice)}</span>
                      </div>
                      <span className={(pos.unrealizedPnL ?? 0) >= 0 ? 'text-green-400' : 'text-red-400'}>
                        {formatCurrency(pos.unrealizedPnL ?? 0)} unrealized
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-slate-400 border border-dashed border-slate-600 rounded-lg">
                  <p className="font-medium">No open positions</p>
                  <p className="text-sm mt-1">Start the engine above. When it opens positions, they appear here and on the Execution page.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trades" className="space-y-4">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle>Recent Trades</CardTitle>
              <CardDescription>
                Autonomous engine trade log. Also visible on the Execution page.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {recentTrades && recentTrades.length > 0 ? (
                <div className="space-y-2">
                  {recentTrades.map((trade: any, idx: number) => (
                    <div key={trade.id || idx} className="flex justify-between items-center p-3 bg-slate-700 rounded text-sm">
                      <div>
                        <p className="font-medium">{trade.symbol}</p>
                        <p className="text-xs text-slate-400">{trade.action} @ {formatTime(trade.timestamp)}</p>
                        <p className="text-xs text-slate-500">{trade.reason}</p>
                      </div>
                      <p className="text-slate-400 text-xs">{trade.price ? formatCurrency(trade.price) : '—'}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-slate-400 border border-dashed border-slate-600 rounded-lg">
                  <p className="font-medium">No recent trades</p>
                  <p className="text-sm mt-1">Start the engine. When it opens or closes positions, they appear here and on Execution.</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Last Opportunities Found */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Market Opportunities Found
              </CardTitle>
              <CardDescription>
                {lastOpportunities?.count || 0} opportunities found in last scan
                {lastOpportunities?.lastScanTime && (
                  <span className="ml-2 text-xs">
                    ({(new Date(lastOpportunities.lastScanTime).toLocaleTimeString())})
                  </span>
                )}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {lastOpportunities && lastOpportunities.opportunities.length > 0 ? (
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {lastOpportunities.opportunities.map((opp: any, idx: number) => (
                    <div key={idx} className="p-2 bg-slate-700 rounded text-sm">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{opp.symbol}</span>
                        <Badge className={opp.opportunity.score >= 85 ? 'bg-green-600' : 'bg-yellow-600'}>
                          Score: {opp.opportunity.score.toFixed(0)}
                        </Badge>
                      </div>
                      <div className="text-xs text-slate-400 mt-1">
                        Win Prob: {(opp.opportunity.winProbability * 100).toFixed(1)}% | 
                        Expected Return: {(opp.opportunity.expectedReturn * 100).toFixed(1)}% |
                        Regime: {opp.regime}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-slate-400">No opportunities found yet. Engine may be scanning...</p>
              )}
            </CardContent>
          </Card>

          {/* Engine Activity Logs */}
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Engine Activity Logs
              </CardTitle>
              <CardDescription>Real-time engine activity and debugging information</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-slate-900 rounded p-4 max-h-96 overflow-y-auto font-mono text-xs">
                {engineLogs && engineLogs.length > 0 ? (
                  <div className="space-y-1">
                    {engineLogs.slice().reverse().map((log: string, idx: number) => (
                      <div key={idx} className="text-slate-300 whitespace-pre-wrap">
                        {log}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-slate-500">No logs yet. Engine may not be running.</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
