/**
 * Real-Time Service
 * Manages WebSocket connections for live dashboard updates
 * Broadcasts market data, regime changes, signals, and trade updates
 */

import { Server as SocketIOServer } from "socket.io";
import { Server as HTTPServer } from "http";
import * as marketDataService from "./marketDataService";
import * as services from "./services";

export interface RealtimeUpdate {
  type:
    | "market_data"
    | "regime_change"
    | "signal_generated"
    | "trade_executed"
    | "position_update"
    | "risk_alert";
  timestamp: Date;
  data: any;
}

export class RealtimeService {
  private io: SocketIOServer;
  private pollingTimer: ReturnType<typeof setInterval> | null = null;
  private activeSymbols: Set<string> = new Set();
  private lastRegimeState: Map<string, any> = new Map();

  constructor(httpServer: HTTPServer) {
    this.io = new SocketIOServer(httpServer, {
      cors: {
        origin: "*",
        methods: ["GET", "POST"],
      },
      transports: ["websocket", "polling"],
    });

    this.setupEventHandlers();
  }

  private setupEventHandlers(): void {
    this.io.on("connection", (socket: any) => {
      console.log(`[Realtime] Client connected: ${socket.id}`);

      // Handle subscription to symbol updates
      socket.on("subscribe", (symbols: string[]) => {
        symbols.forEach((symbol) => this.activeSymbols.add(symbol));
        console.log(`[Realtime] Subscribed to: ${symbols.join(", ")}`);

        // Start polling if not already running
        if (!this.pollingTimer && this.activeSymbols.size > 0) {
          this.startPolling();
        }
      });

      // Handle unsubscription
      socket.on("unsubscribe", (symbols: string[]) => {
        symbols.forEach((symbol) => this.activeSymbols.delete(symbol));
        console.log(`[Realtime] Unsubscribed from: ${symbols.join(", ")}`);

        // Stop polling if no more subscribers
        if (this.activeSymbols.size === 0 && this.pollingTimer) {
          this.stopPolling();
        }
      });

      // Handle disconnect
      socket.on("disconnect", () => {
        console.log(`[Realtime] Client disconnected: ${socket.id}`);
      });
    });
  }

  private startPolling(): void {
    console.log("[Realtime] Starting market data polling");

    this.pollingTimer = setInterval(async () => {
      try {
        await this.pollMarketData();
      } catch (error) {
        console.error("[Realtime] Polling error:", error);
      }
    }, 2000); // Poll every 2 seconds
  }

  private stopPolling(): void {
    if (this.pollingTimer) {
      clearInterval(this.pollingTimer);
      this.pollingTimer = null;
      console.log("[Realtime] Stopped market data polling");
    }
  }

  private async pollMarketData(): Promise<void> {
    const symbols = Array.from(this.activeSymbols);

    for (const symbol of symbols) {
      try {
        // Fetch current market snapshot
        const snapshot = await marketDataService.getMarketSnapshot(symbol);

        // Broadcast market data update
        this.broadcast({
          type: "market_data",
          timestamp: new Date(),
          data: {
            symbol,
            price: snapshot.price,
            bid: snapshot.bid,
            ask: snapshot.ask,
            volume: snapshot.volume,
          },
        });

        // Fetch option chain
        const chain = await marketDataService.getOptionChain(symbol);

        // Analyze regime with correct parameters
        const regimeState = services.analyzeRegime(
          snapshot.price,
          0.25, // IV
          0.2, // RV
          0.5, // GEX
          0.5, // DEX
          1000000, // sweep volume
          30, // days to opex
          0 // earnings flag (0 = no earnings)
        );

        // Detect regime changes
        const lastRegime = this.lastRegimeState.get(symbol);
        if (lastRegime && lastRegime.regime !== regimeState.regime) {
          this.broadcast({
            type: "regime_change",
            timestamp: new Date(),
            data: {
              symbol,
              previousRegime: lastRegime.regime,
              newRegime: regimeState.regime,
              lsIndex: regimeState.liquidityStressIndex,
            },
          });
        }

        this.lastRegimeState.set(symbol, regimeState);

        // Generate signals
        const regimeCode = regimeState.regime === "bull_vol_expansion" ? 1 : regimeState.regime === "bull_vol_compression" ? 2 : regimeState.regime === "bear_vol_expansion" ? 3 : 4;
        const structuralSignal = services.generateFlowSignal(
          snapshot.price,
          0.25,
          0.2,
          regimeCode
        );
        const flowSignal = services.generateFlowSignal(
          1000000,
          500000,
          0.5,
          0.3
        );
        const signals = [structuralSignal, flowSignal].filter((s: any) => s !== null);

        if (signals.length > 0) {
          this.broadcast({
            type: "signal_generated",
            timestamp: new Date(),
            data: {
              symbol,
              signals: signals.map((s: any) => ({
                class: s.class,
                confidence: s.confidence,
                expectedMove: s.expectedMove,
              })),
            },
          });
        }
      } catch (error) {
        console.error(`[Realtime] Error polling ${symbol}:`, error);
      }
    }
  }

  /**
   * Broadcast update to all connected clients
   */
  public broadcast(update: RealtimeUpdate): void {
    this.io.emit("update", update);
  }

  /**
   * Broadcast to specific room/symbol
   */
  public broadcastToSymbol(symbol: string, update: RealtimeUpdate): void {
    this.io.to(symbol).emit("update", update);
  }

  /**
   * Notify trade execution
   */
  public notifyTradeExecution(tradeData: any): void {
    this.broadcast({
      type: "trade_executed",
      timestamp: new Date(),
      data: tradeData,
    });
  }

  /**
   * Notify position update
   */
  public notifyPositionUpdate(positionData: any): void {
    this.broadcast({
      type: "position_update",
      timestamp: new Date(),
      data: positionData,
    });
  }

  /**
   * Notify risk alert
   */
  public notifyRiskAlert(alertData: any): void {
    this.broadcast({
      type: "risk_alert",
      timestamp: new Date(),
      data: alertData,
    });
  }

  /**
   * Get connection stats
   */
  public getStats() {
    return {
      connectedClients: this.io.engine.clientsCount,
      activeSymbols: Array.from(this.activeSymbols),
      pollingActive: this.pollingTimer !== null,
    };
  }

  /**
   * Gracefully shutdown
   */
  public shutdown(): void {
    this.stopPolling();
    this.io.close();
    console.log("[Realtime] Service shutdown complete");
  }
}

// Global instance
let realtimeService: RealtimeService | null = null;

export function initializeRealtimeService(httpServer: HTTPServer): RealtimeService {
  if (!realtimeService) {
    realtimeService = new RealtimeService(httpServer);
  }
  return realtimeService;
}

export function getRealtimeService(): RealtimeService | null {
  return realtimeService;
}
