/**
 * Data Validation
 * Validates all inputs and market data before use
 */

export interface ValidationResult {
  valid: boolean;
  errors: string[];
}

/**
 * Validate market data
 */
export function validateMarketData(data: any): ValidationResult {
  const errors: string[] = [];

  if (!data) {
    return { valid: false, errors: ['Market data is null or undefined'] };
  }

  if (typeof data.price !== 'number' || data.price <= 0) {
    errors.push('Invalid price: must be a positive number');
  }

  if (data.volume !== undefined && (typeof data.volume !== 'number' || data.volume < 0)) {
    errors.push('Invalid volume: must be a non-negative number');
  }

  if (data.changePercent !== undefined && (typeof data.changePercent !== 'number' || Math.abs(data.changePercent) > 100)) {
    errors.push('Invalid changePercent: must be between -100 and 100');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Validate options data
 */
export function validateOptionsData(data: any): ValidationResult {
  const errors: string[] = [];

  if (!data) {
    return { valid: false, errors: ['Options data is null or undefined'] };
  }

  if (data.impliedVolatility !== undefined) {
    if (typeof data.impliedVolatility !== 'number' || data.impliedVolatility < 0 || data.impliedVolatility > 5) {
      errors.push('Invalid impliedVolatility: must be between 0 and 5 (0-500%)');
    }
  }

  if (data.ivRank !== undefined) {
    if (typeof data.ivRank !== 'number' || data.ivRank < 0 || data.ivRank > 100) {
      errors.push('Invalid ivRank: must be between 0 and 100');
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Validate position size inputs
 */
export function validatePositionSizeInputs(inputs: any): ValidationResult {
  const errors: string[] = [];

  if (!inputs) {
    return { valid: false, errors: ['Position size inputs are null or undefined'] };
  }

  if (typeof inputs.accountBalance !== 'number' || inputs.accountBalance <= 0) {
    errors.push('Invalid accountBalance: must be a positive number');
  }

  if (typeof inputs.optionPrice !== 'number' || inputs.optionPrice <= 0) {
    errors.push('Invalid optionPrice: must be a positive number');
  }

  if (inputs.winProbability !== undefined) {
    if (typeof inputs.winProbability !== 'number' || inputs.winProbability < 0 || inputs.winProbability > 1) {
      errors.push('Invalid winProbability: must be between 0 and 1');
    }
  }

  if (inputs.maxRiskPerTrade !== undefined) {
    if (typeof inputs.maxRiskPerTrade !== 'number' || inputs.maxRiskPerTrade < 0 || inputs.maxRiskPerTrade > 1) {
      errors.push('Invalid maxRiskPerTrade: must be between 0 and 1 (0-100%)');
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Validate symbol
 */
export function validateSymbol(symbol: string): ValidationResult {
  const errors: string[] = [];

  if (!symbol || typeof symbol !== 'string') {
    errors.push('Symbol must be a non-empty string');
  } else if (symbol.length > 10) {
    errors.push('Symbol must be 10 characters or less');
  } else if (!/^[A-Z0-9.^]+$/.test(symbol)) {
    errors.push('Symbol contains invalid characters (only letters, numbers, dots, and ^ allowed)');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Validate price
 */
export function validatePrice(price: number): ValidationResult {
  const errors: string[] = [];

  if (typeof price !== 'number') {
    errors.push('Price must be a number');
  } else if (price <= 0) {
    errors.push('Price must be positive');
  } else if (price > 1000000) {
    errors.push('Price seems unreasonably high (>$1M)');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}
