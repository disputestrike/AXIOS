/**
 * IV surface — polynomial fit (polyfit), fitIVSurface, getTermStructure.
 * Run: pnpm test -- --grep "polyfit"
 */
import { describe, it, expect } from "vitest";
import {
  fitIVSurface,
  predictIVAtStrike,
  getTermStructure,
  setIVSurfaceLastCalibration,
  getIVSurfaceHealth,
  type IVSurfacePoint,
} from "./iv-surface-analyzer";

describe("polyfit — IV surface polynomial fit", () => {
  it("polyfit: fitIVSurface produces fitQuality (R²-like) for synthetic data", () => {
    const points: IVSurfacePoint[] = [
      { strike: 95, ivCall: 0.22, ivPut: 0.24, moneyness: 95 / 100, daysToExpiry: 30 },
      { strike: 98, ivCall: 0.21, ivPut: 0.22, moneyness: 98 / 100, daysToExpiry: 30 },
      { strike: 100, ivCall: 0.20, ivPut: 0.21, moneyness: 1, daysToExpiry: 30 },
      { strike: 102, ivCall: 0.21, ivPut: 0.22, moneyness: 102 / 100, daysToExpiry: 30 },
      { strike: 105, ivCall: 0.22, ivPut: 0.23, moneyness: 105 / 100, daysToExpiry: 30 },
    ];
    const surface = fitIVSurface(points, "2025-03-21", 100);
    expect(surface.expiry).toBe("2025-03-21");
    expect(surface.spotPrice).toBe(100);
    expect(surface.callPolyCoeffs.length).toBeGreaterThan(0);
    expect(surface.putPolyCoeffs.length).toBeGreaterThan(0);
    expect(surface.fitQuality).toBeGreaterThanOrEqual(0);
    expect(surface.fitQuality).toBeLessThanOrEqual(1);
  });

  it("polyfit: predictIVAtStrike returns positive IV", () => {
    const points: IVSurfacePoint[] = [
      { strike: 98, ivCall: 0.21, ivPut: 0.22, moneyness: 0.98, daysToExpiry: 30 },
      { strike: 100, ivCall: 0.20, ivPut: 0.21, moneyness: 1, daysToExpiry: 30 },
      { strike: 102, ivCall: 0.21, ivPut: 0.22, moneyness: 1.02, daysToExpiry: 30 },
      { strike: 105, ivCall: 0.22, ivPut: 0.23, moneyness: 1.05, daysToExpiry: 30 },
    ];
    const surface = fitIVSurface(points, "2025-03-21", 100);
    const ivCall = predictIVAtStrike(surface, 100, "call");
    const ivPut = predictIVAtStrike(surface, 100, "put");
    expect(ivCall).toBeGreaterThan(0.01);
    expect(ivPut).toBeGreaterThan(0.01);
  });

  it("polyfit: getTermStructure returns expiryDates and atmIV arrays", () => {
    const points1: IVSurfacePoint[] = [
      { strike: 100, ivCall: 0.20, ivPut: 0.21, moneyness: 1, daysToExpiry: 30 },
      { strike: 102, ivCall: 0.21, ivPut: 0.22, moneyness: 1.02, daysToExpiry: 30 },
      { strike: 98, ivCall: 0.21, ivPut: 0.22, moneyness: 0.98, daysToExpiry: 30 },
      { strike: 105, ivCall: 0.22, ivPut: 0.23, moneyness: 1.05, daysToExpiry: 30 },
    ];
    const points2: IVSurfacePoint[] = [
      { strike: 100, ivCall: 0.19, ivPut: 0.20, moneyness: 1, daysToExpiry: 60 },
      { strike: 102, ivCall: 0.20, ivPut: 0.21, moneyness: 1.02, daysToExpiry: 60 },
      { strike: 98, ivCall: 0.20, ivPut: 0.21, moneyness: 0.98, daysToExpiry: 60 },
      { strike: 105, ivCall: 0.21, ivPut: 0.22, moneyness: 1.05, daysToExpiry: 60 },
    ];
    const s1 = fitIVSurface(points1, "2025-03-21", 100);
    const s2 = fitIVSurface(points2, "2025-04-18", 100);
    const term = getTermStructure([s1, s2]);
    expect(term.expiryDates.length).toBe(2);
    expect(term.atmIV.length).toBe(2);
    expect(term.skew.length).toBe(2);
    expect(term.fitQuality.length).toBe(2);
  });

  it("polyfit: IV surface health updates after setIVSurfaceLastCalibration", () => {
    setIVSurfaceLastCalibration(0.96);
    const health = getIVSurfaceHealth();
    expect(health.lastCalibration).toBeGreaterThan(0);
    expect(health.avgRsquared).toBe(0.96);
    expect(["ok", "stale", "never"]).toContain(health.status);
  });
});
