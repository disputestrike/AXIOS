# How to Use the New Improvements

## Quick Integration Guide

### 1. Replace Basic Signal Generation

**Before:**
```typescript
const signal = generateDealerGammaSignal(gex, vega, price, iv);
```

**After:**
```typescript
import { generateAdvancedSignal } from './advanced-signals';
import { getRealStockPrice, getRealOptionsData } from './real-market-data';

const priceData = await getRealStockPrice(symbol);
const optionsData = await getRealOptionsData(symbol);
const signal = await generateAdvancedSignal(symbol, priceData, optionsData, historicalData);
```

### 2. Use Optimal Position Sizing

**Before:**
```typescript
const maxRisk = accountBalance * 0.01;
const quantity = Math.floor(maxRisk / (optionPrice * 100));
```

**After:**
```typescript
import { calculateOptimalPositionSize } from './position-sizing';

const positionSize = calculateOptimalPositionSize({
  accountBalance,
  winProbability: signal.winProbability,
  avgWinSize: signal.expectedMove / 100,
  avgLossSize: signal.expectedMove * 0.4 / 100,
  currentDrawdown,
  volatility,
  correlation,
  maxRiskPerTrade: 0.01,
  optionPrice,
  strike,
  currentPrice,
});

const quantity = positionSize.quantity;
```

### 3. Add Multi-Timeframe Analysis

**Before:**
```typescript
// Single timeframe analysis
const trend = await getRealTrend(symbol, 20);
```

**After:**
```typescript
import { analyzeMultiTimeframe } from './multi-timeframe';

const timeframeAnalysis = await analyzeMultiTimeframe(symbol);

if (timeframeAnalysis.overallConfidence < 0.6 || timeframeAnalysis.alignment < 0.6) {
  // Skip trade - timeframes not aligned
  return;
}

// Use timeframe targets
const priceTarget = timeframeAnalysis.priceTargets.medium;
const stopLoss = timeframeAnalysis.stopLoss;
```

### 4. Implement Adaptive Risk Management

**Before:**
```typescript
const MAX_RISK = 0.01; // Fixed 1%
const MAX_POSITIONS = 3; // Fixed
```

**After:**
```typescript
import { calculateAdaptiveRisk, calculatePerformanceMetrics, determineMarketConditions } from './adaptive-risk';

const performance = calculatePerformanceMetrics(trades, currentEquity, initialEquity);
const marketConditions = determineMarketConditions(vix, marketTrend, positions);
const riskAdjustment = calculateAdaptiveRisk(performance, marketConditions);

const adjustedRisk = 0.01 * riskAdjustment.riskMultiplier;
const adjustedMaxPositions = riskAdjustment.maxPositions;
const minScore = riskAdjustment.minScoreThreshold;
```

### 5. Use Dynamic Exit Strategies

**Before:**
```typescript
if (currentPrice >= takeProfitPrice) {
  exit();
} else if (currentPrice <= stopLossPrice) {
  exit();
}
```

**After:**
```typescript
import { determineExitStrategy } from './dynamic-exits';

const exitDecision = determineExitStrategy(
  {
    symbol,
    entryPrice,
    currentPrice,
    entryTime,
    currentTime: Date.now(),
    takeProfitPrice,
    stopLossPrice,
    trailingStopPrice,
    highWaterMark,
    unrealizedPnL,
    unrealizedPnLPercent,
    optionType,
    daysToExpiry,
    regime,
    signalClass,
    volatility,
    volume,
    avgVolume,
  },
  {
    vix,
    marketTrend,
    regime,
    timeOfDay,
  },
  {
    winRate,
    profitFactor,
    recentPerformance,
  }
);

if (exitDecision.action !== 'hold') {
  exit(exitDecision.exitPrice, exitDecision.reason);
}
```

---

## Complete Integration Example

```typescript
import { EnhancedTradingEngine } from './enhanced-trading-engine';

const engine = new EnhancedTradingEngine();

// Analyze opportunity
const analysis = await engine.analyzeOpportunity(opportunity);

if (analysis.shouldTrade) {
  // Open position with optimal sizing
  const position = {
    symbol: opportunity.symbol,
    entryPrice: optionPrice,
    currentPrice: optionPrice,
    quantity: analysis.positionSize.quantity,
    entryTime: Date.now(),
    signal: analysis.signal,
    timeframeAnalysis: analysis.timeframeAnalysis,
    positionSize: analysis.positionSize,
  };
  
  // Monitor position
  const exitDecision = await engine.determinePositionExit(position);
  
  if (exitDecision.action !== 'hold') {
    // Exit position
    closePosition(position, exitDecision.exitPrice);
  }
}
```

---

## Expected Improvements

After integration, you should see:

1. **Higher Win Rate** - Better entry timing from multi-timeframe
2. **Better Risk/Reward** - Optimal sizing from Kelly Criterion
3. **Lower Drawdowns** - Adaptive risk management
4. **More Profits** - Dynamic exits capture more gains
5. **Better Performance** - Pattern recognition finds better trades

---

## Testing

1. **Backtest** - Test on historical data first
2. **Paper Trade** - Validate in paper mode
3. **Monitor** - Track performance metrics
4. **Adjust** - Fine-tune parameters based on results

---

**Ready to integrate?** Start with one improvement at a time, test thoroughly, then add the next!
