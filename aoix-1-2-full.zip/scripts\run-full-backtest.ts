/**
 * Full backtest runner: historical (IB) + strategy backtests.
 * Run: pnpm backtest
 *
 * Regimes: backtest uses all 11 regimes for classification (crisis, liquidity_drought,
 * trending_bull, trending_bear, sector_rotation, bull/bear vol compression/expansion,
 * mean_reverting, chaotic). Default filter = only these 3 regimes take trades (best Sharpe/P&L).
 */

import { runHistoricalBacktest, runBacktest } from '../server/backtest-runner';
import type { HistoricalBacktestResult, BacktestResult } from '../server/backtest-runner';

/** Indices + tech + big names — more than 10 stocks for broader backtest. */
const ALL_SYMBOLS: readonly string[] = [
  'SPY', 'QQQ', 'IWM',           // indices
  'AAPL', 'MSFT', 'GOOGL', 'AMZN', 'META', 'NVDA', 'TSLA',  // tech / megacap
  'JPM', 'V', 'JNJ', 'UNH', 'HD', 'DIS', 'NFLX', 'AMD', 'INTC', 'CRM',
];
/** Single best growth pick: QQQ (Nasdaq 100) — aggressive, one symbol only. */
const GROWTH_ONE_SYMBOL = 'QQQ';
/** Symbols to backtest. BACKTEST_GROWTH=1 → one symbol (QQQ). Env BACKTEST_SYMBOLS overrides otherwise. */
const HISTORICAL_SYMBOLS: readonly string[] = (() => {
  if (process.env.BACKTEST_GROWTH === '1') return [GROWTH_ONE_SYMBOL];
  const env = process.env.BACKTEST_SYMBOLS?.trim();
  if (!env) return ALL_SYMBOLS;
  const lower = env.toLowerCase();
  if (lower === 'one' || lower === '1' || lower === 'best_one') return [GROWTH_ONE_SYMBOL];
  if (lower === 'best') return ['SPY', 'QQQ'];
  return env.split(',').map((s) => s.trim().toUpperCase()).filter(Boolean);
})();
/** 6 months ≈ 126 trading days, 12 months ≈ 252. Env BACKTEST_DAYS overrides (e.g. 126 or 252). */
const SIX_MONTHS_DAYS = 126;
const TWELVE_MONTHS_DAYS = 252;
const HISTORICAL_DAYS = process.env.BACKTEST_DAYS ? parseInt(process.env.BACKTEST_DAYS, 10) : TWELVE_MONTHS_DAYS;
/** Hold period in days. Default 3 = robust; BACKTEST_GROWTH=1 → 2. Env BACKTEST_HOLD_DAYS overrides. */
const HOLD_DAYS = process.env.BACKTEST_HOLD_DAYS
  ? Math.max(1, parseInt(process.env.BACKTEST_HOLD_DAYS, 10))
  : process.env.BACKTEST_GROWTH === '1' ? 2 : 3;
/** Starting capital: default $100k. Env BACKTEST_CAPITAL overrides (e.g. 1000 for $1k run). */
const DEFAULT_CAPITAL = 100_000;
const INITIAL_CAPITAL = process.env.BACKTEST_CAPITAL ? Math.max(1, parseInt(process.env.BACKTEST_CAPITAL, 10)) : DEFAULT_CAPITAL;
/** Below this, live options trading usually forces 1 contract = more than target risk per trade. */
const MIN_RECOMMENDED_LIVE_CAPITAL = 2_500;
/** When true, run both 6-month and 12-month backtests. */
const RUN_BOTH_6_AND_12 = process.env.BACKTEST_6_AND_12 === '1' || process.env.BACKTEST_6_AND_12 === 'true';

const STRATEGIES = ['wheel', 'short_term', 'iron_condor', 'adaptive'] as const;

/** Default: best-performing filter (bull + mean-revert + trending bull). Permanent default. */
const DEFAULT_BACKTEST_REGIMES: string[] = ['bull_vol_compression', 'mean_reverting', 'trending_bull'];

/** Regime filter: BACKTEST_REGIMES= unset → default (bull_vol_compression,mean_reverting,trending_bull); '' → all 11 regimes; or comma-separated list. */
const envRegimes = process.env.BACKTEST_REGIMES;
const PREFERRED_REGIMES: string[] | undefined =
  envRegimes === undefined
    ? DEFAULT_BACKTEST_REGIMES
    : envRegimes === ''
      ? undefined
      : envRegimes.split(',').map((s) => s.trim()).filter(Boolean);
const TRADE_ALL_DIRECTIONS = !PREFERRED_REGIMES?.length;
/** True when BACKTEST_REGIMES was not set, so we use the permanent default. */
const USING_DEFAULT_REGIMES = envRegimes === undefined;
/** Risk per trade. Default 0.008 (0.8%); BACKTEST_GROWTH=1 → 0.012 (1.2%). Env BACKTEST_RISK_PER_TRADE overrides. */
const RISK_PER_TRADE = process.env.BACKTEST_RISK_PER_TRADE
  ? parseFloat(process.env.BACKTEST_RISK_PER_TRADE)
  : process.env.BACKTEST_GROWTH === '1' ? 0.012 : 0.008;
/** Contracts per trade (env BACKTEST_CONTRACTS). Default 1; set to 10 for "trade 10 contracts". */
const CONTRACTS_PER_TRADE = process.env.BACKTEST_CONTRACTS ? Math.max(1, parseInt(process.env.BACKTEST_CONTRACTS, 10)) : 1;
/** When set, strategy backtest uses only the single highest explosive setup from scanner (one stop); skips historical run. */
const BACKTEST_ONE_STOP = process.env.BACKTEST_ONE_STOP === '1' || process.env.BACKTEST_ONE_STOP === 'true';
/** Max positions in strategy backtest when not one-stop. Env BACKTEST_MAX_POSITIONS overrides (e.g. 20). */
const MAX_POSITIONS = process.env.BACKTEST_MAX_POSITIONS ? Math.max(1, parseInt(process.env.BACKTEST_MAX_POSITIONS, 10)) : 5;

async function main() {
  console.log('═══════════════════════════════════════════════════════════════');
  console.log('  AOIX-1 FULL BACKTEST');
  console.log('═══════════════════════════════════════════════════════════════\n');
  if (process.env.BACKTEST_GROWTH === '1') {
    console.log('  🚀 Aggressive growth mode: ONE symbol (' + GROWTH_ONE_SYMBOL + '), 1.2% risk/trade, 2-day hold.\n');
  }
  if (INITIAL_CAPITAL < MIN_RECOMMENDED_LIVE_CAPITAL) {
    console.log('  ⚠️  Small-account note: Backtest uses $' + INITIAL_CAPITAL.toLocaleString() + '. For LIVE trading,');
    console.log('      brokers require 1 contract minimum; one contract often risks 5–20%+ of a small account.');
    console.log('      Consider $2,500+ to keep risk per trade near 0.8%, or trade only very cheap options.\n');
  }

  const runPeriod = (label: string, days: number): Promise<HistoricalBacktestResult[]> => {
    const results: HistoricalBacktestResult[] = [];
    return (async () => {
      for (const symbol of HISTORICAL_SYMBOLS) {
        process.stdout.write(`  ${symbol} (${days}d) ... `);
        try {
          const result = await runHistoricalBacktest(symbol, days, HOLD_DAYS, PREFERRED_REGIMES, true, RISK_PER_TRADE, CONTRACTS_PER_TRADE);
          results.push(result);
          if (result.success) {
            const endEquity = INITIAL_CAPITAL * (result.cumulativeGrowth ?? 1);
            const profit = endEquity - INITIAL_CAPITAL;
            const pct = result.totalReturnPercent ?? 0;
            console.log(
              `OK | trades=${result.trades} Sharpe=${result.sharpeRatio.toFixed(2)} maxDD=${result.maxDrawdownPercent.toFixed(1)}% win=${(result.winRate * 100).toFixed(1)}% | P&L $${profit >= 0 ? '+' : ''}${profit.toFixed(0)} (${pct >= 0 ? '+' : ''}${pct.toFixed(1)}%)`
            );
          } else {
            console.log('FAIL | ' + result.message);
          }
        } catch (e) {
          console.log('ERROR | ' + (e instanceof Error ? e.message : String(e)));
          results.push({
            success: false,
            symbol,
            days: 0,
            trades: 0,
            sharpeRatio: 0,
            maxDrawdownPercent: 0,
            winRate: 0,
            profitFactor: 0,
            regimeSummary: {},
            message: String(e),
            durationMs: 0,
          });
        }
      }
      return results;
    })();
  };

  const printSummary = (historicalResults: HistoricalBacktestResult[], periodLabel: string) => {
    console.log('\n  ' + periodLabel + ' (assuming $' + INITIAL_CAPITAL.toLocaleString() + ' starting capital):');
    console.log('  ' + '─'.repeat(90));
    let totalProfit = 0;
    for (const r of historicalResults) {
      if (r.success && r.cumulativeGrowth != null) {
        const endEquity = INITIAL_CAPITAL * r.cumulativeGrowth;
        const profit = endEquity - INITIAL_CAPITAL;
        totalProfit += profit;
        const pct = r.totalReturnPercent ?? 0;
        console.log(
          `  ${r.symbol.padEnd(6)} | trades=${String(r.trades).padStart(4)} | Sharpe=${r.sharpeRatio.toFixed(2).padStart(6)} | maxDD=${(r.maxDrawdownPercent.toFixed(1) + '%').padStart(6)} | win=${(r.winRate * 100).toFixed(1).padStart(5)}% | P&L $${(profit >= 0 ? '+' : '') + profit.toFixed(0).padStart(8)} (${(pct >= 0 ? '+' : '') + pct.toFixed(1)}%)`
        );
      }
    }
    if (historicalResults.filter((r) => r.success).length > 0) {
      console.log('  ' + '─'.repeat(90));
      const okResults = historicalResults.filter((r) => r.success);
      const n = okResults.length;
      const avgSharpe = n > 0 ? okResults.reduce((s, r) => s + r.sharpeRatio, 0) / n : 0;
      console.log(`  Combined: total simulated P&L ≈ $${totalProfit >= 0 ? '+' : ''}${totalProfit.toFixed(0)} across ${n} symbol${n > 1 ? 's' : ''}.`);
      if (n > 1) console.log(`  Portfolio (equal-weight) avg Sharpe: ${avgSharpe.toFixed(2)}.`);
      if (n === 1 && INITIAL_CAPITAL > 0) {
        const r = historicalResults.find((x) => x.success && x.cumulativeGrowth != null);
        if (r) console.log(`  → All $${INITIAL_CAPITAL.toLocaleString()} in ${r.symbol} for this period: $${(INITIAL_CAPITAL * (r.cumulativeGrowth! - 1)).toFixed(0)} P&L (${(r.totalReturnPercent ?? 0).toFixed(1)}%).`);
      } else if (n === 2 && INITIAL_CAPITAL > 0) {
        const [a, b] = historicalResults.filter((x) => x.success && x.cumulativeGrowth != null);
        if (a && b) {
          const half = INITIAL_CAPITAL / 2;
          const pa = half * (a.cumulativeGrowth! - 1);
          const pb = half * (b.cumulativeGrowth! - 1);
          console.log(`  → 50/50 split $${INITIAL_CAPITAL.toLocaleString()} (${a.symbol}+${b.symbol}): ~$${(pa + pb).toFixed(0)} P&L for the period.`);
        }
      }
      console.log('');
    }
  };

  /** Rough 1-week and 1-month $ projections from 12-month stats (single symbol, average pace). */
  function weeklyAndMonthlyProjection(results: HistoricalBacktestResult[], capital: number): void {
    const ok = results.filter((r) => r.success && r.trades >= 10 && r.totalReturnPercent != null);
    if (ok.length === 0 || capital <= 0) return;
    const avgTradesPerWeek = ok.reduce((s, r) => s + r.trades, 0) / ok.length / 52;
    const avgReturnPerTrade = ok.reduce((s, r) => s + (r.totalReturnPercent! / 100) / r.trades, 0) / ok.length;
    const weeklyPct = avgTradesPerWeek * avgReturnPerTrade;
    const monthlyPct = weeklyPct * (52 / 12);
    const weekLow = capital * Math.max(0, weeklyPct * 0.4);
    const weekHigh = capital * weeklyPct * 1.6;
    const monthLow = capital * Math.max(0, monthlyPct * 0.4);
    const monthHigh = capital * monthlyPct * 1.6;
    console.log('  📅 Rough projection (from 12‑month average, single symbol):');
    console.log('     1 week: ~$' + Math.round(weekLow) + '–$' + Math.round(weekHigh) + ' on $' + capital.toLocaleString());
    console.log('     1 month: ~$' + Math.round(monthLow) + '–$' + Math.round(monthHigh) + ' (actual results vary).\n');
  }

  // ─── Historical backtests (IB historical) ───
  let historicalResults: HistoricalBacktestResult[] = [];

  if (RUN_BOTH_6_AND_12) {
    console.log('─── Historical backtests: 6 months (~126 trading days) ───\n');
    if (TRADE_ALL_DIRECTIONS) console.log('  (Regime filter: none — trading all 11 regimes / all directions)\n');
    else if (PREFERRED_REGIMES?.length) console.log(`  (Regime filter: only ${PREFERRED_REGIMES.join(', ')}${USING_DEFAULT_REGIMES ? ' [default]' : ''})\n`);
    if (CONTRACTS_PER_TRADE > 1) console.log(`  (Contracts per trade: ${CONTRACTS_PER_TRADE})\n`);
    historicalResults = await runPeriod('6 months', SIX_MONTHS_DAYS);
    printSummary(historicalResults, '6-month summary');
    console.log('─── Historical backtests: 12 months (~252 trading days) ───\n');
    if (TRADE_ALL_DIRECTIONS) console.log('  (Regime filter: none — trading all 11 regimes / all directions)\n');
    else if (PREFERRED_REGIMES?.length) console.log(`  (Regime filter: only ${PREFERRED_REGIMES.join(', ')}${USING_DEFAULT_REGIMES ? ' [default]' : ''})\n`);
    const results12 = await runPeriod('12 months', TWELVE_MONTHS_DAYS);
    printSummary(results12, '12-month summary');
    weeklyProjection(results12, INITIAL_CAPITAL);
    historicalResults = results12; // use 12m for "best" below
  } else if (!BACKTEST_ONE_STOP) {
    const monthsLabel = HISTORICAL_DAYS >= 252 ? '12 months' : HISTORICAL_DAYS >= 126 ? '6 months' : HISTORICAL_DAYS + ' days';
    console.log('─── Historical backtests (' + monthsLabel + ', hold ' + HOLD_DAYS + ' days) ───\n');
    if (TRADE_ALL_DIRECTIONS) {
      console.log('  (Regime filter: none — trading all 11 regimes / all directions)\n');
    } else if (PREFERRED_REGIMES?.length) {
      const defaultNote = USING_DEFAULT_REGIMES ? ' [default]' : '';
      console.log(`  (Regime filter: only ${PREFERRED_REGIMES.join(', ')}${defaultNote})\n`);
    }
    if (CONTRACTS_PER_TRADE > 1) {
      console.log(`  (Contracts per trade: ${CONTRACTS_PER_TRADE})\n`);
    }
    historicalResults = await runPeriod(monthsLabel, HISTORICAL_DAYS);
    printSummary(historicalResults, 'Historical summary');
    if (HISTORICAL_DAYS >= 252 && historicalResults.some((r) => r.success)) {
      weeklyAndMonthlyProjection(historicalResults, INITIAL_CAPITAL);
    }
  }

  // ─── Strategy backtests (structure selection on current scan; 0 trades if no scan) ───
  if (BACKTEST_ONE_STOP) {
    console.log('\n─── One-stop backtest: scanning for highest explosive setup, then backtesting (max 1 position) ───\n');
    const { getMarketScanner } = await import('../server/market-scanner');
    const scanner = getMarketScanner();
    if (scanner.getStatus().totalOpportunities === 0) {
      console.log('  Running scan...');
      await scanner.scan();
    }
    const one = scanner.getHighestExplosiveSetup({ minWinProbability: 55, minScore: 50 });
    if (one) {
      console.log(`  Best one: ${one.symbol} (win ${((one.opportunity?.winProbability ?? 0) * 100).toFixed(0)}%, score ${one.opportunity?.score ?? 0}, regime ${one.regime})\n`);
    } else {
      console.log('  No opportunity met minWinProbability 55 / minScore 50. Proceeding with backtest.\n');
    }
  }
  console.log('\n─── Strategy backtests (wheel, short_term, iron_condor, adaptive — app strategy types) ───\n');
  const strategyResults: BacktestResult[] = [];

  for (const strategy of STRATEGIES) {
    process.stdout.write(`  ${strategy}${BACKTEST_ONE_STOP ? ' [one stop]' : ''} ... `);
    try {
      const result = await runBacktest({
        strategy,
        oneStop: BACKTEST_ONE_STOP,
        initialCapital: INITIAL_CAPITAL,
        maxPositions: BACKTEST_ONE_STOP ? 1 : MAX_POSITIONS,
      });
      strategyResults.push(result);
      if (result.success) {
        const pnl = result.estimatedPnl != null ? ` | Est. P&L $${result.estimatedPnl >= 0 ? '+' : ''}${result.estimatedPnl}` : '';
        const expRet = result.expectedReturnPercent != null ? ` expRet=${result.expectedReturnPercent.toFixed(1)}%` : '';
        console.log(
          `OK | evaluated=${result.opportunitiesEvaluated} trades=${result.simulatedTrades} win=${((result.winRate ?? 0) * 100).toFixed(0)}%${pnl}${expRet}`
        );
      } else {
        console.log('FAIL | ' + result.message);
      }
    } catch (e) {
      console.log('ERROR | ' + (e instanceof Error ? e.message : String(e)));
    }
  }

  console.log('\n═══════════════════════════════════════════════════════════════');
  console.log('  BACKTEST COMPLETE');
  console.log('═══════════════════════════════════════════════════════════════');
  const histOk = historicalResults.filter((r) => r.success).length;
  console.log(`  Historical: ${histOk}/${historicalResults.length} symbols OK`);
  console.log(`  Strategies: ${strategyResults.filter((r) => r.success).length}/${strategyResults.length} OK`);
  if (BACKTEST_ONE_STOP && strategyResults.some((r) => r.success && r.estimatedPnl != null)) {
    const first = strategyResults.find((r) => r.success && r.estimatedPnl != null);
    const totalEst = strategyResults.reduce((s, r) => s + (r.estimatedPnl ?? 0), 0);
    const avgEst = strategyResults.filter((r) => r.estimatedPnl != null).length ? totalEst / strategyResults.filter((r) => r.estimatedPnl != null).length : 0;
    console.log(`  One-stop ($${INITIAL_CAPITAL.toLocaleString()}): best ${first?.bestSymbol ?? '—'} | Est. P&L $${(first?.estimatedPnl ?? 0) >= 0 ? '+' : ''}${first?.estimatedPnl ?? 0} (≈ $${Math.round(avgEst)} avg across strategies)`);
  }
  if (historicalResults.some((r) => r.success)) {
    const best = historicalResults
      .filter((r) => r.success)
      .sort((a, b) => b.sharpeRatio - a.sharpeRatio)[0];
    if (best && best.cumulativeGrowth != null) {
      const profit = INITIAL_CAPITAL * (best.cumulativeGrowth - 1);
      console.log(`  Best historical: ${best.symbol} Sharpe=${best.sharpeRatio.toFixed(2)} maxDD=${best.maxDrawdownPercent.toFixed(1)}% | Simulated P&L $${profit >= 0 ? '+' : ''}${profit.toFixed(0)} (${(best.totalReturnPercent ?? 0) >= 0 ? '+' : ''}${(best.totalReturnPercent ?? 0).toFixed(1)}%)`);
    }
  }
  console.log('');
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
