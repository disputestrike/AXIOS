/**
 * Claude Validation — Approve / Reject / Modify generated trades.
 * Uses Anthropic Claude API for reasoning check on trade options.
 */

import { invokeClaude, getClaudeText, isClaudeConfigured } from "./_core/claude";
import type { GeneratedTradeOption } from "./catalyst-options-generation";

export type ValidationVerdict = "approve" | "reject" | "modify";

export interface ValidationResult {
  verdict: ValidationVerdict;
  reason: string;
  suggestedChanges?: string;
  /** Raw model response (for debugging) */
  rawResponse?: string;
}

/**
 * Validate a generated trade option with Claude. Returns approve / reject / modify + reason.
 */
export async function validateTradeWithClaude(
  trade: GeneratedTradeOption,
  context?: { regime?: string; recentPnL?: string }
): Promise<ValidationResult> {
  if (!isClaudeConfigured()) {
    return {
      verdict: "approve",
      reason: "Claude not configured; validation skipped.",
    };
  }

  const prompt = buildValidationPrompt(trade, context);
  try {
    const result = await invokeClaude({
      system: VALIDATION_SYSTEM_PROMPT,
      messages: [{ role: "user", content: prompt }],
      max_tokens: 1024,
    });
    const text = getClaudeText(result);
    return parseValidationResponse(text, result.content);
  } catch (e) {
    console.error("[TradeValidation] Claude error:", e);
    return {
      verdict: "reject",
      reason: "Risk check unavailable (network or API error). Try again or use 'Include market thesis' to trade without this check.",
      rawResponse: undefined,
    };
  }
}

const VALIDATION_SYSTEM_PROMPT = `You are a risk-aware options trade validator for a professional trading system. Your job is to review a single trade option and respond with exactly one of: APPROVE, REJECT, or MODIFY.

Output format (use this exact structure):
VERDICT: [APPROVE | REJECT | MODIFY]
REASON: [One to three sentences explaining why.]
If MODIFY, add:
SUGGESTED_CHANGES: [Specific changes: e.g. "Use longer DTE (21-30 days)" or "Prefer conservative tier".]

Consider: regime appropriateness, implied vs historical move alignment, catalyst quality, tier (conservative/balanced/aggressive) vs risk. Be concise.`;

function buildValidationPrompt(
  trade: GeneratedTradeOption,
  context?: { regime?: string; recentPnL?: string }
): string {
  const lines = [
    `Symbol: ${trade.symbol}`,
    `Tier: ${trade.tier}`,
    `Structure: ${trade.structureType} (${trade.direction})`,
    `Implied move: ${trade.impliedMovePercent}% | Historical proxy: ${trade.historicalMovePercent}% | Comparison: ${trade.moveComparison}`,
    `Win probability (scan): ${(trade.winProbability * 100).toFixed(1)}% | Expected return: ${trade.expectedReturn.toFixed(2)}%`,
    `Regime: ${trade.regime}`,
    `Catalysts: ${trade.catalystSummary}`,
  ];
  if (context?.regime) lines.push(`Context regime: ${context.regime}`);
  if (context?.recentPnL) lines.push(`Recent P/L context: ${context.recentPnL}`);
  return "Validate this trade option:\n\n" + lines.join("\n");
}

function parseValidationResponse(
  text: string,
  content: Array<{ type: string; text?: string }>
): ValidationResult {
  const raw = text.trim();
  const verdictMatch = raw.match(/\bVERDICT:\s*(APPROVE|REJECT|MODIFY)\b/i);
  const verdict = (verdictMatch ? verdictMatch[1].toLowerCase() : "approve") as ValidationVerdict;

  let reason = "";
  const reasonMatch = raw.match(/\bREASON:\s*([\s\S]*?)(?=SUGGESTED_CHANGES:|$)/i);
  if (reasonMatch) reason = reasonMatch[1].trim();
  else reason = raw.slice(0, 300);

  let suggestedChanges: string | undefined;
  const changeMatch = raw.match(/\bSUGGESTED_CHANGES:\s*([\s\S]*?)$/i);
  if (changeMatch) suggestedChanges = changeMatch[1].trim();

  return {
    verdict: verdict === "reject" || verdict === "modify" ? verdict : "approve",
    reason: reason || "No reason given.",
    suggestedChanges,
    rawResponse: raw.slice(0, 2000),
  };
}

/**
 * Check if Claude validation is available.
 */
export function isValidationAvailable(): boolean {
  return isClaudeConfigured();
}
