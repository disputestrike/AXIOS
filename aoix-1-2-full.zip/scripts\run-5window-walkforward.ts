/**
 * 5-window walk-forward backtest — robustness validation
 * Run: pnpm backtest:5window
 * Writes: backtest-results/5window-walkforward.json
 */
import { runMultiWindowWalkForward } from '../server/backtest-runner';
import { mkdir, writeFile } from 'fs/promises';
import { join } from 'path';

const SYMBOL = process.env.WALKFORWARD_SYMBOL ?? 'SPY';
const NUM_WINDOWS = parseInt(process.env.WALKFORWARD_WINDOWS ?? '5', 10);
const OUT_DIR = process.env.BACKTEST_RESULTS_DIR ?? join(process.cwd(), 'backtest-results');
const OUT_FILE = join(OUT_DIR, '5window-walkforward.json');

async function main() {
  console.log('[5-Window WF] Starting:', { symbol: SYMBOL, numWindows: NUM_WINDOWS });
  const result = await runMultiWindowWalkForward({
    symbol: SYMBOL,
    numWindows: NUM_WINDOWS,
    trainDays: 252,
    testDays: 84,
    stepDays: 84,
    holdDays: 5,
  });

  const summary = {
    success: result.success,
    symbol: result.symbol,
    numWindows: result.numWindows,
    meanTrainSharpe: result.meanTrainSharpe,
    meanTestSharpe: result.meanTestSharpe,
    avgCollapseRatio: result.avgCollapseRatio,
    robustness: result.robustness,
    durationMs: result.durationMs,
    message: result.message,
    windows: result.windows,
    timestamp: new Date().toISOString(),
  };

  await mkdir(OUT_DIR, { recursive: true });
  await writeFile(OUT_FILE, JSON.stringify(summary, null, 2), 'utf-8');
  console.log('[5-Window WF] Result:', result.message);
  console.log('[5-Window WF] Mean Train Sharpe:', result.meanTrainSharpe.toFixed(2));
  console.log('[5-Window WF] Mean Test Sharpe:', result.meanTestSharpe.toFixed(2));
  console.log('[5-Window WF] Avg Collapse Ratio:', result.avgCollapseRatio.toFixed(2));
  console.log('[5-Window WF] Robustness:', result.robustness);
  console.log('[5-Window WF] Output:', OUT_FILE);
  process.exit(result.success ? 0 : 1);
}

main().catch((e) => {
  console.error('[5-Window WF] Error:', e);
  process.exit(1);
});
