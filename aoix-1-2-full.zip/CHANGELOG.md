# Changelog (10/10 Ecosystem)

All notable changes to AOIX-1 are documented here.

---

## [1.2.0] - 2026-01-30

### Catalyst Detection + Claude Validation + Dynamic Momentum Glide (10/10)

**Catalyst Detection** (`server/catalyst-detection.ts`)
- Real-time catalyst aggregation: options flow, sentiment, optional earnings/SEC/news APIs.
- `getCatalystsForSymbol(symbol)`, `getCatalystsForSymbols(symbols)`, `getCatalystStats()`.
- Optional env: `EARNINGS_API_URL`, `SEC_FILINGS_API_URL`, `CATALYST_NEWS_API_URL`; fallback to stub when unset.

**Options Generation** (`server/catalyst-options-generation.ts`)
- Conservative / Balanced / Aggressive trade options from scan + catalysts.
- Implied vs historical move comparison; DTE and strike multiplier per tier.
- `generateTradeOptions(opportunity)`, `getTodayOpportunityOptions(runScanIfEmpty)`.

**Claude Validation** (`server/trade-validation-claude.ts`)
- Approve / Reject / Modify trades via Anthropic Claude API.
- `validateTradeWithClaude(trade, context)`; `ANTHROPIC_API_KEY` in `.env.local` (see `server/_core/claude.ts`).

**Dynamic Momentum Glide** (`server/dynamic-momentum-glide.ts`)
- Hold / tighten stop / extend target / take partial (25/50/75%) / exit full.
- `getGlideAdvice(position, momentum)`, `computeMomentumStrength(priceChangePercent, volRegime)`.

**tRPC & Dashboard**
- New router: `opportunity` — `getCatalysts`, `getCatalystStats`, `getTodayOpportunity`, `generateOptionsForSymbol`, `validateTrade`, `isValidationAvailable`, `getGlideAdvice`.
- **Today's Opportunity** page at `/today-opportunity`: top pick, Conservative/Balanced/Aggressive cards, Validate with Claude, Glide section. Nav: Crown icon "Today's Opportunity" (highlight).

**Fixes**
- `server/routers.ts`: dynamic import path for market-scanner fixed for esbuild bundle (`./market-scanner`).

**Alternative data (beyond basic news)**
- **`server/alternative-data-news.ts`**: News headlines per symbol via Yahoo Finance RSS; `getNewsForSymbol(symbol)`; `headlineSentimentScore(headlines)` for keyword-based sentiment.
- **`server/alternative-data.ts`**: When `SENTIMENT_API_URL` is unset, sentiment is derived from news headlines (no more stub-only). `getAlternativeDataSummary(symbol, putCallRatio?, impliedVolatility?)` returns sentiment + news + flow + boost in one call.
- **tRPC**: `signals.getAlternativeDataSummary({ symbol, putCallRatio?, impliedVolatility? })` for dashboard.

**Scan universe (10k-ready)**
- **`server/scan-universe.ts`**: `getScanUniverse()` returns symbol list from: `SCAN_UNIVERSE_URL` (JSON array), `SCAN_SYMBOLS` (comma-separated), or built-in ~200; `SCAN_UNIVERSE_MAX` caps at 10k (default). Scanner uses this instead of hardcoded list.
- **Market scanner**: Scan runs over `getScanUniverse()`; batch size and delay scale with universe size (15/200ms for ≤500, 25/150ms for ≤2k, 40/120ms for ≤10k).
- **tRPC**: `marketScanner.getScanUniverseInfo()` returns `{ size, source: 'url'|'env'|'default', defaultSize, maxAllowed }`.

**Liquidity / execution realism (full wire)**
- **`server/liquidity-execution.ts`**: Live bid/ask, OI, ADV from `getLiquidityFromChain` (chain/IB or Yahoo); cached 2 min. `getLiquidityForScoring(symbol)` → `isIlliquid`, `slippageScoreMultiplier`, `spreadAdjustedReturnMultiplier`, `executionCostMultiplier`. `checkLiquidityForOrder(symbol)` for order validation.
- **Slippage-aware scoring**: Scanner applies `slippageScoreMultiplier` (0.7–1.0) to opportunity score when liquidity is available.
- **Auto-reject illiquid**: Scanner sets `isIlliquid` when spread ≥ 5% or OI < 50 or ADV < 100 (env: `LIQUIDITY_MAX_SPREAD_PCT`, `LIQUIDITY_MIN_OI`, `LIQUIDITY_MIN_ADV`). `getTopOpportunities` and `getHighestExplosiveSetup` filter out illiquid. `omega0.placeOrder` rejects with "Order rejected: Illiquid: …" when `checkLiquidityForOrder` fails.
- **Spread-adjusted expected return**: Scanner uses `applySpreadAdjustedReturn(rawExpectedReturn, spreadAdjustedReturnMultiplier)`; composite ranker P8 uses `executionCostMultiplier` from opportunity.

---

## [1.1.0] - 2025-01-29

### 10/10 Category Upgrades

**Signal & regime logic**
- Regime stability and transition probability added to scanner opportunities.
- Composite score normalized 0–100 with regime-stability penalty.
- `getCompositeScoreBand(opp)` for display (low / medium / high).

**Options coverage**
- All 11+ structures documented and aligned with `getLegsForStructure` and `TRADE_STRATEGIES_COMPLETE.md`.
- Diagonal spread supports `diagonalFarStrikeOffset` in placeOrder and estimateOrderCost.

**Risk & sizing**
- Actionable hedge suggestions with approximate contract count (e.g. “Buy ~2 SPY put(s)”).
- VaR uses configurable `dailyVolPercent` in `aggregatePortfolioRisk`.

**Automation**
- Entry probability threshold configurable via `ENTRY_PROBABILITY_THRESHOLD` (env).
- Scan retry up to 2 times on transient failure in auto-trading engine.

**Execution & cost**
- `estimateOrderCost` returns `estimatedSlippagePercent`, `estimatedSlippageDollars`, `estimatedCostWithSlippage`.
- Place order dialog shows slippage and cost with slippage.

**Research & backtest**
- Backtest result includes `sharpeRatio`, `maxDrawdownPercent`, `winRate`, `profitFactor`, `seed`, `configSnapshot`.
- `runWalkForward(config)` added (stub until historical series).

**Alternative data**
- Sentiment plug point: `SENTIMENT_API_URL` (GET `?symbol=XXX`, JSON `{ score, strength }`). Fallback to stub if unset.

**UX & polish**
- Loading and empty states on Recommendations (with CTA to scan).
- Aria-labels on Place order, Close strategy, Close position, Scan Market.

**Documentation**
- `docs/API_REFERENCE.md`: tRPC procedures and key params.
- `docs/RUNBOOK.md`: start/stop, config, troubleshooting.
- `TRADE_STRATEGIES_COMPLETE.md` remains single source for strategies; code refs in API_REFERENCE.

**Ecosystem**
- `CHANGELOG.md` (this file).
- Version set to 1.1.0 for 10/10 release.
- Docker support (see README and Dockerfile).

---

## [1.0.0] - Prior

- Initial AOIX-1 release: regime classification, market scanner, auto-trading engine, Omega0 execution, portfolio risk, multi-leg structures, strategy types (wheel, short_term, iron_condor, adaptive).
