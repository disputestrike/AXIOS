import { tradeHistoryService } from './trade-history-service';

/**
 * Health check middleware - records system health status
 */
export async function healthCheckMiddleware(component: string, fn: () => Promise<any>): Promise<any> {
  const startTime = Date.now();
  try {
    const result = await fn();
    const responseTime = Date.now() - startTime;
    tradeHistoryService.recordSystemHealth(component, 'healthy', undefined, responseTime);
    return result;
  } catch (error) {
    const responseTime = Date.now() - startTime;
    const errorMessage = error instanceof Error ? error.message : String(error);
    tradeHistoryService.recordSystemHealth(component, 'error', errorMessage, responseTime);
    throw error;
  }
}

/**
 * Rate limiter - tracks requests per endpoint per user
 */
export class RateLimiter {
  private limits: Map<string, { count: number; windowStart: number }> = new Map();
  private readonly windowSize = 60000; // 1 minute window
  private readonly maxRequests = 100; // 100 requests per minute

  /**
   * Check if request is allowed
   */
  isAllowed(userId: string, endpoint: string): boolean {
    const key = `${userId}:${endpoint}`;
    const now = Date.now();

    const current = this.limits.get(key);

    if (!current || now - current.windowStart > this.windowSize) {
      // New window
      this.limits.set(key, { count: 1, windowStart: now });
      return true;
    }

    if (current.count < this.maxRequests) {
      current.count++;
      return true;
    }

    return false;
  }

  /**
   * Get remaining requests in current window
   */
  getRemaining(userId: string, endpoint: string): number {
    const key = `${userId}:${endpoint}`;
    const current = this.limits.get(key);

    if (!current) {
      return this.maxRequests;
    }

    const now = Date.now();
    if (now - current.windowStart > this.windowSize) {
      return this.maxRequests;
    }

    return Math.max(0, this.maxRequests - current.count);
  }

  /**
   * Get reset time for current window
   */
  getResetTime(userId: string, endpoint: string): number {
    const key = `${userId}:${endpoint}`;
    const current = this.limits.get(key);

    if (!current) {
      return Date.now() + this.windowSize;
    }

    return current.windowStart + this.windowSize;
  }

  /**
   * Clear old windows
   */
  cleanup(): void {
    const now = Date.now();
    const keysToDelete: string[] = [];

    this.limits.forEach((value, key) => {
      if (now - value.windowStart > this.windowSize * 2) {
        keysToDelete.push(key);
      }
    });

    keysToDelete.forEach((key) => {
      this.limits.delete(key);
    });
  }
}

// Singleton instance
export const rateLimiter = new RateLimiter();

/**
 * Input validation helper
 */
export function validateInput(data: any, schema: Record<string, any>): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  for (const [key, rule] of Object.entries(schema)) {
    const value = data[key];

    // Check required
    if (rule.required && (value === undefined || value === null || value === '')) {
      errors.push(`${key} is required`);
      continue;
    }

    if (value === undefined || value === null) {
      continue;
    }

    // Check type
    if (rule.type && typeof value !== rule.type) {
      errors.push(`${key} must be of type ${rule.type}`);
    }

    // Check min/max for numbers
    if (rule.type === 'number') {
      if (rule.min !== undefined && value < rule.min) {
        errors.push(`${key} must be >= ${rule.min}`);
      }
      if (rule.max !== undefined && value > rule.max) {
        errors.push(`${key} must be <= ${rule.max}`);
      }
    }

    // Check min/max length for strings
    if (rule.type === 'string') {
      if (rule.minLength !== undefined && value.length < rule.minLength) {
        errors.push(`${key} must be at least ${rule.minLength} characters`);
      }
      if (rule.maxLength !== undefined && value.length > rule.maxLength) {
        errors.push(`${key} must be at most ${rule.maxLength} characters`);
      }
    }

    // Check enum
    if (rule.enum && !rule.enum.includes(value)) {
      errors.push(`${key} must be one of: ${rule.enum.join(', ')}`);
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Structured logging helper
 */
export interface LogEntry {
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'debug';
  component: string;
  message: string;
  data?: any;
  error?: string;
}

export class StructuredLogger {
  private logs: LogEntry[] = [];
  private readonly maxLogs = 10000;

  /**
   * Log message
   */
  log(level: 'info' | 'warn' | 'error' | 'debug', component: string, message: string, data?: any): void {
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      component,
      message,
      data,
    };

    this.logs.push(entry);

    // Keep logs under max size
    if (this.logs.length > this.maxLogs) {
      this.logs = this.logs.slice(-this.maxLogs);
    }

    // Also log to console
    const prefix = `[${entry.timestamp}] [${level.toUpperCase()}] [${component}]`;
    if (data) {
      console.log(`${prefix} ${message}`, data);
    } else {
      console.log(`${prefix} ${message}`);
    }
  }

  /**
   * Get logs
   */
  getLogs(filter?: { level?: string; component?: string; limit?: number }): LogEntry[] {
    let result = [...this.logs];

    if (filter?.level) {
      result = result.filter((l) => l.level === filter.level);
    }

    if (filter?.component) {
      result = result.filter((l) => l.component === filter.component);
    }

    if (filter?.limit) {
      result = result.slice(-filter.limit);
    }

    return result;
  }

  /**
   * Clear logs
   */
  clear(): void {
    this.logs = [];
  }
}

// Singleton instance
export const logger = new StructuredLogger();
