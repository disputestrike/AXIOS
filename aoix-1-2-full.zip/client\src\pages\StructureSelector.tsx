import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function StructureSelector() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Options Structure Selector</h1>
        <p className="text-slate-400 mt-2">Optimal structure recommendations with CVaR analysis</p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Recommended Structure</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <p><strong>Type:</strong> Vertical Call Spread</p>
            <p><strong>Direction:</strong> Bullish</p>
            <p><strong>Expected Value:</strong> +$120</p>
            <p><strong>CVaR:</strong> -$40</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
