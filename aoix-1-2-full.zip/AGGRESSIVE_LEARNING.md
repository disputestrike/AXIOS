# Aggressive, Self-Learning Trading Layer

This doc describes the **aggressive, adaptive** layer added on top of the existing AOIX-1 engine: it gets more aggressive as it proves itself, supports named strategies (Wheel, Short-term, Iron Condors), and includes a backtest stub.

---

## 1. What Was Added (No Rebuild From Scratch)

The **existing codebase** was extended; nothing was replaced.

| Component | Purpose |
|-----------|--------|
| **Aggression tier** | Increases risk and position count when the system is winning (consecutive wins, low drawdown). Tier 1 = conservative, Tier 5 = proven (up to 1.5x risk, +2 max positions). |
| **Strategy types** | Named strategies: **Wheel**, **Short-term**, **Iron Condor**, **Adaptive**. Each has preferred structures, min win prob, take profit/stop loss, and max hold. |
| **Backtest runner** | Stub that runs the market scanner + structure selection; evaluates how many opportunities would meet each strategy’s min win prob. No historical price series yet (can add Yahoo historical later). |
| **Engine wiring** | Engine now: (1) uses **closed positions** (realized P&L) for performance metrics, (2) applies **aggression tier** after adaptive risk (multiplies risk, adds max positions, lowers min score when tier > 1), (3) exposes **aggressionTier** and **strategyType** in state. |

---

## 2. Aggression Tier (Gets More Aggressive as It Proves Itself)

- **File:** `server/aggression-tier.ts`
- **Logic:** `getAggressionTier(performance, closedTradeCount)`:
  - Needs at least 3 closed trades to move off tier 1.
  - **Tier 2:** 2+ consecutive wins, drawdown < 5% → 1.1x risk, min score −1.
  - **Tier 3:** 3+ consecutive wins, drawdown < 5% → 1.2x risk, +1 max position, min score −2.
  - **Tier 4:** 5+ consecutive wins, drawdown < 3% → 1.35x risk, +1 max position, min score −3.
  - **Tier 5:** 8+ consecutive wins, drawdown < 2% → 1.5x risk, +2 max positions, min score −5.
  - **Reset to tier 1:** Current drawdown > 5% or 2+ consecutive losses.
- **Engine:** After `calculateAdaptiveRisk`, the engine calls `getAggressionTier`, then applies:
  - `riskMultiplier *= aggression.riskMultiplier`
  - `maxPositions += aggression.maxPositionBonus`
  - `minScoreThreshold -= aggression.minScoreReduction`
- **State:** `state.aggressionTier` (1–5) is set each cycle and returned by `getState()`.

---

## 3. Strategy Types (Wheel, Short-term, Iron Condor, Adaptive)

- **File:** `server/strategy-types.ts`
- **Configs:** `STRATEGY_CONFIGS[strategy]`:
  - **wheel:** Cash-secured put / covered call / vertical spreads; 45d max hold, 70% min win prob, 50% take profit, wide stop. Income-focused.
  - **short_term:** Vertical spreads / straddle / iron condor; 7d max hold, 60% min win prob, 25% take profit, 25% stop. Quick in/out.
  - **iron_condor:** Iron condor / butterfly / calendar; 30d max hold, 65% min win prob, 50% take profit, defined risk.
  - **adaptive:** Regime-based (current engine default); no fixed structure list.
- **Helpers:** `getPreferredStructureForRegime(strategy, regime)` returns a preferred structure type for entry; `getExitParams(strategy)` returns take profit / stop loss %.
- **Engine:** `state.strategyType` (default `'adaptive'`). Set via `autoTrading.setStrategyType` mutation. Structure bias can be wired into entry logic later (e.g. filter or rank by preferred structure).
- **Strategy-specific exits:** When opening a position, if `strategyType` is wheel/short_term/iron_condor, the engine uses `getExitParams(strategyType)` for take-profit and stop-loss (e.g. wheel: 50% TP / wide SL; short_term: 25% TP / 25% SL). Adaptive keeps the default +30% / −20%.

---

## 4. Backtest Runner (Stub)

- **File:** `server/backtest-runner.ts`
- **Usage:** `runBacktest(config)` where `config = { strategy, symbols?, initialCapital, maxPositions }`.
- **Behavior:** Runs market scanner (current opportunities or given symbols), runs structure selection per regime, counts how many opportunities meet the strategy’s min win probability. Returns `simulatedTrades`, `opportunitiesEvaluated`, `structureSummary`, `message`, `durationMs`.
- **Limitation:** No historical price series yet; uses **current scan** only. Add Yahoo (or other) historical data later for true backtests.
- **API:** `autoTrading.runBacktest` mutation (strategy, optional symbols, initialCapital, maxPositions).

---

## 5. New / Updated API

| Procedure | Type | Description |
|-----------|------|-------------|
| `autoTrading.getState` | query | Now includes `aggressionTier` (1–5) and `strategyType` (wheel \| short_term \| iron_condor \| adaptive). |
| `autoTrading.runBacktest` | mutation | Runs backtest stub for a given strategy (and optional symbols). |
| `autoTrading.getStrategyConfigs` | query | Returns list of strategy configs (type, description, preferredStructures, minWinProbability, takeProfitPercent, stopLossPercent). |
| `autoTrading.setStrategyType` | mutation | Sets engine strategy type (wheel \| short_term \| iron_condor \| adaptive). |

---

## 6. Risk Management (Unchanged + Aggression)

- **Existing:** Adaptive risk (drawdown, consecutive losses, win rate, profit factor, VIX, trend) still runs first and **reduces** risk when needed.
- **New:** Aggression tier **only increases** risk/positions when performance is good (consecutive wins, low drawdown). If performance deteriorates, tier resets to 1.
- **Cap:** Risk multiplier from aggression is capped at 1.5x; max position bonus at +2.

---

## 7. Files Touched / Added

| File | Change |
|------|--------|
| `server/aggression-tier.ts` | **New.** Aggression tier 1–5 from performance. |
| `server/strategy-types.ts` | **New.** Wheel, short_term, iron_condor, adaptive configs and helpers. |
| `server/backtest-runner.ts` | **New.** Backtest stub (scanner + structure selection). |
| `server/auto-trading-engine.ts` | Performance from closed positions; aggression tier applied after adaptive risk; `aggressionTier` and `strategyType` in state; `setStrategyType()`. |
| `server/routers/auto-trading.ts` | `runBacktest`, `getStrategyConfigs`, `setStrategyType`. |

---

## 8. What You Can Do Next

1. **Run the app** — Engine now logs aggression tier and rationale each cycle (e.g. `Aggression tier 1 (Insufficient trade history)` until you have 3+ closed trades).
2. **Set strategy** — Call `autoTrading.setStrategyType` with `wheel`, `short_term`, or `iron_condor` to bias behavior (full structure bias in entry can be added later).
3. **Run backtest stub** — Call `autoTrading.runBacktest` with a strategy to see how many current opportunities would qualify.
4. **Add historical backtest** — In `backtest-runner.ts`, add a path that fetches historical data (e.g. Yahoo) and runs the same logic over time.
5. **UI** — On Auto Trading page, show `state.aggressionTier` and `state.strategyType`, and add controls for strategy select and Run backtest.
6. **Portfolio allocation** — Bias opportunity selection by strategy mix (e.g. 60% wheel-like, 30% short-term-like, 10% iron condor).
7. **Full Greeks** — Use Black–Scholes (or market) Greeks in `market-utils` and engine for option pricing and risk.
8. **Historical backtest** — In `backtest-runner.ts`, add Yahoo (or other) historical series for realistic backtest results.

You’re approved to build aggressively; this layer is integrated and ready to extend further.
