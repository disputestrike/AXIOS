@echo off
title AOIX-1 App - Port 3000
cd /d "%~dp0"

echo.
echo Starting AOIX-1 on http://localhost:3000
echo Leave this window OPEN. Then open in browser: http://localhost:3000/auto-trading
echo.
pnpm dev
pause
