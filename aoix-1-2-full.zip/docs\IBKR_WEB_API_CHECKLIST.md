# IBKR Web API Compliance Checklist

Per [IBKR Web API Documentation](https://ibkrcampus.com/campus/ibkr-api-page/webapi-doc/), here’s how AOIX-1 aligns with the documented behavior.

## Authentication & Sessions

| Item | Status | Notes |
|------|--------|-------|
| Cookie format `api={session_token}` | ✅ | `IB_GATEWAY_COOKIE` in `.env.local` |
| /tickle keep-alive | ✅ | Every 45s via `startIBSessionKeepAlive()` |
| Session termination / discard cookies | ⚠️ | On server restart; no explicit /logout |

## Rate Limits (10 req/s global)

| Endpoint | Limit | Our usage |
|----------|-------|-----------|
| /iserver/marketdata/snapshot | 10 req/s | Throttled (scanner batch size, 429 cooldown) |
| /iserver/scanner/run | 1 req/sec | Via scan throttling |
| /tickle | 1 req/sec | Once every 45s |
| /trsrv/secdef | 200 conids/request | Used for options chain |

| Item | Status |
|------|--------|
| 429 Too Many Requests handling | ✅ Cooldown 2 min, skip requests during cooldown |
| Per-endpoint pacing | ✅ Scanner and market-data throttling |

## Market Data

| Item | Status |
|------|--------|
| conid required | ✅ via getContractIdForSymbol |
| /iserver/marketdata/snapshot with fields | ✅ 31,82,83,84,85,86,87,88 |
| Pre-flight for snapshot | ✅ First request primes stream |

## Orders

| Item | Status |
|------|--------|
| /iserver/account/{accountId}/orders | ✅ Single-leg and multi-leg |
| conid / conidex for combos | ✅ Option conids from chain |
| Order reply messages | ⚠️ Not explicitly handled; may need /iserver/reply/{id} |
| /iserver/questions/suppress | ❌ Not used (fat-finger prompts may appear) |

## Instrument Discovery

| Item | Status |
|------|--------|
| /trsrv/stocks | ✅ Primary for stock conid |
| /iserver/secdef/search | ✅ Fallback for conid; fallback for options |
| /trsrv/secdef/schedule | ✅ Option expirations |
| /trsrv/secdef | ✅ Option contracts by symbol+expiry |
| /iserver/secdef/strikes, /info | ✅ Fallback when schedule returns no expirations |

## Option Chain Expiry Formats

- **trsrv**: Uses YYYYMMDD (e.g. `20260130`).
- **iserver/secdef**: Uses MMMYY for `month` (e.g. `JAN26`).
- We normalize and try both when schedule does not list the requested expiry.

## Known Gaps / Future Improvements

1. **Order reply suppression** – Call `/iserver/questions/suppress` at session start to reduce confirmations.
2. **FYI / disclaimers** – No use of /fyi endpoints.
3. **Combo order conidex** – Multi-leg orders use individual leg conids; combo conidex format could be added if required.
