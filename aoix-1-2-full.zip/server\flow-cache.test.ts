/**
 * Options flow API — flow connection (stub when no API), flow cache (FIFO last 100 per symbol).
 * Run: pnpm test -- --grep "flow"
 */
import { describe, it, expect } from "vitest";
import { getUnusualFlow, getFlowCacheStats, getRecentFlow, detectUnusualFlow } from "./options-flow";

describe("flow connection — options flow API", () => {
  it("flow connection: getUnusualFlow connects without errors when no API URL", async () => {
    const prev = process.env.OPTIONS_FLOW_API_URL;
    process.env.OPTIONS_FLOW_API_URL = "";
    try {
      const result = await getUnusualFlow("SPY");
      expect(result).toBeDefined();
      expect(result.putCallRatio).toBeDefined();
      expect(result.source).toMatch(/none|proxy/);
    } finally {
      process.env.OPTIONS_FLOW_API_URL = prev;
    }
  });

  it("flow connection: getUnusualFlow returns none or proxy when OPTIONS_FLOW_API_URL empty", async () => {
    const prev = process.env.OPTIONS_FLOW_API_URL;
    delete process.env.OPTIONS_FLOW_API_URL;
    try {
      const result = await getUnusualFlow("SPY");
      expect(result.source).toMatch(/none|proxy/);
      expect(result.timestamp).toBeGreaterThan(0);
    } finally {
      process.env.OPTIONS_FLOW_API_URL = prev;
    }
  });
});

describe("flow cache — last 100 per symbol FIFO", () => {
  it("flow cache: getFlowCacheStats returns connected and alertsCount", () => {
    const stats = getFlowCacheStats();
    expect(stats).toHaveProperty("connected");
    expect(stats).toHaveProperty("lastUpdate");
    expect(stats).toHaveProperty("alertsCount");
    expect(stats).toHaveProperty("status");
    expect(typeof stats.alertsCount).toBe("number");
  });

  it("flow cache: repeated getUnusualFlow for same symbol uses cache (no crash)", async () => {
    const prev = process.env.OPTIONS_FLOW_API_URL;
    process.env.OPTIONS_FLOW_API_URL = "";
    try {
      await getUnusualFlow("SPY");
      await getUnusualFlow("SPY");
      await getUnusualFlow("SPY");
      const stats = getFlowCacheStats();
      expect(stats.alertsCount).toBeGreaterThanOrEqual(0);
    } finally {
      process.env.OPTIONS_FLOW_API_URL = prev;
    }
  });

  it("flow cache: getRecentFlow returns sweepCount, blockCount, flowScore", async () => {
    const result = await getRecentFlow("SPY");
    expect(result).toHaveProperty("sweepCount");
    expect(result).toHaveProperty("blockCount");
    expect(result).toHaveProperty("flowScore");
    expect(result).toHaveProperty("putCallRatio");
    expect(result).toHaveProperty("averageConfidence");
  });

  it("flow cache: detectUnusualFlow returns type and confidence", async () => {
    const result = await detectUnusualFlow("SPY");
    expect(result).toHaveProperty("type");
    expect(["sweep", "block", "split", "unusual", "normal"]).toContain(result.type);
    expect(result).toHaveProperty("confidence");
    expect(result).toHaveProperty("flowScore");
  });
});
