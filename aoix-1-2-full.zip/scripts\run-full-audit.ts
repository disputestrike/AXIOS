/**
 * Full audit — close gaps with programmed pipeline.
 * Runs: historical P/L, regime win rates, crisis stress, walk-forward CI, optional Monte Carlo, optional realized vol.
 * Usage: pnpm audit:signals:full
 *        SCAN_FIRST=1 pnpm audit:signals:full
 *        MONTE_CARLO=1 pnpm audit:signals:full   # use Monte Carlo for assignment probability
 *        REALIZED_VOL=1 pnpm audit:signals:full   # fetch realized vol from IB for IV exit
 */

import { getMarketScanner } from "../server/market-scanner";
import { runSystemAudit, type AuditTradeInput } from "../server/system-audit";
import {
  runHistoricalPnlPipeline,
  runCrisisStressPipeline,
  getWalkForwardCI,
  getRealizedVolForAudit,
  CRISIS_WINDOWS,
} from "../server/audit-data-pipeline";
import { simulateAssignmentProbability } from "../server/assignment-simulator";
import { getLiquidityForAudit } from "../server/liquidity-for-audit";
import { mkdir, writeFile } from "fs/promises";
import { join } from "path";

const TOP_N = 10;
const OUT_DIR = process.env.BACKTEST_RESULTS_DIR ?? join(process.cwd(), "backtest-results");
const SCAN_FIRST = process.env.SCAN_FIRST === "1" || process.env.SCAN_FIRST === "true";
const USE_MONTE_CARLO = process.env.MONTE_CARLO === "1" || process.env.MONTE_CARLO === "true";
const USE_REALIZED_VOL = process.env.REALIZED_VOL === "1" || process.env.REALIZED_VOL === "true";
const FETCH_LIQUIDITY = process.env.FETCH_LIQUIDITY !== "0";

function opportunityToAuditTrade(opp: {
  symbol: string;
  regime?: string;
  signal?: { confidence?: number };
  opportunity?: { score?: number; expectedReturn?: number; winProbability?: number };
  structure?: { type?: string };
  impliedVolatility?: number;
  greeks?: { delta?: number; gamma?: number; theta?: number; vega?: number };
  currentPrice?: number;
}): AuditTradeInput {
  const structureType = (opp.structure?.type ?? "vertical_call_spread").toString().replace(/\s+/g, "_").toLowerCase();
  return {
    symbol: opp.symbol,
    structureType: structureType || "vertical_call_spread",
    optionType: "C",
    action: "BUY",
    quantity: 1,
    entryPrice: 2,
    strike: Math.round(opp.currentPrice ?? 100),
    score: opp.opportunity?.score ?? 0,
    confidence: opp.signal?.confidence ?? 0.7,
    expectedReturn: opp.opportunity?.expectedReturn ?? 0,
    winProbability: opp.opportunity?.winProbability ?? 0.5,
    regime: opp.regime ?? "neutral",
    impliedVolatility: opp.impliedVolatility ?? 25,
    greeks: opp.greeks,
    spreadWidth: 5,
    netCreditPerContract: 150,
  };
}

function reportToMarkdown(report: ReturnType<typeof runSystemAudit>): string {
  const lines: string[] = [
    "# Full System Audit Report (Gap-Closing Pipeline)",
    "",
    `**Generated:** ${report.timestamp}`,
    `**Trades audited:** ${report.tradesAudited}`,
    "",
    "---",
    "",
    "## Section 1 – Trade Risk / Reward Verification",
    "",
    "| Trade | Max Risk ($) | Max Profit ($) | Historical P/L | Assignment Risk (%) |",
    "|-------|--------------|----------------|----------------|---------------------|",
  ];
  for (const r of report.section1) {
    lines.push(`| ${r.trade} | ${r.maxRiskDollars} | ${r.maxProfitDollars} | ${r.historicalPnl ?? "—"} | ${r.assignmentRiskPercent} |`);
  }
  lines.push("", "## Section 2 – Probability Calibration", "");
  lines.push("| Trade | Score | Confidence | Historical Win Rate (%) | Avg Loss ($) | Max Loss ($) | Regime |");
  lines.push("|-------|-------|-------------|--------------------------|--------------|--------------|--------|");
  for (const r of report.section2) {
    lines.push(`| ${r.trade} | ${r.score} | ${r.confidence} | ${r.historicalWinRatePercent} | ${r.avgLossDollars} | ${r.maxLossDollars} | ${r.regime} |`);
  }
  lines.push("", "## Section 3 – Volatility and IV Analysis", "");
  lines.push("| Trade | IV Start | IV Exit | P/L @ IV−20% | P/L @ IV−50% | Delta | Gamma | Vega | Theta |");
  lines.push("|-------|----------|---------|--------------|--------------|-------|-------|------|-------|");
  for (const r of report.section3) {
    lines.push(`| ${r.trade} | ${r.ivStart} | ${r.ivExit} | ${r.plAtIvMinus20} | ${r.plAtIvMinus50} | ${r.delta} | ${r.gamma} | ${r.vega} | ${r.theta} |`);
  }
  lines.push("", "## Section 4 – Execution Realism", "");
  lines.push("| Trade | Bid/Ask Spread | Filled vs Theoretical | Open Interest | Avg Volume |");
  lines.push("|-------|----------------|------------------------|---------------|------------|");
  for (const r of report.section4) {
    lines.push(`| ${r.trade} | ${r.bidAskSpreadPct}% | ${r.filledVsTheoretical} | ${r.openInterest ?? "—"} | ${r.avgVolume ?? "—"} |`);
  }
  lines.push("", "## Section 5 – Portfolio Risk / Correlation", "");
  lines.push(`**Total dollar risk (VaR99):** ${report.section5.totalDollarRisk} | **VaR95:** ${report.section5.var95} | **Max drawdown:** ${report.section5.maxDrawdownPercent ?? "—"}%`, "");
  lines.push("| Trade Pair | Correlation | Combined Max Risk ($) |");
  lines.push("|------------|-------------|------------------------|");
  for (const r of report.section5.rows) {
    lines.push(`| ${r.tradePair} | ${r.correlation} | ${r.combinedMaxRiskDollars} |`);
  }
  lines.push("", "## Section 6 – Stress-Test / Crisis Simulation", "");
  lines.push("| Trade | Event | P/L | Margin Calls | Realized vs Theoretical |");
  lines.push("|-------|-------|-----|--------------|---------------------------|");
  for (const r of report.section6) {
    lines.push(`| ${r.trade} | ${r.event} | ${r.pl} | ${r.marginCalls} | ${r.realizedVsTheoretical} |`);
  }
  lines.push("", "## Section 7 – Explainability / Transparency", "");
  lines.push("| Trade | Score Reasoning | Expected Return Assumptions | Confidence Interval |");
  lines.push("|-------|-----------------|-----------------------------|---------------------|");
  for (const r of report.section7) {
    lines.push(`| ${r.trade} | ${r.scoreReasoning} | ${r.expectedReturnAssumptions} | ${r.confidenceInterval} |`);
  }
  lines.push("", "---", "", "## Methodology", "", report.methodology, "", "## Data Sources", "");
  report.dataSources.forEach((s) => lines.push(`- ${s}`));
  lines.push("", "## Assumptions", "");
  report.assumptions.forEach((s) => lines.push(`- ${s}`));
  return lines.join("\n");
}

async function main() {
  const scanner = getMarketScanner();
  if (SCAN_FIRST && scanner.getStatus().totalOpportunities === 0) {
    console.log("[Full Audit] Running market scan first...");
    await scanner.scan();
  }

  const opportunities = scanner.getTopOpportunities(TOP_N);
  const trades: AuditTradeInput[] =
    opportunities.length > 0
      ? opportunities.map(opportunityToAuditTrade)
      : [
          { symbol: "SPY", structureType: "vertical_call_spread", regime: "trending_bull", impliedVolatility: 18 },
          { symbol: "AAPL", structureType: "vertical_put_spread", regime: "mean_reverting", impliedVolatility: 22 },
        ];

  const symbols = trades.map((t) => t.symbol);

  console.log("[Full Audit] Running historical P/L pipeline for", symbols.length, "symbols...");
  const pipeline = await runHistoricalPnlPipeline(symbols, { days: 252, holdDays: 5 });

  console.log("[Full Audit] Running crisis stress pipeline...");
  const stressResults = await runCrisisStressPipeline(symbols, CRISIS_WINDOWS);

  console.log("[Full Audit] Running walk-forward CI (SPY)...");
  const walkForwardCI = await getWalkForwardCI("SPY", { numWindows: 5 });

  let liquidityBySymbol: Record<string, { bidAskSpreadPct?: number; openInterest?: number; avgVolume?: number }> | undefined = undefined;
  if (FETCH_LIQUIDITY && symbols.length > 0) {
    console.log("[Full Audit] Fetching liquidity (bid/ask, OI, volume) for", symbols.length, "symbols...");
    liquidityBySymbol = await getLiquidityForAudit(symbols);
  }

  let realizedVolBySymbol: Record<string, number> | undefined;
  if (USE_REALIZED_VOL && symbols.length > 0) {
    console.log("[Full Audit] Fetching realized vol for", symbols.length, "symbols...");
    realizedVolBySymbol = {};
    const endDate = new Date();
    for (const sym of symbols.slice(0, 5)) {
      try {
        realizedVolBySymbol[sym] = await getRealizedVolForAudit(sym, endDate, 30);
      } catch {
        // skip
      }
    }
  }

  let assignmentProbabilityByTrade: Record<string, number> | undefined;
  if (USE_MONTE_CARLO) {
    console.log("[Full Audit] Running Monte Carlo assignment simulation for each trade...");
    assignmentProbabilityByTrade = {};
    for (const t of trades) {
      const key = t.tradeId ?? t.symbol;
      const sigma = (t.impliedVolatility ?? 25) / 100;
      const strike = t.strike ?? 100;
      const width = t.spreadWidth ?? 5;
      const credit = t.netCreditPerContract ?? 150;
      const maxRisk = Math.max(0, width * 100 - credit);
      const res = simulateAssignmentProbability(
        {
          spot: strike,
          strike,
          sigma,
          dte: 30,
          optionType: (t.optionType as "C" | "P") ?? "C",
          maxLossPerContract: maxRisk,
        },
        1000
      );
      assignmentProbabilityByTrade[key] = res.assignmentProbabilityPercent;
    }
  }

  const report = runSystemAudit({
    trades,
    historicalPnlBySymbol: pipeline.historicalPnlBySymbol,
    regimeWinRates: pipeline.regimeWinRates,
    avgLossByRegime: pipeline.avgLossByRegime,
    maxLossByRegime: pipeline.maxLossByRegime,
    maxDrawdownPercent: pipeline.maxDrawdownPercent,
    stressResults,
    walkForwardCI,
    useMonteCarlo: !assignmentProbabilityByTrade && USE_MONTE_CARLO,
    assignmentProbabilityByTrade,
    realizedVolBySymbol,
    liquidityBySymbol,
  });

  const date = new Date().toISOString().slice(0, 10);
  await mkdir(OUT_DIR, { recursive: true });
  const jsonPath = join(OUT_DIR, `full-audit-${date}.json`);
  const mdPath = join(OUT_DIR, `full-audit-${date}.md`);
  await writeFile(jsonPath, JSON.stringify(report, null, 2), "utf-8");
  await writeFile(mdPath, reportToMarkdown(report), "utf-8");
  console.log("[Full Audit] Wrote:", jsonPath);
  console.log("[Full Audit] Wrote:", mdPath);
  process.exit(0);
}

main().catch((e) => {
  console.error("[Full Audit] Error:", e);
  process.exit(1);
});
