/**
 * AOIX-1 Blueprint: Trade outcome log for closed-loop learning.
 * Store forever. Append-only; never mutate historical outcomes.
 * OutcomeStore is injectable (memory or sqlite via OUTCOME_STORE env).
 */

import type { IntentDecision } from "./intent-governance";
import { normalizeRegimeToCanonical, getStrategyClassForStructure, type Regime, type StrategyClass } from "./intent-governance";

export interface TradeOutcome {
  symbol: string;
  regime: Regime;
  intent: IntentDecision;
  strategyClass: StrategyClass;
  pnl: number;
  maxDrawdown: number;
  durationDays: number;
  exitReason: "TARGET" | "STOP" | "TIME" | "MANUAL";
  /** Timestamp when trade was closed */
  closedAt: number;
}

export interface OutcomeStore {
  append(outcome: TradeOutcome): Promise<void>;
  fetchRecent(limit: number): Promise<TradeOutcome[]>;
}

/** In-memory implementation (default). */
class InMemoryOutcomeStore implements OutcomeStore {
  private log: TradeOutcome[] = [];

  async append(outcome: TradeOutcome): Promise<void> {
    this.log.push(outcome);
  }

  async fetchRecent(limit: number): Promise<TradeOutcome[]> {
    return this.log.slice(-limit);
  }

  /** For calibration: all outcomes (used by getRollingSharpeByRegime). */
  getAll(): TradeOutcome[] {
    return [...this.log];
  }

  getCount(): number {
    return this.log.length;
  }
}

const inMemoryStore = new InMemoryOutcomeStore();

/** Resolved store: OUTCOME_STORE=sqlite → SQLiteOutcomeStore, else InMemoryOutcomeStore. */
let resolvedStore: OutcomeStore & { getAll?(): TradeOutcome[]; getCount?(): number } = inMemoryStore;

export function setOutcomeStore(store: OutcomeStore & { getAll?(): TradeOutcome[]; getCount?(): number }): void {
  resolvedStore = store;
}

export function getOutcomeStore(): OutcomeStore {
  return resolvedStore;
}

/** Build a TradeOutcome from close data (minimal intent when missing). Use when wiring auto outcome logging. */
export function buildOutcomeFromClose(params: {
  symbol: string;
  regime?: string;
  pnl: number;
  durationDays: number;
  exitReason: string;
  strategyClass?: StrategyClass;
  structureType?: string;
  intentConfidence?: number;
  closedAt: number;
  maxDrawdown?: number;
}): TradeOutcome {
  const regime = normalizeRegimeToCanonical(params.regime ?? "MEAN_REVERTING");
  const strategyClass =
    params.strategyClass ??
    (params.structureType ? getStrategyClassForStructure(params.structureType) : null) ??
    ("DIRECTIONAL_DEFINED_RISK" as StrategyClass);
  const confidence = Math.min(1, Math.max(0, params.intentConfidence ?? 0.5));
  const intent: IntentDecision = {
    direction: "NEUTRAL",
    volatilityBias: "NEUTRAL",
    allowedClasses: [],
    forbiddenClasses: [],
    confidence,
    rationale: "",
  };
  const exitReasonMap: Record<string, TradeOutcome["exitReason"]> = {
    TARGET: "TARGET",
    TAKE_PROFIT: "TARGET",
    STOP: "STOP",
    STOP_LOSS: "STOP",
    TIME: "TIME",
    TIME_DECAY: "TIME",
    TIME_DECAY_EXIT: "TIME",
    MANUAL: "MANUAL",
    MANUAL_CLOSE: "MANUAL",
    TRAILING_STOP: "STOP",
  };
  const exitReasonNorm =
    exitReasonMap[params.exitReason?.toUpperCase?.() ?? ""] ?? "MANUAL";
  return {
    symbol: params.symbol,
    regime,
    intent,
    strategyClass,
    pnl: params.pnl,
    maxDrawdown: params.maxDrawdown ?? 0,
    durationDays: params.durationDays,
    exitReason: exitReasonNorm,
    closedAt: params.closedAt,
  };
}

/** Append outcome (uses injected store). */
export async function appendOutcome(outcome: TradeOutcome): Promise<void> {
  await resolvedStore.append(outcome);
}

/** Fetch recent outcomes (uses injected store). */
export async function fetchRecentOutcomes(limit: number): Promise<TradeOutcome[]> {
  return resolvedStore.fetchRecent(limit);
}

/** Legacy sync API: append (delegates to store, fire-and-forget). */
export function appendOutcomeSync(outcome: TradeOutcome): void {
  resolvedStore.append(outcome).catch((e) => console.warn("[OutcomeLog] append failed:", e));
}

/** Legacy: get count (in-memory or store that exposes getCount). */
export function getOutcomeCount(): number {
  if (typeof (resolvedStore as { getCount?: () => number }).getCount === "function") {
    return (resolvedStore as { getCount: () => number }).getCount();
  }
  return (resolvedStore as InMemoryOutcomeStore).getCount?.() ?? 0;
}

/** For confidence calibration: rolling Sharpe by regime. Uses store's getAll when available, else fetchRecent(2*window). */
export async function getRollingSharpeByRegimeAsync(
  store: OutcomeStore & { getAll?(): TradeOutcome[] },
  window = 50
): Promise<Record<string, number>> {
  const all = typeof store.getAll === "function" ? store.getAll() : await store.fetchRecent(window * 2);
  const byRegime = new Map<string, number[]>();
  const recent = all.slice(-window * 2);
  for (const o of recent) {
    const r = o.regime;
    if (!byRegime.has(r)) byRegime.set(r, []);
    byRegime.get(r)!.push(o.pnl);
  }
  const out: Record<string, number> = {};
  byRegime.forEach((pnls, regime) => {
    if (pnls.length < 5) {
      out[regime] = 1.0;
      return;
    }
    const mean = pnls.reduce((a: number, b: number) => a + b, 0) / pnls.length;
    const variance = pnls.reduce((s: number, x: number) => s + (x - mean) ** 2, 0) / pnls.length;
    const std = Math.sqrt(variance) || 0.01;
    out[regime] = std > 0 ? mean / std : 1.0;
  });
  return out;
}

/** Sync version for in-memory store (backward compat). */
export function getRollingSharpeByRegime(window = 50): Record<string, number> {
  const all = (resolvedStore as InMemoryOutcomeStore).getAll?.() ?? [];
  const byRegime = new Map<string, number[]>();
  const recent = all.slice(-window * 2);
  for (const o of recent) {
    const r = o.regime;
    if (!byRegime.has(r)) byRegime.set(r, []);
    byRegime.get(r)!.push(o.pnl);
  }
  const out: Record<string, number> = {};
  byRegime.forEach((pnls, regime) => {
    if (pnls.length < 5) {
      out[regime] = 1.0;
      return;
    }
    const mean = pnls.reduce((a: number, b: number) => a + b, 0) / pnls.length;
    const variance = pnls.reduce((s: number, x: number) => s + (x - mean) ** 2, 0) / pnls.length;
    const std = Math.sqrt(variance) || 0.01;
    out[regime] = std > 0 ? mean / std : 1.0;
  });
  return out;
}

/** Legacy: get full log (in-memory only). */
export function getOutcomeLog(): readonly TradeOutcome[] {
  return (resolvedStore as InMemoryOutcomeStore).getAll?.() ?? [];
}
