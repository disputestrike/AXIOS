#!/usr/bin/env node

/**
 * AOIX-1 Setup Verification Script
 * Checks all prerequisites and configuration for local development
 */

import { readFileSync, existsSync, copyFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const projectRoot = join(__dirname, '..');

const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  cyan: '\x1b[36m',
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

function error(message) {
  log(`❌ ${message}`, 'red');
}

function success(message) {
  log(`✅ ${message}`, 'green');
}

function warning(message) {
  log(`⚠️  ${message}`, 'yellow');
}

function info(message) {
  log(`ℹ️  ${message}`, 'cyan');
}

let hasErrors = false;

log('\n================================', 'cyan');
log('AOIX-1 Setup Verification', 'cyan');
log('================================\n', 'cyan');

// Check Node.js version
log('Checking Node.js version...', 'yellow');
const nodeVersion = process.version;
const nodeMajorVersion = parseInt(nodeVersion.slice(1).split('.')[0]);
if (nodeMajorVersion < 22) {
  error(`Node.js 22+ required. Current: ${nodeVersion}`);
  hasErrors = true;
} else {
  success(`Node.js ${nodeVersion}`);
}

// Check pnpm
log('\nChecking pnpm...', 'yellow');
try {
  const { execSync } = await import('child_process');
  const pnpmVersion = execSync('pnpm --version', { encoding: 'utf-8' }).trim();
  success(`pnpm ${pnpmVersion}`);
} catch (e) {
  error('pnpm not found. Install with: npm install -g pnpm');
  hasErrors = true;
}

// Check .env.local exists; create from example if missing
log('\nChecking environment configuration...', 'yellow');
const envLocalPath = join(projectRoot, '.env.local');
const envExamplePath = join(projectRoot, '.env.local.example');
if (!existsSync(envLocalPath)) {
  if (existsSync(envExamplePath)) {
    copyFileSync(envExamplePath, envLocalPath);
    success('.env.local created from .env.local.example');
    warning('Edit .env.local and set at least JWT_SECRET (required). DATABASE_URL and TWS_PORT=5000 are optional but recommended.');
  } else {
    error('.env.local not found!');
    info('Create .env.local (see .env.local.example for format)');
    hasErrors = true;
  }
} else {
  success('.env.local found');
}

if (existsSync(envLocalPath)) {
  // Load and validate environment variables
  try {
    const envContent = readFileSync(envLocalPath, 'utf-8');
    const envVars = {};
    envContent.split('\n').forEach(line => {
      const trimmed = line.trim();
      if (trimmed && !trimmed.startsWith('#')) {
        const [key, ...valueParts] = trimmed.split('=');
        if (key && valueParts.length > 0) {
          envVars[key.trim()] = valueParts.join('=').trim();
        }
      }
    });

    // Only JWT_SECRET is required for app to run; others optional
    const requiredVars = ['JWT_SECRET'];

    let missingVars = [];
    let placeholderVars = [];

    requiredVars.forEach(varName => {
      if (!envVars[varName]) {
        missingVars.push(varName);
      } else if (envVars[varName].includes('your_') || envVars[varName].includes('change-this')) {
        placeholderVars.push(varName);
      }
    });

    if (missingVars.length > 0) {
      error(`Missing required variables: ${missingVars.join(', ')}`);
      hasErrors = true;
    }

    if (placeholderVars.length > 0) {
      warning(`Variables with placeholder values: ${placeholderVars.join(', ')}`);
      info('Please update these in .env.local');
    }

    if (missingVars.length === 0 && placeholderVars.length === 0) {
      success('Required environment variables are set');
    }
    if (!envVars.DATABASE_URL || envVars.DATABASE_URL.includes('your_') || envVars.DATABASE_URL.includes('user:password')) {
      warning('DATABASE_URL not set or placeholder — Database will show "not configured". Add mysql://user:password@localhost:3306/aoix1 and run pnpm db:migrate, then restart.');
    }
    const twsPort = envVars.TWS_PORT || '5000';
    if (twsPort !== '5000') {
      info('TWS_PORT=' + twsPort + ' — Client Portal Gateway uses 5000. Set TWS_PORT=5000 for IBKR.');
    }

    // Test database connection (skip if placeholder)
    const dbUrlPlaceholder = !envVars.DATABASE_URL || envVars.DATABASE_URL.includes('your_') || envVars.DATABASE_URL.includes('user:password@');
    if (envVars.DATABASE_URL && !dbUrlPlaceholder) {
      log('\nTesting database connection...', 'yellow');
      try {
        // Parse MySQL connection string
        const dbUrl = envVars.DATABASE_URL;
        const urlMatch = dbUrl.match(/mysql:\/\/([^:]+):([^@]+)@([^:]+):(\d+)\/(.+)/);
        
        if (urlMatch) {
          const { createConnection } = await import('mysql2/promise');
          const [, user, password, host, port, database] = urlMatch;
          const connection = await createConnection({
            host,
            port: parseInt(port),
            user,
            password,
            database,
            connectTimeout: 5000,
          });
          await connection.end();
          success('Database connection successful');
        } else {
          warning('Could not parse DATABASE_URL format');
          info('Expected format: mysql://user:password@host:port/database');
        }
      } catch (e) {
        error(`Database connection failed: ${e.message}`);
        warning('Make sure your database is running and DATABASE_URL is correct');
      }
    }

  } catch (e) {
    error(`Error reading .env.local: ${e.message}`);
    hasErrors = true;
  }
}

// Check IB Client Portal Gateway (optional) — port 5000
log('\nChecking IB Client Portal Gateway (optional)...', 'yellow');
try {
  const { default: http } = await import('http');
  const testConnection = (port) => {
    return new Promise((resolve) => {
      const req = http.get(`http://localhost:${port}`, { timeout: 2000 }, (res) => {
        resolve(true);
      });
      req.on('error', () => resolve(false));
      req.on('timeout', () => {
        req.destroy();
        resolve(false);
      });
    });
  };
  const port = 5000;
  const isConnected = await testConnection(port);
  if (isConnected) {
    success(`IB Client Portal Gateway is running on localhost:${port}`);
  } else {
    warning(`IB Gateway not responding on localhost:${port}`);
    info('Start Client Portal Gateway and open http://localhost:5000 to log in for IBKR data and orders');
  }
} catch (e) {
  warning('Could not check IB Gateway connection');
}

// Check node_modules
log('\nChecking dependencies...', 'yellow');
const nodeModulesPath = join(projectRoot, 'node_modules');
if (!existsSync(nodeModulesPath)) {
  warning('node_modules not found. Run: pnpm install');
} else {
  success('Dependencies installed');
}

// Summary
log('\n================================', 'cyan');
if (hasErrors) {
  error('Setup verification failed. Please fix the errors above.');
  process.exit(1);
} else {
  success('Setup verification passed! You can start the server with: pnpm dev');
}
log('================================\n', 'cyan');
