/**
 * Regime and Strategy Coverage Diagnostic — table + JSON for dashboard/analysis.
 * Run: pnpm diagnostic:regime-strategy
 *      SCAN_FIRST=1 pnpm diagnostic:regime-strategy
 * Writes: backtest-results/regime-strategy-diagnostic-YYYY-MM-DD.json and .md
 */

import { getMarketScanner } from "../server/market-scanner";
import { runRegimeStrategyDiagnostic, type RegimeStrategyDiagnosticResult } from "../server/regime-strategy-diagnostic";
import { mkdir, writeFile } from "fs/promises";
import { join } from "path";

const TOP_N = 100;
const OUT_DIR = process.env.BACKTEST_RESULTS_DIR ?? join(process.cwd(), "backtest-results");
const SCAN_FIRST = process.env.SCAN_FIRST === "1" || process.env.SCAN_FIRST === "true";

function diagnosticToMarkdown(result: RegimeStrategyDiagnosticResult): string {
  const lines: string[] = [
    "# Regime and Strategy Coverage Diagnostic",
    "",
    `**Generated:** ${result.timestamp}`,
    `**Top N:** ${result.topN} | **Total opportunities:** ${result.totalOpportunities}`,
    "",
    "---",
    "",
    "## 1. By Regime",
    "",
  ];
  for (const e of result.byRegime) {
    lines.push(`### ${e.regime} (${e.count})`);
    if (e.count === 0) {
      lines.push(`- **Reason if 0:** ${e.reasonIfZero ?? "—"}`);
    } else {
      lines.push("| Symbol | Strategy | Score | Win Prob (%) | Expected Return |");
      lines.push("|--------|----------|-------|--------------|-----------------|");
      for (const o of e.opportunities.slice(0, 30)) {
        lines.push(`| ${o.symbol} | ${o.strategy} | ${o.score} | ${o.winProbability.toFixed(1)} | ${o.expectedReturn.toFixed(2)} |`);
      }
      if (e.opportunities.length > 30) {
        lines.push(`| ... | ${e.opportunities.length - 30} more | | | |`);
      }
      lines.push(`- **Highest score:** ${e.highestScore} | **Avg win prob:** ${e.avgWinProb}%`);
    }
    lines.push("");
  }

  lines.push("## 2. By Strategy (structure type)", "");
  for (const e of result.byStrategy) {
    lines.push(`### ${e.strategy} (${e.count})`);
    if (e.count === 0) {
      lines.push(`- **Reason if 0:** ${e.reasonIfZero ?? "—"}`);
    } else {
      lines.push("| Symbol | Regime | Score | Win Prob (%) | Expected Return |");
      lines.push("|--------|--------|-------|--------------|-----------------|");
      for (const o of e.opportunities.slice(0, 30)) {
        lines.push(`| ${o.symbol} | ${o.regime} | ${o.score} | ${o.winProbability.toFixed(1)} | ${o.expectedReturn.toFixed(2)} |`);
      }
      if (e.opportunities.length > 30) {
        lines.push(`| ... | ${e.opportunities.length - 30} more | | | |`);
      }
      lines.push(`- **Highest score:** ${e.highestScore} | **Avg win prob:** ${e.avgWinProb}%`);
    }
    lines.push("");
  }

  lines.push("## 3. Summary Table (Regime × Strategy)", "");
  lines.push("| Regime | Strategy | # Opportunities | Highest Score | Avg Win Prob | Reason if 0 |");
  lines.push("|--------|----------|------------------|---------------|--------------|-------------|");
  for (const row of result.summaryTable) {
    const reason = row.reasonIfZero ?? "—";
    lines.push(`| ${row.regime} | ${row.strategy} | ${row.count} | ${row.highestScore} | ${row.avgWinProb} | ${reason} |`);
  }

  lines.push("", "## 4. Filter Notes", "");
  lines.push("- **Scanner filters:** " + result.filterNotes.scannerFilters);
  lines.push("- **Min win probability by engine strategy:** " + JSON.stringify(result.filterNotes.minWinProbabilityByStrategy));
  lines.push("", "**Possible reasons for zero opportunities:**", "");
  result.filterNotes.possibleReasonsForZero.forEach((r) => lines.push(`- ${r}`));
  return lines.join("\n");
}

async function main() {
  if (SCAN_FIRST) {
    const scanner = getMarketScanner();
    if (scanner.getStatus().totalOpportunities === 0) {
      console.log("[Diagnostic] Running market scan first...");
      await scanner.scan();
    }
  }

  const result = runRegimeStrategyDiagnostic(TOP_N);
  const date = new Date().toISOString().slice(0, 10);
  await mkdir(OUT_DIR, { recursive: true });
  const jsonPath = join(OUT_DIR, `regime-strategy-diagnostic-${date}.json`);
  const mdPath = join(OUT_DIR, `regime-strategy-diagnostic-${date}.md`);
  await writeFile(jsonPath, JSON.stringify(result, null, 2), "utf-8");
  await writeFile(mdPath, diagnosticToMarkdown(result), "utf-8");
  console.log("[Diagnostic] Wrote:", jsonPath);
  console.log("[Diagnostic] Wrote:", mdPath);
  process.exit(0);
}

main().catch((e) => {
  console.error("[Diagnostic] Error:", e);
  process.exit(1);
});
