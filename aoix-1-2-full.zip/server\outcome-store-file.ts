/**
 * Append-only file store for trade outcomes (JSONL).
 * No DB required. Use OUTCOME_STORE=file and set OUTCOME_FILE path (default: ./data/outcomes.jsonl).
 * Migration-safe: no deletes, never mutate historical outcomes.
 */

import { createWriteStream, readFileSync, existsSync, mkdirSync } from "fs";
import { join } from "path";
import type { OutcomeStore } from "./outcome-log";
import type { TradeOutcome } from "./outcome-log";

const DEFAULT_DIR = join(process.cwd(), "data");
const DEFAULT_FILE = "outcomes.jsonl";

function getFilePath(): string {
  const dir = process.env.OUTCOME_FILE ? join(process.env.OUTCOME_FILE, "..") : DEFAULT_DIR;
  const base = process.env.OUTCOME_FILE ? join(process.env.OUTCOME_FILE).split(/[/\\]/).pop()! : DEFAULT_FILE;
  const path = process.env.OUTCOME_FILE ?? join(DEFAULT_DIR, base);
  return path;
}

function ensureDir(path: string): void {
  const dir = join(path, "..");
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
}

/** Reconstruct TradeOutcome from stored row (we store minimal + intent_confidence + intent_rationale). */
function rowToOutcome(row: Record<string, unknown>): TradeOutcome {
  return {
    symbol: String(row.symbol ?? ""),
    regime: row.regime as TradeOutcome["regime"],
    strategyClass: row.strategy_class as TradeOutcome["strategyClass"],
    pnl: Number(row.pnl ?? 0),
    maxDrawdown: Number(row.max_drawdown ?? 0),
    durationDays: Number(row.duration_days ?? 0),
    exitReason: row.exit_reason as TradeOutcome["exitReason"],
    closedAt: Number(row.closed_at ?? 0),
    intent: {
      direction: "NEUTRAL",
      volatilityBias: "NEUTRAL",
      allowedClasses: [],
      forbiddenClasses: [],
      confidence: Number(row.intent_confidence ?? 0.5),
      rationale: String(row.intent_rationale ?? ""),
    },
  };
}

export class FileOutcomeStore implements OutcomeStore {
  private path: string;
  private cache: TradeOutcome[] = [];
  private cacheDirty = true;

  constructor(filePath?: string) {
    this.path = filePath ?? getFilePath();
    ensureDir(this.path);
  }

  async append(outcome: TradeOutcome): Promise<void> {
    const line =
      JSON.stringify({
        id: `out_${outcome.closedAt}_${Math.random().toString(36).slice(2, 10)}`,
        symbol: outcome.symbol,
        regime: outcome.regime,
        strategy_class: outcome.strategyClass,
        intent_confidence: outcome.intent.confidence,
        intent_rationale: outcome.intent.rationale,
        pnl: outcome.pnl,
        max_drawdown: outcome.maxDrawdown,
        duration_days: outcome.durationDays,
        exit_reason: outcome.exitReason,
        closed_at: outcome.closedAt,
      }) + "\n";
    const stream = createWriteStream(this.path, { flags: "a" });
    await new Promise<void>((resolve, reject) => {
      stream.write(line, (err) => (err ? reject(err) : resolve()));
      stream.end();
    });
    this.cacheDirty = true;
  }

  private readAll(): TradeOutcome[] {
    if (!this.cacheDirty) return this.cache;
    if (!existsSync(this.path)) {
      this.cache = [];
      this.cacheDirty = false;
      return this.cache;
    }
    const content = readFileSync(this.path, "utf-8");
    const lines = content.trim().split("\n").filter(Boolean);
    this.cache = lines.map((ln) => {
      try {
        return rowToOutcome(JSON.parse(ln) as Record<string, unknown>);
      } catch {
        return null;
      }
    }).filter((o): o is TradeOutcome => o != null);
    this.cacheDirty = false;
    return this.cache;
  }

  async fetchRecent(limit: number): Promise<TradeOutcome[]> {
    const all = this.readAll();
    return all.slice(-limit);
  }

  getAll(): TradeOutcome[] {
    return this.readAll();
  }

  getCount(): number {
    return this.readAll().length;
  }
}
