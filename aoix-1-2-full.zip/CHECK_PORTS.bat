@echo off
title Check Ports 3000 and 5000
echo.
echo Checking if anything is running on port 3000 and 5000...
echo.

netstat -an | findstr ":3000 " | findstr "LISTENING" >nul 2>&1
if errorlevel 1 (
    echo [FAIL] Port 3000: NOT running - AOIX-1 app is not started.
    echo        Fix: Double-click START_APP.bat and wait for "Server running: http://localhost:3000/"
) else (
    echo [OK]   Port 3000: Running - app is up. Open http://localhost:3000/auto-trading
)

netstat -an | findstr ":5000 " | findstr "LISTENING" >nul 2>&1
if errorlevel 1 (
    echo [FAIL] Port 5000: NOT running - IBKR Gateway is not started.
    echo        Fix: Go to C:\Users\benxp\Downloads\clientportal.gw and double-click START_IB_GATEWAY.bat
) else (
    echo [OK]   Port 5000: Running - gateway is up. Open http://localhost:5000
)

echo.
echo Yahoo Finance has NOTHING to do with "connection refused".
echo Connection refused = the program for that port is not running.
echo.
pause
