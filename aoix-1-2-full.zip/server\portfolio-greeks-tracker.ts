/**
 * Portfolio Greeks tracker — aggregate Greeks from positions, check imbalance, optional hedge suggestion.
 * Complements portfolio-risk.ts with stateful tracking and thresholds.
 */

import type { PositionGreeks } from "./portfolio-risk";

export interface PortfolioGreeks {
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
  timestamp: number;
}

export interface GreeksImbalance {
  dimension: "delta" | "gamma" | "vega" | "theta";
  current: number;
  threshold: number;
  status: "ok" | "warning" | "critical";
}

const portfolioGreeksCache = new Map<string, { greeks: PortfolioGreeks; ts: number }>();
const CACHE_TTL_MS = 60_000; // 1 min

const DEFAULT_THRESHOLDS = {
  maxDeltaAbsolute: 50,
  maxGammaAbsolute: 20,
  maxVegaAbsolute: 500,
  maxThetaAbsolute: 200,
};

/**
 * Update portfolio Greeks from position list (aggregate). Call from getStatus or after fill.
 */
export function updatePortfolioGreeks(
  positions: Array<{
    symbol: string;
    delta?: number;
    gamma?: number;
    theta?: number;
    vega?: number;
    quantity: number;
    action: string;
  }>,
  accountId = "default"
): PortfolioGreeks {
  let delta = 0,
    gamma = 0,
    vega = 0,
    theta = 0;
  for (const pos of positions) {
    const mult = pos.action === "SELL" ? -1 : 1;
    const q = (pos.quantity ?? 1) * mult;
    delta += (pos.delta ?? 0) * q;
    gamma += (pos.gamma ?? 0) * q;
    vega += (pos.vega ?? 0) * q;
    theta += (pos.theta ?? 0) * q;
  }
  const greeks: PortfolioGreeks = {
    delta,
    gamma,
    vega,
    theta,
    timestamp: Date.now(),
  };
  portfolioGreeksCache.set(accountId, { greeks, ts: Date.now() });
  return greeks;
}

/**
 * Check for Greeks imbalance vs thresholds. Returns list of issues.
 */
export function checkGreeksImbalance(
  accountId = "default",
  thresholds: Partial<typeof DEFAULT_THRESHOLDS> = {}
): GreeksImbalance[] {
  const cached = portfolioGreeksCache.get(accountId);
  if (!cached || Date.now() - cached.ts > CACHE_TTL_MS) return [];
  const g = cached.greeks;
  const t = { ...DEFAULT_THRESHOLDS, ...thresholds };
  const issues: GreeksImbalance[] = [];

  const check = (
    dimension: GreeksImbalance["dimension"],
    current: number,
    maxAbs: number
  ) => {
    if (Math.abs(current) <= maxAbs) return;
    const status: "warning" | "critical" =
      Math.abs(current) > maxAbs * 1.5 ? "critical" : "warning";
    issues.push({
      dimension,
      current,
      threshold: maxAbs,
      status,
    });
  };

  check("delta", g.delta, t.maxDeltaAbsolute);
  check("gamma", g.gamma, t.maxGammaAbsolute);
  check("vega", g.vega, t.maxVegaAbsolute);
  check("theta", g.theta, t.maxThetaAbsolute);
  return issues;
}

/**
 * Suggest hedge size/direction to bring delta toward target (e.g. 0).
 */
export function suggestDeltaHedge(
  accountId = "default",
  targetDelta = 0
): { hedgeSize: number; direction: "BUY" | "SELL" } {
  const cached = portfolioGreeksCache.get(accountId);
  if (!cached) return { hedgeSize: 0, direction: "BUY" };
  const imbalance = cached.greeks.delta - targetDelta;
  const hedgeSize = Math.round(Math.abs(imbalance));
  return {
    hedgeSize,
    direction: imbalance > 0 ? "SELL" : "BUY",
  };
}

/**
 * Get last known portfolio Greeks (for UI).
 */
export function getPortfolioGreeks(accountId = "default"): PortfolioGreeks | null {
  const cached = portfolioGreeksCache.get(accountId);
  if (!cached) return null;
  return cached.greeks;
}
