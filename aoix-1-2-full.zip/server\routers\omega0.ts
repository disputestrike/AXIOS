import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import { z } from "zod";
import * as db from "../db";
import { dbTradeService } from "../db-trade-service";
import { getBreakevens, getMaxLossEstimate, getMaxProfitEstimate } from "../risk-metrics";
import { aggregatePortfolioRisk, stressPortfolioRisk, type OpenPositionForRisk } from "../portfolio-risk";

/**
 * In-memory paper trading state
 * Persists across requests but resets on server restart
 */
interface PaperTrade {
  tradeId: string;
  userId: string;
  symbol: string;
  expiry: string;
  strike: number;
  optionType: "C" | "P";
  action: "BUY" | "SELL";
  quantity: number;
  entryPrice: number;
  entryTime: Date;
  exitPrice?: number;
  exitTime?: Date;
  pnl?: number;
  status: "OPEN" | "CLOSED";
  /** Multi-leg strategy: same comboId on all legs so we can close entire strategy at once */
  comboId?: string;
  /** Structure type (e.g. iron_condor, calendar_spread) for display and close-strategy */
  structureType?: string;
}

// Global paper trading state
const paperTrades: PaperTrade[] = [];
let accountValue = 100000;
let buyingPower = 400000;

/** Last order summary for trade log — exactly what was traded (structure + each leg). Keyed by userId. */
interface LastOrderSummary {
  message: string;
  structureType: string;
  legsCount: number;
  legsDetail: Array<{ strike: number; optionType: string; action: string; fillPrice: number; quantity: number }>;
  symbol: string;
  quantity: number;
  filledTime: Date;
  orderId: string;
  /** Total cost in USD (debit to open; credit if net credit). */
  totalCost: number;
}
const lastOrderByUser: Map<string, LastOrderSummary> = new Map();

const INITIAL_ACCOUNT = 100000;
const INITIAL_BUYING_POWER = 400000;

function safeNum(n: unknown, fallback: number): number {
  const v = Number(n);
  return Number.isFinite(v) ? v : fallback;
}

/** Get current price for an option position (option premium, not underlying). Returns entryPrice if unavailable so P&L stays sane. */
async function getCurrentOptionPrice(t: PaperTrade): Promise<number> {
  try {
    const { getIBOptionsChain } = await import('../ib-market-data');
    const chain = await getIBOptionsChain(t.symbol);
    if (!chain?.options?.length) return t.entryPrice;
    const opt = chain.options.find(
      (o) => o.expiry === t.expiry && o.strike === t.strike && o.right === t.optionType
    );
    if (!opt) return t.entryPrice;
    const mid = opt.bid > 0 || opt.ask > 0 ? (opt.bid + opt.ask) / 2 : opt.last;
    return mid > 0 ? mid : t.entryPrice;
  } catch {
    return t.entryPrice;
  }
}

/** Get fill price for a single option leg (for multi-leg structures). Uses REAL prices per expiry. */
async function getFillPriceForLeg(symbol: string, expiry: string, strike: number, optionType: "C" | "P"): Promise<number> {
  try {
    const { getIBOptionsChain } = await import('../ib-market-data');
    const chain = await getIBOptionsChain(symbol);
    if (chain?.options?.length) {
      const opt = chain.options.find(
        (o) => o.expiry === expiry && o.strike === strike && o.right === optionType
      );
      if (opt) {
        const mid = opt.bid > 0 || opt.ask > 0 ? (opt.bid + opt.ask) / 2 : opt.last;
        if (mid > 0) return mid;
      }
    }
  } catch {
    // IB only
  }
  try {
    const { getRealOptionPrice } = await import('../real-market-data');
    const realPrice = await getRealOptionPrice(symbol, expiry, strike, optionType);
    if (realPrice != null && realPrice > 0) return realPrice;
  } catch {
    // ignore
  }
  try {
    const { getIBMarketData } = await import('../ib-market-data');
    const ibData = await getIBMarketData(symbol);
    if (ibData?.price != null && ibData.price > 0) {
      const intrinsic = optionType === 'C'
        ? Math.max(0, ibData.price - strike)
        : Math.max(0, strike - ibData.price);
      const daysToExpiry = daysFromExpiry(expiry);
      const timeValue = Math.max(0.1, 0.02 * ibData.price * Math.sqrt(daysToExpiry / 365));
      const fill = Math.max(0.50, intrinsic + timeValue * 0.5);
      return fill;
    }
  } catch {
    // ignore
  }
  return 0.50; // minimum sane option price (never use 0.01)
}

function daysFromExpiry(expiryStr: string): number {
  if (!/^\d{8}$/.test(expiryStr)) return 30;
  const y = parseInt(expiryStr.slice(0, 4), 10);
  const m = parseInt(expiryStr.slice(4, 6), 10) - 1;
  const d = parseInt(expiryStr.slice(6, 8), 10);
  const exp = new Date(y, m, d);
  const now = new Date();
  return Math.max(0, Math.ceil((exp.getTime() - now.getTime()) / (24 * 60 * 60 * 1000)));
}

/** One option leg for a multi-leg order. expiry optional; quantity defaults to order quantity (butterfly uses 1,2,1). */
interface OrderLeg {
  strike: number;
  optionType: "C" | "P";
  action: "BUY" | "SELL";
  expiry?: string;
  quantity?: number;
}

/** Given YYYYMMDD string, return YYYYMMDD for 7 days earlier (for calendar/diagonal near-term). */
function nearExpiryFrom(expiryStr: string): string {
  if (!/^\d{8}$/.test(expiryStr)) return expiryStr;
  const y = parseInt(expiryStr.slice(0, 4), 10);
  const m = parseInt(expiryStr.slice(4, 6), 10) - 1;
  const d = parseInt(expiryStr.slice(6, 8), 10);
  const date = new Date(y, m, d);
  date.setDate(date.getDate() - 7);
  const ny = date.getFullYear();
  const nm = String(date.getMonth() + 1).padStart(2, "0");
  const nd = String(date.getDate()).padStart(2, "0");
  return `${ny}${nm}${nd}`;
}

/** All structure types the scanner/strategies can recommend — every one maps to legs. */
const STRUCTURE_ALIASES: Record<string, string> = {
  cash_secured_put: "cash_secured_put",
  csp: "cash_secured_put",
  covered_call: "covered_call",
  cc: "covered_call",
  vertical_call_spread: "vertical_call_spread",
  vertical_put_spread: "vertical_put_spread",
  iron_condor: "iron_condor",
  iron_butterfly: "iron_butterfly",
  calendar_spread: "calendar_spread",
  calendar: "calendar_spread",
  diagonal_spread: "diagonal_spread",
  diagonal: "diagonal_spread",
  straddle: "straddle",
  strangle: "strangle",
  butterfly: "butterfly",
  call_spread: "vertical_call_spread",
  put_spread: "vertical_put_spread",
};

/** Options for getLegsForStructure (e.g. true diagonal = different far strike). */
interface LegsOptions {
  /** For diagonal spread only: far-dated leg strike = center + this offset (default 0 = calendar-style same strike). */
  diagonalFarStrikeOffset?: number;
}

/** Expand recommended structure into legs. center = at-the-money strike. inputExpiry = YYYYMMDD. */
function getLegsForStructure(
  structureType: string,
  center: number,
  direction: "bullish" | "bearish",
  inputExpiry: string,
  options?: LegsOptions
): OrderLeg[] {
  const w = 5;
  const norm = (structureType || "").toLowerCase().replace(/\s+/g, "_");
  const key = STRUCTURE_ALIASES[norm] ?? norm;

  // ——— Single-leg (wheel / income) ———
  if (key === "cash_secured_put") {
    return [{ strike: center, optionType: "P", action: "SELL" }];
  }
  if (key === "covered_call") {
    return [{ strike: center, optionType: "C", action: "SELL" }];
  }

  // ——— Vertical spreads ———
  if (key === "vertical_call_spread") {
    if (direction === "bullish") {
      return [
        { strike: center, optionType: "C", action: "BUY" },
        { strike: center + w, optionType: "C", action: "SELL" },
      ];
    }
    return [
      { strike: center, optionType: "C", action: "SELL" },
      { strike: center + w, optionType: "C", action: "BUY" },
    ];
  }
  if (key === "vertical_put_spread") {
    if (direction === "bullish") {
      return [
        { strike: center, optionType: "P", action: "SELL" },
        { strike: center - w, optionType: "P", action: "BUY" },
      ];
    }
    return [
      { strike: center - w, optionType: "P", action: "BUY" },
      { strike: center, optionType: "P", action: "SELL" },
    ];
  }

  // ——— Condor / butterfly (symmetric wings: w each side, 2w between short strikes) ———
  if (key === "iron_condor") {
    // Standard iron condor: BUY put @ center-2w, SELL put @ center-w, SELL call @ center+w, BUY call @ center+2w
    return [
      { strike: center - 2 * w, optionType: "P", action: "BUY" },
      { strike: center - w, optionType: "P", action: "SELL" },
      { strike: center + w, optionType: "C", action: "SELL" },
      { strike: center + 2 * w, optionType: "C", action: "BUY" },
    ];
  }
  if (key === "iron_butterfly") {
    // Short straddle (SELL put/call @ center) + long wings (BUY put @ center-w, BUY call @ center+w); credit
    return [
      { strike: center - w, optionType: "P", action: "BUY" },
      { strike: center, optionType: "P", action: "SELL" },
      { strike: center, optionType: "C", action: "SELL" },
      { strike: center + w, optionType: "C", action: "BUY" },
    ];
  }
  if (key === "butterfly") {
    // Call butterfly: buy 1 low, sell 2 mid, buy 1 high (quantity per leg)
    return [
      { strike: center - w, optionType: "C", action: "BUY", quantity: 1 },
      { strike: center, optionType: "C", action: "SELL", quantity: 2 },
      { strike: center + w, optionType: "C", action: "BUY", quantity: 1 },
    ];
  }

  // ——— Straddle / strangle ———
  if (key === "straddle") {
    return [
      { strike: center, optionType: "C", action: "BUY" },
      { strike: center, optionType: "P", action: "BUY" },
    ];
  }
  if (key === "strangle") {
    return [
      { strike: center - w, optionType: "P", action: "BUY" },
      { strike: center + w, optionType: "C", action: "BUY" },
    ];
  }

  // ——— Time spreads. Calendar = same strike; diagonal = optional different far strike (true diagonal). ———
  // Calendar: net debit always (far-dated costs more). Diagonal with diagonalFarStrikeOffset = different strike + expiry.
  if (key === "calendar_spread" || key === "diagonal_spread") {
    const nearExp = nearExpiryFrom(inputExpiry);
    const ot = direction === "bullish" ? "C" : "P";
    const farStrike = (key === "diagonal_spread" && options?.diagonalFarStrikeOffset != null)
      ? center + options.diagonalFarStrikeOffset
      : center;
    return [
      { strike: center, optionType: ot, action: "SELL", expiry: nearExp },
      { strike: farStrike, optionType: ot, action: "BUY", expiry: inputExpiry },
    ];
  }

  return [];
}

const W = 5; // strike width for spreads

/** Snap a strike to the nearest available in the chain (avoids "No options for strike X" when chain has 72.5, 75, etc.). */
function snapStrikeToNearest(strike: number, availableStrikes: number[]): number {
  if (!availableStrikes?.length) return strike;
  let best = availableStrikes[0]!;
  let bestDist = Math.abs(strike - best);
  for (const s of availableStrikes) {
    const d = Math.abs(strike - s);
    if (d < bestDist) {
      bestDist = d;
      best = s;
    }
  }
  return best;
}

/**
 * Omega-0 IBKR Execution Router
 * All trading (paper and live) goes through IBKR Gateway. No mock or in-memory execution.
 */
export const omega0Router = router({
  getStatus: protectedProcedure.query(async ({ ctx }) => {
    const openTrades = paperTrades.filter(t => t.userId === String(ctx.user.id) && t.status === "OPEN");
    const totalTrades = paperTrades.filter(t => t.userId === String(ctx.user.id));
    const safeAccount = safeNum(accountValue, INITIAL_ACCOUNT);
    if (!Number.isFinite(accountValue)) accountValue = safeAccount;
    try {
      const { updateDrawdown } = await import("../drawdown-limiter");
      updateDrawdown(safeAccount);
    } catch {
      // non-fatal
    }
    let connected = false;
    const gatewayPort = process.env.TWS_PORT || "5000";
    const gatewayHost = process.env.TWS_HOST || "localhost";
    const gatewayUrl = `http://${gatewayHost}:${gatewayPort}`;
    let message = `Connect IBKR Gateway to trade. App checks ${gatewayUrl}/v1/api (Client Portal Gateway uses port 5000).`;
    try {
      const { checkIBGatewayConnection } = await import("../ib-orders");
      connected = await checkIBGatewayConnection();
      message = connected
        ? "Connected to IBKR Gateway — paper and live orders go through Gateway."
        : `Not connected. Start Client Portal Gateway, open ${gatewayUrl} in your browser, log in, then click Connect or open the demo app to activate the API session.`;
    } catch {
      // keep connected false, message as above
    }
    return {
      connected,
      paperTrading: true, // UI: paper vs live is account type in IBKR
      accountValue: safeAccount,
      openTrades: openTrades.length,
      totalTrades: totalTrades.length,
      message,
      gatewayUrl: gatewayUrl + "/v1/api",
    };
  }),

  getAccountSummary: protectedProcedure.query(async ({ ctx }) => {
    // Prefer real IB balance when Gateway is connected
    try {
      const { checkIBGatewayConnection, getIBAccountId, getIBPortfolioLedger } = await import("../ib-orders");
      if (await checkIBGatewayConnection()) {
        const accountId = await getIBAccountId();
        if (accountId) {
          const ledger = await getIBPortfolioLedger(accountId);
          if (ledger && ledger.netLiquidationValue > 0) {
            return {
              netLiquidation: ledger.netLiquidationValue,
              buyingPower: ledger.cashBalance,
              cashBalance: ledger.cashBalance,
              stockMarketValue: ledger.stockMarketValue,
              unrealizedPnL: ledger.unrealizedPnL,
              realizedPnL: ledger.realizedPnL,
              source: "ib" as const,
            };
          }
        }
      }
    } catch (e) {
      console.warn("[Omega0] IB ledger fetch failed, using simulated:", e instanceof Error ? e.message : e);
    }

    // Fallback: in-memory simulated values (original 100k / 400k behavior)
    const openTrades = paperTrades.filter(t => t.userId === String(ctx.user.id) && t.status === "OPEN");
    const unrealizedArr = await Promise.all(openTrades.map(async (t) => {
      const entryPrice = safeNum(t.entryPrice, 0);
      const quantity = safeNum(t.quantity, 0);
      if (entryPrice <= 0) return 0;
      try {
        const currentPrice = await getCurrentOptionPrice(t);
        const pnl = (currentPrice - entryPrice) * quantity * 100;
        return Number.isFinite(pnl) ? pnl : 0;
      } catch (error) {
        console.warn(`[Omega0] Could not fetch option price for ${t.symbol}:`, error);
        return 0;
      }
    }));
    const unrealizedPnL = unrealizedArr.reduce((sum, p) => sum + (Number.isFinite(p) ? p : 0), 0);
    const safeAccount = safeNum(accountValue, INITIAL_ACCOUNT);
    const safeBuying = safeNum(buyingPower, INITIAL_BUYING_POWER);
    if (!Number.isFinite(accountValue)) accountValue = safeAccount;
    if (!Number.isFinite(buyingPower)) buyingPower = safeBuying;
    const netLiq = safeAccount + (Number.isFinite(unrealizedPnL) ? unrealizedPnL : 0);
    return {
      netLiquidation: netLiq,
      buyingPower: safeBuying,
      cashBalance: safeAccount * 0.2,
      stockMarketValue: undefined,
      unrealizedPnL: Number.isFinite(unrealizedPnL) ? unrealizedPnL : 0,
      realizedPnL: undefined,
      source: "simulated" as const,
    };
  }),

  getOptionChain: protectedProcedure
    .input(z.object({ symbol: z.string(), expiryDaysOut: z.number().default(0) }))
    .query(async ({ input }) => {
      // Get real option chain from IB Gateway or market data service; include ivSurfaces and termStructure when IV data available
      try {
        const { getIBOptionsChain } = await import('../ib-market-data');
        const { getOptionChain } = await import('../marketDataService');
        const { fitIVSurface, getTermStructure, setIVSurfaceLastCalibration } = await import('../iv-surface-analyzer');

        // Try IB Gateway first
        const ibChain = await getIBOptionsChain(input.symbol);
        if (ibChain && ibChain.options.length > 0) {
          const base = {
            symbol: ibChain.underlying,
            currentPrice: ibChain.underlyingPrice,
            expirations: ibChain.expirations,
            strikes: ibChain.strikes,
          };
          let ivSurfaces: Array<{ expiry: string; spotPrice: number; fitQuality: number; skewIntercept: number }> = [];
          let termStructure: { expiryDates: string[]; atmIV: number[]; skew: number[]; fitQuality: number[] } | null = null;
          try {
            const spotPrice = ibChain.underlyingPrice || 1;
            const byExpiry = new Map<string, Array<{ strike: number; right: string; iv: number }>>();
            for (const opt of ibChain.options) {
              const iv = Number(opt.impliedVolatility) || 0;
              if (iv <= 0) continue;
              const list = byExpiry.get(opt.expiry) ?? [];
              list.push({ strike: opt.strike, right: opt.right, iv });
              byExpiry.set(opt.expiry, list);
            }
            const surfaces: Array<ReturnType<typeof fitIVSurface>> = [];
            for (const [expiry, opts] of Array.from(byExpiry)) {
              const byStrike = new Map<number, { call: number; put: number }>();
              for (const o of opts) {
                const s = byStrike.get(o.strike) ?? { call: 0, put: 0 };
                if (o.right === 'C') s.call = o.iv; else s.put = o.iv;
                byStrike.set(o.strike, s);
              }
              const points = Array.from(byStrike.entries()).map(([strike, v]) => ({
                strike,
                ivCall: v.call,
                ivPut: v.put,
                moneyness: spotPrice > 0 ? strike / spotPrice : 1,
                daysToExpiry: 30,
              }));
              if (points.length >= 4) {
                const fitted = fitIVSurface(points, expiry, spotPrice);
                surfaces.push(fitted);
                ivSurfaces.push({ expiry: fitted.expiry, spotPrice: fitted.spotPrice, fitQuality: fitted.fitQuality, skewIntercept: fitted.skewIntercept });
              }
            }
            if (surfaces.length > 0) {
              termStructure = getTermStructure(surfaces);
              const avgR2 = ivSurfaces.reduce((s, v) => s + v.fitQuality, 0) / ivSurfaces.length;
              setIVSurfaceLastCalibration(avgR2);
            }
          } catch (e) {
            console.warn('[Omega0] IV surface fit skipped:', e);
          }
          return { ...base, ivSurfaces, termStructure };
        }

        // Fallback to market data service
        const chain = await getOptionChain(input.symbol, input.expiryDaysOut);
        const base = {
          symbol: chain.underlying,
          currentPrice: chain.currentPrice,
          expirations: chain.expirations,
          strikes: chain.strikes,
        };
        let ivSurfaces: Array<{ expiry: string; spotPrice: number; fitQuality: number; skewIntercept: number }> = [];
        let termStructure: { expiryDates: string[]; atmIV: number[]; skew: number[]; fitQuality: number[] } | null = null;
        const quotes = (chain as { quotes?: Array<{ strike: number; expiry: string; optionType: string; impliedVolatility?: number }> }).quotes;
        if (quotes && quotes.length >= 4) {
          try {
            const spotPrice = chain.currentPrice || 1;
            const byExpiry = new Map<string, Array<{ strike: number; right: string; iv: number }>>();
            for (const q of quotes) {
              const iv = Number((q as { impliedVolatility?: number }).impliedVolatility) || 0;
              if (iv <= 0) continue;
              const list = byExpiry.get(q.expiry) ?? [];
              list.push({ strike: q.strike, right: q.optionType === 'C' ? 'C' : 'P', iv });
              byExpiry.set(q.expiry, list);
            }
            const surfaces: Array<ReturnType<typeof fitIVSurface>> = [];
            for (const [expiry, opts] of Array.from(byExpiry)) {
              const byStrike = new Map<number, { call: number; put: number }>();
              for (const o of opts) {
                const s = byStrike.get(o.strike) ?? { call: 0, put: 0 };
                if (o.right === 'C') s.call = o.iv; else s.put = o.iv;
                byStrike.set(o.strike, s);
              }
              const points = Array.from(byStrike.entries()).map(([strike, v]) => ({
                strike,
                ivCall: v.call,
                ivPut: v.put,
                moneyness: spotPrice > 0 ? strike / spotPrice : 1,
                daysToExpiry: 30,
              }));
              if (points.length >= 4) {
                const fitted = fitIVSurface(points, expiry, spotPrice);
                surfaces.push(fitted);
                ivSurfaces.push({ expiry: fitted.expiry, spotPrice: fitted.spotPrice, fitQuality: fitted.fitQuality, skewIntercept: fitted.skewIntercept });
              }
            }
            if (surfaces.length > 0) {
              termStructure = getTermStructure(surfaces);
              const avgR2 = ivSurfaces.reduce((s, v) => s + v.fitQuality, 0) / ivSurfaces.length;
              setIVSurfaceLastCalibration(avgR2);
            }
          } catch (e) {
            console.warn('[Omega0] IV surface fit (fallback) skipped:', e);
          }
        }
        return { ...base, ivSurfaces, termStructure };
      } catch (error) {
        console.error(`[Omega0] Error fetching option chain for ${input.symbol}:`, error);
        throw new Error(`Unable to fetch option chain for ${input.symbol} - IB Gateway connection required`);
      }
    }),

  /** Option chain for trade dialog: real strikes/expirations with bid/ask. Empty chain returns error so UI can show "No options available". */
  getOptionChainForTrade: protectedProcedure
    .input(z.object({ symbol: z.string().min(1) }))
    .query(async ({ input }) => {
      try {
        const { getIBOptionsChain } = await import("../ib-market-data");
        // Pass plausible expiries so iserver fallback runs when trsrv/schedule returns empty (AMD, PLTR, etc.)
        const today = new Date();
        const expiriesToTry: string[] = [];
        for (let i = 0; i < 6; i++) {
          const d = new Date(today);
          d.setDate(d.getDate() + 7 * i);
          const daysToFriday = (5 - d.getDay() + 7) % 7 || 7;
          d.setDate(d.getDate() + daysToFriday);
          const yyyymmdd = d.toISOString().slice(0, 10).replace(/-/g, "");
          if (!expiriesToTry.includes(yyyymmdd)) expiriesToTry.push(yyyymmdd);
        }
        let chain = await getIBOptionsChain(input.symbol, expiriesToTry);
        if (!chain?.options?.length) chain = await getIBOptionsChain(input.symbol);
        if (!chain) {
          return {
            symbol: input.symbol,
            currentPrice: 0,
            expirations: [],
            strikes: [],
            options: [],
            error: "no_option_chain" as const,
          };
        }
        if (!chain.options?.length) {
          return {
            symbol: chain.underlying,
            currentPrice: chain.underlyingPrice ?? 0,
            expirations: chain.expirations ?? [],
            strikes: chain.strikes ?? [],
            options: [],
            error: "no_option_chain" as const,
          };
        }
        const options = chain.options.map((o) => ({
          expiry: o.expiry,
          strike: o.strike,
          right: o.right,
          bid: o.bid,
          ask: o.ask,
          last: o.last,
        }));
        const expirations = [...new Set(chain.options.map((o) => o.expiry))].sort();
        const strikes = [...new Set(chain.options.map((o) => o.strike))].sort((a, b) => a - b);
        return {
          symbol: chain.underlying,
          currentPrice: chain.underlyingPrice ?? 0,
          expirations,
          strikes,
          options,
        };
      } catch (e) {
        console.warn("[Omega0] getOptionChainForTrade failed:", e);
        return {
          symbol: input.symbol,
          currentPrice: 0,
          expirations: [],
          strikes: [],
          options: [],
          error: "no_option_chain" as const,
        };
      }
    }),

  placeOrder: protectedProcedure
    .input(
      z.object({
        symbol: z.string().min(1, "Symbol is required").max(20),
        expiry: z.string().min(1, "Expiry is required"),
        strike: z.number().positive("Strike must be positive"),
        optionType: z.enum(["C", "P"]),
        action: z.enum(["BUY", "SELL"]),
        quantity: z.number().int().positive("Quantity must be at least 1"),
        /** Order type: MKT (default) or LMT. LMT requires limitPrice. */
        orderType: z.enum(["MKT", "LMT"]).optional().default("MKT"),
        /** Limit price per contract (required when orderType is LMT). Paper fill at limit or better. */
        limitPrice: z.number().positive().optional(),
        /** Recommended structure from scanner (e.g. iron_condor, vertical_call_spread). When set, we execute that structure instead of a single option. */
        structureType: z.string().optional(),
        /** For vertical spreads: bullish, bearish, or neutral (neutral structures: iron condor, straddle, etc.). */
        direction: z.enum(["bullish", "bearish", "neutral"]).optional(),
        /** For diagonal spread only: far-dated leg strike = strike + this offset (true diagonal). Omit = calendar-style same strike. */
        diagonalFarStrikeOffset: z.number().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const dir = input.direction ?? (input.optionType === "C" ? "bullish" : "bearish");
      const direction: "bullish" | "bearish" = dir === "neutral" ? "bullish" : dir;
      const structureType = (input.structureType || "").trim().toLowerCase().replace(/\s+/g, "_") || undefined;
      const center = input.strike;

      // Liquidity / execution realism: auto-reject illiquid (spread/OI/ADV below threshold)
      const { checkLiquidityForOrder } = await import("../liquidity-execution");
      const liquidityCheck = await checkLiquidityForOrder(input.symbol);
      if (!liquidityCheck.allowed) {
        throw new Error(`Order rejected: ${liquidityCheck.reason ?? "Illiquid symbol"}.`);
      }

      // Capacity: cap order size vs ADV (hedge fund style)
      const { getMaxOrderSize } = await import("../market-impact");
      const cappedQty = getMaxOrderSize({ symbol: input.symbol, quantity: input.quantity });
      const quantity = cappedQty;

      const legsOptions = (structureType?.includes("diagonal") && input.diagonalFarStrikeOffset != null)
        ? { diagonalFarStrikeOffset: input.diagonalFarStrikeOffset }
        : undefined;
      const legs = structureType ? getLegsForStructure(structureType, center, direction, input.expiry, legsOptions) : [];

      // Pre-flight validation: estimated cost and slippage vs thresholds
      const MAX_SLIPPAGE_PERCENT = Number(process.env.MAX_SLIPPAGE_PERCENT) || 3.0; // options: 0.5–3% normal; 1.5% was too strict
      const MAX_ORDER_COST_USD = Number(process.env.MAX_ORDER_COST_USD) || 50_000;
      let estimatedCostPreFlight = 0;
      let estimatedSlippagePercentPreFlight = 0.5;
      if (legs.length > 0) {
        for (const leg of legs) {
          const legQty = leg.quantity ?? quantity;
          const legExpiry = leg.expiry ?? input.expiry;
          const fillPrice = Math.max(0.01, await getFillPriceForLeg(input.symbol, legExpiry, leg.strike, leg.optionType));
          estimatedCostPreFlight += leg.action === "BUY" ? fillPrice * legQty * 100 : -fillPrice * legQty * 100;
        }
        estimatedSlippagePercentPreFlight = 0.5 * legs.length;
      } else {
        const fillPrice = Math.max(0.01, await getFillPriceForLeg(input.symbol, input.expiry, input.strike, input.optionType));
        estimatedCostPreFlight = input.action === "BUY" ? fillPrice * quantity * 100 : -fillPrice * quantity * 100;
      }
      if (estimatedSlippagePercentPreFlight > MAX_SLIPPAGE_PERCENT) {
        throw new Error(`Pre-flight validation failed: estimated slippage ${estimatedSlippagePercentPreFlight.toFixed(1)}% exceeds max ${MAX_SLIPPAGE_PERCENT}%. Reduce size or use limit order.`);
      }
      if (Math.abs(estimatedCostPreFlight) > MAX_ORDER_COST_USD) {
        throw new Error(`Pre-flight validation failed: estimated cost $${Math.abs(estimatedCostPreFlight).toFixed(0)} exceeds max $${MAX_ORDER_COST_USD}. Reduce size.`);
      }

      if (legs.length > 0) {
        // Multi-leg: validate ALL legs exist in option chain BEFORE sending any order (avoid partial fill)
        const { getIBOptionsChain } = await import("../ib-market-data");
        const normExpiry = (s: string) => String(s || "").replace(/[-/\s]/g, "").slice(0, 8);
        const legExpiries = [...new Set(legs.map((leg) => normExpiry(leg.expiry ?? input.expiry)).filter(Boolean))];
        const chain = await getIBOptionsChain(
          input.symbol,
          legExpiries.length > 0 ? legExpiries : undefined
        );
        if (!chain?.options?.length) {
          const withExpiry = legExpiries.length > 0 ? ` for expiries ${legExpiries.slice(0, 3).join(", ")}` : "";
          throw new Error(
            `No option chain for ${input.symbol}${withExpiry}. Check symbol and IB Gateway. Try SPY or QQQ for reliable expirations.`
          );
        }
        const availableStrikes = chain.strikes ?? [...new Set(chain.options.map((o) => o.strike))].sort((a, b) => a - b);
        const snappedLegs = legs.map((leg) => {
          const snapped = snapStrikeToNearest(leg.strike, availableStrikes);
          return { ...leg, strike: snapped };
        });

        const availableExpirations = [...new Set(chain.options.map((o) => o.expiry))].sort();
        for (let i = 0; i < snappedLegs.length; i++) {
          const leg = snappedLegs[i]!;
          const legExpiry = leg.expiry ?? input.expiry;
          const wantNorm = normExpiry(legExpiry);
          const found = chain.options.some(
            (o) =>
              normExpiry(o.expiry) === wantNorm &&
              o.strike === leg.strike &&
              o.right === leg.optionType
          );
          if (!found) {
            const available = availableExpirations.slice(0, 8).join(", ");
            throw new Error(
              `No options for ${input.symbol} on ${legExpiry} (strike ${leg.strike}${leg.optionType}). ` +
                `Available expirations: ${available || "none"}. Choose an expiry from the trade dialog or try SPY/QQQ.`
            );
          }
        }

        // Multi-leg: execute via IBKR Gateway (paper and live both through Gateway)
        const { checkIBGatewayConnection, getIBAccountId, placeIBOptionOrder } = await import("../ib-orders");
        if (!(await checkIBGatewayConnection())) {
          throw new Error("Connect IBKR Gateway to trade. Multi-leg orders require Gateway (paper or live account).");
        }
        const accountId = await getIBAccountId();
        if (!accountId) {
          throw new Error("IBKR account not available. Log in at Gateway (http://localhost:5000) and try again.");
        }
        const comboId = `COMBO_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
        const executed: Array<{ tradeId: string; strike: number; optionType: string; action: string; fillPrice: number; quantity: number }> = [];
        let totalCost = 0;

        for (let i = 0; i < snappedLegs.length; i++) {
          const leg = snappedLegs[i]!;
          const legQty = leg.quantity ?? quantity;
          const legExpiry = leg.expiry ?? input.expiry;
          const fillPrice = Math.max(0.01, await getFillPriceForLeg(input.symbol, legExpiry, leg.strike, leg.optionType));
          const ibResult = await placeIBOptionOrder({
            accountId,
            symbol: input.symbol,
            expiry: legExpiry,
            strike: leg.strike,
            optionType: leg.optionType as "C" | "P",
            side: leg.action as "BUY" | "SELL",
            quantity: legQty,
            orderType: (input.orderType ?? "MKT") as "MKT" | "LMT",
            limitPrice: input.orderType === "LMT" && input.limitPrice != null ? input.limitPrice : undefined,
          });
          if (!ibResult.success) {
            throw new Error(`Multi-leg leg ${i + 1} failed: ${ibResult.error ?? "Unknown"}. Roll back any prior legs manually.`);
          }
          const tradeId = `IBKR_${ibResult.orderId ?? Date.now()}_${i}`;
          const cost = leg.action === "BUY" ? fillPrice * legQty * 100 : -fillPrice * legQty * 100;
          totalCost += cost;

          const trade: PaperTrade = {
            tradeId,
            userId: String(ctx.user.id),
            symbol: input.symbol,
            expiry: legExpiry,
            strike: leg.strike,
            optionType: leg.optionType,
            action: leg.action,
            quantity: legQty,
            entryPrice: fillPrice,
            entryTime: new Date(),
            status: "OPEN",
            comboId,
            structureType: structureType ?? "multi_leg",
          };
          paperTrades.push(trade);
          executed.push({ tradeId, strike: leg.strike, optionType: leg.optionType, action: leg.action, fillPrice, quantity: legQty });
          try {
            const { logTCA } = await import("../tca");
            const intendedPrice = fillPrice;
            logTCA({ timestamp: Date.now(), symbol: input.symbol, side: leg.action as "BUY" | "SELL", quantity: legQty, intendedPrice, fillPrice, orderType: (input.orderType ?? "MKT") as "MKT" | "LMT", structureType, orderId: comboId });
          } catch {
            // non-fatal
          }
          try {
            const now = Date.now();
            await dbTradeService.saveTradeRecord(
              {
                id: tradeId,
                symbol: input.symbol,
                assetType: "option",
                entryPrice: fillPrice,
                entryTime: now,
                quantity: legQty,
                direction: leg.action === "BUY" ? "long" : "short",
                structureType: structureType || "iron_condor",
                status: "open",
                createdAt: now,
                updatedAt: now,
              },
              ctx.user.id
            );
          } catch (err) {
            console.warn("[Omega0] Failed to persist leg to DB (non-fatal):", err);
          }
        }

        buyingPower -= totalCost;

        const legsDesc = executed.map((e) => `${e.action} ${e.strike}${e.optionType} @ $${e.fillPrice.toFixed(2)} × ${e.quantity}`).join(" | ");
        const filledTime = new Date();
        const result = {
          orderId: executed[0]?.tradeId ?? comboId,
          symbol: input.symbol,
          expiry: input.expiry,
          strike: input.strike,
          optionType: input.optionType,
          action: input.action,
          quantity: input.quantity,
          filledPrice: totalCost / (quantity * 100),
          filledTime,
          status: "FILLED" as const,
          message: `IBKR ${structureType} (${snappedLegs.length} legs) — ${legsDesc}`,
          legs: executed.length,
          structureType,
          legsDetail: executed.map((e) => ({ strike: e.strike, optionType: e.optionType, action: e.action, fillPrice: e.fillPrice, quantity: e.quantity })),
          totalCost,
          estimatedCost: estimatedCostPreFlight,
          estimatedSlippagePercent: estimatedSlippagePercentPreFlight,
        };
        lastOrderByUser.set(String(ctx.user.id), {
          message: result.message,
          structureType: structureType ?? "multi_leg",
          legsCount: result.legs,
          legsDetail: result.legsDetail,
          symbol: input.symbol,
          quantity,
          filledTime,
          orderId: result.orderId,
          totalCost,
        });
        return result;
      }

      // Single-leg: try real IBKR order first when Gateway is connected
      const { checkIBGatewayConnection, getIBAccountId, placeIBOptionOrder } = await import('../ib-orders');
      if (await checkIBGatewayConnection()) {
        const accountId = await getIBAccountId();
        if (accountId) {
          const ibResult = await placeIBOptionOrder({
            accountId,
            symbol: input.symbol,
            expiry: input.expiry,
            strike: input.strike,
            optionType: input.optionType,
            side: input.action,
            quantity: input.quantity,
            orderType: 'MKT',
          });
          if (ibResult.success) {
            const fillPrice = 0.50; // IB fills at market; we don't have fill price until later
            const tradeId = `IBKR_${ibResult.orderId ?? Date.now()}`;
            const trade: PaperTrade = {
              tradeId,
              userId: String(ctx.user.id),
              symbol: input.symbol,
              expiry: input.expiry,
              strike: input.strike,
              optionType: input.optionType,
              action: input.action,
            quantity,
            entryPrice: fillPrice,
            entryTime: new Date(),
            status: "OPEN",
          };
          paperTrades.push(trade);
          try {
            const { logTCA } = await import("../tca");
            logTCA({ timestamp: Date.now(), symbol: input.symbol, side: input.action, quantity, intendedPrice: fillPrice, fillPrice, orderType: "MKT" });
          } catch {
            // non-fatal
          }
          try {
            const now = Date.now();
            await dbTradeService.saveTradeRecord(
              {
                id: tradeId,
                symbol: input.symbol,
                assetType: "option",
                entryPrice: fillPrice,
                entryTime: now,
                quantity,
                  direction: input.action === "BUY" ? "long" : "short",
                  structureType: "option",
                  status: "open",
                  createdAt: now,
                  updatedAt: now,
                },
                ctx.user.id
              );
            } catch (err) {
              console.warn("[Omega0] Failed to persist IBKR trade to DB (non-fatal):", err);
            }
            const filledTime = new Date();
            const result = {
              orderId: tradeId,
              symbol: input.symbol,
              expiry: input.expiry,
              strike: input.strike,
              optionType: input.optionType,
              action: input.action,
              quantity: input.quantity,
              filledPrice: fillPrice,
              filledTime,
              status: "FILLED" as const,
              message: `Live IBKR order placed — ${input.action} ${quantity} ${input.symbol} ${input.expiry} ${input.strike}${input.optionType} (order ${ibResult.orderId ?? "submitted"})`,
            };
            lastOrderByUser.set(String(ctx.user.id), {
              message: result.message,
              structureType: "option",
              legsCount: 1,
              legsDetail: [{ strike: input.strike, optionType: input.optionType, action: input.action, fillPrice, quantity }],
              symbol: input.symbol,
              quantity,
              filledTime,
              orderId: result.orderId,
              totalCost: fillPrice * quantity * 100,
            });
            return result;
          }
          throw new Error(`IBKR order failed: ${ibResult.error ?? "Unknown"}. Connect Gateway and try again.`);
        }
      }

      // Single-leg requires IBKR Gateway (no in-memory fallback)
      throw new Error("Connect IBKR Gateway to trade. Paper and live trading both go through Gateway. Start Client Portal Gateway and log in at http://localhost:5000.");
    }),

  /** Estimated cost of an order (no execution). Use before placing to show "Cost: $X" and "Max loss: $Y". */
  estimateOrderCost: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        expiry: z.string(),
        strike: z.number(),
        optionType: z.enum(["C", "P"]),
        quantity: z.number(),
        structureType: z.string().optional(),
        direction: z.enum(["bullish", "bearish", "neutral"]).optional(),
        /** For diagonal spread only: far-dated leg strike = strike + this offset (true diagonal). */
        diagonalFarStrikeOffset: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      const dir = input.direction ?? (input.optionType === "C" ? "bullish" : "bearish");
      const direction: "bullish" | "bearish" = dir === "neutral" ? "bullish" : dir;
      const structureType = (input.structureType || "").trim().toLowerCase().replace(/\s+/g, "_") || undefined;
      const center = input.strike;
      const legsOptions = (structureType?.includes("diagonal") && input.diagonalFarStrikeOffset != null)
        ? { diagonalFarStrikeOffset: input.diagonalFarStrikeOffset }
        : undefined;
      const legs = structureType ? getLegsForStructure(structureType, center, direction, input.expiry, legsOptions) : [];

      if (legs.length > 0) {
        let estimatedCost = 0;
        const breakdown: Array<{ strike: number; optionType: string; action: string; fillPrice: number; quantity: number; legCost: number }> = [];
        for (const leg of legs) {
          const legQty = leg.quantity ?? input.quantity;
          const legExpiry = leg.expiry ?? input.expiry;
          const fillPrice = Math.max(0.01, await getFillPriceForLeg(input.symbol, legExpiry, leg.strike, leg.optionType));
          const legCost = leg.action === "BUY" ? fillPrice * legQty * 100 : -fillPrice * legQty * 100;
          estimatedCost += legCost;
          breakdown.push({ strike: leg.strike, optionType: leg.optionType, action: leg.action, fillPrice, quantity: legQty, legCost });
        }
        const maxLossEstimate = getMaxLossEstimate(structureType || "", center, estimatedCost, input.quantity);
        const maxProfitEstimate = getMaxProfitEstimate(structureType || "", center, estimatedCost, input.quantity);
        const breakevens = getBreakevens(structureType || "", center, estimatedCost);
        const estimatedSlippagePercent = 0.5 * legs.length;
        const estimatedSlippageDollars = Math.abs(estimatedCost) * (estimatedSlippagePercent / 100);
        return {
          estimatedCost,
          maxLossEstimate,
          maxProfitEstimate,
          breakevens,
          breakdown,
          currency: "USD",
          estimatedSlippagePercent,
          estimatedSlippageDollars,
          estimatedCostWithSlippage: estimatedCost + (estimatedCost >= 0 ? estimatedSlippageDollars : -estimatedSlippageDollars),
        };
      }

      // Single-leg
      let fillPrice = 0;
      try {
        const { getIBOptionsChain } = await import('../ib-market-data');
        const chain = await getIBOptionsChain(input.symbol);
        if (chain) {
          const option = chain.options.find(
            opt => opt.expiry === input.expiry && opt.strike === input.strike && opt.right === input.optionType
          );
          if (option) fillPrice = (option.bid + option.ask) / 2;
        }
      } catch {
        try {
          const { getIBMarketData } = await import('../ib-market-data');
          const ibData = await getIBMarketData(input.symbol);
          if (ibData?.price != null && ibData.price > 0) {
            const timeValue = 0.02 * ibData.price;
            fillPrice = Math.max(0, Math.abs(ibData.price - input.strike) + timeValue);
          } else {
            fillPrice = 0.50;
          }
        } catch {
          fillPrice = 0.50;
        }
      }
      if (!Number.isFinite(fillPrice) || fillPrice <= 0) fillPrice = 0.50;
      const estimatedCost = fillPrice * input.quantity * 100;
      const maxLossEstimate = getMaxLossEstimate("single", center, estimatedCost, input.quantity);
      const maxProfitEstimate = getMaxProfitEstimate("single", center, estimatedCost, input.quantity);
      const breakevens = getBreakevens("single", center, estimatedCost);
      const estimatedSlippagePercent = 0.5;
      const estimatedSlippageDollars = estimatedCost * (estimatedSlippagePercent / 100);
      return {
        estimatedCost,
        maxLossEstimate,
        maxProfitEstimate,
        breakevens,
        breakdown: [{ strike: input.strike, optionType: input.optionType, action: "BUY", fillPrice, quantity: input.quantity, legCost: estimatedCost }],
        currency: "USD",
        estimatedSlippagePercent,
        estimatedSlippageDollars,
        estimatedCostWithSlippage: estimatedCost + estimatedSlippageDollars,
      };
    }),

  /** Last executed order — exactly what was traded (for trade log). */
  getLastOrderSummary: protectedProcedure.query(({ ctx }) => {
    const summary = lastOrderByUser.get(String(ctx.user.id));
    if (!summary) return null;
    let totalCost = (summary as any).totalCost;
    if (totalCost === undefined && summary.legsDetail?.length) {
      totalCost = summary.legsDetail.reduce(
        (sum: number, leg: { action: string; fillPrice: number; quantity: number }) =>
          sum + (leg.action === "BUY" ? 1 : -1) * leg.fillPrice * leg.quantity * 100,
        0
      );
    }
    return {
      ...summary,
      filledTime: summary.filledTime,
      totalCost: Number.isFinite(totalCost) ? totalCost : 0,
    };
  }),

  getTCADrillDown: protectedProcedure
    .input(z.object({ orderId: z.string().min(1) }))
    .query(async ({ input }) => {
      const { getTCADrillDown } = await import("../tca");
      return getTCADrillDown(input.orderId);
    }),

  closePosition: protectedProcedure
    .input(
      z.object({
        tradeId: z.string().optional(),
        symbol: z.string(),
        expiry: z.string(),
        strike: z.number(),
        optionType: z.enum(["C", "P"]),
        quantity: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Find the open trade
      const trade = paperTrades.find(
        t => t.userId === String(ctx.user.id) && 
             t.symbol === input.symbol && 
             t.expiry === input.expiry &&
             t.strike === input.strike &&
             t.optionType === input.optionType &&
             t.status === "OPEN"
      );
      
      if (!trade) {
        throw new Error("No open position found to close");
      }
      
      // Use option premium for exit, not underlying price (underlying would produce absurd P&L)
      const currentPrice = await getCurrentOptionPrice(trade);
      const entryPrice = safeNum(trade.entryPrice, 0);
      const quantity = safeNum(trade.quantity, 0);
      const exitPrice = Number.isFinite(currentPrice) && currentPrice > 0
        ? Math.round(currentPrice * 100) / 100
        : entryPrice;
      const pnl = Number.isFinite(exitPrice) && Number.isFinite(entryPrice) ? (exitPrice - entryPrice) * quantity * 100 : 0;
      
      // Update trade
      trade.exitPrice = exitPrice;
      trade.exitTime = new Date();
      trade.pnl = pnl;
      trade.status = "CLOSED";

      // Persist close to database
      try {
        await dbTradeService.updateTradeRecord({
          id: trade.tradeId,
          symbol: trade.symbol,
          assetType: "option",
          entryPrice: trade.entryPrice,
          entryTime: trade.entryTime.getTime(),
          exitPrice,
          exitTime: trade.exitTime.getTime(),
          quantity: trade.quantity,
          direction: "long",
          structureType: "vertical_call_spread",
          status: "closed",
          pnl,
          pnlPercent: (pnl / (trade.entryPrice * trade.quantity * 100)) * 100,
          createdAt: trade.entryTime.getTime(),
          updatedAt: Date.now(),
        });
      } catch (err) {
        console.warn("[Omega0] Failed to persist trade close to DB (non-fatal):", err);
      }

      // Update account
      accountValue += pnl;
      buyingPower += exitPrice * trade.quantity * 100;

      // Outcome log + calibration (automatic rollout)
      try {
        const { buildOutcomeFromClose } = await import("../outcome-log");
        const { appendOutcomeAndMaybeCalibrate } = await import("../calibration-job");
        const exitTime = trade.exitTime?.getTime() ?? Date.now();
        const entryTime = trade.entryTime?.getTime?.() ?? trade.entryTime ?? exitTime;
        const durationDays = Math.max(0, (exitTime - entryTime) / (24 * 60 * 60 * 1000));
        const outcome = buildOutcomeFromClose({
          symbol: input.symbol,
          pnl,
          durationDays,
          exitReason: "MANUAL",
          structureType: trade.structureType ?? "vertical_call_spread",
          closedAt: exitTime,
          maxDrawdown: 0,
        });
        await appendOutcomeAndMaybeCalibrate(outcome);
      } catch (err) {
        console.warn("[Omega0] Outcome log/calibration (non-fatal):", err);
      }

      return {
        orderId: `CLOSE_${Date.now()}`,
        tradeId: trade.tradeId,
        symbol: input.symbol,
        action: "SELL",
        quantity: input.quantity,
        exitPrice,
        status: "FILLED",
        pnl,
        message: `Position closed: ${input.symbol} ${input.strike}${input.optionType} @ $${exitPrice} | P&L: $${pnl.toFixed(2)}`,
      };
    }),

  /** Portfolio-level risk (hedge fund style): Greeks, VaR, hedge suggestions. Uses real Greeks from IB chain when available. */
  getPortfolioRisk: protectedProcedure.query(async ({ ctx }) => {
    const openTrades = paperTrades.filter(t => t.userId === String(ctx.user.id) && t.status === "OPEN");
    const positions: OpenPositionForRisk[] = [];
    for (const t of openTrades) {
      const base: OpenPositionForRisk = {
        symbol: t.symbol,
        structureType: t.structureType,
        optionType: t.optionType,
        action: t.action,
        quantity: t.quantity,
        entryPrice: t.entryPrice,
        strike: t.strike,
      };
      try {
        const { getIBOptionsChain } = await import('../ib-market-data');
        const chain = await getIBOptionsChain(t.symbol);
        const opt = chain?.options?.find(o => o.expiry === t.expiry && o.strike === t.strike && o.right === t.optionType);
        if (opt && (opt.delta != null || opt.gamma != null)) {
          const mult = t.action === 'SELL' ? -1 : 1;
          const q = t.quantity * 100;
          base.greeks = {
            delta: mult * (opt.delta ?? 0) * (q / 100),
            gamma: mult * (opt.gamma ?? 0) * (q / 100),
            theta: mult * (opt.theta ?? 0) * (q / 100),
            vega: mult * (opt.vega ?? 0) * (q / 100),
          };
        }
      } catch {
        // IB not available; use estimated Greeks
      }
      positions.push(base);
    }
    const safeAccount = safeNum(accountValue, INITIAL_ACCOUNT);
    const snapshot = aggregatePortfolioRisk(positions, safeAccount);
    try {
      const { updatePortfolioGreeks } = await import("../portfolio-greeks-tracker");
      updatePortfolioGreeks(
        positions.map((p) => ({
          symbol: p.symbol,
          delta: p.greeks?.delta,
          gamma: p.greeks?.gamma,
          theta: p.greeks?.theta,
          vega: p.greeks?.vega,
          quantity: p.quantity,
          action: p.action ?? "BUY",
        }))
      );
    } catch {
      // non-critical
    }
    return snapshot;
  }),

  /** Stress-test portfolio: SPY -5%, VIX +50%, etc. Returns estimated P&L impact and VaR after stress. */
  getPortfolioStress: protectedProcedure
    .input(
      z
        .object({
          scenarios: z
            .array(
              z.object({
                name: z.string(),
                deltaMultiplier: z.number().optional(),
                vegaShock: z.number().optional(),
              })
            )
            .optional(),
        })
        .optional()
    )
    .query(async ({ ctx, input }) => {
      const openTrades = paperTrades.filter(t => t.userId === String(ctx.user.id) && t.status === "OPEN");
      const positions: OpenPositionForRisk[] = openTrades.map(t => ({
        symbol: t.symbol,
        structureType: t.structureType,
        optionType: t.optionType,
        action: t.action,
        quantity: t.quantity,
        entryPrice: t.entryPrice,
        strike: t.strike,
      }));
      const safeAccount = safeNum(accountValue, INITIAL_ACCOUNT);
      const snapshot = aggregatePortfolioRisk(positions, safeAccount);
      const defaultScenarios = [
        { name: "SPY -5%", deltaMultiplier: 0.95 },
        { name: "SPY +5%", deltaMultiplier: 1.05 },
        { name: "VIX +50%", vegaShock: 0.5 },
      ];
      const scenarios = input?.scenarios?.length ? input.scenarios : defaultScenarios;
      return stressPortfolioRisk(snapshot, safeAccount, scenarios);
    }),

  /** Best strike/expiry for a symbol. Set fullScan=true to score hundreds/thousands of options and pick the best. */
  getBestStrikeExpiry: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        structureType: z.string().default("vertical_call_spread"),
        direction: z.enum(["bullish", "bearish", "neutral"]),
        currentPrice: z.number().optional(),
        fullScan: z.boolean().optional(), // true = scan thousands of strike/expiry/type combos and pick best
      })
    )
    .query(async ({ input }) => {
      const { selectBestStrikeExpiry } = await import("../strike-expiry-selector");
      let price = input.currentPrice;
      if (price == null || price <= 0) {
        try {
          const { getIBMarketData } = await import("../ib-market-data");
          const data = await getIBMarketData(input.symbol);
          if (data?.price != null && data.price > 0) price = data.price;
        } catch {
          // ignore
        }
        if (price == null || price <= 0) price = 100;
      }
      return selectBestStrikeExpiry(
        input.symbol,
        input.structureType,
        input.direction,
        price,
        input.fullScan
      );
    }),

  /** Scan hundreds/thousands of option combinations and return top calls/puts and best pick. */
  scanBestOptionCombinations: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        direction: z.enum(["bullish", "bearish", "neutral"]),
        currentPrice: z.number().optional(),
        maxCombinations: z.number().min(100).max(5000).optional(),
        topN: z.number().min(1).max(20).optional(),
      })
    )
    .query(async ({ input }) => {
      const { scanBestOptionCombinations } = await import("../option-combination-scanner");
      let price = input.currentPrice;
      if (price == null || price <= 0) {
        try {
          const { getIBMarketData } = await import("../ib-market-data");
          const data = await getIBMarketData(input.symbol);
          price = data?.price ?? 100;
        } catch {
          price = 100;
        }
      }
      return scanBestOptionCombinations(input.symbol, price, input.direction, {
        maxCombinations: input.maxCombinations,
        topN: input.topN,
      });
    }),

  /** Suggested quantity (contracts) using position sizing; capped by ADV/market impact. When ENABLE_CONFIDENCE_SIZING, optional regime + intentConfidence scale risk within cap. */
  suggestQuantity: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        optionPrice: z.number().positive(),
        winProbability: z.number().min(0).max(1).default(0.6),
        accountBalance: z.number().positive().optional(),
        maxRiskPerTrade: z.number().min(0.01).max(0.1).default(0.01),
        regime: z.string().optional(),
        intentConfidence: z.number().min(0).max(1).optional(),
      })
    )
    .query(async ({ ctx, input }) => {
      const balance = input.accountBalance ?? safeNum(accountValue, INITIAL_ACCOUNT);
      const { calculateOptimalPositionSize, getConfidenceMultiplier } = await import("../position-sizing");
      const { getMaxOrderSize } = await import("../market-impact");
      let effectiveRisk = input.maxRiskPerTrade;
      const { ENV } = await import("../_core/env");
      if (ENV.enableConfidenceSizing && (input.regime != null || input.intentConfidence != null)) {
        const { getRegimeRiskMultiplierForSizing, normalizeRegimeToCanonical } = await import("../intent-governance");
        const regimeMultiplier = input.regime != null ? getRegimeRiskMultiplierForSizing(normalizeRegimeToCanonical(input.regime)) : 1.0;
        const confidenceMultiplier = getConfidenceMultiplier(input.intentConfidence);
        effectiveRisk = input.maxRiskPerTrade * regimeMultiplier * confidenceMultiplier;
      }
      const sizing = calculateOptimalPositionSize({
        accountBalance: balance,
        winProbability: input.winProbability,
        avgWinSize: 0.25,
        avgLossSize: 0.15,
        currentDrawdown: 0,
        volatility: 0.2,
        correlation: 0,
        maxRiskPerTrade: effectiveRisk,
        optionPrice: input.optionPrice,
        strike: 0,
        currentPrice: 0,
      });
      const capped = getMaxOrderSize({ symbol: input.symbol, quantity: sizing.quantity });
      return {
        quantity: capped,
        recommended: sizing.quantity,
        capped: capped < sizing.quantity,
        rationale: sizing.rationale,
      };
    }),

  getOpenTrades: protectedProcedure.query(async ({ ctx }) => {
    const openTrades = paperTrades.filter(t => t.userId === String(ctx.user.id) && t.status === "OPEN");
    
    return Promise.all(openTrades.map(async (t) => {
      const entryPrice = Number(t.entryPrice) || 0;
      const quantity = Number(t.quantity) || 0;
      let currentPrice = entryPrice;
      try {
        currentPrice = await getCurrentOptionPrice(t);
      } catch (error) {
        console.warn(`[Omega0] Could not fetch option price for ${t.symbol}`);
      }
      const finalPrice = Number.isFinite(currentPrice) ? Math.round(currentPrice * 100) / 100 : entryPrice;
      // Short (sold to open): profit when price falls → (entry - current). Long: (current - entry).
      const unrealizedPnL = Number.isFinite(finalPrice) && Number.isFinite(entryPrice)
        ? t.action === "SELL"
          ? (entryPrice - finalPrice) * quantity * 100
          : (finalPrice - entryPrice) * quantity * 100
        : 0;
      
      return {
        tradeId: t.tradeId,
        symbol: t.symbol,
        expiry: t.expiry,
        strike: t.strike,
        optionType: t.optionType,
        action: t.action,
        quantity,
        entryPrice: entryPrice || t.entryPrice,
        entryTime: t.entryTime,
        currentPrice: finalPrice,
        unrealizedPnL,
        comboId: t.comboId,
        structureType: t.structureType,
      };
    }));
  }),

  /** Close entire multi-leg strategy at once (all legs with same comboId). */
  closeCombo: protectedProcedure
    .input(z.object({ comboId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const legs = paperTrades.filter(
        t => t.userId === String(ctx.user.id) && t.status === "OPEN" && t.comboId === input.comboId
      );
      if (legs.length === 0) {
        throw new Error("No open strategy found with that ID");
      }

      let totalPnL = 0;
      const closed: Array<{ strike: number; optionType: string; pnl: number }> = [];

      for (const trade of legs) {
        const currentPrice = await getCurrentOptionPrice(trade);
        const entryPrice = safeNum(trade.entryPrice, 0);
        const quantity = safeNum(trade.quantity, 0);
        const exitPrice = Number.isFinite(currentPrice) && currentPrice > 0
          ? Math.round(currentPrice * 100) / 100
          : entryPrice;
        // Short (sold to open): profit when we buy back cheaper → pnl = (entry - exit) * qty * 100
        // Long (bought to open): profit when we sell higher → pnl = (exit - entry) * qty * 100
        const pnl = Number.isFinite(exitPrice) && Number.isFinite(entryPrice)
          ? trade.action === "SELL"
            ? (entryPrice - exitPrice) * quantity * 100
            : (exitPrice - entryPrice) * quantity * 100
          : 0;

        trade.exitPrice = exitPrice;
        trade.exitTime = new Date();
        trade.pnl = pnl;
        trade.status = "CLOSED";
        totalPnL += pnl;
        closed.push({ strike: trade.strike, optionType: trade.optionType, pnl });

        try {
          await dbTradeService.updateTradeRecord({
            id: trade.tradeId,
            symbol: trade.symbol,
            assetType: "option",
            entryPrice: trade.entryPrice,
            entryTime: trade.entryTime.getTime(),
            exitPrice,
            exitTime: trade.exitTime.getTime(),
            quantity: trade.quantity,
            direction: "long",
            structureType: trade.structureType || "vertical_call_spread",
            status: "closed",
            pnl,
            pnlPercent: entryPrice > 0 ? (pnl / (entryPrice * quantity * 100)) * 100 : 0,
            createdAt: trade.entryTime.getTime(),
            updatedAt: Date.now(),
          });
        } catch (err) {
          console.warn("[Omega0] Failed to persist leg close (non-fatal):", err);
        }

        accountValue += pnl;
        buyingPower += exitPrice * quantity * 100;
      }
      try {
        const { updateDrawdown } = await import("../drawdown-limiter");
        updateDrawdown(accountValue);
      } catch {
        // non-fatal
      }

      // Outcome log + calibration (one outcome per closed structure)
      try {
        const first = legs[0];
        if (first) {
          const { buildOutcomeFromClose } = await import("../outcome-log");
          const { appendOutcomeAndMaybeCalibrate } = await import("../calibration-job");
          const exitTime = first.exitTime?.getTime() ?? Date.now();
          const entryTime = first.entryTime?.getTime?.() ?? first.entryTime ?? exitTime;
          const durationDays = Math.max(0, (exitTime - entryTime) / (24 * 60 * 60 * 1000));
          const outcome = buildOutcomeFromClose({
            symbol: first.symbol,
            pnl: totalPnL,
            durationDays,
            exitReason: "MANUAL",
            structureType: first.structureType ?? "vertical_call_spread",
            closedAt: exitTime,
            maxDrawdown: 0,
          });
          await appendOutcomeAndMaybeCalibrate(outcome);
        }
      } catch (err) {
        console.warn("[Omega0] Outcome log/calibration (non-fatal):", err);
      }

      const structureLabel = legs[0]?.structureType?.replace(/_/g, " ") ?? "strategy";
      return {
        orderId: `CLOSE_COMBO_${Date.now()}`,
        comboId: input.comboId,
        legsClosed: legs.length,
        totalPnL,
        status: "FILLED",
        message: `Closed entire ${structureLabel} (${legs.length} legs) — total P&L: $${totalPnL.toFixed(2)}`,
        closed,
      };
    }),

  getClosedTrades: protectedProcedure
    .input(z.object({ limit: z.number().default(50) }))
    .query(async ({ ctx, input }) => {
      const closedTrades = paperTrades
        .filter(t => t.userId === String(ctx.user.id) && t.status === "CLOSED")
        .sort((a, b) => (b.exitTime?.getTime() || 0) - (a.exitTime?.getTime() || 0))
        .slice(0, input.limit);
      
      return closedTrades.map(t => ({
        tradeId: t.tradeId,
        symbol: t.symbol,
        expiry: t.expiry,
        strike: t.strike,
        optionType: t.optionType,
        quantity: t.quantity,
        entryPrice: t.entryPrice,
        entryTime: t.entryTime,
        exitPrice: t.exitPrice,
        exitTime: t.exitTime,
        pnl: t.pnl,
        pnlPercent: t.entryPrice > 0 ? ((t.exitPrice || 0) - t.entryPrice) / t.entryPrice * 100 : 0,
      }));
    }),

  getPerformanceMetrics: protectedProcedure.query(async ({ ctx }) => {
    const userTrades = paperTrades.filter(t => t.userId === String(ctx.user.id));
    const closedTrades = userTrades.filter(t => t.status === "CLOSED");
    const wins = closedTrades.filter(t => (t.pnl || 0) > 0);
    const losses = closedTrades.filter(t => (t.pnl || 0) < 0);
    
    const totalPnL = closedTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
    const totalWins = wins.reduce((sum, t) => sum + (t.pnl || 0), 0);
    const totalLosses = Math.abs(losses.reduce((sum, t) => sum + (t.pnl || 0), 0));
    
    // PROBLEM 1 FIX: Calculate Sharpe Ratio (risk-adjusted returns)
    // Sharpe = (Average Return - Risk Free Rate) / Standard Deviation of Returns
    // Annualized for daily returns: Sharpe = (Mean Return * sqrt(252)) / StdDev
    let sharpeRatio = 0;
    if (closedTrades.length > 1) {
      // Calculate returns as percentage of account (using entry price as proxy for position size)
      const returns = closedTrades.map(t => {
        const entryValue = (t.entryPrice || 0) * (t.quantity || 0) * 100; // Option contract value
        if (entryValue > 0) {
          return (t.pnl || 0) / entryValue; // Return as fraction
        }
        return 0;
      });
      
      const meanReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
      
      // Calculate standard deviation
      const variance = returns.reduce((sum, r) => sum + Math.pow(r - meanReturn, 2), 0) / (returns.length - 1);
      const stdDev = Math.sqrt(variance);
      
      // Annualize Sharpe ratio (assuming daily trades, sqrt(252) for trading days)
      // Risk-free rate assumed to be 0 for simplicity (or use current risk-free rate)
      sharpeRatio = stdDev > 0 ? (meanReturn * Math.sqrt(252)) / stdDev : 0;
    }
    
    // PROBLEM 2 FIX: Calculate Max Drawdown (peak-to-trough decline)
    // This is CRITICAL for risk assessment - shows worst case scenario
    // Max Drawdown = (Peak Equity - Trough Equity) / Peak Equity
    let maxDrawdown = 0;
    const initialEquity = 100000; // Starting account value
    let peakEquity = initialEquity;
    let runningEquity = initialEquity;
    
    // Sort trades by exit time (oldest first) to calculate drawdown chronologically
    const sortedTrades = [...closedTrades].sort((a, b) => 
      (a.exitTime?.getTime() || 0) - (b.exitTime?.getTime() || 0)
    );
    
    // Calculate equity curve and find max drawdown
    for (const trade of sortedTrades) {
      runningEquity += trade.pnl || 0;
      
      // Update peak if we hit a new high
      if (runningEquity > peakEquity) {
        peakEquity = runningEquity;
      }
      
      // Calculate current drawdown from peak
      const currentDrawdown = peakEquity > 0 ? (peakEquity - runningEquity) / peakEquity : 0;
      
      // Track maximum drawdown
      if (currentDrawdown > maxDrawdown) {
        maxDrawdown = currentDrawdown;
      }
    }
    
    // Also check current drawdown from peak (including open positions)
    const currentEquity = accountValue; // Current account value
    if (currentEquity > peakEquity) {
      peakEquity = currentEquity;
    }
    const currentDrawdown = peakEquity > 0 ? (peakEquity - currentEquity) / peakEquity : 0;
    if (currentDrawdown > maxDrawdown) {
      maxDrawdown = currentDrawdown;
    }
    
    return {
      totalTrades: userTrades.length,
      closedTrades: closedTrades.length,
      openTrades: userTrades.filter(t => t.status === "OPEN").length,
      winRate: closedTrades.length > 0 ? (wins.length / closedTrades.length) * 100 : 0,
      totalPnL: safeNum(totalPnL, 0),
      avgWinSize: wins.length > 0 ? safeNum(totalWins / wins.length, 0) : 0,
      avgLossSize: losses.length > 0 ? safeNum(totalLosses / losses.length, 0) : 0,
      profitFactor: totalLosses > 0 ? safeNum(totalWins / totalLosses, 0) : 0,
      sharpeRatio: safeNum(sharpeRatio, 0),
      maxDrawdown: safeNum(maxDrawdown * 100, 0),
    };
  }),
  
  // Quick trade from opportunity - pre-fills with recommended strategy
  tradeOpportunity: protectedProcedure
    .input(
      z.object({
        symbol: z.string(),
        structure: z.string(),
        direction: z.enum(["bullish", "bearish", "neutral"]),
        quantity: z.number().default(1),
      })
    )
    .mutation(async ({ ctx, input }) => {
      // Get current price from IB only
      let currentPrice = 0;
      try {
        const { getIBMarketData } = await import('../ib-market-data');
        const ibData = await getIBMarketData(input.symbol);
        if (ibData?.price > 0) currentPrice = ibData.price;
        if (currentPrice <= 0) throw new Error(`No price for ${input.symbol}`);
      } catch (error) {
        console.error(`[Omega0] Error fetching price for ${input.symbol}:`, error);
        throw new Error(`Unable to fetch price for ${input.symbol} - IB Gateway required`);
      }
      
      // Determine option type based on direction
      const optionType = input.direction === "bearish" ? "P" : "C";
      
      // Calculate strike based on structure
      let strike = currentPrice;
      if (input.structure.includes("spread")) {
        strike = Math.round(currentPrice * (input.direction === "bullish" ? 1.02 : 0.98));
      }
      
      // Get real expiry dates from option chain
      let expiry = "20260219"; // Default fallback
      try {
        const { getIBOptionsChain } = await import('../ib-market-data');
        const chain = await getIBOptionsChain(input.symbol);
        if (chain && chain.expirations.length > 0) {
          // Use nearest expiry
          expiry = chain.expirations[0];
        }
      } catch (error) {
        console.warn(`[Omega0] Could not fetch real expiry dates, using default`);
      }
      
      // Get real option price
      let fillPrice = 0;
      try {
        const { getIBOptionsChain } = await import('../ib-market-data');
        const chain = await getIBOptionsChain(input.symbol);
        if (chain) {
          const option = chain.options.find(
            opt => opt.expiry === expiry && 
                   opt.strike === strike && 
                   opt.right === optionType
          );
          if (option) {
            fillPrice = (option.bid + option.ask) / 2;
          } else {
            throw new Error(`Option not found in chain`);
          }
        } else {
          throw new Error(`No option chain available`);
        }
      } catch (error) {
        console.error(`[Omega0] Error fetching option price:`, error);
        throw new Error(`Unable to fetch real option price - IB Gateway connection required`);
      }
      const tradeId = `PAPER_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
      
      const trade: PaperTrade = {
        tradeId,
        userId: String(ctx.user.id),
        symbol: input.symbol,
        expiry,
        strike,
        optionType,
        action: "BUY",
        quantity: input.quantity,
        entryPrice: fillPrice,
        entryTime: new Date(),
        status: "OPEN",
      };
      
      paperTrades.push(trade);
      buyingPower -= fillPrice * input.quantity * 100;
      
      return {
        success: true,
        tradeId,
        symbol: input.symbol,
        structure: input.structure,
        strike,
        optionType,
        expiry,
        quantity: input.quantity,
        filledPrice: fillPrice,
        message: `Executed ${input.structure} on ${input.symbol}: ${input.quantity} ${strike}${optionType} @ $${fillPrice}`,
      };
    }),
});
