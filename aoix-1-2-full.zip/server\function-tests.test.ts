import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { AutoTradingEngine } from './auto-trading-engine';
import { GatewayAdapter } from './gateway-adapter';

// Stub opportunity for fast tests (avoids 186-stock IB scan and timeouts)
const STUB_OPPORTUNITY = {
  symbol: 'AAPL',
  currentPrice: 150,
  priceChange: 1,
  priceChangePercent: 0.67,
  volume: 50_000_000,
  avgVolume: 48_000_000,
  high52Week: 200,
  low52Week: 120,
  regime: 'bull_vol_compression',
  signal: { class: 'A', confidence: 0.75, direction: 'bullish' },
  opportunity: { score: 72, expectedReturn: 2.5, riskReward: 1.2, winProbability: 0.65 },
  structure: { type: 'vertical_call_spread', direction: 'bullish', expectedValue: 1.5, cvar: -0.5 },
  ivRank: 55,
  timestamp: Date.now(),
  dataSource: 'ibkr' as const,
};

function createStubScanner() {
  const opps = [STUB_OPPORTUNITY];
  return {
    scan: vi.fn().mockResolvedValue(opps),
    getTopOpportunities: (n: number) => opps.slice(0, n),
    getOpportunity: (sym: string) => opps.find(o => o.symbol === sym),
    getAllOpportunities: () => [...opps],
  };
}

vi.mock('./market-scanner', () => ({
  getMarketScanner: () => createStubScanner(),
  MarketScanner: class StubMarketScanner {
    scan = () => Promise.resolve([STUB_OPPORTUNITY]);
    getTopOpportunities = (n: number) => [STUB_OPPORTUNITY].slice(0, n);
    getOpportunity = (sym: string) => (sym === 'AAPL' ? STUB_OPPORTUNITY : undefined);
    getAllOpportunities = () => [STUB_OPPORTUNITY];
  },
}));

import { getMarketScanner, MarketScanner } from './market-scanner';

/**
 * COMPREHENSIVE FUNCTION TESTS
 * Tests all tRPC endpoints and backend services (scanner stubbed to avoid network/timeout)
 */

describe('Function Tests - Market Scanner Endpoints', () => {
  function getScanner() {
    return getMarketScanner();
  }

  it('should scan market and return opportunities', async () => {
    const scanner = getScanner();
    const result = await scanner.scan();
    expect(result).toBeDefined();
    expect(Array.isArray(result)).toBe(true);
    expect(result.length).toBeGreaterThanOrEqual(0);
  });

  it('should get top opportunities with correct count', async () => {
    const scanner = getScanner();
    await scanner.scan();
    const top10 = scanner.getTopOpportunities(10);
    expect(top10.length).toBeLessThanOrEqual(10);
    const top20 = scanner.getTopOpportunities(20);
    expect(top20.length).toBeLessThanOrEqual(20);
  });

  it('should get opportunity for specific symbol', async () => {
    const scanner = getScanner();
    await scanner.scan();
    const opp = scanner.getOpportunity('AAPL');
    if (opp) {
      expect(opp.symbol).toBe('AAPL');
      expect(opp.currentPrice).toBeGreaterThan(0);
      expect(opp.opportunity.score).toBeGreaterThanOrEqual(0);
      expect(opp.opportunity.score).toBeLessThanOrEqual(100);
    }
  });

  it('should get all opportunities', async () => {
    const scanner = getScanner();
    await scanner.scan();
    const all = scanner.getAllOpportunities();
    expect(Array.isArray(all)).toBe(true);
  });

  it('should return array from getAllOpportunities', () => {
    const scanner = getScanner();
    const all = scanner.getAllOpportunities();
    expect(Array.isArray(all)).toBe(true);
  });

  it('should validate opportunity structure', async () => {
    const scanner = getScanner();
    const opps = await scanner.scan();
    if (opps.length > 0) {
      const opp = opps[0];
      expect(opp.symbol).toBeDefined();
      expect(opp.currentPrice).toBeGreaterThan(0);
      expect(opp.regime).toBeDefined();
      expect(opp.signal?.class).toBeDefined();
      expect(opp.signal?.confidence).toBeGreaterThanOrEqual(0);
      expect(opp.signal?.confidence).toBeLessThanOrEqual(1);
      expect(opp.signal?.direction).toMatch(/bullish|bearish|neutral/);
      expect(opp.opportunity?.score).toBeGreaterThanOrEqual(0);
      expect(opp.opportunity?.score).toBeLessThanOrEqual(100);
      expect(opp.opportunity?.expectedReturn).toBeDefined();
      expect(opp.opportunity?.riskReward).toBeGreaterThanOrEqual(0);
      expect(opp.opportunity?.winProbability).toBeGreaterThanOrEqual(0);
      expect(opp.opportunity?.winProbability).toBeLessThanOrEqual(1);
      expect(opp.structure?.type).toBeDefined();
      expect(opp.structure?.direction).toBeDefined();
    }
  });
});

describe('Function Tests - Auto Trading Engine Endpoints', () => {
  let engine: AutoTradingEngine;

  beforeEach(() => {
    engine = new AutoTradingEngine();
  });

  afterEach(() => {
    engine.stop();
  });

  it('should start trading engine', () => {
    engine.start();
    const state = engine.getState();
    expect(state.isRunning).toBe(true);
  });

  it('should stop trading engine', () => {
    engine.start();
    let state = engine.getState();
    expect(state.isRunning).toBe(true);
    
    engine.stop();
    state = engine.getState();
    expect(state.isRunning).toBe(false);
  });

  it('should reset engine state', () => {
    engine.start();
    engine.resetAccount();
    
    const state = engine.getState();
    expect(state.positions).toHaveLength(0);
    expect(state.totalPnL).toBe(0);
  });

  it('should get current engine state', () => {
    engine.start();
    const state = engine.getState();
    
    expect(state.isRunning).toBe(true);
    expect(state.currentRegime).toBeDefined();
    expect(Array.isArray(state.positions)).toBe(true);
    expect(state.totalPnL).toBeDefined();
    expect(state.dayPnL).toBeDefined();
    expect(state.trades).toBeDefined();
    expect(Array.isArray(state.trades)).toBe(true);
  });

  it('should get performance metrics from state', () => {
    engine.start();
    const state = engine.getState();
    
    expect(state.trades).toBeDefined();
    expect(Array.isArray(state.trades)).toBe(true);
    expect(state.totalPnL).toBeDefined();
    expect(state.dayPnL).toBeDefined();
    expect(state.riskMetrics).toBeDefined();
    expect(state.accountBalance).toBeGreaterThan(0);
  });

  it('should enforce risk management limits', () => {
    engine.start();
    const state = engine.getState();
    
    // Max 3 positions
    expect(state.positions.length).toBeLessThanOrEqual(3);
    
    // Daily loss limit
    expect(state.dayPnL).toBeGreaterThan(-state.accountBalance * 0.05);
  });

  it('should validate engine state structure', () => {
    engine.start();
    const state = engine.getState();
    
    expect(state.isRunning).toBe(true);
    expect(state.currentRegime).toBeDefined();
    expect(state.positions).toBeDefined();
    expect(state.totalPnL).toBeDefined();
    expect(state.dayPnL).toBeDefined();
    expect(state.trades).toBeDefined();
    expect(state.riskMetrics).toBeDefined();
  });
});

describe('Function Tests - Gateway Adapter Endpoints', () => {
  let adapter: GatewayAdapter;
  let engine: AutoTradingEngine;

  beforeEach(() => {
    engine = new AutoTradingEngine();
    adapter = new GatewayAdapter(engine);
  });

  afterEach(() => {
    adapter.disconnect();
    engine.stop();
  });

  it('should get gateway configuration', () => {
    const config = adapter.getConfig();
    
    expect(config.host).toBeDefined();
    expect(config.port).toBeGreaterThan(0);
    expect(config.clientId).toBeGreaterThan(0);
  });

  it('should set gateway configuration', () => {
    adapter.setConfig({
      host: '192.168.1.100',
      port: 7497,
      clientId: 1
    });
    
    const config = adapter.getConfig();
    expect(config.host).toBe('192.168.1.100');
    expect(config.port).toBe(7497);
  });

  it('should connect to gateway', async () => {
    const result = await adapter.connect();
    expect(result).toBeDefined();
    // Result may be true or false depending on whether Gateway is running
  });

  it('should disconnect from gateway', async () => {
    await adapter.connect();
    adapter.disconnect();
    const status = adapter.getConnectionStatus();
    expect(status.isConnected).toBe(false);
  });

  it('should report connection status', () => {
    const status = adapter.getConnectionStatus();
    expect(typeof status.isConnected).toBe('boolean');
  });

  it('should get gateway status', () => {
    const status = adapter.getConnectionStatus();
    
    expect(typeof status.isConnected).toBe('boolean');
    expect(status.mode).toMatch(/paper|live/);
    expect(status.lastConnectAttempt).toBeDefined();
    expect(status.connectionError).toBeDefined();
  });

  it('should validate gateway configuration structure', () => {
    const config = adapter.getConfig();
    
    expect(config.host).toBeDefined();
    expect(typeof config.host).toBe('string');
    expect(config.port).toBeGreaterThan(0);
    expect(config.port).toBeLessThan(65536);
    expect(config.clientId).toBeGreaterThanOrEqual(1);
  });
});

describe('Function Tests - Edge Cases', () => {
  it('should handle empty market scan gracefully', async () => {
    const scanner = new MarketScanner();
    const result = await scanner.scan();
    expect(Array.isArray(result)).toBe(true);
  });

  it('should handle invalid opportunity symbol', () => {
    const scanner = getMarketScanner();
    const opp = scanner.getOpportunity('INVALID_SYMBOL_XYZ');
    expect(opp).toBeUndefined();
  });

  it('should handle zero count for top opportunities', () => {
    const scanner = getMarketScanner();
    const result = scanner.getTopOpportunities(0);
    expect(result).toHaveLength(0);
  });

  it('should handle large count for top opportunities', () => {
    const scanner = getMarketScanner();
    const result = scanner.getTopOpportunities(1000);
    expect(Array.isArray(result)).toBe(true);
  });

  it('should handle engine start/stop cycles', () => {
    const engine = new AutoTradingEngine();
    
    for (let i = 0; i < 5; i++) {
      engine.start();
      let state = engine.getState();
      expect(state.isRunning).toBe(true);
      
      engine.stop();
      state = engine.getState();
      expect(state.isRunning).toBe(false);
    }
  });

  it('should handle gateway reconnection attempts', async () => {
    const engine = new AutoTradingEngine();
    const adapter = new GatewayAdapter(engine);
    
    for (let i = 0; i < 3; i++) {
      await adapter.connect();
      adapter.disconnect();
    }
    
    const status = adapter.getConnectionStatus();
    expect(status.isConnected).toBe(false);
  });
});

describe('Function Tests - Data Validation', () => {
  it('should validate opportunity scores are in range', async () => {
    const scanner = getMarketScanner();
    const opps = await scanner.scan();
    
    opps.forEach(opp => {
      expect(opp.opportunity.score).toBeGreaterThanOrEqual(0);
      expect(opp.opportunity.score).toBeLessThanOrEqual(100);
    });
  });

  it('should validate win probabilities are in range', async () => {
    const scanner = getMarketScanner();
    const opps = await scanner.scan();
    
    opps.forEach(opp => {
      expect(opp.opportunity.winProbability).toBeGreaterThanOrEqual(0);
      expect(opp.opportunity.winProbability).toBeLessThanOrEqual(1);
    });
  });

  it('should validate signal confidence is in range', async () => {
    const scanner = getMarketScanner();
    const opps = await scanner.scan();
    
    opps.forEach(opp => {
      expect(opp.signal.confidence).toBeGreaterThanOrEqual(0);
      expect(opp.signal.confidence).toBeLessThanOrEqual(1);
    });
  });

  it('should validate IV rank is in range', async () => {
    const scanner = getMarketScanner();
    const opps = await scanner.scan();
    opps.forEach(opp => {
      if (opp.ivRank != null) {
        expect(opp.ivRank).toBeGreaterThanOrEqual(0);
        expect(opp.ivRank).toBeLessThanOrEqual(100);
      }
    });
  });

  it('should validate engine state metrics', () => {
    const engine = new AutoTradingEngine();
    engine.start();
    
    const state = engine.getState();
    expect(state.totalPnL).toBeDefined();
    expect(state.dayPnL).toBeDefined();
    expect(state.positions).toBeDefined();
    expect(Array.isArray(state.positions)).toBe(true);
    
    engine.stop();
  });
});

describe('Function Tests - Integration', () => {
  it('should integrate market scanner with auto trading', async () => {
    const scanner = getMarketScanner();
    const opps = await scanner.scan();
    const engine = new AutoTradingEngine();
    engine.start();
    const state = engine.getState();
    expect(state.isRunning).toBe(true);
    expect(Array.isArray(state.positions)).toBe(true);
    engine.stop();
  });

  it('should integrate gateway with auto trading', async () => {
    const engine = new AutoTradingEngine();
    const adapter = new GatewayAdapter(engine);
    engine.start();
    const state = engine.getState();
    expect(state.isRunning).toBe(true);
    engine.stop();
    adapter.disconnect();
  });

  it('should handle complete trading workflow', async () => {
    const scanner = getMarketScanner();
    const opps = await scanner.scan();
    expect(Array.isArray(opps)).toBe(true);
    const engine = new AutoTradingEngine();
    engine.start();
    let state = engine.getState();
    expect(state.isRunning).toBe(true);
    expect(Array.isArray(state.positions)).toBe(true);
    expect(Array.isArray(state.trades)).toBe(true);
    engine.stop();
    state = engine.getState();
    expect(state.isRunning).toBe(false);
  });
});
