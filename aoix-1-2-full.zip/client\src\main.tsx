import { trpc } from "@/lib/trpc";
import { UNAUTHED_ERR_MSG } from '@shared/const';
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { httpBatchLink, TRPCClientError } from "@trpc/client";
import { createRoot } from "react-dom/client";
import superjson from "superjson";
import App from "./App";
import { getLoginUrl } from "./const";
import "./index.css";

const queryClient = new QueryClient();

const redirectToLoginIfUnauthorized = (error: unknown) => {
  if (!(error instanceof TRPCClientError)) return;
  if (typeof window === "undefined") return;

  const isUnauthorized = error.message === UNAUTHED_ERR_MSG;

  if (!isUnauthorized) return;

  window.location.href = getLoginUrl();
};

queryClient.getQueryCache().subscribe(event => {
  if (event.type === "updated" && event.action.type === "error") {
    const error = event.query.state.error;
    redirectToLoginIfUnauthorized(error);
    console.error("[API Query Error]", error);
  }
});

queryClient.getMutationCache().subscribe(event => {
  if (event.type === "updated" && event.action.type === "error") {
    const error = event.mutation.state.error;
    redirectToLoginIfUnauthorized(error);
    console.error("[API Mutation Error]", error);
  }
});

const trpcClient = trpc.createClient({
  links: [
    httpBatchLink({
      url: "/api/trpc",
      transformer: superjson,
      fetch(input, init) {
        const url = typeof input === "string" ? input : (input instanceof Request ? input.url : String(input));
        console.log("[tRPC] Fetching:", url, "method:", init?.method || "GET", "headers:", init?.headers);
        return globalThis.fetch(input, {
          ...(init ?? {}),
          credentials: "include",
        })
        .then((response) => {
          console.log("[tRPC] Response status:", response.status, "ok:", response.ok, "url:", url);
          if (!response.ok) {
            console.error("[tRPC] Response not OK:", response.status, response.statusText);
          }
          return response;
        })
        .catch((error) => {
          console.error("[tRPC] Fetch error:", error, "url:", url, "error type:", error?.constructor?.name);
          console.error("[tRPC] Error details:", {
            message: error?.message,
            stack: error?.stack,
            cause: error?.cause,
          });
          throw error;
        });
      },
    }),
  ],
});

createRoot(document.getElementById("root")!).render(
  <trpc.Provider client={trpcClient} queryClient={queryClient}>
    <QueryClientProvider client={queryClient}>
      <App />
    </QueryClientProvider>
  </trpc.Provider>
);
