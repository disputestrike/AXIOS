/**
 * Correlation regime stress — identify high-correlation periods and optional backtest.
 * Used to see how strategy performs when cross-asset correlation rises (e.g. crisis).
 */

interface PriceBar {
  date: Date;
  close: number;
}

export interface CorrelationRegime {
  date: Date;
  avgCorrelation: number;
  regime: "low" | "medium" | "high";
}

/** Pearson correlation between two return series. */
function pearsonCorrelation(x: number[], y: number[]): number {
  const n = x.length;
  if (n < 2) return 0;
  const meanX = x.reduce((a, b) => a + b, 0) / n;
  const meanY = y.reduce((a, b) => a + b, 0) / n;
  let num = 0,
    denX = 0,
    denY = 0;
  for (let i = 0; i < n; i++) {
    const dx = x[i] - meanX;
    const dy = y[i] - meanY;
    num += dx * dy;
    denX += dx * dx;
    denY += dy * dy;
  }
  const den = Math.sqrt(denX * denY);
  return den > 0 ? num / den : 0;
}

/** Fetch historical chart for a symbol. IB only: use IB historical API. */
export async function getHistoricalPriceData(
  _symbol: string,
  _startDate: Date,
  _endDate: Date
): Promise<PriceBar[]> {
  throw new Error("Historical data requires IB API (no third-party source)");
}

/** Align series by date and compute returns. */
function alignedReturns(
  series: Map<string, PriceBar[]>,
  symbols: string[],
  windowStart: number,
  windowEnd: number
): number[][] {
  const dates = series.get(symbols[0])?.slice(windowStart, windowEnd).map((p) => p.date.getTime()) ?? [];
  const out: number[][] = symbols.map(() => []);
  for (let i = 0; i < symbols.length; i++) {
    const bars = series.get(symbols[i]) ?? [];
    for (let j = windowStart; j < Math.min(windowEnd, bars.length - 1); j++) {
      if (bars[j].close > 0 && bars[j + 1].close != null) {
        out[i].push((bars[j + 1].close - bars[j].close) / bars[j].close);
      }
    }
  }
  const minLen = Math.min(...out.map((r) => r.length));
  return out.map((r) => r.slice(0, minLen));
}

/** Identify correlation regime over rolling window (avg pairwise correlation). */
export async function identifyHighCorrelationPeriods(
  symbols: string[],
  startDate: Date,
  endDate: Date,
  windowDays = 20
): Promise<CorrelationRegime[]> {
  const allData = new Map<string, PriceBar[]>();
  for (const symbol of symbols) {
    try {
      const bars = await getHistoricalPriceData(symbol, startDate, endDate);
      allData.set(symbol, bars);
    } catch {
      // skip symbol
    }
  }
  if (allData.size < 2) return [];
  const ref = allData.get(symbols[0]) ?? [];
  const results: CorrelationRegime[] = [];
  for (let i = windowDays; i < ref.length - 1; i++) {
    const rets = alignedReturns(allData, symbols, i - windowDays, i + 1);
    const minLen = Math.min(...rets.map((r) => r.length));
    if (minLen < 5) continue;
    const trimmed = rets.map((r) => r.slice(0, minLen));
    let sum = 0,
      count = 0;
    for (let a = 0; a < trimmed.length; a++) {
      for (let b = a + 1; b < trimmed.length; b++) {
        sum += pearsonCorrelation(trimmed[a], trimmed[b]);
        count++;
      }
    }
    const avgCorr = count > 0 ? sum / count : 0;
    const regime: "low" | "medium" | "high" =
      avgCorr < 0.4 ? "low" : avgCorr < 0.6 ? "medium" : "high";
    results.push({
      date: ref[i].date,
      avgCorrelation: avgCorr,
      regime,
    });
  }
  return results;
}
