import net from 'net';
import https from 'https';
import { URL } from 'url';

/**
 * TCP to HTTPS Proxy
 * Converts raw TCP connections to HTTPS requests for LocalTunnel
 */

const TUNNEL_URL = 'https://afraid-bikes-wash.loca.lt';
const PROXY_PORT = 9001;

const server = net.createServer((clientSocket) => {
  console.log('[TCP-HTTPS Proxy] Client connected');

  const tunnelUrl = new URL(TUNNEL_URL);
  
  const options = {
    hostname: tunnelUrl.hostname,
    port: 443,
    path: '/',
    method: 'CONNECT',
    rejectUnauthorized: false, // Allow self-signed certs from LocalTunnel
  };

  const req = https.request(options, (res) => {
    console.log('[TCP-HTTPS Proxy] Response received');
  });

  req.on('connect', (res, socket, head) => {
    console.log('[TCP-HTTPS Proxy] CONNECT successful');
    
    // Bidirectional pipe
    clientSocket.pipe(socket);
    socket.pipe(clientSocket);

    clientSocket.on('end', () => {
      console.log('[TCP-HTTPS Proxy] Client disconnected');
      socket.end();
    });

    socket.on('end', () => {
      console.log('[TCP-HTTPS Proxy] Tunnel disconnected');
      clientSocket.end();
    });

    clientSocket.on('error', (err) => {
      console.error('[TCP-HTTPS Proxy] Client error:', err.message);
      socket.destroy();
    });

    socket.on('error', (err) => {
      console.error('[TCP-HTTPS Proxy] Socket error:', err.message);
      clientSocket.destroy();
    });
  });

  req.on('error', (err) => {
    console.error('[TCP-HTTPS Proxy] Request error:', err.message);
    clientSocket.destroy();
  });

  req.end();
});

server.listen(PROXY_PORT, 'localhost', () => {
  console.log(`[TCP-HTTPS Proxy] Listening on localhost:${PROXY_PORT}`);
  console.log(`[TCP-HTTPS Proxy] Forwarding to ${TUNNEL_URL}`);
});

server.on('error', (err) => {
  console.error('[TCP-HTTPS Proxy] Server error:', err);
});
