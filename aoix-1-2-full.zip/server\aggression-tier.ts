/**
 * Aggression Tier — "Gets more aggressive as it proves itself"
 * Uses recent performance to allow higher risk and more positions when the system is winning.
 */

import type { PerformanceMetrics } from './adaptive-risk';

export type AggressionTier = 1 | 2 | 3 | 4 | 5;

export interface AggressionResult {
  tier: AggressionTier;
  /** Multiplier for base risk (1.0 = no change, up to 1.5 when tier 5) */
  riskMultiplier: number;
  /** Extra max positions allowed (0–2) */
  maxPositionBonus: number;
  /** Min score threshold reduction (stricter when conservative) */
  minScoreReduction: number;
  rationale: string;
}

const TIER_CAPS = {
  riskMultiplierMax: 1.5,
  maxPositionBonusMax: 2,
  minScoreReductionMax: 5,
} as const;

/**
 * Compute aggression tier from performance.
 * Tier 1 = conservative (no bonus), Tier 5 = proven (max bonus).
 */
export function getAggressionTier(
  performance: PerformanceMetrics,
  closedTradeCount: number
): AggressionResult {
  const rationale: string[] = [];
  let tier: AggressionTier = 1;
  let riskMultiplier = 1.0;
  let maxPositionBonus = 0;
  let minScoreReduction = 0;

  // Need at least some history to increase aggression
  if (closedTradeCount < 3) {
    return {
      tier: 1,
      riskMultiplier: 1.0,
      maxPositionBonus: 0,
      minScoreReduction: 0,
      rationale: 'Insufficient trade history — stay conservative',
    };
  }

  // Consecutive wins: tier up
  if (performance.consecutiveWins >= 8 && performance.currentDrawdown < 0.02) {
    tier = 5;
    riskMultiplier = 1.5;
    maxPositionBonus = 2;
    minScoreReduction = 5;
    rationale.push(`${performance.consecutiveWins} consecutive wins, low drawdown`);
  } else if (performance.consecutiveWins >= 5 && performance.currentDrawdown < 0.03) {
    tier = 4;
    riskMultiplier = 1.35;
    maxPositionBonus = 1;
    minScoreReduction = 3;
    rationale.push(`${performance.consecutiveWins} wins, drawdown ${(performance.currentDrawdown * 100).toFixed(1)}%`);
  } else if (performance.consecutiveWins >= 3 && performance.currentDrawdown < 0.05) {
    tier = 3;
    riskMultiplier = 1.2;
    maxPositionBonus = 1;
    minScoreReduction = 2;
    rationale.push(`${performance.consecutiveWins} wins`);
  } else if (performance.consecutiveWins >= 2 && performance.currentDrawdown < 0.05) {
    tier = 2;
    riskMultiplier = 1.1;
    maxPositionBonus = 0;
    minScoreReduction = 1;
    rationale.push('Building confidence');
  }

  // Sharpe / win rate: can boost tier if not already high
  if (tier < 5 && performance.winRate >= 0.65 && performance.profitFactor >= 1.5 && performance.currentDrawdown < 0.03) {
    if (tier < 4) {
      tier = Math.min(tier + 1, 4) as AggressionTier;
      riskMultiplier = Math.min(riskMultiplier + 0.1, TIER_CAPS.riskMultiplierMax);
      rationale.push(`Strong stats: WR ${(performance.winRate * 100).toFixed(0)}%, PF ${performance.profitFactor.toFixed(2)}`);
    }
  }

  // Drawdown or losses: force tier down
  if (performance.currentDrawdown > 0.05 || performance.consecutiveLosses >= 2) {
    tier = 1;
    riskMultiplier = 1.0;
    maxPositionBonus = 0;
    minScoreReduction = 0;
    rationale.length = 0;
    rationale.push('Drawdown or losses — back to conservative');
  }

  return {
    tier,
    riskMultiplier: Math.min(riskMultiplier, TIER_CAPS.riskMultiplierMax),
    maxPositionBonus: Math.min(maxPositionBonus, TIER_CAPS.maxPositionBonusMax),
    minScoreReduction: Math.min(minScoreReduction, TIER_CAPS.minScoreReductionMax),
    rationale: rationale.length > 0 ? rationale.join(' | ') : 'Default (tier 1)',
  };
}
