# MySQL Setup — Next Steps

You have MySQL set up. Follow these steps so the app uses it.

## 1. Create the database (if not already)

In MySQL (command line, Workbench, or any client):

```sql
CREATE DATABASE aoix1 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

(Use a different name if you prefer; update step 2 accordingly.)

## 2. Set `DATABASE_URL` in `.env.local`

In the project root, open or create `.env.local` and add (replace with your MySQL user, password, host, port, and database name):

```bash
# MySQL — use your real user, password, and database name
DATABASE_URL=mysql://USER:PASSWORD@localhost:3306/aoix1
```

Examples:

- Local MySQL, user `root`, password `mypass`, database `aoix1`:
  ```bash
  DATABASE_URL=mysql://root:mypass@localhost:3306/aoix1
  ```
- Non-default port (e.g. 3307):
  ```bash
  DATABASE_URL=mysql://user:password@localhost:3307/aoix1
  ```

If your password contains special characters, URL-encode them (e.g. `#` → `%23`, `@` → `%40`).

## 3. Run migrations

From the project root:

```bash
pnpm db:migrate
```

This applies the existing migrations and creates the tables (users, marketData, trades, etc.).

If you see `DATABASE_URL is required`, ensure `.env.local` exists and contains `DATABASE_URL`; the Drizzle config loads `.env.local` automatically.

Optional (if you change the schema later):

```bash
pnpm db:push
```

(`db:push` = generate + migrate; use after schema changes.)

## 4. Restart the app

```bash
pnpm dev
```

## 5. Verify

- Open **System Health** in the app.
- **Database** should show **healthy** (green), not “Database not configured (using in-memory fallback)”.

---

## Quick checklist

- [ ] MySQL is running.
- [ ] Database `aoix1` (or your name) exists.
- [ ] `.env.local` has `DATABASE_URL=mysql://user:password@host:port/database`.
- [ ] `pnpm db:migrate` completed without errors.
- [ ] App restarted (`pnpm dev`).
- [ ] System Health shows Database **healthy**.

## Optional: outcome store for learning from trades

To have the system learn from trades across restarts, add to `.env.local`:

```bash
OUTCOME_STORE=file
# Or OUTCOME_STORE=sqlite (requires better-sqlite3)
```

Then, after enough closed trades (e.g. 50+), you can enable confidence calibration:

```bash
ENABLE_CONFIDENCE_CALIBRATION=true
```
