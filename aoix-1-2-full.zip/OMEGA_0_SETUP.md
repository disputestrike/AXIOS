# Omega-0: IBKR Live Trading Integration

## Overview

Omega-0 is the execution layer that connects AOIX-1 (Sovereign Market Organism) to Interactive Brokers for **real, live options trading**. This is not a simulator. This is money moving.

**Philosophy:** No abstractions. No 404s. No "AI magic." Only closed-loop execution with deterministic risk management.

---

## Prerequisites

### 1. Interactive Brokers Account
- **Paper Trading Account** (recommended for testing)
- **Live Account** (for production trading)
- Account must have options trading enabled

### 2. TWS or IB Gateway
Download and install one of:
- **Trader Workstation (TWS)** - Full desktop application
- **IB Gateway** - Lightweight command-line tool

Both are available at: https://www.interactivebrokers.com/en/trading/platforms/

### 3. API Configuration
In TWS/IB Gateway:
1. Go to **Edit → Settings → API**
2. Enable "Enable ActiveX and Socket Clients"
3. Set port to **7497** (paper trading) or **7496** (live trading)
4. Uncheck "Read-Only API"
5. Restart TWS/IB Gateway

### 4. Python Dependencies
```bash
pip install ib-insync pandas numpy
```

---

## System Architecture

```
┌─────────────────────────────────────────────────────────┐
│                   AOIX-1 Dashboard                      │
│         (Regime, Signals, Structures, Risk)             │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│              Omega-0 Execution Engine                   │
│  ┌──────────────────────────────────────────────────┐   │
│  │ 1. Signal Validation (Entry Gates)               │   │
│  │ 2. Option Chain Fetching (IBKR)                  │   │
│  │ 3. Position Sizing (Risk % of Account)           │   │
│  │ 4. Order Placement (Market/Limit)                │   │
│  │ 5. Position Monitoring (Real-time P&L)           │   │
│  │ 6. Exit Automation (Take Profit / Stop Loss)     │   │
│  │ 7. Trade Logging (All fills, exits, P&L)         │   │
│  └──────────────────────────────────────────────────┘   │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│          Interactive Brokers (IBKR)                     │
│  ┌──────────────────────────────────────────────────┐   │
│  │ Real Options Contracts                           │   │
│  │ Real Order Execution                             │   │
│  │ Real Fills & Slippage                            │   │
│  │ Real Account Management                          │   │
│  └──────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
```

---

## Omega-0 Ruleset (Immutable)

These rules are **locked** and cannot be overridden:

| Rule | Value | Rationale |
|------|-------|-----------|
| **Product** | Equity options | Liquid, well-understood |
| **Structure** | Long ATM option | Defined risk, clear payoff |
| **Direction** | Momentum-based | Follows regime signals |
| **Max Risk per Trade** | 1% of account | Prevents ruin |
| **Take Profit** | +30% | Captures edge, exits winners |
| **Stop Loss** | -20% | Limits downside |
| **Max Positions** | 1 at a time | Reduces correlation risk |
| **Kill Switch** | Enabled | Stops all trading on command |

---

## API Reference

### Omega-0 tRPC Procedures

#### `omega0.getStatus()`
Get current IBKR connection status.

**Response:**
```typescript
{
  connected: boolean;
  accountValue: number;
  openTrades: number;
  totalTrades: number;
  message: string;
}
```

#### `omega0.getAccountSummary()`
Get account metrics (net liquidation, buying power, cash).

**Response:**
```typescript
{
  netLiquidation: number;
  buyingPower: number;
  cashBalance: number;
}
```

#### `omega0.getOptionChain(symbol, expiryDaysOut?)`
Fetch available option strikes and expirations.

**Input:**
```typescript
{
  symbol: string;        // e.g., "SPY"
  expiryDaysOut?: number; // Days to expiration (default: 0)
}
```

**Response:**
```typescript
{
  symbol: string;
  currentPrice: number;
  expirations: string[];  // ["20260129", "20260205", ...]
  strikes: number[];      // [440, 445, 450, 455, ...]
}
```

#### `omega0.placeOrder(symbol, expiry, strike, optionType, action, quantity)`
Place a market order for an option contract.

**Input:**
```typescript
{
  symbol: string;           // e.g., "SPY"
  expiry: string;           // e.g., "20260129"
  strike: number;           // e.g., 450
  optionType: "C" | "P";    // Call or Put
  action: "BUY" | "SELL";   // Buy or Sell
  quantity: number;         // Number of contracts
}
```

**Response:**
```typescript
{
  orderId: number;
  symbol: string;
  expiry: string;
  strike: number;
  optionType: "C" | "P";
  action: "BUY" | "SELL";
  quantity: number;
  filledPrice: number;
  filledTime: Date;
  status: "FILLED" | "PENDING" | "CANCELLED";
}
```

#### `omega0.closePosition(symbol, expiry, strike, optionType, quantity, exitPrice)`
Close an open position (sell to exit).

**Input:**
```typescript
{
  symbol: string;
  expiry: string;
  strike: number;
  optionType: "C" | "P";
  quantity: number;
  exitPrice: number;
}
```

**Response:**
```typescript
{
  orderId: number;
  symbol: string;
  action: "SELL";
  quantity: number;
  exitPrice: number;
  status: "FILLED";
  pnl: number;  // P&L in dollars
}
```

#### `omega0.getOpenTrades()`
Get all currently open positions.

**Response:**
```typescript
Array<{
  tradeId: string;
  symbol: string;
  expiry: string;
  strike: number;
  optionType: "C" | "P";
  entryPrice: number;
  entryTime: Date;
  quantity: number;
  status: "OPEN";
}>
```

#### `omega0.getClosedTrades(limit?)`
Get closed trades (history).

**Input:**
```typescript
{
  limit?: number; // Default: 50
}
```

**Response:**
```typescript
Array<{
  tradeId: string;
  symbol: string;
  expiry: string;
  strike: number;
  optionType: "C" | "P";
  entryPrice: number;
  entryTime: Date;
  exitPrice: number;
  exitTime: Date;
  quantity: number;
  pnl: number;
  pnlPercent: number;
  status: "CLOSED";
}>
```

#### `omega0.getPerformanceMetrics()`
Get trading performance statistics.

**Response:**
```typescript
{
  totalTrades: number;
  closedTrades: number;
  winRate: number;           // 0.0 to 1.0
  totalPnL: number;          // Total profit/loss in dollars
  avgWinSize: number;        // Average winning trade
  avgLossSize: number;       // Average losing trade
  profitFactor: number;      // Total wins / Total losses
}
```

---

## Quick Start

### 1. Start TWS/IB Gateway
```bash
# On macOS/Linux
/opt/IBController/IBController.sh

# Or open TWS directly
```

Verify API is listening on port 7497:
```bash
netstat -an | grep 7497
```

### 2. Start AOIX-1
```bash
cd /home/ubuntu/aoix-1
pnpm dev
```

### 3. Navigate to Execution Dashboard
Open browser to: `http://localhost:3000/dashboard/execution`

### 4. Check Connection Status
- If connected: Green checkmark appears
- If disconnected: Yellow warning with message

### 5. Place a Trade
1. Select symbol (e.g., SPY)
2. Select expiry (e.g., 20260129)
3. Select strike (e.g., 450)
4. Enter quantity (e.g., 1)
5. Click "Buy Call" or "Buy Put"

### 6. Monitor Position
- Dashboard updates every 2 seconds
- P&L shown in real-time
- Exit automatically when take profit (+30%) or stop loss (-20%) is hit

---

## Error Handling

### "IBKR connection requires TWS/IB Gateway running"
**Solution:** Start TWS or IB Gateway and ensure API is enabled on port 7497.

### "No option chain available"
**Solution:** Verify symbol is valid (e.g., SPY, QQQ, IWM) and has liquid options.

### "Position size too small"
**Solution:** Account is too small for 1% risk. Increase account value or reduce max risk %.

### "No option liquidity"
**Solution:** Selected strike/expiry has no bid/ask. Choose more liquid expiry (closer to today).

---

## Risk Management

### Capital Preservation
- **Max Risk Per Trade:** 1% of account
- **Max Positions:** 1 at a time
- **Stop Loss:** -20% (automatic exit)
- **Take Profit:** +30% (automatic exit)

### Kill Switch
If system behaves unexpectedly:
1. Click "Kill Switch" in dashboard
2. All positions are closed immediately
3. No new trades are placed

### Daily Loss Limit
(Optional) Set a daily loss limit:
- If daily loss > 2% of account, stop trading for the day

---

## Monitoring & Logging

All trades are logged to the database:
- Entry price, time, size
- Exit price, time, P&L
- Slippage, fees
- Regime at entry/exit
- Signal confidence

Access trade history:
```bash
# Via dashboard: /dashboard/execution → Recent Trades
# Via API: trpc.omega0.getClosedTrades.useQuery()
```

---

## Production Deployment

### Before Going Live:
1. ✅ Test with paper trading for 2+ weeks
2. ✅ Validate all exit logic (take profit, stop loss)
3. ✅ Confirm slippage modeling matches reality
4. ✅ Set up monitoring/alerts
5. ✅ Document all procedures

### Live Trading:
1. Switch IBKR to live account
2. Change port from 7497 to 7496 (if using live)
3. Reduce position size (start with 0.25% risk)
4. Monitor closely for first week
5. Gradually increase position size

---

## Troubleshooting

| Issue | Cause | Solution |
|-------|-------|----------|
| Connection fails | TWS not running | Start TWS/IB Gateway |
| Connection fails | API disabled | Enable API in settings |
| Connection fails | Wrong port | Verify port 7497 (paper) or 7496 (live) |
| No fills | Market closed | Trade during market hours (9:30-16:00 ET) |
| No fills | No liquidity | Choose more liquid strikes/expirations |
| Slippage high | Wide spreads | Trade closer to market hours |
| Slippage high | Large position | Reduce position size |

---

## Support

For issues or questions:
1. Check logs: `.manus-logs/devserver.log`
2. Verify IBKR connection: `netstat -an | grep 7497`
3. Test manually in TWS before using API
4. Contact IBKR support for account/API issues

---

**Remember:** Omega-0 is a tool. The edge comes from AOIX-1's regime analysis, signal generation, and risk management. Omega-0 just executes it.

**Survival is mandatory. Intelligence is optional.**
