/**
 * A+++ Pillar 2: Bayesian regime classifier with persistence forecast.
 * P(regime_t+1 == regime_t) over 20 days; regime-specific vol target alignment.
 * Replaces deterministic snapshot with probability-weighted view.
 */

import type { RegimeType } from './services';

export interface RegimeState {
  regime: RegimeType;
  probability: number;
  /** P(regime persists next period) from recent history. */
  persistenceProbability: number;
  /** Vol target alignment ±15% (1.0 = neutral). */
  volTargetAlignment: number;
  /** Transition risk: penalty 0–1 if unfavorable transition likely. */
  transitionRisk: number;
}

const REGIME_IDS: RegimeType[] = [
  'bull_vol_compression', 'bull_vol_expansion', 'bear_vol_compression', 'bear_vol_expansion',
  'mean_reverting', 'chaotic', 'crisis', 'liquidity_drought', 'trending_bull', 'trending_bear', 'sector_rotation',
];

/** Default persistence by regime (stable regimes persist more). */
const DEFAULT_PERSISTENCE: Record<string, number> = {
  mean_reverting: 0.85,
  bull_vol_compression: 0.78,
  bear_vol_compression: 0.78,
  trending_bull: 0.72,
  trending_bear: 0.72,
  bull_vol_expansion: 0.65,
  bear_vol_expansion: 0.65,
  chaotic: 0.55,
  liquidity_drought: 0.6,
  crisis: 0.45,
  sector_rotation: 0.6,
};

/**
 * Compute regime persistence from a short history of regime labels.
 * P(persist) = fraction of last 20 bars where regime stayed same (or smoothed).
 */
export function regimePersistenceForecast(regimeHistory: string[], currentRegime: string, window = 20): number {
  if (regimeHistory.length < 2) return DEFAULT_PERSISTENCE[currentRegime] ?? 0.65;
  const recent = regimeHistory.slice(-window);
  let same = 0;
  for (let i = 1; i < recent.length; i++) {
    if (recent[i] === recent[i - 1]) same++;
  }
  const raw = recent.length > 1 ? same / (recent.length - 1) : 0.7;
  return Math.max(0.3, Math.min(0.95, raw * 0.9 + (DEFAULT_PERSISTENCE[currentRegime] ?? 0.65) * 0.1));
}

/**
 * Bayesian-style regime state: probability, persistence, vol alignment, transition risk.
 * When regimeHistory is provided, persistence is computed from it; else default.
 */
export function getBayesianRegimeState(
  currentRegime: RegimeType,
  transitionProbability: number,
  regimeStability: number,
  regimeHistory: string[] = []
): RegimeState {
  const r = currentRegime as string;
  const persistence = regimeHistory.length >= 2
    ? regimePersistenceForecast(regimeHistory, r)
    : (DEFAULT_PERSISTENCE[r] ?? 0.65);

  // Vol target alignment: ±15% by regime (premium sellers like calm, vol buyers like expansion).
  let volTargetAlignment = 1.0;
  if (r.includes('bull_vol_compression') || r === 'mean_reverting') volTargetAlignment = 1.1;
  if (r.includes('bull_vol_expansion')) volTargetAlignment = 1.15;
  if (r === 'crisis' || r === 'chaotic') volTargetAlignment = 0.85;

  // Transition risk: penalty when transition prob high or stability low (spec: -15 to -20%).
  const transitionRisk = transitionProbability > 0.4 ? Math.min(1, 0.15 + (transitionProbability - 0.4) * 0.5) : 0;
  const stabilityRisk = regimeStability < 0.5 ? 0.2 : 0;

  return {
    regime: currentRegime,
    probability: Math.max(0.1, 1 - transitionProbability),
    persistenceProbability: persistence,
    volTargetAlignment,
    transitionRisk: Math.min(0.25, transitionRisk + stabilityRisk),
  };
}

/**
 * Regime transition penalty for composite score: 0–0.20 (spec: -15% to -20% if unfavorable).
 */
export function getRegimeTransitionPenalty(state: RegimeState): number {
  return state.transitionRisk;
}
