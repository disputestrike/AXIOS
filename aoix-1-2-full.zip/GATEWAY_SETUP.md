# IB Gateway Setup Guide

Complete guide for setting up Interactive Brokers Client Portal Gateway for live trading with AOIX-1.

**AOIX-1 uses the Client Portal Gateway (browser login at http://localhost:5000).** For that setup — including what to do if you see "Authentication failed" — use **IB_GATEWAY_SETUP.md** and **IB_CLIENT_PORTAL_5000.md**. This file describes the classic socket Gateway (port 7497) for reference.

## Overview

The AOIX-1 autonomous trading engine can operate in two modes:

- **Paper Trading Mode (Default)** - Simulated trading with realistic execution modeling, no Gateway required
- **Live Trading Mode** - Real order execution through Interactive Brokers, requires IB Gateway

This guide walks you through setting up IB Gateway for live trading.

## System Requirements

- **Operating System:** Windows, macOS, or Linux
- **Java:** Java 8 or higher (IB Gateway requires Java runtime)
- **Network:** Stable internet connection
- **Interactive Brokers Account:** Active account with API access enabled
- **Port 7497:** Must be available (default IB Gateway port)

## Step 1: Download IB Gateway

1. Visit [Interactive Brokers Download Center](https://www.interactivebrokers.com/en/trading/platforms/ib-gateway.php)
2. Select your operating system (Windows, macOS, or Linux)
3. Download the latest version of IB Gateway
4. Install following the on-screen instructions

### macOS Installation Example

```bash
# Download
curl -O https://download2.interactivebrokers.com/downloads/IBGateway-latest-macos.zip

# Extract
unzip IBGateway-latest-macos.zip

# Run
cd IBGateway
./IBGateway
```

### Linux Installation Example

```bash
# Download
wget https://download2.interactivebrokers.com/downloads/IBGateway-latest-linux-x64.zip

# Extract
unzip IBGateway-latest-linux-x64.zip

# Run
cd IBGateway
./IBGateway
```

## Step 2: Configure IB Gateway

### Enable API Access in Your IB Account

1. Log in to your Interactive Brokers account at [ibkr.com](https://www.ibkr.com)
2. Go to **Account Settings** → **API**
3. Enable **API** (if not already enabled)
4. Set **API Socket Port** to `7497` (default)
5. Enable **Read-Only API** or **Trading API** based on your needs
6. Save settings

### IB Gateway Connection Settings

When you launch IB Gateway, you'll see a login screen:

1. **Username:** Your Interactive Brokers username
2. **Password:** Your Interactive Brokers password
3. **Trading Mode:** Select **Paper Trading** or **Live Trading**
   - Use **Paper Trading** first to test the connection
   - Switch to **Live Trading** only after validation
4. **Port:** Leave as default `7497`
5. **Click Connect**

## Step 3: Verify Gateway Connection

### Check Gateway is Running

```bash
# Test if Gateway is listening on port 7497
netstat -an | grep 7497

# On macOS/Linux
lsof -i :7497

# On Windows
netstat -ano | findstr :7497
```

You should see output indicating the port is listening.

### Test Connection from AOIX-1

1. Open AOIX-1 dashboard at your deployment URL
2. Navigate to **Auto Trading** page
3. Click **Connect Gateway** button
4. If successful, you'll see:
   - Status changes to "Live Trading (Gateway Connected)"
   - Wifi icon becomes green and animated
   - Button changes to "Disconnect Gateway"

## Step 4: Configure AOIX-1 for Gateway

In the AOIX-1 dashboard, you can configure Gateway settings:

### Gateway Configuration

The system uses these default settings:
- **Host:** `localhost` (or `127.0.0.1`)
- **Port:** `7497`
- **Client ID:** `1`
- **Account ID:** Auto-detected from Gateway

### Modify Gateway Settings (Advanced)

If your Gateway is on a different machine:

1. Open browser developer console
2. Call the tRPC endpoint:

```javascript
// Connect to remote Gateway
await trpc.gateway.setConfig.mutate({
  host: '192.168.1.100',  // Gateway machine IP
  port: 7497,
  accountId: 'DU123456'    // Your account ID
});

// Enable Gateway
await trpc.gateway.enable.mutate();
```

## Step 5: Start Paper Trading

Before trading with real money, validate the system:

### Paper Trading Validation

1. In AOIX-1, ensure **Connect Gateway** is showing "Paper Trading" mode
2. Set **Trading Mode** to **Paper Trading** in IB Gateway
3. Click **Start Engine** in AOIX-1
4. Monitor for 30 minutes:
   - Check if signals are generated
   - Verify orders are placed correctly
   - Confirm fills are realistic
   - Monitor position management (take profit, stop loss)

### What to Monitor

- **Order Execution:** Orders should execute within 1-2 seconds
- **Fill Prices:** Should be within 0.5% of market price
- **Position Management:** Take profit at +30%, stop loss at -20%
- **Trailing Stops:** Activate at +15% gain, trail at 10%
- **Risk Limits:** Max 1% risk per trade, max 3 positions, 5% daily loss limit

## Step 6: Switch to Live Trading

Once paper trading is validated:

### Enable Live Trading

1. In IB Gateway, change **Trading Mode** to **Live Trading**
2. Confirm the warning message
3. In AOIX-1, the status should still show "Live Trading (Gateway Connected)"
4. **Start with reduced position size:**
   - First week: 0.25% risk per trade (instead of 1%)
   - Second week: 0.5% risk per trade
   - Third week: 0.75% risk per trade
   - Week 4+: 1% risk per trade (full size)

### Risk Management for Live Trading

- **Daily Loss Limit:** 5% of account (automatic kill switch)
- **Max Positions:** 3 concurrent trades
- **Max Risk per Trade:** 1% of account
- **Ruin Probability Threshold:** 10% (triggers kill switch)

## Troubleshooting

### Gateway Connection Failed

**Problem:** "Cannot connect to Gateway at localhost:7497"

**Solutions:**
1. Verify IB Gateway is running
2. Check port 7497 is not blocked by firewall
3. Verify Gateway login was successful
4. Try restarting IB Gateway
5. Check your internet connection

### Orders Not Executing

**Problem:** "Orders placed but not filling"

**Solutions:**
1. Verify you're in Paper Trading mode first
2. Check if market is open (SPX options trade 9:30 AM - 4:00 PM ET)
3. Verify option chain is available (check Market Data dashboard)
4. Check if order prices are reasonable (not too far from market)
5. Verify account has sufficient buying power

### Incorrect Account ID

**Problem:** "Wrong account selected in Gateway"

**Solutions:**
1. Check your account ID in IB Gateway connection window
2. Update AOIX-1 Gateway config with correct account ID
3. Restart IB Gateway and reconnect

### Port Already in Use

**Problem:** "Port 7497 already in use"

**Solutions:**
1. Check if another IB Gateway instance is running
2. Use different port in IB Gateway settings
3. Update AOIX-1 Gateway config to match new port

## Security Best Practices

### Protect Your Credentials

1. **Never share** your IB username/password
2. **Use strong passwords** for your IB account
3. **Enable 2FA** on your IB account if available
4. **Restrict API access** to your local network only
5. **Use firewall rules** to limit access to port 7497

### Account Safety

1. **Start with paper trading** - Always validate before live trading
2. **Use kill switch** - System automatically stops trading if risk limits exceeded
3. **Monitor regularly** - Check dashboard at least daily
4. **Set daily loss limits** - Default is 5% of account
5. **Keep backups** - Save your trading logs and performance data

## Monitoring and Maintenance

### Daily Checks

- [ ] IB Gateway is running and connected
- [ ] AOIX-1 shows "Live Trading (Gateway Connected)"
- [ ] Market data is updating in real-time
- [ ] No error messages in logs
- [ ] Account balance and P&L are accurate

### Weekly Checks

- [ ] Review trade history and performance
- [ ] Check for any connection drops
- [ ] Verify risk metrics are within limits
- [ ] Review any failed trades or errors
- [ ] Backup trading logs and data

### Monthly Maintenance

- [ ] Update IB Gateway to latest version
- [ ] Review and optimize trading parameters
- [ ] Analyze performance metrics (win rate, Sharpe ratio, etc.)
- [ ] Rebalance risk limits if needed
- [ ] Review account statements with IB

## Support and Resources

### Interactive Brokers Resources

- [IB API Documentation](https://www.interactivebrokers.com/en/trading/ib-api.php)
- [IB Gateway Documentation](https://www.interactivebrokers.com/en/trading/platforms/ib-gateway.php)
- [IB Support Center](https://www.interactivebrokers.com/en/trading/support.php)

### AOIX-1 Resources

- **Dashboard:** Auto Trading page with real-time monitoring
- **Logs:** Check server logs for connection issues
- **Tests:** Run unit tests to verify system integrity

## Frequently Asked Questions

### Q: Can I use IB Gateway on a different machine?

**A:** Yes, but you need to configure the host IP address in AOIX-1 Gateway settings. Make sure the firewall allows port 7497 traffic.

### Q: What if IB Gateway disconnects?

**A:** AOIX-1 automatically falls back to paper trading mode. You'll see "Paper Trading Mode" status and the system continues running safely.

### Q: Can I trade multiple assets simultaneously?

**A:** Yes, AOIX-1 supports SPX, QQQ, SPY, and IWM. Select the asset from the dropdown in the Auto Trading dashboard.

### Q: What's the minimum account size?

**A:** Interactive Brokers requires a minimum of $2,000 for margin accounts. For options trading, you need approval for options trading level 2 or higher.

### Q: Can I manually override trades?

**A:** Yes, you can always click "Stop Engine" to halt automatic trading. You can then manually manage positions through IB.

### Q: How do I know if the system is working correctly?

**A:** Monitor the Performance Metrics tab:
- Win Rate should be > 50%
- Profit Factor should be > 1.0
- Sharpe Ratio should be > 1.0
- Max Drawdown should be < 10%

---

**Last Updated:** January 2026

For additional support or questions, please refer to the AOIX-1 documentation or contact Interactive Brokers support.
