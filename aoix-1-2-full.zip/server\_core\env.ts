// Load environment variables with fallback
const getEnvVar = (key: string, defaultValue: string = ""): string => {
  const value = process.env[key];
  if (value && value.length > 0) {
    return value;
  }
  return defaultValue;
};

// Read at access time so .env.local (loaded later in server entry) is visible
function getAnthropicApiKey(): string {
  return getEnvVar("ANTHROPIC_API_KEY", "");
}

export const ENV = {
  appId: getEnvVar("VITE_APP_ID", "aoix-1-local"),
  cookieSecret: getEnvVar("JWT_SECRET", ""),
  databaseUrl: getEnvVar("DATABASE_URL", ""),
  oAuthServerUrl: getEnvVar("OAUTH_SERVER_URL", ""),
  ownerOpenId: getEnvVar("OWNER_OPEN_ID", ""),
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: getEnvVar("BUILT_IN_FORGE_API_URL", ""),
  forgeApiKey: getEnvVar("BUILT_IN_FORGE_API_KEY", ""),
  get anthropicApiKey(): string {
    return getAnthropicApiKey();
  },
  /** Position sizing × intent.confidence. Turn on only after 100–150 trades confirm calibration. */
  enableConfidenceSizing: process.env.ENABLE_CONFIDENCE_SIZING === "true",
  /** Outcome store: "file" (default, persistent), "memory", or "sqlite". */
  outcomeStore: getEnvVar("OUTCOME_STORE", "file"),
  /** Confidence calibration every 50 trades. Turn on only after persistent storage is live. */
  enableConfidenceCalibration: process.env.ENABLE_CONFIDENCE_CALIBRATION === "true",
};
