/**
 * Liquidity for audit — fetch real option chain data (bid/ask, OI, volume) and build liquidityBySymbol.
 * IB only: marketDataService.getOptionChain (IB Gateway). Section 4 when runSystemAudit({ liquidityBySymbol }).
 */

import { getOptionChain, type OptionQuote } from "./marketDataService";

export interface LiquidityMetrics {
  bidAskSpreadPct: number;
  openInterest: number | null;
  avgVolume: number | null;
}

/**
 * Compute representative bid/ask spread %, open interest, and avg volume from option chain quotes.
 * Uses ATM-ish options (closest to current price) or first N quotes with valid bid/ask.
 */
function metricsFromQuotes(
  quotes: OptionQuote[],
  currentPrice: number,
  stockAvgVolume: number | null
): LiquidityMetrics {
  const withSpread = quotes.filter(
    (q) => q.mid > 0 && q.bid >= 0 && q.ask > 0
  );
  if (withSpread.length === 0) {
    return {
      bidAskSpreadPct: 0.15,
      openInterest: null,
      avgVolume: stockAvgVolume,
    };
  }
  const spreadPcts = withSpread.map(
    (q) => ((q.ask - q.bid) / q.mid) * 100
  );
  const rawAvg =
    spreadPcts.length > 0
      ? spreadPcts.reduce((a, b) => a + b, 0) / spreadPcts.length
      : 0.15;
  const bidAskSpreadPct = Math.round(Math.min(30, Math.max(0.01, rawAvg)) * 100) / 100;
  const openInterestSum = withSpread.reduce(
    (s, q) => s + (q.openInterest ?? 0),
    0
  );
  const openInterest =
    openInterestSum > 0 ? Math.round(openInterestSum / withSpread.length) : null;
  const optionVolumeSum = withSpread.reduce((s, q) => s + (q.volume ?? 0), 0);
  const avgVolume =
    optionVolumeSum > 0
      ? Math.round(optionVolumeSum / withSpread.length)
      : stockAvgVolume;
  return {
    bidAskSpreadPct,
    openInterest,
    avgVolume: avgVolume ?? stockAvgVolume,
  };
}

/**
 * Fetch liquidity metrics for one symbol from option chain (IB only).
 * Returns null on failure so caller can skip or use placeholder.
 */
export async function getLiquidityFromChain(
  symbol: string
): Promise<LiquidityMetrics | null> {
  try {
    const chain = await getOptionChain(symbol, 0);
    const stockAvgVolume: number | null = null;
    if (chain.quotes.length > 0) {
      return metricsFromQuotes(
        chain.quotes,
        chain.currentPrice,
        stockAvgVolume
      );
    }
    return {
      bidAskSpreadPct: 0.15,
      openInterest: null,
      avgVolume: stockAvgVolume,
    };
  } catch (err) {
    console.warn(`[Liquidity] Failed for ${symbol}:`, (err as Error).message);
    return null;
  }
}

/**
 * Fetch liquidity for multiple symbols; build liquidityBySymbol for runSystemAudit.
 * One symbol failure does not break others; missing symbols are omitted (Section 4 will use placeholders for them).
 */
export async function getLiquidityForAudit(
  symbols: string[]
): Promise<Record<string, { bidAskSpreadPct?: number; openInterest?: number; avgVolume?: number }>> {
  const result: Record<string, { bidAskSpreadPct?: number; openInterest?: number; avgVolume?: number }> = {};
  for (const symbol of symbols) {
    const liq = await getLiquidityFromChain(symbol);
    if (liq) {
      result[symbol] = {
        bidAskSpreadPct: liq.bidAskSpreadPct,
        openInterest: liq.openInterest ?? undefined,
        avgVolume: liq.avgVolume ?? undefined,
      };
    }
  }
  return result;
}
