import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { TrendingUp, Brain, Shield, Zap, Activity, Target, BarChart3, AlertTriangle, Cpu, GitBranch, Crown, CheckCircle2 } from "lucide-react";

export default function Home() {
  const { isAuthenticated } = useAuth();
  const utils = trpc.useUtils();
  const loginMutation = trpc.auth.login.useMutation({
    onSuccess: async (data) => {
      console.log("[Client] Login success:", data);
      // Force a full page reload to ensure cookie is read
      // The cookie is set by the server, so we need to reload to send it back
      window.location.href = "/";
    },
    onError: (error) => {
      console.error("[Client] Login error:", error);
      console.error("[Client] Error details:", {
        message: error.message,
        data: error.data,
        ...(error instanceof Error && { cause: error.cause, stack: error.stack }),
      });
      const errorMessage = error.message || "Unknown error occurred";
      alert(`Login failed: ${errorMessage}`);
    },
  });

  if (isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
        <div className="container mx-auto px-4 py-16">
          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold text-white mb-4">AOIX-1</h1>
            <p className="text-xl text-slate-300">Sovereign Market Organism</p>
            <p className="text-slate-400 mt-2">Institutional-Grade Options Trading Intelligence</p>
          </div>

          {/* 10/10 Blueprint — visible so the work is obvious */}
          <Link href="/today-opportunity" className="block mb-8">
            <Card className="bg-gradient-to-r from-emerald-500/20 to-teal-500/20 border-emerald-500/50 hover:border-emerald-400 transition-all cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-2xl">
                  <Crown className="w-8 h-8 text-emerald-500" />
                  <span className="text-emerald-400">10/10 Blueprint</span>
                  <Badge className="bg-emerald-600 text-white border-0">LIVE</Badge>
                </CardTitle>
                <CardDescription className="text-slate-300 text-base">
                  Intent governance • Strategy compatibility law • Outcome logging • Calibration every 50 trades. Market thesis + risk tiers on Today&apos;s Opportunity.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-3 text-sm">
                  <span className="flex items-center gap-1.5 text-emerald-300"><CheckCircle2 className="w-4 h-4" /> Intent-driven flow</span>
                  <span className="flex items-center gap-1.5 text-emerald-300"><CheckCircle2 className="w-4 h-4" /> Regime × strategy law</span>
                  <span className="flex items-center gap-1.5 text-emerald-300"><CheckCircle2 className="w-4 h-4" /> Auto outcome log on close</span>
                  <span className="flex items-center gap-1.5 text-emerald-300"><CheckCircle2 className="w-4 h-4" /> Confidence calibration</span>
                </div>
                <p className="text-emerald-400/90 mt-3 text-sm font-medium">Go to Today&apos;s Opportunity →</p>
              </CardContent>
            </Card>
          </Link>

          {/* Primary Feature: Auto Trading */}
          <Link href="/auto-trading" className="block mb-8">
            <Card className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border-yellow-500/50 hover:border-yellow-400 transition-all cursor-pointer">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-2xl">
                  <Zap className="w-8 h-8 text-yellow-500" />
                  <span className="text-yellow-500">Autonomous Trading Engine</span>
                  <span className="ml-auto text-sm bg-yellow-500 text-black px-3 py-1 rounded-full">NEW</span>
                </CardTitle>
                <CardDescription className="text-slate-300 text-base">
                  Fully automatic trading with regime-based signals, risk management, and position automation
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-500">+30%</p>
                    <p className="text-slate-400">Take Profit</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-red-500">-20%</p>
                    <p className="text-slate-400">Stop Loss</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-blue-500">1%</p>
                    <p className="text-slate-400">Max Risk/Trade</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-purple-500">10%</p>
                    <p className="text-slate-400">Trailing Stop</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          {/* Analysis Dashboards */}
          <h2 className="text-xl font-semibold text-slate-300 mb-4">Analysis Dashboards</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
            <Link href="/market-data" className="block">
              <Card className="hover:shadow-lg hover:border-slate-600 transition-all cursor-pointer h-full bg-slate-800/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-slate-200">
                    <TrendingUp className="w-5 h-5 text-blue-400" />
                    Market Data
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-slate-400">Real-time price, volatility & microstructure</p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/regime" className="block">
              <Card className="hover:shadow-lg hover:border-slate-600 transition-all cursor-pointer h-full bg-slate-800/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-slate-200">
                    <Brain className="w-5 h-5 text-purple-400" />
                    Regime
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-slate-400">Classification & transition detection</p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/signals" className="block">
              <Card className="hover:shadow-lg hover:border-slate-600 transition-all cursor-pointer h-full bg-slate-800/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-slate-200">
                    <Activity className="w-5 h-5 text-green-400" />
                    Signals
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-slate-400">Class A-D signal taxonomy</p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/structures" className="block">
              <Card className="hover:shadow-lg hover:border-slate-600 transition-all cursor-pointer h-full bg-slate-800/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-slate-200">
                    <Target className="w-5 h-5 text-orange-400" />
                    Structures
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-slate-400">Optimal structure recommendations</p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/risk" className="block">
              <Card className="hover:shadow-lg hover:border-slate-600 transition-all cursor-pointer h-full bg-slate-800/50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-slate-200">
                    <Shield className="w-5 h-5 text-red-400" />
                    Risk
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-slate-400">Dynamic risk management</p>
                </CardContent>
              </Card>
            </Link>
          </div>

          {/* Advanced Systems */}
          <h2 className="text-xl font-semibold text-slate-300 mb-4">Advanced Systems</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <Link href="/execution" className="block">
              <Card className="hover:shadow-lg hover:border-slate-600 transition-all cursor-pointer h-full bg-slate-800/50">
                <CardHeader>
                  <CardTitle className="text-sm flex items-center gap-2 text-slate-200">
                    <Zap className="w-4 h-4 text-yellow-400" />
                    Execution
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-xs text-slate-400">Entry gates & slippage</p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/meta-intelligence" className="block">
              <Card className="hover:shadow-lg hover:border-slate-600 transition-all cursor-pointer h-full bg-slate-800/50">
                <CardHeader>
                  <CardTitle className="text-sm flex items-center gap-2 text-slate-200">
                    <Cpu className="w-4 h-4 text-cyan-400" />
                    Meta-Intelligence
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-xs text-slate-400">System self-awareness</p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/failures" className="block">
              <Card className="hover:shadow-lg hover:border-slate-600 transition-all cursor-pointer h-full bg-slate-800/50">
                <CardHeader>
                  <CardTitle className="text-sm flex items-center gap-2 text-slate-200">
                    <AlertTriangle className="w-4 h-4 text-red-400" />
                    Failures
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-xs text-slate-400">Taxonomy & attribution</p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/shadow-system" className="block">
              <Card className="hover:shadow-lg hover:border-slate-600 transition-all cursor-pointer h-full bg-slate-800/50">
                <CardHeader>
                  <CardTitle className="text-sm flex items-center gap-2 text-slate-200">
                    <BarChart3 className="w-4 h-4 text-indigo-400" />
                    Shadow System
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-xs text-slate-400">Ruin simulations</p>
                </CardContent>
              </Card>
            </Link>

            <Link href="/correlations" className="block">
              <Card className="hover:shadow-lg hover:border-slate-600 transition-all cursor-pointer h-full bg-slate-800/50">
                <CardHeader>
                  <CardTitle className="text-sm flex items-center gap-2 text-slate-200">
                    <GitBranch className="w-4 h-4 text-pink-400" />
                    Correlations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-xs text-slate-400">Cross-asset reflexivity</p>
                </CardContent>
              </Card>
            </Link>
          </div>

          {/* Level Omega Footer */}
          <div className="mt-12 text-center text-slate-500 text-sm">
            <p>Level Omega Protocol: Survival is mandatory, intelligence is optional.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex flex-col items-center justify-center px-4">
      <div className="text-center max-w-2xl">
        <h1 className="text-6xl font-bold text-white mb-6">AOIX-1</h1>
        <p className="text-2xl text-slate-300 mb-4">Sovereign Market Organism</p>
        <p className="text-lg text-slate-400 mb-8">
          Institutional-grade options trading intelligence platform combining real-time data ingestion, regime analysis, signal classification, and adversarial risk management.
        </p>
        <p className="text-slate-400 mb-12">
          Built on Level Omega principles: survival is mandatory, intelligence is optional.
        </p>
        <Button 
          size="lg" 
          className="bg-blue-600 hover:bg-blue-700"
          onClick={() => {
            console.log("[Client] Login button clicked");
            loginMutation.mutate({}, {
              onError: (error) => {
                console.error("[Client] Login mutation error:", error);
              },
            });
          }}
          disabled={loginMutation.isPending}
        >
          {loginMutation.isPending ? "Signing In..." : "Sign In (Demo Mode)"}
        </Button>
      </div>
    </div>
  );
}
