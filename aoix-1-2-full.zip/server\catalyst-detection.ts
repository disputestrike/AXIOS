/**
 * Catalyst Detection Layer — Hedge fund style (FDA, earnings, M&A, SEC, options flow, news)
 * Optional APIs via env; fallback to free/stub. Unified CatalystEvent[] for options generation.
 */

import { getUnusualFlow } from "./options-flow";
import { getSentimentForSymbol } from "./alternative-data";

export type CatalystType =
  | "fda"
  | "earnings"
  | "sec_filing"
  | "news"
  | "options_flow"
  | "ma"
  | "sentiment";

export interface CatalystEvent {
  symbol: string;
  type: CatalystType;
  title: string;
  /** ISO date or YYYY-MM-DD */
  date: string;
  /** 0–1 confidence */
  confidence: number;
  source: "api" | "proxy" | "none" | "rss";
  /** Optional: implied move % (earnings/IV), or narrative */
  impliedMovePercent?: number;
  timestamp: number;
}

const CATALYST_CACHE = new Map<string, { data: CatalystEvent[]; ts: number }>();
const CATALYST_TTL_MS = 300_000; // 5 min

/**
 * Get catalysts for a single symbol. Uses optional env APIs + options flow + sentiment; else stubs.
 */
export async function getCatalystsForSymbol(symbol: string): Promise<CatalystEvent[]> {
  const cacheKey = `catalyst_${symbol}`;
  const cached = CATALYST_CACHE.get(cacheKey);
  if (cached && Date.now() - cached.ts < CATALYST_TTL_MS) return cached.data;

  const events: CatalystEvent[] = [];
  const now = Date.now();
  const today = new Date().toISOString().slice(0, 10);

  // 1) Options flow (always: we have proxy/stub)
  try {
    const flow = await getUnusualFlow(symbol);
    if (flow.impliedMovePercent > 0 || flow.unusualVolume) {
      events.push({
        symbol,
        type: "options_flow",
        title: flow.unusualVolume ? "Unusual options volume" : "Options flow implied move",
        date: today,
        confidence: flow.source === "api" ? 0.85 : flow.source === "proxy" ? 0.6 : 0.4,
        source: flow.source as "api" | "proxy" | "none",
        impliedMovePercent: flow.impliedMovePercent,
        timestamp: now,
      });
    }
  } catch (e) {
    console.warn("[Catalyst] Options flow failed for", symbol, e);
  }

  // 2) Sentiment (stub or API)
  try {
    const sent = await getSentimentForSymbol(symbol);
    if (sent.source !== "stub" && sent.source !== "none" && sent.strength > 0.3) {
      events.push({
        symbol,
        type: "sentiment",
        title: `Sentiment ${sent.score >= 0 ? "bullish" : "bearish"} (strength ${(sent.strength * 100).toFixed(0)}%)`,
        date: today,
        confidence: sent.strength,
        source: sent.source as "api" | "none",
        timestamp: now,
      });
    }
  } catch (e) {
    console.warn("[Catalyst] Sentiment failed for", symbol, e);
  }

  // 3) Optional: Earnings API (EARNINGS_API_URL GET ?symbol=XXX → [{ date, type: 'earnings' }])
  const earningsUrl = process.env.EARNINGS_API_URL?.trim();
  if (earningsUrl) {
    try {
      const url = `${earningsUrl}${earningsUrl.includes("?") ? "&" : "?"}symbol=${encodeURIComponent(symbol)}`;
      const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
      if (res.ok) {
        const data = (await res.json()) as { date?: string; type?: string }[] | { events?: { date?: string }[] };
        const list = Array.isArray(data) ? data : (data as { events?: { date?: string }[] }).events ?? [];
        for (const ev of list.slice(0, 3)) {
          const d = ev.date ?? (ev as { date?: string }).date;
          if (d) {
            events.push({
              symbol,
              type: "earnings",
              title: "Earnings",
              date: String(d).slice(0, 10),
              confidence: 0.9,
              source: "api",
              timestamp: now,
            });
          }
        }
      }
    } catch (e) {
      console.warn("[Catalyst] Earnings API failed for", symbol, e);
    }
  }

  // 4) Optional: SEC filings (SEC_FILINGS_API_URL GET ?symbol=XXX → [{ date, form, title }])
  const secUrl = process.env.SEC_FILINGS_API_URL?.trim();
  if (secUrl) {
    try {
      const url = `${secUrl}${secUrl.includes("?") ? "&" : "?"}symbol=${encodeURIComponent(symbol)}`;
      const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
      if (res.ok) {
        const data = (await res.json()) as { form?: string; title?: string; date?: string }[];
        const list = Array.isArray(data) ? data : [];
        for (const ev of list.slice(0, 5)) {
          events.push({
            symbol,
            type: "sec_filing",
            title: ev.title || ev.form || "SEC filing",
            date: ev.date ? String(ev.date).slice(0, 10) : today,
            confidence: 0.75,
            source: "api",
            timestamp: now,
          });
        }
      }
    } catch (e) {
      console.warn("[Catalyst] SEC API failed for", symbol, e);
    }
  }

  // 5) Optional: News (CATALYST_NEWS_API_URL GET ?symbol=XXX → [{ title, date, url }])
  const newsUrl = process.env.CATALYST_NEWS_API_URL?.trim();
  if (newsUrl) {
    try {
      const url = `${newsUrl}${newsUrl.includes("?") ? "&" : "?"}symbol=${encodeURIComponent(symbol)}`;
      const res = await fetch(url, { signal: AbortSignal.timeout(5000) });
      if (res.ok) {
        const data = (await res.json()) as { title?: string; date?: string }[];
        const list = Array.isArray(data) ? data : [];
        for (const ev of list.slice(0, 5)) {
          events.push({
            symbol,
            type: "news",
            title: ev.title || "News",
            date: ev.date ? String(ev.date).slice(0, 10) : today,
            confidence: 0.7,
            source: "api",
            timestamp: now,
          });
        }
      }
    } catch (e) {
      console.warn("[Catalyst] News API failed for", symbol, e);
    }
  }

  // 6) Stub: if no events yet, add a generic “market catalyst” so UI always has something
  if (events.length === 0) {
    events.push({
      symbol,
      type: "options_flow",
      title: "Market / options data (run scan for full catalysts)",
      date: today,
      confidence: 0,
      source: "none",
      timestamp: now,
    });
  }

  CATALYST_CACHE.set(cacheKey, { data: events, ts: now });
  return events;
}

/**
 * Get catalysts for multiple symbols (batched).
 */
export async function getCatalystsForSymbols(symbols: string[]): Promise<Map<string, CatalystEvent[]>> {
  const out = new Map<string, CatalystEvent[]>();
  await Promise.all(
    symbols.map(async (s) => {
      const list = await getCatalystsForSymbol(s);
      out.set(s, list);
    })
  );
  return out;
}

/**
 * Health: whether any catalyst API is configured, last update, count.
 */
export function getCatalystStats(): {
  hasEarningsApi: boolean;
  hasSecApi: boolean;
  hasNewsApi: boolean;
  lastUpdate: number;
  cachedSymbols: number;
} {
  let lastUpdate = 0;
  for (const [, v] of Array.from(CATALYST_CACHE)) {
    if (v.ts > lastUpdate) lastUpdate = v.ts;
  }
  return {
    hasEarningsApi: Boolean(process.env.EARNINGS_API_URL?.trim()),
    hasSecApi: Boolean(process.env.SEC_FILINGS_API_URL?.trim()),
    hasNewsApi: Boolean(process.env.CATALYST_NEWS_API_URL?.trim()),
    lastUpdate,
    cachedSymbols: CATALYST_CACHE.size,
  };
}
