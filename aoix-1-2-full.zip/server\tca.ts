/**
 * Transaction Cost Analysis (TCA) — Hedge fund style
 * Log intended vs fill price, compute slippage and spread cost.
 * Use for execution quality and limit-order tuning.
 */

export interface TCAEntry {
  id: string;
  timestamp: number;
  symbol: string;
  side: "BUY" | "SELL";
  quantity: number;
  intendedPrice: number;
  fillPrice: number;
  /** Slippage in $ per contract (fill - intended for BUY, intended - fill for SELL) */
  slippagePerContract: number;
  /** Slippage as % of intended price */
  slippagePercent: number;
  orderType: "MKT" | "LMT";
  structureType?: string;
  /** Order ID from placeOrder (for drill-down by order). */
  orderId?: string;
}

const tcaLog: TCAEntry[] = [];
const MAX_LOG = 500;

export function logTCA(entry: Omit<TCAEntry, "id" | "slippagePerContract" | "slippagePercent">): void {
  const slippagePerContract =
    entry.side === "BUY" ? entry.fillPrice - entry.intendedPrice : entry.intendedPrice - entry.fillPrice;
  const slippagePercent =
    entry.intendedPrice > 0 ? (slippagePerContract / entry.intendedPrice) * 100 : 0;
  const full: TCAEntry = {
    ...entry,
    id: `tca_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
    slippagePerContract,
    slippagePercent,
  };
  tcaLog.push(full);
  if (tcaLog.length > MAX_LOG) tcaLog.shift();
}

export interface TCASummary {
  totalTrades: number;
  avgSlippagePerContract: number;
  avgSlippagePercent: number;
  maxSlippagePercent: number;
  implementationShortfallEstimate: number; // total $ lost to slippage
  /** Execution quality score 0–100: excellent (&lt;0.5% avg slippage), good (&lt;1%), fair (&lt;2%), poor (≥2%). */
  executionQualityScore: number;
}

/** Compute execution quality score 0–100 from avg slippage % (institutional-style bar). */
export function computeExecutionQualityScore(avgSlippagePercent: number): number {
  if (avgSlippagePercent <= 0) return 100;
  if (avgSlippagePercent < 0.5) return Math.round(100 - avgSlippagePercent * 20); // excellent
  if (avgSlippagePercent < 1) return Math.round(90 - (avgSlippagePercent - 0.5) * 20); // good
  if (avgSlippagePercent < 2) return Math.round(80 - (avgSlippagePercent - 1) * 10); // fair
  return Math.max(0, Math.round(70 - avgSlippagePercent * 5)); // poor
}

export function getTCASummary(): TCASummary {
  if (tcaLog.length === 0) {
    return {
      totalTrades: 0,
      avgSlippagePerContract: 0,
      avgSlippagePercent: 0,
      maxSlippagePercent: 0,
      implementationShortfallEstimate: 0,
      executionQualityScore: 100,
    };
  }
  const avgSlippage = tcaLog.reduce((s, e) => s + e.slippagePerContract, 0) / tcaLog.length;
  const avgPct = tcaLog.reduce((s, e) => s + e.slippagePercent, 0) / tcaLog.length;
  const maxPct = Math.max(...tcaLog.map((e) => e.slippagePercent));
  const totalShortfall = tcaLog.reduce(
    (s, e) => s + e.slippagePerContract * e.quantity * 100,
    0
  );
  const executionQualityScore = computeExecutionQualityScore(avgPct);
  return {
    totalTrades: tcaLog.length,
    avgSlippagePerContract: avgSlippage,
    avgSlippagePercent: avgPct,
    maxSlippagePercent: maxPct,
    implementationShortfallEstimate: totalShortfall,
    executionQualityScore,
  };
}

export function getTCALog(limit: number = 50): TCAEntry[] {
  return tcaLog.slice(-limit).reverse();
}

export interface TCADrillDown {
  orderId: string;
  entries: TCAEntry[];
  totalSlippageDollars: number;
  totalSlippagePercent: number;
  structureType?: string;
  symbol: string;
  executionQualityScore: number;
}

/** Drill-down by order ID: all TCA entries for that order + summary. */
export function getTCADrillDown(orderId: string): TCADrillDown | null {
  const entries = tcaLog.filter((e) => e.orderId === orderId);
  if (entries.length === 0) return null;
  const totalSlippageDollars = entries.reduce(
    (s, e) => s + e.slippagePerContract * e.quantity * 100,
    0
  );
  const avgPct = entries.reduce((s, e) => s + e.slippagePercent, 0) / entries.length;
  const structureType = entries[0]?.structureType;
  const symbol = entries[0]?.symbol ?? "";
  return {
    orderId,
    entries,
    totalSlippageDollars,
    totalSlippagePercent: avgPct,
    structureType,
    symbol,
    executionQualityScore: computeExecutionQualityScore(avgPct),
  };
}
