# System Audit Report

**Generated:** 2026-02-01T02:48:37.286Z
**Trades audited:** 2

---

## Section 1 – Trade Risk / Reward Verification

| Trade | Max Risk ($) | Max Profit ($) | Historical P/L | Assignment Risk (%) |
|-------|--------------|----------------|----------------|---------------------|
| SPY | 300 | 200 | — | 0 |
| AAPL | 300 | 200 | — | 0 |

## Section 2 – Probability Calibration

| Trade | Score | Confidence | Historical Win Rate (%) | Avg Loss ($) | Max Loss ($) | Regime |
|-------|-------|-------------|--------------------------|--------------|--------------|--------|
| SPY | 85 | 0.75 | 50 | 100 | 300 | trending_bull |
| AAPL | 78 | 0.7 | 50 | 100 | 300 | mean_reverting |

## Section 3 – Volatility and IV Analysis

| Trade | IV Start | IV Exit | P/L @ IV−20% | P/L @ IV−50% | Delta | Gamma | Vega | Theta |
|-------|----------|---------|--------------|--------------|-------|-------|------|-------|
| SPY | 18 | 16.2 | -0.04 | -0.1 | 0.3 | 0 | 0 | -0.01 |
| AAPL | 22 | 19.8 | -0.04 | -0.1 | -0.3 | 0 | 0 | -0.01 |

## Section 4 – Execution Realism

| Trade | Bid/Ask Spread | Filled vs Theoretical | Open Interest | Avg Volume |
|-------|----------------|------------------------|---------------|------------|
| SPY | 0.15% | No fills yet; pre-trade estimate 0.5% per leg | — | — |
| AAPL | 0.15% | No fills yet; pre-trade estimate 0.5% per leg | — | — |

## Section 5 – Portfolio Risk / Correlation

**Total dollar risk (VaR99):** 0 | **VaR95:** 0 | **Max drawdown:** —%

| Trade Pair | Correlation | Combined Max Risk ($) |
|------------|-------------|------------------------|
| SPY / AAPL | 0.3 | 600 |

## Section 6 – Stress-Test / Crisis Simulation

| Trade | Event | P/L | Margin Calls | Realized vs Theoretical |
|-------|-------|-----|--------------|---------------------------|
| SPY | Mar 2020 crash | -0.15 | 0 | Run pnpm backtest:stress-regime for actual |
| SPY | Feb 2022 vol spike | -0.08 | 0 | Run pnpm backtest:stress-regime for actual |
| AAPL | Mar 2020 crash | -0.15 | 0 | Run pnpm backtest:stress-regime for actual |
| AAPL | Feb 2022 vol spike | -0.08 | 0 | Run pnpm backtest:stress-regime for actual |

## Section 7 – Explainability / Transparency

| Trade | Score Reasoning | Expected Return Assumptions | Confidence Interval |
|-------|-----------------|-----------------------------|---------------------|
| SPY | Regime: trending_bull; structure vertical_call_spread; composite score from 9-pillar ranker (regime–signal–structure alignment, IV/DTE, flow). | Point estimate from signal expected return × regime multiplier; win probability 50%. No explicit confidence interval; historical OOS variance can be attached from walk-forward. | Not computed; use runWalkForward / runMultiWindowWalkForward for OOS stdev. |
| AAPL | Regime: mean_reverting; structure vertical_put_spread; composite score from 9-pillar ranker (regime–signal–structure alignment, IV/DTE, flow). | Point estimate from signal expected return × regime multiplier; win probability 50%. No explicit confidence interval; historical OOS variance can be attached from walk-forward. | Not computed; use runWalkForward / runMultiWindowWalkForward for OOS stdev. |

---

## Methodology

Max risk/profit from structure type and spread width (default $5) when option chain not loaded. Greeks from portfolio-risk estimates or chain. Historical P/L and win rate from backtest-runner (Yahoo daily + Black–Scholes option P&L) when provided. Stress from regime-transition-stress and stress-regime-transitions scripts. TCA from logged fills.

## Data Sources

- Yahoo Finance (daily OHLC)
- IBKR Gateway (options chain, Greeks when connected)
- execution-cost-model (spread, commission)
- portfolio-risk (Greeks, VaR)
- tca (logged fills)
- backtest-runner (historical, walk-forward, regime stress)

## Assumptions

- Default spread width $5 for vertical spreads when not from chain.
- Assignment risk proxy: short-option ITM probability from Black–Scholes.
- IV at exit: proxy from realized vol when historical option IV not available.
- Correlation: symbol–symbol from historical returns when not provided.
- Stress P/L: run pnpm backtest:stress-regime and pass stressResults for actual crisis dates.