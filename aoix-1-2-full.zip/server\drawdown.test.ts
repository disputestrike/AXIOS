/**
 * Drawdown limiter — tracker init, monthly reset, auto-stop at threshold.
 * Run: pnpm test -- --grep "drawdown"
 */
import { describe, it, expect } from "vitest";
import {
  initDrawdownTracker,
  updateDrawdown,
  getDrawdownStatus,
  isTradingStoppedDueToDrawdown,
  clearDrawdownStop,
  type DrawdownStatus,
} from "./drawdown-limiter";

describe("drawdown — tracker initialization", () => {
  it("drawdown: initDrawdownTracker sets peak and current", () => {
    initDrawdownTracker(100_000);
    const status = getDrawdownStatus();
    expect(status).toHaveProperty("peakEquity");
    expect(status).toHaveProperty("currentEquity");
    expect(status).toHaveProperty("drawdownPercent");
    expect(status.peakEquity).toBeGreaterThanOrEqual(100_000);
    expect(status.currentEquity).toBe(100_000);
  });

  it("drawdown: getDrawdownStatus returns status ok/warning/critical", () => {
    initDrawdownTracker(100_000);
    const status = getDrawdownStatus();
    expect(["ok", "warning", "critical"]).toContain(status.status);
  });

  it("drawdown: drawdown calculation (peak - current) / peak * 100", () => {
    initDrawdownTracker(100_000);
    updateDrawdown(90_000);
    const status = getDrawdownStatus();
    expect(status.drawdownPercent).toBeCloseTo(10, 1);
  });
});

describe("drawdown — monthly reset", () => {
  it("drawdown: updateDrawdown updates current equity", () => {
    initDrawdownTracker(100_000);
    updateDrawdown(95_000);
    const status = getDrawdownStatus(95_000);
    expect(status.currentEquity).toBe(95_000);
    expect(status.drawdownPercent).toBeCloseTo(5, 1);
  });

  it("drawdown: peak updates when current exceeds peak", () => {
    initDrawdownTracker(100_000);
    updateDrawdown(110_000);
    const status = getDrawdownStatus();
    expect(status.peakEquity).toBeGreaterThanOrEqual(110_000);
  });

  it("drawdown: getDrawdownStatus returns timeToResetMs and monthStart", () => {
    const status = getDrawdownStatus();
    expect(status).toHaveProperty("timeToResetMs");
    expect(status).toHaveProperty("monthStart");
    expect(typeof status.timeToResetMs).toBe("number");
  });
});

describe("drawdown — auto-stop at threshold", () => {
  it("drawdown: isTradingStoppedDueToDrawdown returns boolean", () => {
    const stopped = isTradingStoppedDueToDrawdown();
    expect(typeof stopped).toBe("boolean");
  });

  it("drawdown: clearDrawdownStop resets stop flag", () => {
    clearDrawdownStop();
    const stopped = isTradingStoppedDueToDrawdown();
    expect(stopped).toBe(false);
  });

  it("drawdown: status exceeded is true when drawdown >= max", () => {
    initDrawdownTracker(100_000);
    updateDrawdown(84_000); // 16% drawdown; default max 15%
    const status = getDrawdownStatus();
    if (status.drawdownPercent >= 15) {
      expect(status.exceeded).toBe(true);
    }
  });

  it("drawdown: drawdown percent equals (peak - current) / peak * 100", () => {
    initDrawdownTracker(100_000);
    updateDrawdown(90_000);
    const status = getDrawdownStatus();
    const manual = status.peakEquity > 0
      ? ((status.peakEquity - status.currentEquity) / status.peakEquity) * 100
      : 0;
    expect(Math.abs(status.drawdownPercent - manual)).toBeLessThanOrEqual(0.01);
  });
});
