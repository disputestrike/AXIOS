import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Activity, RefreshCw, ChevronRight } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";

const REFETCH_INTERVAL_MS = 15_000;

export default function MarketDataDashboard() {
  const { data: topData, isLoading } = trpc.marketScanner.getTopOpportunities.useQuery(
    { count: 20, includeIlliquid: true },
    { refetchInterval: REFETCH_INTERVAL_MS }
  );
  const { data: status } = trpc.marketScanner.getStatus.useQuery(undefined, {
    refetchInterval: REFETCH_INTERVAL_MS,
  });
  const { data: twsStatus } = trpc.twsConnection.getStatus.useQuery(undefined, { refetchInterval: 10_000 });

  const opportunities = topData?.opportunities ?? [];
  const lead = opportunities[0];
  const hasScanData = (status?.totalOpportunities ?? 0) > 0;

  // Build chart data from real opportunities (price/IV snapshot per symbol)
  const priceChartData = opportunities.slice(0, 12).map((o, i) => ({
    symbol: o.symbol,
    price: o.currentPrice,
    iv: o.impliedVolatility != null ? o.impliedVolatility * 100 : null,
    change: o.priceChangePercent,
  })).filter(d => d.price != null);

  const avgIv = opportunities.length
    ? opportunities.reduce((s, o) => s + (o.impliedVolatility ?? 0) * 100, 0) / opportunities.filter(o => o.impliedVolatility != null).length || 0
    : 0;
  const avgPriceChange = opportunities.length
    ? opportunities.reduce((s, o) => s + o.priceChangePercent, 0) / opportunities.length
    : 0;

  const [, navigate] = useLocation();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-3xl font-bold">Market Data Ingestion</h1>
          <p className="text-slate-400 mt-2">
            Real prices and volatility — auto-refreshes every 15s (IBKR)
          </p>
          <p className="text-slate-500 text-sm mt-1">
            For trade recommendations use <Button variant="link" className="p-0 h-auto text-emerald-400 hover:text-emerald-300" onClick={() => navigate("/today-opportunity")}>Today&apos;s Opportunity <ChevronRight className="h-3 w-3 inline ml-0.5" /></Button>.
          </p>
        </div>
        {status && (
          <span className="text-xs text-slate-500">
            Last scan: {status.lastScanTime ? new Date(status.lastScanTime).toLocaleTimeString() : "Never"}
          </span>
        )}
      </div>

      {isLoading && !lead && !hasScanData ? (
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="py-12 text-center text-slate-400">
            <RefreshCw className="h-8 w-8 mx-auto animate-spin mb-2" />
            <p>Loading market data… Run a scan on Market Opportunities if needed.</p>
          </CardContent>
        </Card>
      ) : !lead && !hasScanData ? (
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="py-12 text-center text-slate-400">
            <p>No market data yet. Go to <strong>Market Opportunities</strong> and click &quot;Scan Market&quot; to load real prices.</p>
          </CardContent>
        </Card>
      ) : !lead && hasScanData ? (
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="py-12 text-center text-slate-400">
            <p>Scanner has {status?.totalOpportunities ?? 0} opportunities; top picks may be filtered. Run a fresh scan on <strong>Market Opportunities</strong> or check back after the next auto-refresh.</p>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">{lead.symbol} Price</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">${lead.currentPrice.toFixed(2)}</div>
                <div className={`text-sm mt-2 ${lead.priceChangePercent >= 0 ? "text-green-500" : "text-red-500"}`}>
                  {lead.priceChangePercent >= 0 ? "+" : ""}{lead.priceChange.toFixed(2)} ({lead.priceChangePercent >= 0 ? "+" : ""}{lead.priceChangePercent.toFixed(2)}%)
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Implied Vol (avg)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{avgIv > 0 ? `${avgIv.toFixed(1)}%` : "—"}</div>
                <div className="text-slate-500 text-sm mt-2">
                  {lead.impliedVolatility != null ? `Lead: ${(lead.impliedVolatility * 100).toFixed(1)}%` : "From scanner"}
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Avg Price Change</CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-2xl font-bold ${avgPriceChange >= 0 ? "text-green-500" : "text-red-500"}`}>
                  {avgPriceChange >= 0 ? "+" : ""}{avgPriceChange.toFixed(2)}%
                </div>
                <div className="text-slate-500 text-sm mt-2">Across {opportunities.length} symbols</div>
              </CardContent>
            </Card>

            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Symbols</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{opportunities.length}</div>
                <div className="text-slate-500 text-sm mt-2">From IBKR</div>
              </CardContent>
            </Card>
          </div>

          {priceChartData.length > 0 && (
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle>Price & Volatility Snapshot</CardTitle>
                <CardDescription>Current price and IV by symbol (real data)</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={priceChartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="symbol" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Legend />
                    <Line yAxisId="left" type="monotone" dataKey="price" stroke="#3b82f6" name="Price" />
                    {priceChartData.some(d => d.iv != null) && (
                      <Line yAxisId="right" type="monotone" dataKey="iv" stroke="#ef4444" name="IV %" />
                    )}
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}

          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle>Live Symbols</CardTitle>
              <CardDescription>Top opportunities — price, change, regime</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-slate-400 border-b border-slate-700">
                      <th className="py-2 pr-4">Symbol</th>
                      <th className="py-2 pr-4">Price</th>
                      <th className="py-2 pr-4">Change %</th>
                      <th className="py-2 pr-4">Regime</th>
                      <th className="py-2 pr-4">IV</th>
                    </tr>
                  </thead>
                  <tbody>
                    {opportunities.slice(0, 15).map((o) => (
                      <tr key={o.symbol} className="border-b border-slate-800">
                        <td className="py-2 font-medium">{o.symbol}</td>
                        <td className="py-2">${o.currentPrice.toFixed(2)}</td>
                        <td className={o.priceChangePercent >= 0 ? "text-green-400" : "text-red-400"}>
                          {o.priceChangePercent >= 0 ? "+" : ""}{o.priceChangePercent.toFixed(2)}%
                        </td>
                        <td className="py-2 text-slate-400">{o.regime.replace(/_/g, " ")}</td>
                        <td className="py-2">{o.impliedVolatility != null ? `${(o.impliedVolatility * 100).toFixed(1)}%` : "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </>
      )}

      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle>Data Ingestion Health</CardTitle>
          <CardDescription>Scanner status from market scan</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-slate-900 rounded">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-green-500" />
                <span>Total opportunities</span>
              </div>
              <span className="text-sm font-mono">{status?.totalOpportunities ?? 0}</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-slate-900 rounded">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-green-500" />
                <span>Last scan</span>
              </div>
              <span className="text-sm font-mono">
                {status?.lastScanTime ? new Date(status.lastScanTime).toLocaleString() : "—"}
              </span>
            </div>
            {(status?.errors?.length ?? 0) > 0 && (
              <div className="flex items-center justify-between p-3 bg-slate-900 rounded">
                <div className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-yellow-500" />
                  <span>Scan errors</span>
                </div>
                <span className="text-sm font-mono">{status?.errors?.length ?? 0}</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
