/**
 * Claude Trade Decision Engine — Chief Strategist (advisory only).
 * Blueprint: Claude = intent + constraints; Core = execution + risk.
 * Two paths: IntentDecision (10/10 advisory) and TradeDecision (legacy structure pick).
 * Intent: 6s timeout with one retry; on timeout/error → enhanced fallback intent.
 */

import { invokeClaude, getClaudeText, isClaudeConfigured } from "./_core/claude";
import { ALL_STRUCTURE_TYPES, ALL_REGIMES } from "./strategy-types";
import {
  type IntentDecision,
  type StrategyClass,
  normalizeRegimeToCanonical,
  STRATEGY_COMPATIBILITY,
  ALL_STRATEGY_CLASSES,
} from "./intent-governance";

/** Intent step: 6s max per attempt; one retry on timeout/error. */
const INTENT_TIMEOUT_MS = 6000;
const INTENT_MAX_RETRIES = 1;

/** Market context built from scanner opportunity + catalyst + flow. */
export interface MarketContext {
  symbol: string;
  regime: string;
  /** 0–100, 50 = neutral; derived from signal confidence + direction */
  sentiment: number;
  impliedMovePercent: number;
  historicalMovePercent: number;
  ivPercentile: number;
  ivRank: number;
  /** VIX level (0 = unavailable) */
  vix?: number;
  currentPrice: number;
  catalystSummary: string;
  /** e.g. "bullish", "bearish" from flow/signal */
  flowSignal?: string;
  technicalSignal?: string;
  /** 0–1 from scanner */
  regimeStability?: number;
  signalClass?: string;
  signalConfidence?: number;
}

/** Claude's decision: direction, action, recommended structure, reasoning. */
export interface TradeDecision {
  direction: "BULLISH" | "BEARISH" | "NEUTRAL" | "UNDEFINED";
  action: "BUY_PREMIUM" | "SELL_PREMIUM" | "UNDEFINED";
  /** One of: iron_condor, vertical_call_spread, ... (exact id from ALL_STRUCTURE_TYPES) */
  recommendedStructure: string;
  alternateStructures: string[];
  reasoning: string;
  confidence: number;
  rationale: {
    regimeAlignment: string;
    ivAnalysis: string;
    sentimentAnalysis: string;
    catalystAnalysis?: string;
  };
}

const STRUCTURE_IDS = ALL_STRUCTURE_TYPES.filter((s) => s.id !== "any").map((s) => s.id);
const REGIME_IDS = ALL_REGIMES.filter((r) => r.id !== "any").map((r) => r.id);

const STRATEGY_CLASS_IDS = [
  "DIRECTIONAL_DEFINED_RISK",
  "NEUTRAL_RANGE",
  "VOLATILITY",
  "TIME_SKEW",
  "STOCK_ANCHORED",
] as const;

const INTENT_SYSTEM_PROMPT = `You are the Chief Strategist (advisory only). You output INTENT only. You must NOT name strategies, recommend strikes, recommend size, or override hard rules.

Output valid JSON only, no markdown:
{"direction":"BULLISH|BEARISH|NEUTRAL","volatilityBias":"SELL|BUY|NEUTRAL","allowedClasses":["DIRECTIONAL_DEFINED_RISK"|"NEUTRAL_RANGE"|"VOLATILITY"|"TIME_SKEW"|"STOCK_ANCHORED"],"forbiddenClasses":[],"confidence":0.0-1.0,"rationale":"2-3 sentences max."}

Allowed class ids: ${STRATEGY_CLASS_IDS.join(", ")}.`;

const SYSTEM_PROMPT = `You are an expert institutional options trader. Your job: analyze market conditions and decide:
1. DIRECTION: BULLISH, BEARISH, or NEUTRAL (align with sentiment and catalyst).
2. ACTION: BUY_PREMIUM (when IV low/cheap) or SELL_PREMIUM (when IV high/expensive). If implied move > historical, options are often overpriced → SELL_PREMIUM. If implied < historical → BUY_PREMIUM.
3. RECOMMENDED STRUCTURE: Pick the single best structure from the allowed list for this regime and direction.
4. ALTERNATE STRUCTURES: Up to 3 other structures that also fit (ranked).

Allowed structure ids (use these exact strings): ${STRUCTURE_IDS.join(", ")}
Regimes (for context): ${REGIME_IDS.join(", ")}

Rules:
- Direction must align with sentiment (bullish sentiment → BULLISH or NEUTRAL, not BEARISH).
- Action must align with IV: implied > historical → SELL_PREMIUM; implied < historical → BUY_PREMIUM.
- In crisis or chaotic regime prefer straddle/strangle (buy volatility). In bull/bear stable prefer iron_condor/iron_butterfly (sell premium).
- Respond ONLY with valid JSON in this exact shape, no markdown:
{"direction":"BULLISH|BEARISH|NEUTRAL|UNDEFINED","action":"BUY_PREMIUM|SELL_PREMIUM|UNDEFINED","recommendedStructure":"<one structure id>","alternateStructures":["<id>","<id>"],"reasoning":"One sentence.","confidence":0.85,"rationale":{"regimeAlignment":"...","ivAnalysis":"...","sentimentAnalysis":"...","catalystAnalysis":"..."}}`;

function normalizeStructureId(s: string): string {
  const lower = (s || "").toLowerCase().replace(/\s+/g, "_").trim();
  const found = STRUCTURE_IDS.find((id) => id === lower || id.replace(/_/g, "").includes(lower.replace(/_/g, "")));
  return found ?? "vertical_call_spread";
}

/**
 * Generate trade decision from Claude. Returns decision or fallback when Claude not configured.
 */
export async function generateTradeDecision(ctx: MarketContext): Promise<TradeDecision> {
  if (!isClaudeConfigured()) {
    return getFallbackDecision(ctx);
  }

  const prompt = `Analyze this market and decide direction, action, and best structure.

SYMBOL: ${ctx.symbol}
REGIME: ${ctx.regime}
SENTIMENT: ${ctx.sentiment}% (0=bearish, 50=neutral, 100=bullish)
IMPLIED MOVE: ${ctx.impliedMovePercent}%
HISTORICAL MOVE: ${ctx.historicalMovePercent}%
IV RANK: ${ctx.ivRank}% | IV PERCENTILE: ${ctx.ivPercentile}%
CURRENT PRICE: $${ctx.currentPrice}
CATALYST: ${ctx.catalystSummary || "None"}
${ctx.flowSignal ? `FLOW: ${ctx.flowSignal}` : ""}
${ctx.technicalSignal ? `TECHNICAL: ${ctx.technicalSignal}` : ""}
${ctx.regimeStability != null ? `REGIME STABILITY: ${(ctx.regimeStability * 100).toFixed(0)}%` : ""}

Respond with JSON only.`;

  try {
    const response = await invokeClaude({
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: prompt }],
      max_tokens: 1024,
    });
    const text = getClaudeText(response);
    return parseTradeDecision(text, ctx);
  } catch (e) {
    console.warn("[ClaudeDecision] Claude call failed, using fallback:", e);
    return getFallbackDecision(ctx);
  }
}

function parseTradeDecision(text: string, ctx: MarketContext): TradeDecision {
  const raw = text.trim().replace(/^```json\s*/i, "").replace(/\s*```$/i, "").trim();
  let parsed: Record<string, unknown>;
  try {
    parsed = JSON.parse(raw) as Record<string, unknown>;
  } catch {
    return getFallbackDecision(ctx);
  }

  const direction = ["BULLISH", "BEARISH", "NEUTRAL", "UNDEFINED"].includes(String(parsed.direction))
    ? (parsed.direction as TradeDecision["direction"])
    : "NEUTRAL";
  const action = ["BUY_PREMIUM", "SELL_PREMIUM", "UNDEFINED"].includes(String(parsed.action))
    ? (parsed.action as TradeDecision["action"])
    : "UNDEFINED";
  const recommendedStructure = normalizeStructureId(String(parsed.recommendedStructure ?? "vertical_call_spread"));
  const alternateStructures = Array.isArray(parsed.alternateStructures)
    ? (parsed.alternateStructures as string[]).map(normalizeStructureId).filter((s) => s !== recommendedStructure)
    : [];
  const reasoning = String(parsed.reasoning ?? "No reasoning provided.");
  const confidence = Math.min(1, Math.max(0, Number(parsed.confidence) || 0.7));
  const rationale = (parsed.rationale as Record<string, string>) ?? {};
  return {
    direction,
    action,
    recommendedStructure,
    alternateStructures: alternateStructures.slice(0, 3),
    reasoning,
    confidence,
    rationale: {
      regimeAlignment: String(rationale.regimeAlignment ?? "—"),
      ivAnalysis: String(rationale.ivAnalysis ?? "—"),
      sentimentAnalysis: String(rationale.sentimentAnalysis ?? "—"),
      catalystAnalysis: rationale.catalystAnalysis ? String(rationale.catalystAnalysis) : undefined,
    },
  };
}

function getFallbackDecision(ctx: MarketContext): TradeDecision {
  const sentiment = ctx.sentiment ?? 50;
  const direction: TradeDecision["direction"] =
    sentiment >= 60 ? "BULLISH" : sentiment <= 40 ? "BEARISH" : "NEUTRAL";
  const impliedAboveHistorical = ctx.impliedMovePercent > (ctx.historicalMovePercent ?? 10) * 1.1;
  const action: TradeDecision["action"] = impliedAboveHistorical ? "SELL_PREMIUM" : "BUY_PREMIUM";
  const regime = (ctx.regime ?? "").toLowerCase();
  let recommendedStructure = "vertical_call_spread";
  if (regime.includes("crisis") || regime.includes("chaotic")) {
    recommendedStructure = "straddle";
  } else if (regime.includes("bull") || regime.includes("bear")) {
    recommendedStructure = direction === "NEUTRAL" ? "iron_condor" : direction === "BULLISH" ? "vertical_call_spread" : "vertical_put_spread";
  } else {
    recommendedStructure = "iron_condor";
  }
  return {
    direction,
    action,
    recommendedStructure,
    alternateStructures: ["iron_condor", "vertical_call_spread", "vertical_put_spread"].filter((s) => s !== recommendedStructure),
    reasoning: "Claude not configured; using heuristic (direction from sentiment, action from IV, structure from regime).",
    confidence: 0.5,
    rationale: {
      regimeAlignment: `Regime ${ctx.regime} suggests ${recommendedStructure}.`,
      ivAnalysis: impliedAboveHistorical ? "Implied > historical → sell premium." : "Implied ≤ historical → buy premium.",
      sentimentAnalysis: `Sentiment ${ctx.sentiment}% → ${direction}.`,
    },
  };
}

/** Fallback intent when Claude times out or is not configured. IV/catalyst-aware "Claude Lite". */
function getFallbackIntent(ctx: MarketContext): IntentDecision {
  const regime = normalizeRegimeToCanonical(ctx.regime ?? "");
  const sentiment = ctx.sentiment ?? 50;
  const ivRank = ctx.ivRank ?? 50;
  const direction: IntentDecision["direction"] =
    sentiment >= 60 ? "BULLISH" : sentiment <= 40 ? "BEARISH" : "NEUTRAL";
  const impliedAboveHistorical = ctx.impliedMovePercent > (ctx.historicalMovePercent ?? 10) * 1.1;
  const volatilityBias: IntentDecision["volatilityBias"] =
    impliedAboveHistorical ? "SELL" : "BUY";

  // Build allowedClasses from context so fallback isn't one-size-fits-all
  const highIv = ivRank >= 55;
  const crisisLike = regime === "CRISIS" || regime === "CHAOTIC";
  const cat = (ctx.catalystSummary ?? "").toLowerCase();
  const hasEarnings = cat.includes("earnings") || cat.includes("earnings date") || cat.includes("er ");
  const hasEvent = cat.includes("fda") || cat.includes("event") || cat.includes("catalyst");

  const preferred: StrategyClass[] = [];
  if (direction !== "NEUTRAL") {
    preferred.push("DIRECTIONAL_DEFINED_RISK", "STOCK_ANCHORED");
  }
  if (highIv || crisisLike) {
    preferred.push("NEUTRAL_RANGE", "VOLATILITY");
  }
  if (hasEarnings || hasEvent) {
    preferred.push("TIME_SKEW");
  }
  // Ensure we always have at least 2 classes; dedupe and fall back to full set
  const allowedSet = new Set<StrategyClass>(preferred.length > 0 ? preferred : ALL_STRATEGY_CLASSES);
  if (allowedSet.size < 2) {
    ALL_STRATEGY_CLASSES.forEach((c) => allowedSet.add(c));
  }
  const allowedClasses = Array.from(allowedSet) as IntentDecision["allowedClasses"];

  // Confidence varies by context so fallback is distinguishable and not flat 0.5
  const confidence = Math.min(
    0.7,
    Math.max(0.35, 0.35 + 0.25 * (sentiment / 50) + 0.15 * (ivRank / 100))
  );

  const hint =
    highIv && crisisLike
      ? "high IV in stressed regime → prefer defined-risk/vol selling."
      : hasEarnings || hasEvent
        ? "catalyst present → time/skew plays allowed."
        : direction !== "NEUTRAL"
          ? "directional bias → directional/stock-anchored allowed."
          : "neutral → range/vol allowed.";
  const rationale = `${ctx.symbol} at $${ctx.currentPrice}: ${regime}, IV rank ${ivRank}%, sentiment ${ctx.sentiment}%. ${hint} Implied ${ctx.impliedMovePercent}% vs historical ${ctx.historicalMovePercent}%.`;

  return {
    direction,
    volatilityBias,
    allowedClasses,
    forbiddenClasses: [],
    confidence,
    rationale,
  };
}

/**
 * Generate intent decision (advisory only). Blueprint Step 4.
 * Timeout 6s per attempt, one retry; on timeout or error → enhanced fallback intent.
 */
export async function generateIntentDecision(ctx: MarketContext): Promise<IntentDecision> {
  if (!isClaudeConfigured()) {
    return getFallbackIntent(ctx);
  }

  const prompt = `Symbol: ${ctx.symbol} at $${ctx.currentPrice}. Regime: ${ctx.regime}. Sentiment: ${ctx.sentiment}%. Implied move: ${ctx.impliedMovePercent}%. Historical: ${ctx.historicalMovePercent}%. IV rank: ${ctx.ivRank}%.${ctx.vix != null && ctx.vix > 0 ? ` VIX: ${ctx.vix.toFixed(1)}.` : ""}
${ctx.catalystSummary ? `Catalyst: ${ctx.catalystSummary}` : ""}

CRITICAL: Write a UNIQUE 2-3 sentence rationale for ${ctx.symbol} ONLY. Reference the symbol name, its price, IV rank, and regime. Do NOT use generic phrases like "liquidity drought regime" for every symbol. Each stock is different.`;

  let lastError: unknown;
  for (let attempt = 0; attempt <= INTENT_MAX_RETRIES; attempt++) {
    try {
      const response = await invokeClaude({
        system: INTENT_SYSTEM_PROMPT,
        messages: [{ role: "user", content: prompt }],
        max_tokens: 512,
        timeoutMs: INTENT_TIMEOUT_MS,
      });
      const text = getClaudeText(response);
      return parseIntentDecision(text, ctx);
    } catch (e) {
      lastError = e;
      if (attempt < INTENT_MAX_RETRIES) {
        console.warn("[ClaudeIntent] Attempt failed, retrying once:", e);
      } else {
        console.warn("[ClaudeIntent] Timeout or error after retries, using fallback:", lastError);
      }
    }
  }
  return getFallbackIntent(ctx);
}

function parseIntentDecision(text: string, ctx: MarketContext): IntentDecision {
  const raw = text.trim().replace(/^```json\s*/i, "").replace(/\s*```$/i, "").trim();
  let parsed: Record<string, unknown>;
  try {
    parsed = JSON.parse(raw) as Record<string, unknown>;
  } catch {
    return getFallbackIntent(ctx);
  }

  const direction = ["BULLISH", "BEARISH", "NEUTRAL"].includes(String(parsed.direction))
    ? (parsed.direction as IntentDecision["direction"])
    : "NEUTRAL";
  const volatilityBias = ["SELL", "BUY", "NEUTRAL"].includes(String(parsed.volatilityBias))
    ? (parsed.volatilityBias as IntentDecision["volatilityBias"])
    : "NEUTRAL";
  const allowedClasses = Array.isArray(parsed.allowedClasses)
    ? (parsed.allowedClasses as string[]).filter((c) => STRATEGY_CLASS_IDS.includes(c as any))
    : [];
  const forbiddenClasses = Array.isArray(parsed.forbiddenClasses)
    ? (parsed.forbiddenClasses as string[]).filter((c) => STRATEGY_CLASS_IDS.includes(c as any))
    : [];
  const confidence = Math.min(1, Math.max(0, Number(parsed.confidence) ?? 0.7));
  const rationale = String(parsed.rationale ?? "No rationale.").slice(0, 500);

  const regime = normalizeRegimeToCanonical(ctx.regime ?? "");
  const available = STRATEGY_COMPATIBILITY[regime] ?? ALL_STRATEGY_CLASSES;
  const effectiveAllowed: IntentDecision["allowedClasses"] = allowedClasses.length > 0
    ? (allowedClasses.filter((c) => available.includes(c as any)) as IntentDecision["allowedClasses"])
    : ([...available] as IntentDecision["allowedClasses"]);
  const finalAllowed = effectiveAllowed.length === 0 ? ([...ALL_STRATEGY_CLASSES] as IntentDecision["allowedClasses"]) : effectiveAllowed;

  return {
    direction,
    volatilityBias,
    allowedClasses: finalAllowed,
    forbiddenClasses: forbiddenClasses as IntentDecision["forbiddenClasses"],
    confidence,
    rationale,
  };
}
