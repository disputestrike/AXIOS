import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { sdk } from "./sdk";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;

  try {
    user = await sdk.authenticateRequest(opts.req);
    if (user) {
      // Don't log every request to avoid spam
    }
  } catch (error) {
    // Authentication is optional for public procedures.
    // Only log if it's not a common "no session" case
    const errorMsg = error instanceof Error ? error.message : String(error);
    if (!errorMsg.includes("Invalid session cookie") && !errorMsg.includes("Missing session")) {
      console.log("[Context] Authentication failed (non-critical):", errorMsg);
    }
    user = null;
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
  };
}
