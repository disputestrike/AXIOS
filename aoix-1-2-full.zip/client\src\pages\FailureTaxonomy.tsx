import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function FailureTaxonomy() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Failure Taxonomy</h1>
        <p className="text-slate-400 mt-2">Loss classification and attribution analysis</p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Recent Failures</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-slate-400">No failures recorded in current session</p>
        </CardContent>
      </Card>
    </div>
  );
}
