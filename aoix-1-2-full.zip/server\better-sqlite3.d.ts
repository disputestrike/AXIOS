/** Type declaration for optional dependency better-sqlite3 (OUTCOME_STORE=sqlite). */
declare module "better-sqlite3" {
  interface Database {
    exec(sql: string): this;
    prepare(sql: string): Statement;
    close(): this;
  }
  interface Statement {
    run(...params: unknown[]): unknown;
    get(...params: unknown[]): unknown;
    all(...params: unknown[]): unknown[];
  }
  export default class Database {
    constructor(filename: string);
    exec(sql: string): this;
    prepare(sql: string): Statement;
    close(): this;
  }
}
