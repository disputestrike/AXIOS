/**
 * Signal contribution breakdown for a symbol — final score, weights, top drivers.
 * Uses signals.getActiveWithBreakdown(underlying).
 * Reference only; trading recommendations use Today's Opportunity (intent governance).
 */

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { Activity, RefreshCw, ChevronRight } from "lucide-react";

interface BreakdownItem {
  type: string;
  score: number;
  weight: number;
  rationale: string;
}

interface SignalBreakdownData {
  finalScore: number;
  winProbability: number;
  breakdown: BreakdownItem[];
  topThreeSignals: Array<{ type: string; score: number; rationale: string }>;
}

interface SignalBreakdownProps {
  symbol: string;
  /** If true, show compact single card; if false, full width. */
  compact?: boolean;
}

const typeColors: Record<string, string> = {
  signal: "#4ECDC4",
  regime: "#45B7D1",
  opportunity: "#FFA500",
  gamma: "#FF6B6B",
  flow: "#4ECDC4",
  momentum: "#45B7D1",
  catalyst: "#FFA500",
};

export function SignalBreakdown({ symbol, compact = false }: SignalBreakdownProps) {
  const [, navigate] = useLocation();
  const { data, isLoading, isError, error, refetch, isRefetching } = trpc.signals.getActiveWithBreakdown.useQuery(
    { underlying: symbol },
    { enabled: !!symbol?.trim(), retry: 1, staleTime: 30_000 }
  );

  if (!symbol?.trim()) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="pt-6 py-8 text-center text-slate-400 text-sm">
          Select a symbol to view signal breakdown.
        </CardContent>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="pt-6 flex items-center justify-center py-8 text-slate-400">
          <RefreshCw className="h-5 w-5 animate-spin mr-2" />
          Loading signal breakdown for {symbol}…
        </CardContent>
      </Card>
    );
  }

  if (isError) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="pt-6 py-8 text-center text-slate-400 text-sm">
          <p>Could not load breakdown for {symbol}.</p>
          <p className="mt-1 text-xs">{error?.message ?? "Request failed"}</p>
          <button type="button" onClick={() => refetch()} className="mt-2 text-xs text-sky-400 hover:underline">
            Retry
          </button>
        </CardContent>
      </Card>
    );
  }

  const payload = data as SignalBreakdownData | undefined;
  if (!payload) {
    return (
      <Card className="bg-slate-800/50 border-slate-700">
        <CardContent className="pt-6 py-8 text-center text-slate-400 text-sm">
          No breakdown data for {symbol}. Run a scan on Market Opportunities so {symbol} is in the scan results, then try again.
        </CardContent>
      </Card>
    );
  }

  const colors = payload.breakdown?.map((b) => typeColors[b.type] ?? "#94a3b8") ?? [];

  return (
    <Card className="bg-slate-800/50 border-slate-700">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Activity className="h-5 w-5" />
              Signal Breakdown — {symbol}
            </CardTitle>
            <CardDescription>Reference only; not used for trade decisions. For trading use Today&apos;s Opportunity. Composite score, win probability, and contributing factors.</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              className="text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10 text-xs"
              onClick={() => navigate("/today-opportunity")}
            >
              Today&apos;s Opportunity <ChevronRight className="h-3 w-3 ml-0.5" />
            </Button>
            <button
              type="button"
              onClick={() => refetch()}
              disabled={isRefetching}
              className="text-slate-400 hover:text-white transition-colors p-1 rounded"
              aria-label="Refresh breakdown"
            >
              <RefreshCw className={`h-4 w-4 ${isRefetching ? "animate-spin" : ""}`} />
            </button>
          </div>
        </div>
      </CardHeader>
      <CardContent className={compact ? "space-y-3" : "space-y-4"}>
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 bg-slate-900/50 rounded-lg">
            <div className="text-xs text-slate-400">Final composite score</div>
            <div
              className="text-2xl font-bold"
              style={{ color: (payload.finalScore ?? 0) >= 70 ? "#22c55e" : "#eab308" }}
            >
              {(payload.finalScore ?? 0).toFixed(1)}
            </div>
          </div>
          <div className="p-3 bg-slate-900/50 rounded-lg">
            <div className="text-xs text-slate-400">Win probability</div>
            <div className="text-2xl font-bold text-slate-200">
              {((payload.winProbability ?? 0) * 100).toFixed(1)}%
            </div>
          </div>
        </div>

        {Array.isArray(payload.topThreeSignals) && payload.topThreeSignals.length > 0 && (
          <div>
            <div className="text-sm font-semibold text-slate-300 mb-2">Top drivers</div>
            <ul className="space-y-1 text-xs text-slate-400">
              {payload.topThreeSignals.map((s, i) => (
                <li key={i}>
                  {i + 1}. {s.type}: {(s.score * 100).toFixed(0)}% — {s.rationale}
                </li>
              ))}
            </ul>
          </div>
        )}

        {Array.isArray(payload.breakdown) && payload.breakdown.length > 0 && (
          <div className="space-y-2">
            <div className="text-sm font-semibold text-slate-300">Breakdown</div>
            {payload.breakdown.map((b, idx) => (
              <div key={b.type} className="p-2 rounded bg-slate-900/50">
                <div className="flex justify-between items-center mb-1">
                  <span className="font-medium text-sm" style={{ color: colors[idx] ?? "#94a3b8" }}>
                    {b.type}
                  </span>
                  <span className="text-xs font-mono">Score: {(b.score * 100).toFixed(0)}% · Weight: {((b.weight ?? 0) * 100).toFixed(0)}%</span>
                </div>
                <div className="w-full bg-slate-700 rounded h-2 overflow-hidden">
                  <div
                    className="h-full transition-all"
                    style={{
                      width: `${Math.min(100, (b.weight ?? 0) * 100)}%`,
                      backgroundColor: colors[idx] ?? "#64748b",
                    }}
                  />
                </div>
                <div className="text-xs text-slate-400 mt-1">{b.rationale}</div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
