# Get IB Client Portal Gateway Running on localhost:5000

The app needs **Client Portal Gateway** on **port 5000** for market data. It’s a **separate app** from IB — you download it, run it, then open http://localhost:5000 in your browser.

---

## Step 1: Install Java (if needed)

Client Portal Gateway needs **Java 8 or higher**.

- Check: open a terminal and run: `java -version`
- If it’s missing or too old: install from https://adoptium.net/ (Java 17 LTS) or use your system’s Java.

---

## Step 2: Download Client Portal Gateway

1. Go to: **https://www.interactivebrokers.com/en/trading/ibgateway-latest.php**  
   (or search “Interactive Brokers Client Portal Gateway download”.)
2. Download **Client Portal Gateway** — look for **`clientportal.gw.zip`** (or a link that says “Client Portal Gateway”).
3. **Unzip** it to a folder, e.g. `C:\IB\clientportal.gw` (or anywhere you like).

---

## Step 3: Run the Gateway (Windows)

1. Open **Command Prompt** or **PowerShell**.
2. Go into the **unzipped folder** (where you see `bin` and `root`):
   ```bash
   cd C:\IB\clientportal.gw
   ```
   *(Use the path where you unzipped it.)*
3. Start the gateway:
   ```bash
   bin\run.bat root\conf.yaml
   ```
4. Leave this window **open**. You should see logs; when it’s ready it will listen on port 5000.

---

## Step 4: Open http://localhost:5000 in your browser

1. In Chrome/Firefox/Edge go to: **http://localhost:5000**
2. You should see the **IB login page** (Client Portal).
3. **Log in** with your Interactive Brokers username and password (and 2FA if asked).
4. After login, keep the Gateway window and the browser tab open. The app can then use the session (and optionally the cookie — see main setup).

### If you see "Authentication failed" on the login page

That message is from **Interactive Brokers**, not from this app. Check:

- **Username & password** — Same as at [ibkr.com](https://www.ibkr.com); no typos.
- **2FA** — Request a **new** code (app or SMS); don't reuse an old one.
- **Paper vs Live** — Toggle must match your account type.
- **Lockout** — After many failed attempts, wait 15–30 minutes or log in on ibkr.com first.
- Use **"Problem with logging in?"** on the page for password reset or account recovery.

---

## If localhost:5000 doesn’t load

| Issue | What to do |
|--------|------------|
| **Connection refused** | Gateway isn’t running. Run `bin\run.bat root\conf.yaml` again from the unzipped folder and leave the window open. |
| **Java not found** | Install Java 8+ and run the command again. |
| **Port 5000 in use** | Another program is using 5000. Close it or change the Gateway port in `root/conf.yaml` (and set `TWS_PORT` in `.env.local` to that port). |
| **Firewall blocking** | Allow Java (or the run.bat) in Windows Firewall. You can run `ALLOW_JAVA_FIREWALL.bat` as Administrator from the project folder. |

---

## After it’s working

- In the **app** (e.g. http://localhost:3004), go to **Market Opportunities** and click **Test SPY**.
- If you see **SPY = $XXX**, the app is talking to the Gateway on 5000.
- Optional: copy the **`api`** cookie from http://localhost:5000 (F12 → Application → Cookies) into `.env.local` as `IB_GATEWAY_COOKIE=api=YOUR_VALUE` and restart the app so it stays connected without re-login.
