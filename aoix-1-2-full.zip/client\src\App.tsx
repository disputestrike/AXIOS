import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import DashboardLayout from "./components/DashboardLayout";
import MarketDataDashboard from "./pages/MarketDataDashboard";
import RegimeClassification from "./pages/RegimeClassification";
import SignalTaxonomy from "./pages/SignalTaxonomy";
import StructureSelector from "./pages/StructureSelector";
import RiskEngine from "./pages/RiskEngine";
import ExecutionDashboard from "./pages/ExecutionDashboard";
import ExecutionInterface from "./pages/ExecutionInterface";
import MetaIntelligence from "./pages/MetaIntelligence";
import FailureTaxonomy from "./pages/FailureTaxonomy";
import ShadowSystem from "./pages/ShadowSystem";
import CrossAssetReflexivity from "./pages/CrossAssetReflexivity";
import AutoTrading from "./pages/AutoTrading";
import Recommendations from "./pages/Recommendations";
import SystemHealth from "./pages/SystemHealth";
import Home from "./pages/Home";
import TodayOpportunity from "./pages/TodayOpportunity";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/today-opportunity">
        {() => (
          <DashboardLayout>
            <TodayOpportunity />
          </DashboardLayout>
        )}
      </Route>
      <Route path="/auto-trading">
        {() => (
          <DashboardLayout>
            <AutoTrading />
          </DashboardLayout>
        )}
      </Route>
      <Route path="/recommendations">
        {() => (
          <DashboardLayout>
            <Recommendations />
          </DashboardLayout>
        )}
      </Route>
      <Route path="/system-health">
        {() => (
          <DashboardLayout>
            <SystemHealth />
          </DashboardLayout>
        )}
      </Route>
      <Route path="/market-data">
        {() => (
          <DashboardLayout>
            <MarketDataDashboard />
          </DashboardLayout>
        )}
      </Route>
      <Route path="/regime">
        {() => (
          <DashboardLayout>
            <RegimeClassification />
          </DashboardLayout>
        )}
      </Route>
      <Route path="/signals">
        {() => (
          <DashboardLayout>
            <SignalTaxonomy />
          </DashboardLayout>
        )}
      </Route>
      <Route path="/structures">
        {() => (
          <DashboardLayout>
            <StructureSelector />
          </DashboardLayout>
        )}
      </Route>
      <Route path="/risk">
        {() => (
          <DashboardLayout>
            <RiskEngine />
          </DashboardLayout>
        )}
      </Route>
      <Route path="/execution">
        {() => (
          <DashboardLayout>
            <ExecutionDashboard />
          </DashboardLayout>
        )}
      </Route>
      <Route path="/execution/interface">
        {() => (
          <DashboardLayout>
            <ExecutionInterface />
          </DashboardLayout>
        )}
      </Route>
      <Route path="/meta-intelligence">
        {() => (
          <DashboardLayout>
            <MetaIntelligence />
          </DashboardLayout>
        )}
      </Route>
      <Route path="/failures">
        {() => (
          <DashboardLayout>
            <FailureTaxonomy />
          </DashboardLayout>
        )}
      </Route>
      <Route path="/shadow-system">
        {() => (
          <DashboardLayout>
            <ShadowSystem />
          </DashboardLayout>
        )}
      </Route>
      <Route path="/correlations">
        {() => (
          <DashboardLayout>
            <CrossAssetReflexivity />
          </DashboardLayout>
        )}
      </Route>
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
