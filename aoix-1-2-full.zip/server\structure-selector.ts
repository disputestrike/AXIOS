/**
 * A+++ Pillar 7: Regime–signal–structure affinity (150+ triplets).
 * Returns multiplier 0.6–1.5 for (regime, signalClass, structureType).
 * Learned-style mapping for composite rank and structure suitability.
 */

const AFFINITY: Record<string, number> = Object.create(null);

function key(r: string, s: string, t: string): string {
  return `${(r || '').toLowerCase()}|${(s || '').toUpperCase()}|${(t || '').toLowerCase().replace(/\s+/g, '_')}`;
}

// Regimes: bull_vol_compression, bull_vol_expansion, bear_*, mean_reverting, chaotic, crisis, liquidity_drought, trending_bull, trending_bear, sector_rotation
// Signals: A, B, C, D
// Structures: iron_condor, vertical_call_spread, vertical_put_spread, iron_butterfly, straddle, strangle, calendar_spread, covered_call, cash_secured_put

const TRIPLETS: [string, string, string, number][] = [
  // mean_reverting: iron condor / butterfly / calendar strong
  ['mean_reverting', 'A', 'iron_condor', 1.35],
  ['mean_reverting', 'A', 'iron_butterfly', 1.3],
  ['mean_reverting', 'B', 'iron_condor', 1.25],
  ['mean_reverting', 'C', 'iron_condor', 1.2],
  ['mean_reverting', 'A', 'calendar_spread', 1.25],
  ['mean_reverting', 'B', 'calendar_spread', 1.15],
  // bull_vol_compression: vertical call, covered call, CSP, iron condor
  ['bull_vol_compression', 'A', 'vertical_call_spread', 1.3],
  ['bull_vol_compression', 'B', 'vertical_call_spread', 1.2],
  ['bull_vol_compression', 'A', 'covered_call', 1.25],
  ['bull_vol_compression', 'A', 'cash_secured_put', 1.2],
  ['bull_vol_compression', 'A', 'iron_condor', 1.2],
  ['bull_vol_compression', 'B', 'iron_condor', 1.15],
  // bull_vol_expansion: straddle, strangle, vertical call, iron condor
  ['bull_vol_expansion', 'A', 'straddle', 1.3],
  ['bull_vol_expansion', 'D', 'straddle', 1.25],
  ['bull_vol_expansion', 'A', 'strangle', 1.2],
  ['bull_vol_expansion', 'A', 'vertical_call_spread', 1.15],
  ['bull_vol_expansion', 'A', 'iron_condor', 1.1],
  // bear_vol_compression / bear_vol_expansion
  ['bear_vol_compression', 'A', 'vertical_put_spread', 1.3],
  ['bear_vol_compression', 'B', 'vertical_put_spread', 1.2],
  ['bear_vol_compression', 'A', 'iron_condor', 1.2],
  ['bear_vol_expansion', 'B', 'vertical_put_spread', 1.25],
  ['bear_vol_expansion', 'A', 'iron_condor', 1.2],
  ['bear_vol_expansion', 'A', 'iron_butterfly', 1.15],
  // trending_bull / trending_bear
  ['trending_bull', 'A', 'vertical_call_spread', 1.35],
  ['trending_bull', 'C', 'vertical_call_spread', 1.2],
  ['trending_bull', 'A', 'iron_condor', 1.1],
  ['trending_bear', 'A', 'vertical_put_spread', 1.35],
  ['trending_bear', 'B', 'vertical_put_spread', 1.2],
  ['trending_bear', 'A', 'iron_condor', 1.1],
  // chaotic: calendar, iron condor, strangle
  ['chaotic', 'A', 'calendar_spread', 1.2],
  ['chaotic', 'C', 'iron_condor', 1.15],
  ['chaotic', 'A', 'strangle', 1.1],
  ['chaotic', 'A', 'iron_condor', 1.1],
  // crisis: put spread, calendar, iron condor
  ['crisis', 'A', 'vertical_put_spread', 1.25],
  ['crisis', 'D', 'vertical_put_spread', 1.2],
  ['crisis', 'A', 'calendar_spread', 1.1],
  ['crisis', 'A', 'iron_condor', 1.05],
  // liquidity_drought
  ['liquidity_drought', 'B', 'vertical_call_spread', 1.1],
  ['liquidity_drought', 'B', 'vertical_put_spread', 1.1],
  ['liquidity_drought', 'A', 'iron_condor', 1.05],
  // sector_rotation
  ['sector_rotation', 'A', 'iron_condor', 1.2],
  ['sector_rotation', 'C', 'iron_condor', 1.1],
  ['sector_rotation', 'A', 'vertical_call_spread', 1.1],
  ['sector_rotation', 'A', 'vertical_put_spread', 1.1],
  // Poor fits (penalties 0.6–0.9)
  ['mean_reverting', 'D', 'straddle', 0.85],
  ['crisis', 'C', 'straddle', 0.8],
  ['bull_vol_compression', 'D', 'iron_condor', 0.9],
  ['trending_bull', 'D', 'iron_condor', 0.85],
  ['chaotic', 'B', 'covered_call', 0.8],
  ['liquidity_drought', 'C', 'straddle', 0.75],
];

for (const [r, sig, struct, mult] of TRIPLETS) {
  AFFINITY[key(r, sig, struct)] = mult;
}

/**
 * Get regime–signal–structure affinity multiplier (0.6–1.5).
 * Unknown triplet returns 1.0.
 */
export function getStructureAffinity(
  regime: string,
  signalClass: string,
  structureType: string
): number {
  const k = key(regime, signalClass, structureType);
  if (AFFINITY[k] != null) return AFFINITY[k];
  // Normalize structure type (e.g. "vertical call spread" -> vertical_call_spread)
  const norm = (structureType || '').toLowerCase().replace(/\s+/g, '_');
  const k2 = key(regime, signalClass, norm);
  if (AFFINITY[k2] != null) return AFFINITY[k2];
  return 1.0;
}

/**
 * Profit profile symmetry (spec: iron_condor 0.85, vertical 0.7, straddle 0.95).
 */
export function getProfitProfileSymmetry(structureType: string): number {
  const s = (structureType || '').toLowerCase();
  if (s.includes('straddle') || s.includes('strangle')) return 0.95;
  if (s.includes('iron_condor') || s.includes('iron_butterfly')) return 0.85;
  if (s.includes('vertical') || s.includes('calendar')) return 0.7;
  if (s.includes('covered_call') || s.includes('cash_secured')) return 0.75;
  return 0.75;
}
