# IB Gateway Setup Guide for AOIX-1

This guide explains how to set up Interactive Brokers Gateway to provide real market data to AOIX-1.

## Client Portal Gateway (REST API) — recommended

AOIX-1 uses the **Client Portal Gateway** REST API by default:

- **Port: 5000** — Start the Client Portal Gateway, then open **http://localhost:5000** in your browser to log in.
- Set in `.env.local`: `TWS_HOST=localhost` and **`TWS_PORT=5000`** (do not use 4001/7497; those are for the older TWS socket API).
- After logging in at localhost:5000, click **Connect** or open the demo app so the API session is active; then the app can call `/v1/api/iserver/accounts` and see you as connected.

## Two common issues when Connect fails

**Issue 1: Gateway rate limit (429)**  
You hit the IB Gateway rate limit. It's temporary.

- **Fix:** Wait 1–2 minutes without clicking anything, then click **Connect** once. If it still fails, restart the Client Portal Gateway (the app), wait another minute, then try again.

**Issue 2: Cookie not set**  
The app shows `Cookie in .env.local: not set`. The server cannot use your browser session until you give it the cookie.

- **Fix:** Get your cookie (see below), add `IB_GATEWAY_COOKIE=api=YOUR_VALUE` to `.env.local`, **restart the app** (Ctrl+C, then `pnpm dev`), wait 1–2 minutes, then click **Connect**.

### How to get your cookie

**Option A — Browser (after logging in at http://localhost:5000):**

1. With the Client Portal page open, press **F12** → **Application** (or **Storage**) → **Cookies** → **http://localhost:5000**.
2. Find the cookie named **`api`** and copy its **Value**.
3. In `.env.local`: `IB_GATEWAY_COOKIE=api=PASTE_THE_VALUE_HERE`

**Option B — Gateway Settings (if your version has it):**

1. Log in at **http://localhost:5000**.
2. Open **Settings** (top right) and look for **API** or **Web API**.
3. Find the line that shows `api=SOME_LONG_VALUE_HERE` and copy the **entire** value (including `api=`).
4. In `.env.local`: `IB_GATEWAY_COOKIE=PASTE_THE_COPIED_VALUE_HERE` (e.g. `IB_GATEWAY_COOKIE=api=DyS7RkL2x8mN9pQv...`).

**After editing `.env.local`:** Restart the app (Ctrl+C, then `pnpm dev`), wait 1–2 minutes, then click **Connect**.

---

## Diagnosis when you see 0 opportunities

The app is **IBKR-only**. If the Gateway connection fails, you get 0 market data and 0 opportunities.

1. **Check if Client Portal Gateway is running** at **http://localhost:5000** (not 7497 — that’s the TWS socket port).
   ```bash
   curl http://localhost:5000
   ```
   You should get a response (e.g. HTML or redirect), not "Connection refused".

2. **Verify IB_GATEWAY_COOKIE** in `.env.local`:
   - Log in at **http://localhost:5000** in your browser.
   - Open DevTools → Application → Cookies → `localhost:5000` → copy the **`api`** cookie value.
   - In `.env.local`: `IB_GATEWAY_COOKIE=api=YOUR_COPIED_VALUE`
   - Restart the server (`pnpm dev`).

3. **Use the "Test SPY" button** on the **Market Opportunities** (Recommendations) page:
   - If it shows **SPY = $XXX** → IB connection works; if you still see 0 opportunities, check server logs for scan/parsing.
   - If it shows **SPY failed: …** → IB connection is broken; the message (and server console) will indicate 401 (session/cookie), 400 (not ready), or connection refused.

4. **Check the server console** (where you run `pnpm dev`) for lines like:
   - `[IB] No contract for SPY – response: ...`
   - `[IB] No price in snapshot for SPY – keys: ...`
   - `[MarketScanner] 0 results – Gateway connected ...` or `... NOT connected ...`

**Common fixes:** Gateway not running → start Client Portal Gateway; wrong port → use **5000** in `TWS_PORT`; cookie expired → re-copy `api` from browser; firewall → allow localhost:5000.

## Login page shows "Authentication failed"

That message comes from **Interactive Brokers**, not from this app. The app cannot fix it. Do the following:

1. **Username and password** — Use the same IBKR username and password you use at [ibkr.com](https://www.ibkr.com). Check for typos.
2. **2FA / security code** — Request a **new** code (IBKR Mobile app or SMS). Do not reuse an old code; they expire quickly.
3. **Paper vs Live** — The toggle on the Gateway login must match your account (Paper for paper account, Live for live).
4. **Temporary lockout** — After several failed attempts, IB may block login for 15–30 minutes. Wait and try again, or log in on the main IBKR website first to confirm the account is not locked.
5. **Password reset** — Use the **"Problem with logging in?"** link on the Gateway login page (localhost:5000) to reset your password or recover your account.

After you successfully log in and the Client Portal page loads, follow the cookie steps above so the app can connect.

## What is IB Gateway?

IB Gateway is a lightweight application from Interactive Brokers that provides API access to real-time market data, options chains, and order execution. It runs locally on your machine. **Client Portal Gateway** uses HTTP on port **5000** and a REST API at `/v1/api`.

## Prerequisites

1. **Interactive Brokers Account** - You need an active IB account (paper trading or live)
2. **IB Gateway Application** - Download from Interactive Brokers website
3. **Local Machine** - Gateway runs on your computer, not in the cloud

## Installation Steps

### 1. Download IB Gateway

- Visit: https://www.interactivebrokers.com/en/trading/platforms/ib-gateway.php
- Download the latest version for your operating system (Windows, Mac, or Linux)
- Install following the IB instructions

### 2. Launch IB Gateway

1. Start the IB Gateway application
2. Log in with your Interactive Brokers credentials
3. Select either:
   - **Paper Trading Account** - For testing (recommended to start)
   - **Live Trading Account** - For real trading

### 3. Configure API Settings

Once logged in:

1. Go to **Settings** → **API** (or **Configure** → **Settings**)
2. Enable the following:
   - ✅ Enable ActiveX and Socket Clients
   - ✅ Allow connections from localhost only (for security)
   - Set **Socket Port** to `4001` (default)
   - ✅ Read-Only API (recommended for data-only access)

3. Click **Apply** and restart the application

### 4. Verify Connection

Gateway should now be running and listening on `http://localhost:4001`

To verify:
```bash
curl -X GET http://localhost:4001/v1/iserver/account
```

If successful, you'll see your account information in JSON format.

## AOIX-1 Configuration

Once IB Gateway is running, AOIX-1 will automatically:

1. **Detect Gateway Connection** - Checks if Gateway is available on startup
2. **Fetch Real Market Data** - Pulls live prices for all stocks
3. **Get Options Chains** - Retrieves real options data with Greeks
4. **Generate Real Signals** - Based on actual market conditions
5. **Execute Trades** - When connected to live trading (if enabled)

### Environment Variable (Optional)

If your IB Gateway is running on a different host/port, set:

```bash
IB_GATEWAY_URL=http://your-host:4001/v1
```

## Using AOIX-1 with Real Market Data

### 1. Start IB Gateway

Launch the IB Gateway application and log in.

### 2. Start AOIX-1

The system will automatically:
- Connect to Gateway
- Begin scanning real market data
- Display real opportunities in the dashboard
- Update dashboards with live market data

### 3. Select Assets

In the **Auto Trading** dashboard:
- Select **Tesla**, **Apple**, **SPY**, **QQQ**, or any other symbol
- The system will fetch real options data for that asset
- Recommendations will show real opportunities

### 4. Monitor Real Data

- **Market Opportunities** page shows real stocks with real signals
- **System Health** page shows Gateway connection status
- **Auto Trading** dashboard shows real market data and live P&L

## Troubleshooting

### Gateway Not Connecting (including "was working yesterday")

**Problem:** System shows "Gateway not connected" or TWS/IB Gateway not connecting; it was working yesterday.

**Most common cause:** Session expired. IB Gateway requires you to log in again after sleep, restart, or ~24 hours.

**Solution (do in order):**

1. **Start IB Gateway**  
   Launch the IB Gateway app (or Client Portal Gateway). Leave it running.

2. **Log in again in the browser**  
   - **Client Portal Gateway:** Open **http://localhost:5000** in your browser and log in with your IB credentials.  
   - **Standalone IB Gateway:** If you use a different port (e.g. 4001), open the URL shown in the Gateway window and log in.  
   After login, leave the tab/window open; the session is tied to that login.

3. **Check the port the app uses**  
   Your app uses `TWS_PORT` from `.env.local` (e.g. **4001**). The API URL is:  
   `http://localhost:<TWS_PORT>/v1/api`  
   Test it (replace 4001 with your port if different):
   ```bash
   curl -s -o NUL -w "%{http_code}" http://localhost:4001/v1/api/iserver/accounts
   ```
   - **200** = OK, app should connect.  
   - **401 / 302** = Not logged in or session expired → do step 2 again.  
   - **Connection refused** = Gateway not running or wrong port → check step 1 and port below.

4. **In the AOIX-1 app: Auto Trading page**  
   - Set **Host** to `localhost` and **Port** to the same as `TWS_PORT` (e.g. **4001**).  
   - Click **Configure & Connect**.  
   - If you just logged in via browser (step 2), you can also click **"I'm logged in at the gateway, confirm connection"**.

5. **If still failing**  
   - Restart IB Gateway, log in again in the browser, then retry step 4.  
   - Confirm firewall/antivirus is not blocking `localhost` on the Gateway port.  
   - Try port **5000** in `.env.local` (`TWS_PORT=5000`) and in the app if you use Client Portal Gateway; some setups use 5000 for both login and API.

### Gateway Not Connecting (first time or generic)

**Problem:** System shows "Gateway not connected" warning

**Solution:**
1. Verify IB Gateway is running and you are logged in (see "Gateway Not Connecting (including was working yesterday)" above).
2. Test API: `curl -s -o NUL -w "%{http_code}" http://localhost:4001/v1/api/iserver/accounts` (use your TWS_PORT).
3. Verify API settings in Gateway: Enable ActiveX and Socket Clients; allow localhost; Socket Port = your port (e.g. 4001 or 5000).
4. Check firewall isn't blocking the Gateway port.
5. Restart IB Gateway and AOIX-1, then try Connect again.

### No Market Data

**Problem:** Dashboards still show simulated data

**Solution:**
1. Verify Gateway connection (see above)
2. Ensure you have market data subscriptions for the symbols you're trading
3. Check that your IB account has sufficient permissions
4. Restart AOIX-1 to reconnect

### Slow Data Updates

**Problem:** Market data updates are slow

**Solution:**
1. IB Gateway may be rate-limited - this is normal
2. Increase the scan interval in settings (default 5 minutes)
3. Reduce the number of stocks being scanned
4. Check your internet connection

## Security Considerations

1. **Localhost Only** - Configure Gateway to accept connections from localhost only
2. **Read-Only API** - Use read-only API for data-only access
3. **Firewall** - Don't expose port 4001 to the internet
4. **Credentials** - Never share your IB credentials
5. **Paper Trading** - Test with paper trading account first

## Paper vs. Live Trading

### Paper Trading (Recommended for Testing)

- ✅ Real market data
- ✅ Simulated order execution
- ✅ No real money at risk
- ✅ Perfect for testing strategies

### Live Trading

- ⚠️ Real market data
- ⚠️ Real order execution
- ⚠️ Real money at risk
- ⚠️ Only after thorough testing

## Switching Between Paper and Live

1. Close IB Gateway
2. Restart and log in to different account type
3. AOIX-1 will automatically use the new account

## Advanced: Multiple Symbols

AOIX-1 can scan 500+ stocks simultaneously when connected to IB Gateway:

- **S&P 500** - Top 100 stocks by market cap
- **Tech Stocks** - AAPL, MSFT, GOOGL, AMZN, NVDA, TSLA, META, etc.
- **Financial Stocks** - JPM, BAC, GS, MS, etc.
- **Healthcare** - UNH, JNJ, PFE, etc.
- **Energy** - XOM, CVX, COP, etc.

The system will:
1. Fetch real market data for all symbols
2. Generate real signals based on market conditions
3. Rank opportunities by probability of profit
4. Automatically trade the best opportunities

## Support

For IB Gateway issues:
- Interactive Brokers Support: https://www.interactivebrokers.com/en/support/
- API Documentation: https://www.interactivebrokers.com/en/trading/platforms/ib-gateway.php

For AOIX-1 issues:
- Check System Health dashboard for connection status
- Review logs for error messages
- Verify IB Gateway is running and logged in
