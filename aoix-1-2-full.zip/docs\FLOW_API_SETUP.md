# Options Flow API Setup Guide

**Purpose:** Configure real options flow data (sweeps, blocks, unusual volume) for AOIX-1 signals.  
**Audience:** Engineers setting up flow providers (e.g. Unusual Whales, Cheddar, Sprout, OptionStrat).  
**Time to setup:** &lt; 1 hour.

---

## 1. Get an API key

- **Unusual Whales / Cheddar:** Sign up at the provider’s site and obtain an API key or WebSocket URL.
- **OptionStrat / Sprout:** Use the provider’s API docs to get an API key or feed URL.
- If you have no key, AOIX-1 uses a **stub/proxy** (put/call ratio + IV from our data); signals still work at reduced quality.

---

## 2. Set environment variables

Create or edit `.env.local` in the project root:

```bash
# Options Flow API (optional)
OPTIONS_FLOW_API_URL=https://api.example.com/flow
# Or WebSocket base URL if your provider uses WebSockets (HTTP proxy still supported)
# OPTIONS_FLOW_API_URL=https://ws.example.com/flow
```

- **`OPTIONS_FLOW_API_URL`**  
  - Base URL for the flow API (e.g. `https://api.example.com/flow`).  
  - When **empty or unset**, the app uses the stub/proxy (no external flow API).  
  - Requests are sent as: `{OPTIONS_FLOW_API_URL}?symbol={SYMBOL}` (or `&symbol=` if the URL already contains `?`).

No other env vars are required for flow. API keys are usually passed via query or header per provider docs.

---

## 3. Test the connection

### From the app

1. Start the server: `pnpm dev`
2. Call the flow health endpoint:
   ```bash
   curl http://localhost:3000/api/health/flow-api
   ```
   Expected (with API configured): `{"connected":true,"lastUpdate":...,"alertsCount":...,"status":"ok"}`  
   With no API: `{"connected":false,"lastUpdate":0,"alertsCount":0,"status":"stub"}`

3. Trigger a flow fetch (e.g. open a symbol that uses flow in the UI, or call the tRPC procedure that uses `getUnusualFlow`/`getRecentFlow`). Then call `/api/health/flow-api` again; `lastUpdate` and `alertsCount` should update if the API is working.

### Manual check (optional)

If your provider supports a simple REST call:

```bash
curl -H "Authorization: Bearer YOUR_API_KEY" "https://api.example.com/flow?symbol=SPY"
```

Confirm the response includes fields the app can use (e.g. `sweepCount`, `putCallRatio`, `unusualVolume`). The app maps common names (see `server/options-flow.ts`).

---

## 4. Flow cache behavior

- **TTL:** 2 minutes per symbol/params; after that the next request refetches.
- **FIFO cap:** Last **100 entries per symbol**; older entries are evicted when the cap is reached.
- **Health:** `GET /api/health/flow-api` returns `connected`, `lastUpdate`, `alertsCount`, `status`.

---

## 5. Troubleshooting

| Issue | Check |
|-------|--------|
| `connected: false` | `OPTIONS_FLOW_API_URL` set in `.env.local` and server restarted. |
| `status: "stub"` | API URL empty; app is using stub/proxy. |
| No flow in signals | Ensure the scanner/signal code calls `getUnusualFlow` or `getRecentFlow` for the symbol. |
| Timeouts | Provider timeout is 5s; increase in `server/options-flow.ts` if needed. |

---

## 6. References

- Flow integration: `server/options-flow.ts`  
- Health: `GET /api/health/flow-api` (see `server/_core/index.ts`)  
- RUNBOOK: `docs/RUNBOOK.md` (env vars and startup)

When `OPTIONS_FLOW_API_URL` is set and `/api/health/flow-api` shows `connected: true`, flow API setup is complete.
