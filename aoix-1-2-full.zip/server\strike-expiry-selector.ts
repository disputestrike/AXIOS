/**
 * Strike / Expiry Selection — Hedge fund style
 * Score a small set of strikes and expirations by liquidity, IV rank, delta; pick best.
 * Avoids fixed "ATM + next Friday"; improves execution quality.
 */

export interface StrikeExpiryCandidate {
  strike: number;
  expiry: string; // YYYYMMDD
  bid: number;
  ask: number;
  delta?: number;
  iv?: number;
  volume?: number;
  /** Score 0–1 (higher = better) */
  score: number;
}

export interface BestStrikeExpiryResult {
  strike: number;
  expiry: string;
  score: number;
  /** Optional: use when no chain available */
  fallbackReason?: string;
}

/**
 * Score candidate by liquidity (tight spread), optional delta (near 0.5 for direction), IV.
 * When we have chain data we use it; else return ATM + next Friday.
 */
function scoreCandidate(
  c: { strike: number; expiry: string; bid: number; ask: number; delta?: number; iv?: number; volume?: number },
  currentPrice: number,
  direction: "bullish" | "bearish" | "neutral"
): number {
  let score = 0.5;
  const spread = c.ask - c.bid;
  const mid = (c.bid + c.ask) / 2;
  if (mid > 0 && spread < mid * 0.1) score += 0.2; // tight spread
  if (c.volume != null && c.volume > 0) score += Math.min(0.2, c.volume / 500); // liquidity
  if (c.delta != null) {
    if (direction === "bullish" && c.delta > 0.3 && c.delta < 0.7) score += 0.15;
    if (direction === "bearish" && c.delta < -0.3 && c.delta > -0.7) score += 0.15;
    if (direction === "neutral" && Math.abs(c.delta) < 0.3) score += 0.15;
  }
  return Math.min(1, score);
}

/**
 * Select best (strike, expiry) from option chain for a structure.
 * When useFullScan=true, scores hundreds/thousands of combinations and picks the best; else uses small set (4 exp × 5 strikes).
 */
export async function selectBestStrikeExpiry(
  symbol: string,
  structureType: string,
  direction: "bullish" | "bearish" | "neutral",
  currentPrice: number,
  useFullScan?: boolean
): Promise<BestStrikeExpiryResult> {
  const fallbackStrike = Math.round(currentPrice / 5) * 5;
  const nextFriday = new Date();
  const daysUntilFriday = (5 - nextFriday.getDay() + 7) % 7 || 7;
  nextFriday.setDate(nextFriday.getDate() + daysUntilFriday);
  const fallbackExpiry = nextFriday.toISOString().slice(0, 10).replace(/-/g, "");

  if (useFullScan) {
    try {
      const { scanBestOptionCombinations } = await import("./option-combination-scanner");
      const res = await scanBestOptionCombinations(symbol, currentPrice, direction, { maxCombinations: 3000, topN: 1 });
      const best = direction === "bearish" ? res.bestPut : res.bestCall;
      if (best) {
        return {
          strike: best.contract.strike,
          expiry: best.contract.expiry,
          score: best.score / 100,
        };
      }
    } catch {
      // fall through to small set
    }
  }

  try {
    const { getIBOptionsChain } = await import("./ib-market-data");
    const chain = await getIBOptionsChain(symbol);
    if (!chain?.options?.length) {
      return { strike: fallbackStrike, expiry: fallbackExpiry, score: 0.5, fallbackReason: "no_chain" };
    }

    const expirations = Array.from(new Set(chain.options.map((o) => o.expiry))).slice(0, 4);
    const strikes = Array.from(new Set(chain.options.map((o) => o.strike)))
      .filter((s) => Math.abs(s - currentPrice) / currentPrice < 0.1)
      .sort((a, b) => Math.abs(a - currentPrice) - Math.abs(b - currentPrice))
      .slice(0, 5);

    const optionType = direction === "bearish" ? "P" : "C";
    const candidates: StrikeExpiryCandidate[] = [];
    for (const expiry of expirations) {
      for (const strike of strikes) {
        const opt = chain.options.find(
          (o) => o.expiry === expiry && o.strike === strike && o.right === optionType
        );
        if (!opt) continue;
        const bid = opt.bid ?? 0;
        const ask = opt.ask ?? 0;
        const score = scoreCandidate(
          {
            strike: opt.strike,
            expiry: opt.expiry,
            bid,
            ask,
            delta: opt.delta,
            iv: opt.impliedVolatility,
            volume: opt.volume,
          },
          currentPrice,
          direction
        );
        candidates.push({
          strike: opt.strike,
          expiry: opt.expiry,
          bid,
          ask,
          delta: opt.delta,
          iv: opt.impliedVolatility,
          volume: opt.volume,
          score,
        });
      }
    }

    if (candidates.length === 0) {
      return { strike: fallbackStrike, expiry: fallbackExpiry, score: 0.5, fallbackReason: "no_candidates" };
    }
    const best = candidates.reduce((a, b) => (a.score >= b.score ? a : b));
    return { strike: best.strike, expiry: best.expiry, score: best.score };
  } catch {
    return { strike: fallbackStrike, expiry: fallbackExpiry, score: 0.5, fallbackReason: "error" };
  }
}
