@echo off
REM Run this script AS ADMINISTRATOR to allow Java through Windows Firewall.
REM Right-click ALLOW_JAVA_FIREWALL.bat -> Run as administrator

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo This script must be run as Administrator.
    echo Right-click ALLOW_JAVA_FIREWALL.bat and choose "Run as administrator"
    pause
    exit /b 1
)

REM Try common Java locations (edit JAVA_PATH below if your Java is elsewhere)
set "JAVA_PATH="
for %%J in (jdk1.8.0_481 jre1.8.0_481 jdk-8 jre-8) do (
    if exist "C:\Program Files\Java\%%J\bin\java.exe" set "JAVA_PATH=C:\Program Files\Java\%%J\bin\java.exe"
    if exist "C:\Program Files (x86)\Java\%%J\bin\java.exe" set "JAVA_PATH=C:\Program Files (x86)\Java\%%J\bin\java.exe"
)
if exist "C:\Program Files\Java\jdk1.8.0_481\jre\bin\java.exe" set "JAVA_PATH=C:\Program Files\Java\jdk1.8.0_481\jre\bin\java.exe"
if not defined JAVA_PATH (
    echo Java.exe not found in common locations.
    echo Edit this script and set JAVA_PATH to your java.exe path, e.g.:
    echo   set "JAVA_PATH=C:\Program Files\Java\jdk1.8.0_481\bin\java.exe"
    pause
    exit /b 1
)

echo Adding firewall rule for: %JAVA_PATH%
netsh advfirewall firewall add rule name="Java (IB Gateway)" dir=in action=allow program="%JAVA_PATH%" enable=yes
if errorlevel 1 (
    echo Failed to add rule. Make sure you ran as Administrator.
) else (
    echo Rule added. Restart the Client Portal Gateway and the trading app, then try Connect again.
)
echo.
pause
