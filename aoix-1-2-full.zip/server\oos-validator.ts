/**
 * A+++ Pillar 9: Live track record & overfitting penalty.
 * Walk-forward 70/30 train/holdout, OOS Sharpe ≥ 60% of IS, max DD OOS, parameter stability, live divergence.
 */

export interface WalkForwardConfig {
  trainPct: number;
  holdoutPct: number;
  retrainIntervalMonths: number;
  minOOSSharpeRatio: number;
  maxOOSDD: number;
  maxLiveBacktestDivergence: number;
}

export const DEFAULT_WALK_FORWARD: WalkForwardConfig = {
  trainPct: 0.7,
  holdoutPct: 0.3,
  retrainIntervalMonths: 1,
  minOOSSharpeRatio: 0.6,
  maxOOSDD: 0.10,
  maxLiveBacktestDivergence: 0.30,
};

export interface OOSValidationResult {
  inSampleSharpe: number;
  outOfSampleSharpe: number;
  oosOverISRatio: number;
  inSampleMaxDD: number;
  outOfSampleMaxDD: number;
  passed: boolean;
  /** Overfitting penalty for composite: 0–1 (1 = no penalty). */
  penaltyFactor: number;
  message: string;
}

/**
 * Validate OOS: require OOS Sharpe ≥ minOOSSharpeRatio × IS Sharpe, OOS max DD ≤ maxOOSDD.
 * Returns penalty factor 0.85–1.0 for composite pillar 9 when used in production.
 */
export function validateOOS(
  inSampleSharpe: number,
  outOfSampleSharpe: number,
  inSampleMaxDD: number,
  outOfSampleMaxDD: number,
  config: Partial<WalkForwardConfig> = {}
): OOSValidationResult {
  const cfg = { ...DEFAULT_WALK_FORWARD, ...config };
  const oosOverIS = inSampleSharpe !== 0 ? outOfSampleSharpe / inSampleSharpe : 0;
  const passed = oosOverIS >= cfg.minOOSSharpeRatio && outOfSampleMaxDD <= cfg.maxOOSDD;
  let penaltyFactor = 1.0;
  if (oosOverIS < cfg.minOOSSharpeRatio) penaltyFactor = Math.max(0.85, oosOverIS / cfg.minOOSSharpeRatio);
  if (outOfSampleMaxDD > cfg.maxOOSDD) penaltyFactor *= Math.max(0.85, 1 - (outOfSampleMaxDD - cfg.maxOOSDD));
  const message = passed
    ? `OOS valid: Sharpe ratio ${(oosOverIS * 100).toFixed(0)}% of IS, max DD ${(outOfSampleMaxDD * 100).toFixed(1)}%`
    : `OOS fail: Sharpe ratio ${(oosOverIS * 100).toFixed(0)}% of IS (min ${cfg.minOOSSharpeRatio * 100}%), max DD ${(outOfSampleMaxDD * 100).toFixed(1)}% (max ${(cfg.maxOOSDD * 100).toFixed(0)}%)`;
  return {
    inSampleSharpe,
    outOfSampleSharpe,
    oosOverISRatio: oosOverIS,
    inSampleMaxDD,
    outOfSampleMaxDD,
    passed,
    penaltyFactor: Math.max(0.85, Math.min(1, penaltyFactor)) as number,
    message,
  };
}

/**
 * Live vs backtest divergence: penalty if |liveSharpe - backtestSharpe| / backtestSharpe > 30%.
 */
export function getLiveDivergencePenalty(
  liveSharpe: number,
  backtestSharpe: number
): number {
  if (backtestSharpe === 0) return 1.0;
  const divergence = Math.abs(liveSharpe - backtestSharpe) / Math.abs(backtestSharpe);
  if (divergence <= 0.30) return 1.0;
  return Math.max(0.7, 1 - (divergence - 0.30));
}

/**
 * Validate walk-forward: given in-sample and out-of-sample backtest metrics, return OOS result.
 * Use after running backtest on train period (70%) and holdout period (30%).
 */
export function validateWalkForward(
  inSample: { sharpeRatio?: number; maxDrawdownPercent?: number },
  outOfSample: { sharpeRatio?: number; maxDrawdownPercent?: number },
  config: Partial<WalkForwardConfig> = {}
): OOSValidationResult {
  const isSharpe = inSample.sharpeRatio ?? 0;
  const oosSharpe = outOfSample.sharpeRatio ?? 0;
  const isDD = (inSample.maxDrawdownPercent ?? 0) / 100;
  const oosDD = (outOfSample.maxDrawdownPercent ?? 0) / 100;
  return validateOOS(isSharpe, oosSharpe, isDD, oosDD, config);
}
