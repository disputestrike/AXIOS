/**
 * A+++ Pillar 5: Market microstructure & flow.
 * Order book imbalance, sweep volume, bid/ask spread tightness, block trade volume, unusual options flow.
 */

import { getUnusualFlow } from './options-flow';

export interface MicrostructureSignal {
  /** Bid/ask volume ratio (e.g. > 1.2 = bid-heavy). L2 or proxy. */
  orderBookImbalance: number;
  /** True if bid/ask ratio in [0.6, 1.5] (balanced). */
  orderBookBalanced: boolean;
  /** Sweep volume signal: > 3× avg daily & direction match. */
  sweepVolumeSignal: boolean;
  /** Bid/ask spread as % of mid (tight < 0.1% +8%, wide > 0.3% -8%). */
  spreadPct: number;
  /** Spread bonus: +0.08 if tight, -0.08 if wide. */
  spreadBonus: number;
  /** Block trade count (24h). Bonus if aligned. */
  blockTradeCount: number;
  /** Unusual options flow (3× vol on strikes). */
  unusualOptionsFlow: boolean;
  /** Composite 0–1 for pillar. */
  compositeScore: number;
}

/**
 * Get microstructure signals for a symbol. Uses options flow + volume proxy when L2 not available.
 */
export async function getMicrostructureSignals(
  symbol: string,
  volume: number,
  avgVolume: number,
  putCallRatio?: number,
  impliedVol?: number,
  bidAskSpreadPct?: number
): Promise<MicrostructureSignal> {
  const flow = await getUnusualFlow(symbol, putCallRatio, impliedVol);
  const volumeRatio = avgVolume && avgVolume > 0 ? volume / avgVolume : 1;
  const sweepVolumeSignal = volumeRatio > 3 && flow.unusualVolume;
  const spreadPct = bidAskSpreadPct ?? 0.15;
  const orderBookBalanced = true; // no L2: assume balanced
  const orderBookImbalance = 1.0;
  let spreadBonus = 0;
  if (spreadPct < 0.1) spreadBonus = 0.08;
  else if (spreadPct > 0.3) spreadBonus = -0.08;
  const blockTradeCount = flow.sweepCount > 0 ? flow.sweepCount : 0;
  const unusualOptionsFlow = flow.unusualVolume;
  let compositeScore = 0.5;
  if (volumeRatio > 2) compositeScore = 0.75;
  if (flow.unusualVolume) compositeScore = Math.min(1, compositeScore + 0.15);
  if (flow.sweepCount > 0) compositeScore = Math.min(1, compositeScore + 0.1 * Math.min(flow.sweepCount, 3));
  compositeScore = Math.max(0, Math.min(1, compositeScore + spreadBonus));
  return {
    orderBookImbalance,
    orderBookBalanced,
    sweepVolumeSignal,
    spreadPct,
    spreadBonus,
    blockTradeCount,
    unusualOptionsFlow,
    compositeScore,
  };
}
