/**
 * AOIX-1 Blueprint: Confidence calibration every 50 trades.
 * calibratedConfidence = intent.confidence × clamp(sharpe / 1.2, 0.75, 1.1)
 * Minimum sample size ≥ 20 trades per regime; skip if volatility > threshold; log every adjustment.
 * Enable with ENABLE_CONFIDENCE_CALIBRATION=true (only after persistent storage is live).
 */

import { getOutcomeStore } from "./outcome-log";
import { getRollingSharpeByRegimeAsync } from "./outcome-log";
import type { Regime } from "./intent-governance";

const CALIBRATION_WINDOW = 50;
const MIN_SAMPLE_PER_REGIME = 20;
const SHARPE_BENCHMARK = 1.2;
const CALIBRATION_FLOOR = 0.75;
const CALIBRATION_CAP = 1.1;

/** In-memory calibration table: regime → multiplier (clamp(sharpe/1.2, 0.75, 1.1)). */
const calibrationTable: Record<string, number> = {};

/**
 * Get calibration multiplier for a regime. Returns 1.0 if calibration not run or sample too small.
 */
export function getCalibrationMultiplier(regime: Regime | string): number {
  const r = String(regime);
  return calibrationTable[r] ?? 1.0;
}

/**
 * Apply calibration to raw confidence: calibrated = raw × getCalibrationMultiplier(regime).
 */
export function calibrateConfidence(rawConfidence: number, regime: Regime | string): number {
  const mult = getCalibrationMultiplier(regime);
  return Math.min(1, Math.max(0, rawConfidence * mult));
}

/**
 * Update calibration table from rolling Sharpe by regime.
 * Safe rule: multiplier = clamp(sharpe / 1.2, 0.75, 1.1). Skip regime if sample < 20.
 */
export async function runCalibrationJob(): Promise<{ updated: number; byRegime: Record<string, number> }> {
  const store = getOutcomeStore();
  type StoreWithGetAll = import("./outcome-log").OutcomeStore & { getAll?(): import("./outcome-log").TradeOutcome[] };
  const storeWithGetAll = store as StoreWithGetAll;
  const sharpeByRegime = await getRollingSharpeByRegimeAsync(storeWithGetAll, CALIBRATION_WINDOW);

  const byRegime: Record<string, number> = {};
  let updated = 0;

  const countByRegime = new Map<string, number>();
  if (typeof storeWithGetAll.getAll === "function") {
    const all = storeWithGetAll.getAll();
    for (const o of all.slice(-CALIBRATION_WINDOW * 2)) {
      countByRegime.set(o.regime, (countByRegime.get(o.regime) ?? 0) + 1);
    }
  }

  for (const [regime, sharpe] of Object.entries(sharpeByRegime)) {
    const sampleSize = countByRegime.get(regime) ?? 0;
    if (sampleSize < MIN_SAMPLE_PER_REGIME) {
      continue;
    }
    const mult = Math.min(CALIBRATION_CAP, Math.max(CALIBRATION_FLOOR, sharpe / SHARPE_BENCHMARK));
    calibrationTable[regime] = mult;
    byRegime[regime] = mult;
    updated++;
    if (process.env.ENABLE_CONFIDENCE_CALIBRATION === "true") {
      console.log(`[Calibration] ${regime}: sharpe=${sharpe.toFixed(2)}, mult=${mult.toFixed(2)}, n=${sampleSize}`);
    }
  }

  return { updated, byRegime };
}

/**
 * Run calibration if total outcome count is multiple of 50. Call after each closed trade.
 */
export async function runCalibrationIfDue(): Promise<boolean> {
  if (process.env.ENABLE_CONFIDENCE_CALIBRATION !== "true") return false;
  const store = getOutcomeStore();
  const storeWithCount = store as unknown as { getCount?(): number };
  const count = typeof storeWithCount.getCount === "function" ? storeWithCount.getCount() : 0;
  if (count === 0 || count % CALIBRATION_WINDOW !== 0) return false;
  await runCalibrationJob();
  return true;
}

/**
 * After closing a trade: append outcome then run calibration if total count is multiple of 50.
 * Call this from the engine/router when a trade is closed.
 */
export async function appendOutcomeAndMaybeCalibrate(
  outcome: import("./outcome-log").TradeOutcome
): Promise<boolean> {
  const { appendOutcome } = await import("./outcome-log");
  await appendOutcome(outcome);
  return runCalibrationIfDue();
}

export { CALIBRATION_WINDOW, MIN_SAMPLE_PER_REGIME, SHARPE_BENCHMARK, CALIBRATION_FLOOR, CALIBRATION_CAP };
