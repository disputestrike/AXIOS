import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function RiskEngine() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dynamic Risk Engine</h1>
        <p className="text-slate-400 mt-2">Portfolio heat maps and correlation-aware exposure limits</p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Portfolio Greeks</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div><strong>Delta:</strong> +0.35</div>
            <div><strong>Gamma:</strong> +0.08</div>
            <div><strong>Theta:</strong> +$125</div>
            <div><strong>Vega:</strong> -$450</div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
