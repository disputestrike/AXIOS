@echo off
cd /d "%~dp0"
echo Starting AOIX-1...
echo.
echo After the server starts, your browser will open to http://localhost:3000
echo If it does not open, go to: http://localhost:3000
echo.
echo Press Ctrl+C to stop the server.
echo.
pnpm dev
pause
