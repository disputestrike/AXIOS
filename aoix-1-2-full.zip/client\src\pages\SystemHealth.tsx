import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertCircle, CheckCircle2, AlertTriangle, RefreshCw, Activity } from 'lucide-react';
import { trpc } from '@/lib/trpc';

interface HealthComponent {
  component: string;
  status: 'healthy' | 'warning' | 'error';
  lastCheck: string;
  responseTimeMs?: number;
  error?: string;
}

interface PerformanceData {
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRate: number;
  profitFactor: number;
  sharpeRatio: number;
  maxDrawdown: number;
  avgWin: number;
  avgLoss: number;
  largestWin: number;
  largestLoss: number;
  totalPnL: number;
  dailyPnL: number;
  consecutiveWins: number;
  consecutiveLosses: number;
}

export default function SystemHealth() {
  const [health, setHealth] = useState<HealthComponent[]>([]);
  const [performance, setPerformance] = useState<PerformanceData | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const healthQuery = trpc.system.health.useQuery(undefined, {
    refetchInterval: 15_000, // 15s like other dashboards
  });

  const performanceQuery = trpc.omega0.getPerformanceMetrics.useQuery(undefined, {
    refetchInterval: 30_000,
  });

  useEffect(() => {
    if (healthQuery.data?.components && Array.isArray(healthQuery.data.components)) {
      const components: HealthComponent[] = healthQuery.data.components.map((comp: { component: string; status: string; lastCheck?: number; responseTimeMs?: number; error?: string }) => ({
        component: comp.component,
        status: comp.status as HealthComponent['status'],
        lastCheck: typeof comp.lastCheck === 'number' ? String(comp.lastCheck) : String(Date.now()),
        responseTimeMs: comp.responseTimeMs,
        error: comp.error,
      }));
      components.sort((a, b) => {
        const statusOrder = { healthy: 0, warning: 1, error: 2 };
        return (statusOrder[a.status] ?? 3) - (statusOrder[b.status] ?? 3);
      });
      setHealth(components);
    } else {
      setHealth([]);
    }
  }, [healthQuery.data, healthQuery.error]);

  useEffect(() => {
    if (performanceQuery.data) {
      setPerformance({
        totalTrades: performanceQuery.data.totalTrades || 0,
        winningTrades: 0,
        losingTrades: 0,
        winRate: performanceQuery.data.winRate || 0,
        profitFactor: performanceQuery.data.profitFactor || 0,
        sharpeRatio: 0,
        maxDrawdown: 0,
        avgWin: performanceQuery.data.avgWinSize || 0,
        avgLoss: performanceQuery.data.avgLossSize || 0,
        largestWin: 0,
        largestLoss: 0,
        totalPnL: performanceQuery.data.totalPnL || 0,
        dailyPnL: 0,
        consecutiveWins: 0,
        consecutiveLosses: 0,
      });
    }
  }, [performanceQuery.data]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await Promise.all([healthQuery.refetch(), performanceQuery.refetch()]);
    setIsRefreshing(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy':
        return <CheckCircle2 className="h-5 w-5 text-green-500" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Activity className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'healthy':
        return <Badge className="bg-green-100 text-green-800">Healthy</Badge>;
      case 'warning':
        return <Badge className="bg-yellow-100 text-yellow-800">Warning</Badge>;
      case 'error':
        return <Badge className="bg-red-100 text-red-800">Error</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">Unknown</Badge>;
    }
  };

  const overallStatus = health.length > 0 ? (health.some((h) => h.status === 'error') ? 'error' : health.some((h) => h.status === 'warning') ? 'warning' : 'healthy') : 'unknown';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">System Health</h1>
          <p className="text-gray-600 mt-1">Real-time monitoring of all system components</p>
        </div>
        <Button onClick={handleRefresh} disabled={isRefreshing} className="gap-2">
          <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          {isRefreshing ? 'Refreshing...' : 'Refresh'}
        </Button>
      </div>

      {/* Overall Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {getStatusIcon(healthQuery.data?.status || overallStatus)}
            Overall System Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">System Status</p>
              <p className="text-2xl font-bold capitalize mt-1">
                {healthQuery.data?.status || overallStatus}
              </p>
              {healthQuery.data?.timestamp && (
                <p className="text-xs text-gray-500 mt-1">
                  Last checked: {new Date(healthQuery.data.timestamp).toLocaleString()}
                </p>
              )}
            </div>
            <div className="text-right">
              {getStatusBadge(healthQuery.data?.status || overallStatus)}
              <p className="text-sm text-gray-600 mt-2">
                {health.length} components monitored
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Component Health Grid */}
      {healthQuery.isLoading ? (
        <Card>
          <CardContent className="py-8">
            <div className="text-center text-gray-500">Loading health checks...</div>
          </CardContent>
        </Card>
      ) : health.length === 0 ? (
        <Card>
          <CardContent className="py-8">
            <div className="text-center text-gray-500">No health components available yet. Please refresh.</div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {health.map((component) => (
          <Card key={component.component}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  {getStatusIcon(component.status)}
                  {component.component}
                </CardTitle>
                {getStatusBadge(component.status)}
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              <div>
                <p className="text-xs text-gray-600">Last Check</p>
                <p className="text-sm font-mono">
                  {new Date(Number(component.lastCheck) || Date.now()).toLocaleTimeString()}
                </p>
              </div>
              {component.responseTimeMs !== undefined && (
                <div>
                  <p className="text-xs text-gray-600">Response Time</p>
                  <p className="text-sm font-mono">{component.responseTimeMs}ms</p>
                </div>
              )}
              {component.error && (
                <div>
                  <p className="text-xs text-gray-600">Status</p>
                  <p className="text-sm text-yellow-600 font-mono truncate" title={component.error}>
                    {component.error}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
        </div>
      )}

      {/* Performance Metrics - only when logged in / data available */}
      {!performanceQuery.isLoading && performanceQuery.error && (
        <Card>
          <CardContent className="py-6">
            <p className="text-center text-gray-500 text-sm">
              Sign in to view trading performance metrics.
            </p>
          </CardContent>
        </Card>
      )}
      {performance && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Trading Statistics */}
          <Card>
            <CardHeader>
              <CardTitle>Trading Statistics</CardTitle>
              <CardDescription>Overall performance metrics</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Total Trades</p>
                  <p className="text-2xl font-bold">{performance.totalTrades}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Win Rate</p>
                  <p className="text-2xl font-bold">{performance.winRate.toFixed(1)}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Risk Metrics */}
          <Card>
            <CardHeader>
              <CardTitle>Risk Metrics</CardTitle>
              <CardDescription>Risk and return analysis</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-600">Profit Factor</p>
                  <p className="text-2xl font-bold">{performance.profitFactor.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Total P&L</p>
                  <p
                    className={`text-lg font-semibold ${
                      performance.totalPnL >= 0 ? 'text-green-600' : 'text-red-600'
                    }`}
                  >
                    ${performance.totalPnL.toFixed(2)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
