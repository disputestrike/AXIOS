/**
 * Regime transition stress — regime flip detection, findRegimeFlips.
 * Run: pnpm test -- --grep "regime.*flip"
 */
import { describe, it, expect } from "vitest";
import { findRegimeFlips, stressTestRegimeTransitions, type RegimeFlip } from "./regime-transition-stress";

describe("regime flip — detection", () => {
  it("regime flip: findRegimeFlips returns array", () => {
    const history = [
      { date: new Date("2024-01-01"), regime: "bull_vol_compression" },
      { date: new Date("2024-01-02"), regime: "bull_vol_compression" },
      { date: new Date("2024-01-03"), regime: "bear_vol_expansion" },
      { date: new Date("2024-01-04"), regime: "bear_vol_expansion" },
    ];
    const flips = findRegimeFlips(history);
    expect(Array.isArray(flips)).toBe(true);
  });

  it("regime flip: findRegimeFlips detects change when regime differs from previous", () => {
    const history = [
      { date: new Date("2024-01-01"), regime: "bull_vol_compression" },
      { date: new Date("2024-01-02"), regime: "bull_vol_compression" },
      { date: new Date("2024-01-03"), regime: "bear_vol_expansion" },
    ];
    const flips = findRegimeFlips(history);
    expect(flips.length).toBeGreaterThanOrEqual(1);
    expect(flips[0]).toHaveProperty("date");
    expect(flips[0]).toHaveProperty("fromRegime");
    expect(flips[0]).toHaveProperty("toRegime");
  });

  it("regime flip: findRegimeFlips returns empty when no changes", () => {
    const history = [
      { date: new Date("2024-01-01"), regime: "bull_vol_compression" },
      { date: new Date("2024-01-02"), regime: "bull_vol_compression" },
    ];
    const flips = findRegimeFlips(history);
    expect(flips.length).toBe(0);
  });

  it("regime flip: findRegimeFlips handles empty history", () => {
    const flips = findRegimeFlips([]);
    expect(flips).toEqual([]);
  });
});

describe("regime flip — stress test", () => {
  it("regime flip: stressTestRegimeTransitions returns array of stress results", async () => {
    const history = [
      { date: new Date("2024-01-01"), regime: "bull_vol_compression" },
      { date: new Date("2024-01-02"), regime: "bear_vol_expansion" },
    ];
    const flips = findRegimeFlips(history);
    if (flips.length === 0) return;
    const results = await stressTestRegimeTransitions("SPY", flips, 5, 5);
    expect(Array.isArray(results)).toBe(true);
    results.forEach((r) => {
      expect(r).toHaveProperty("flip");
      expect(r).toHaveProperty("preSharpe");
      expect(r).toHaveProperty("postSharpe");
    });
  });
});
