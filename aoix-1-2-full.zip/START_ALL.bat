@echo off
title AOIX-1 - Start All
setlocal

REM === EDIT THESE PATHS IF YOUR FOLDERS ARE ELSEWHERE ===
set "GATEWAY_DIR=C:\Users\benxp\Downloads\clientportal.gw"
set "APP_DIR=C:\Users\benxp\Downloads\aoix-1(2)"

echo.
echo ============================================
echo   Starting Gateway + App
echo ============================================
echo.

REM 1) Start Client Portal Gateway (port 5000)
if not exist "%GATEWAY_DIR%\bin\run.bat" (
    echo ERROR: Gateway not found at: %GATEWAY_DIR%
    echo Edit START_ALL.bat and set GATEWAY_DIR to your clientportal.gw folder.
    goto :open_browser
)
echo [1/3] Starting IBKR Gateway on port 5000...
start "IBKR Gateway 5000" cmd /k "cd /d ""%GATEWAY_DIR%"" && bin\run.bat root\conf.yaml"
echo      Waiting 12 seconds for gateway to start...
timeout /t 12 /nobreak >nul

REM 2) Start AOIX-1 app (port 3000)
echo [2/3] Starting AOIX-1 app on port 3000...
start "AOIX-1 App 3000" cmd /k "cd /d ""%APP_DIR%"" && pnpm dev"
echo      Waiting 15 seconds for app to start...
timeout /t 15 /nobreak >nul

:open_browser
REM 3) Open browser
echo [3/3] Opening browser...
start "" "http://localhost:5000"
timeout /t 2 /nobreak >nul
start "" "http://localhost:3000/auto-trading"

echo.
echo Done. Two CMD windows should be open:
echo   - "IBKR Gateway 5000" = must stay open for http://localhost:5000
echo   - "AOIX-1 App 3000"    = must stay open for http://localhost:3000
echo.
echo If localhost still refuses: wait 30 sec, then refresh the page.
echo.
pause
endlocal
