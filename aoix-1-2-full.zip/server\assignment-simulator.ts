/**
 * Assignment / extreme risk simulation for audit.
 * Monte Carlo: simulate price paths, compute % ITM at expiry (short option assignment proxy).
 * Scenario: extreme gap ±10%, ±20% → max loss.
 */

/** Normal CDF approximation. */
function normCdf(x: number): number {
  const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741, a4 = -1.453152027, a5 = 1.061405429;
  const t = 1 / (1 + 0.2316419 * Math.abs(x));
  const d = 1 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp((-x * x) / 2);
  return x >= 0 ? d : 1 - d;
}

/** Box–Muller: standard normal. */
function randomNormal(): number {
  const u1 = Math.random();
  const u2 = Math.random();
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}

export interface AssignmentSimInput {
  spot: number;
  strike: number;
  /** Annualized vol (decimal, e.g. 0.25). */
  sigma: number;
  /** Days to expiry. */
  dte: number;
  /** Short call vs short put. */
  optionType: "C" | "P";
  /** Max loss per contract if assigned (e.g. spread width * 100 - credit). */
  maxLossPerContract: number;
}

export interface AssignmentSimResult {
  /** Probability of finishing ITM (assignment proxy), 0–1. */
  assignmentProbability: number;
  /** Probability as %. */
  assignmentProbabilityPercent: number;
  /** Paths simulated. */
  paths: number;
}

/**
 * Monte Carlo: simulate price paths (GBM), count % paths where option is ITM at expiry.
 */
export function simulateAssignmentProbability(
  input: AssignmentSimInput,
  paths: number = 2000
): AssignmentSimResult {
  const { spot, strike, sigma, dte, optionType } = input;
  const T = Math.max(0.01, dte / 365);
  const sqrtT = Math.sqrt(T);
  let itmCount = 0;
  for (let i = 0; i < paths; i++) {
    const z = randomNormal();
    const S_T = spot * Math.exp(-0.5 * sigma * sigma * T + sigma * sqrtT * z);
    const itm =
      optionType === "C" ? S_T > strike : S_T < strike;
    if (itm) itmCount++;
  }
  const p = itmCount / paths;
  return {
    assignmentProbability: p,
    assignmentProbabilityPercent: Math.round(p * 1000) / 10,
    paths,
  };
}

export interface ExtremeLossInput {
  spot: number;
  strike: number;
  /** Net credit per contract ($). */
  netCreditPerContract: number;
  /** Spread width in $ (e.g. 5). */
  spreadWidth: number;
  structureType: string;
  optionType: "C" | "P";
}

/**
 * Scenario: underlying gaps by gapPct (e.g. -0.10 = -10%). Return approximate max loss per contract.
 */
export function scenarioExtremeLoss(
  input: ExtremeLossInput,
  gapPct: number
): number {
  const { spot, strike, netCreditPerContract, spreadWidth, structureType, optionType } = input;
  const S_new = spot * (1 + gapPct);
  const s = (structureType || "").toLowerCase();
  const widthDollars = spreadWidth * 100;
  if (s.includes("vertical_put") || s.includes("put_spread")) {
    const intrinsic = Math.max(0, strike - S_new);
    const loss = intrinsic * 100 - netCreditPerContract;
    return Math.round(Math.max(0, loss) * 100) / 100;
  }
  if (s.includes("vertical_call") || s.includes("call_spread")) {
    const intrinsic = Math.max(0, S_new - strike);
    const loss = intrinsic * 100 - netCreditPerContract;
    return Math.round(Math.max(0, loss) * 100) / 100;
  }
  if (s.includes("iron_condor") || s.includes("iron_butterfly")) {
    const maxLoss = widthDollars - netCreditPerContract;
    return Math.round(Math.max(0, maxLoss) * 100) / 100;
  }
  return Math.round((widthDollars - netCreditPerContract) * 100) / 100;
}
