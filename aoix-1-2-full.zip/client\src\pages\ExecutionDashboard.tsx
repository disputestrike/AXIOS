import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { TCADrillDown } from "@/components/TCADrillDown";
import { AlertCircle, CheckCircle, Zap, TrendingUp, TrendingDown, X, Search } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function ExecutionDashboard() {
  const { user } = useAuth();
  const utils = trpc.useUtils();
  
  // Form state
  const [symbol, setSymbol] = useState("SPY");
  const [expiry, setExpiry] = useState("20260129");
  const [strike, setStrike] = useState(450);
  const [quantity, setQuantity] = useState(1);
  const [tcaOrderId, setTcaOrderId] = useState("");
  
  // Omega-0 status
  const statusQuery = trpc.omega0.getStatus.useQuery(undefined, {
    refetchInterval: 2000,
  });

  // Account summary (real IB balance when Gateway connected, else simulated)
  const accountQuery = trpc.omega0.getAccountSummary.useQuery(undefined, {
    refetchInterval: 10_000, // IB rate limit ~1/5s for ledger; 10s is safe
  });

  // Performance metrics
  const metricsQuery = trpc.omega0.getPerformanceMetrics.useQuery(undefined, {
    refetchInterval: 3000,
  });
  
  // Open trades
  const openTradesQuery = trpc.omega0.getOpenTrades.useQuery(undefined, {
    refetchInterval: 3000,
  });
  
  // Closed trades
  const closedTradesQuery = trpc.omega0.getClosedTrades.useQuery({ limit: 10 }, {
    refetchInterval: 5000,
  });

  // Last order summary — exactly what was traded (for trade log)
  const lastOrderQuery = trpc.omega0.getLastOrderSummary.useQuery(undefined, {
    refetchInterval: 5000,
  });

  // TCA summary (slippage, implementation shortfall)
  const tcaQuery = trpc.autoTrading.getTCASummary.useQuery(undefined, { refetchInterval: 10_000 });
  const tcaLogQuery = trpc.autoTrading.getTCALog.useQuery({ limit: 50 }, { refetchInterval: 10_000 });

  // Portfolio stress (SPY ±5%, VIX +50%)
  const stressQuery = trpc.omega0.getPortfolioStress.useQuery(undefined, { refetchInterval: 15_000 });

  // Auto-trading engine (so one page shows both manual and auto trades)
  const { data: enginePositions, refetch: refetchEnginePositions } = trpc.autoTrading.getPositions.useQuery(undefined, {
    refetchInterval: 4000,
  });
  const { data: engineTrades } = trpc.autoTrading.getTrades.useQuery({ limit: 20 }, {
    refetchInterval: 5000,
  });
  const closeEnginePositionMutation = trpc.autoTrading.closePosition.useMutation({
    onSuccess: () => {
      toast.success("Engine position closed");
      refetchEnginePositions();
    },
    onError: (e) => toast.error(e.message),
  });
  
  // Place order mutation
  const placeOrderMutation = trpc.omega0.placeOrder.useMutation({
    onSuccess: (data) => {
      toast.success(data.message || `Trade executed: ${data.action} ${data.quantity} ${data.symbol}`);
      utils.omega0.getOpenTrades.invalidate();
      utils.omega0.getPerformanceMetrics.invalidate();
      utils.omega0.getAccountSummary.invalidate();
    },
    onError: (error) => {
      toast.error(`Trade failed: ${error.message}`);
    },
  });
  
  // Close position mutation (single leg)
  const closePositionMutation = trpc.omega0.closePosition.useMutation({
    onSuccess: (data) => {
      toast.success(data.message || `Position closed: P&L $${data.pnl?.toFixed(2)}`);
      utils.omega0.getOpenTrades.invalidate();
      utils.omega0.getClosedTrades.invalidate();
      utils.omega0.getPerformanceMetrics.invalidate();
      utils.omega0.getAccountSummary.invalidate();
    },
    onError: (error) => {
      toast.error(`Close failed: ${error.message}`);
    },
  });

  // Close entire strategy (all legs at once)
  const closeComboMutation = trpc.omega0.closeCombo.useMutation({
    onSuccess: (data) => {
      toast.success(data.message || `Strategy closed — P&L $${data.totalPnL?.toFixed(2)}`);
      utils.omega0.getOpenTrades.invalidate();
      utils.omega0.getClosedTrades.invalidate();
      utils.omega0.getPerformanceMetrics.invalidate();
      utils.omega0.getAccountSummary.invalidate();
    },
    onError: (error) => {
      toast.error(`Close strategy failed: ${error.message}`);
    },
  });
  
  const handleBuyCall = () => {
    placeOrderMutation.mutate({
      symbol,
      expiry,
      strike,
      optionType: "C",
      action: "BUY",
      quantity,
    });
  };
  
  const handleBuyPut = () => {
    placeOrderMutation.mutate({
      symbol,
      expiry,
      strike,
      optionType: "P",
      action: "BUY",
      quantity,
    });
  };
  
  const handleClosePosition = (trade: any) => {
    closePositionMutation.mutate({
      symbol: trade.symbol,
      expiry: trade.expiry,
      strike: trade.strike,
      optionType: trade.optionType,
      quantity: trade.quantity,
    });
  };

  const handleCloseCombo = (comboId: string) => {
    closeComboMutation.mutate({ comboId });
  };

  // Group open trades by comboId for multi-leg strategies (one "Close strategy" per combo)
  const openTrades = openTradesQuery.data ?? [];
  const comboGroups = openTrades.reduce<Record<string, typeof openTrades>>((acc, t: any) => {
    const key = t.comboId ?? t.tradeId;
    if (!acc[key]) acc[key] = [];
    acc[key].push(t);
    return acc;
  }, {});
  const comboEntries = Object.entries(comboGroups);

  const safeNum = (n: unknown, fallback: number): number => {
    const v = typeof n === "number" ? n : Number(n);
    return Number.isFinite(v) ? v : fallback;
  };
  const fmtMoney = (n: unknown, fallback = "—") =>
    Number.isFinite(Number(n)) ? `$${Number(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : fallback;

  /** Format expiry YYYYMMDD as short date (e.g. Jan 17) so calendar/diagonal legs are distinguishable */
  const fmtExpiry = (expiry: string | undefined) => {
    if (!expiry || expiry.length < 8) return "";
    const y = expiry.slice(0, 4);
    const m = expiry.slice(4, 6);
    const d = expiry.slice(6, 8);
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const mi = parseInt(m, 10) - 1;
    return `${monthNames[mi] || m} ${parseInt(d, 10)}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">Execution — All Trades</h1>
          <p className="text-slate-400">
            Manual trades (from Trade Now) and auto-trading engine activity — open positions and recent trades in one place.
          </p>
        </div>

        {/* Connection Status */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {statusQuery.data?.connected ? (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-yellow-500" />
                )}
                IBKR Connection
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-300 mb-4">
                {statusQuery.data?.message || "Connecting..."}
              </p>
              <p className="text-sm text-slate-400">
                Status: <span className={statusQuery.data?.connected ? "text-green-400" : "text-yellow-400"}>
                  {statusQuery.data?.connected ? "Connected" : "Disconnected"}
                </span>
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-blue-500" />
                Account Value
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-white mb-2">
                ${accountQuery.data?.netLiquidation?.toLocaleString() ?? "—"}
              </p>
              <p className="text-sm text-slate-400">
                Buying Power: ${accountQuery.data?.buyingPower?.toLocaleString() ?? "—"}
              </p>
              {accountQuery.data?.source === "ib" && (
                <p className="text-xs text-green-500 mt-1">Live from IB</p>
              )}
              {accountQuery.data?.source === "simulated" && (
                <p className="text-xs text-amber-500 mt-1">Simulated (connect Gateway for real balance)</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Profit & Loss and performance */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-sm">Total P&L</CardTitle>
            </CardHeader>
            <CardContent>
              <p className={`text-3xl font-bold ${safeNum(metricsQuery.data?.totalPnL, 0) >= 0 ? "text-green-400" : "text-red-400"}`}>
                {fmtMoney(metricsQuery.data?.totalPnL)}
              </p>
              <p className="text-xs text-slate-500 mt-1">Realized from closed trades</p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-sm">Total Trades</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-white">
                {safeNum(metricsQuery.data?.totalTrades, 0)}
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-sm">Win Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-green-400">
                {safeNum(metricsQuery.data?.winRate, 0).toFixed(1)}%
              </p>
            </CardContent>
          </Card>

          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-sm">Profit Factor</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-blue-400">
                {safeNum(metricsQuery.data?.profitFactor, 0).toFixed(2)}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* TCA & Stress */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-sm">TCA — Execution Quality</CardTitle>
              <CardDescription>Slippage and implementation shortfall</CardDescription>
            </CardHeader>
            <CardContent>
              {tcaQuery.data ? (
                <div className="space-y-1 text-sm">
                  <p className="text-slate-300">Avg slippage: <span className="text-amber-400">{typeof (tcaQuery.data as { avgSlippagePercent?: number }).avgSlippagePercent === "number" ? `${(tcaQuery.data as { avgSlippagePercent: number }).avgSlippagePercent.toFixed(2)}%` : "—"}</span></p>
                  <p className="text-slate-300">Implementation shortfall: <span className="text-amber-400">{typeof (tcaQuery.data as { implementationShortfallEstimate?: number }).implementationShortfallEstimate === "number" ? `$${(tcaQuery.data as { implementationShortfallEstimate: number }).implementationShortfallEstimate.toFixed(2)}` : "—"}</span></p>
                  <p className="text-slate-400 text-xs mt-2">From last trades</p>
                </div>
              ) : (
                <p className="text-slate-500 text-sm">No TCA data yet — place trades to see slippage</p>
              )}
            </CardContent>
          </Card>
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <CardTitle className="text-sm">Portfolio Stress</CardTitle>
              <CardDescription>SPY ±5%, VIX +50% — scenario P&L impact</CardDescription>
            </CardHeader>
            <CardContent>
              {Array.isArray(stressQuery.data) && stressQuery.data.length > 0 ? (
                <div className="space-y-2 text-sm">
                  {stressQuery.data.map((s: { scenario: string; estimatedPnLImpact: number }) => (
                    <p key={s.scenario} className="text-slate-300 flex justify-between">
                      <span>{s.scenario}</span>
                      <span className={Number(s.estimatedPnLImpact ?? 0) >= 0 ? "text-green-400" : "text-red-400"}>
                        ${(s.estimatedPnLImpact ?? 0).toFixed(0)}
                      </span>
                    </p>
                  ))}
                </div>
              ) : (
                <p className="text-slate-500 text-sm">No open positions — stress shows $0</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* TCA Drill-Down — by order ID */}
        <Card className="bg-slate-800 border-slate-700 mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-sm">
              <Search className="w-5 h-5 text-amber-500" />
              TCA Drill-Down
            </CardTitle>
            <CardDescription>
              View execution quality and slippage per order. Enter an order ID below or click one from recent TCA log.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <label className="text-slate-400 text-sm">Order ID</label>
              <input
                type="text"
                value={tcaOrderId}
                onChange={(e) => setTcaOrderId(e.target.value.trim())}
                placeholder="e.g. combo_abc123 or trade id"
                className="bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white font-mono text-sm w-48"
              />
            </div>
            {Array.isArray(tcaLogQuery.data) && tcaLogQuery.data.length > 0 && (
              <div>
                <p className="text-xs text-slate-400 mb-2">Recent TCA (click order ID to drill down)</p>
                <div className="flex flex-wrap gap-2">
                  {Array.from(new Set((tcaLogQuery.data as { orderId?: string }[]).map((e) => e.orderId).filter(Boolean))).slice(0, 10).map((oid) => (
                    <button
                      key={oid}
                      type="button"
                      onClick={() => setTcaOrderId(oid ?? "")}
                      className="px-2 py-1 rounded bg-slate-700 hover:bg-slate-600 text-slate-300 text-xs font-mono"
                    >
                      {oid}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {tcaOrderId && <TCADrillDown orderId={tcaOrderId} />}
          </CardContent>
        </Card>

        {/* Execution Controls */}
        <Card className="bg-slate-800 border-slate-700 mb-8">
          <CardHeader>
            <CardTitle>Execution Controls</CardTitle>
            <CardDescription>Manual trade entry and management</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <label className="text-sm text-slate-400 block mb-2">Symbol</label>
                  <input
                    type="text"
                    value={symbol}
                    onChange={(e) => setSymbol(e.target.value.toUpperCase())}
                    className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-400 block mb-2">Expiry</label>
                  <input
                    type="text"
                    value={expiry}
                    onChange={(e) => setExpiry(e.target.value)}
                    className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-400 block mb-2">Strike</label>
                  <input
                    type="number"
                    value={strike}
                    onChange={(e) => setStrike(Number(e.target.value))}
                    className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-sm text-slate-400 block mb-2">Contracts (1 = 100 shares)</label>
                  <input
                    type="number"
                    min={1}
                    max={100}
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, Math.min(100, Number(e.target.value) || 1)))}
                    className="w-full bg-slate-700 border border-slate-600 rounded px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div className="flex gap-4">
                <Button 
                  className="bg-green-600 hover:bg-green-700 flex-1"
                  onClick={handleBuyCall}
                  disabled={placeOrderMutation.isPending}
                >
                  <TrendingUp className="w-4 h-4 mr-2" />
                  {placeOrderMutation.isPending ? "Executing..." : "Buy Call"}
                </Button>
                <Button 
                  className="bg-red-600 hover:bg-red-700 flex-1"
                  onClick={handleBuyPut}
                  disabled={placeOrderMutation.isPending}
                >
                  <TrendingDown className="w-4 h-4 mr-2" />
                  {placeOrderMutation.isPending ? "Executing..." : "Buy Put"}
                </Button>
              </div>

              <p className="text-xs text-green-500">
                ✓ Paper trading mode - simulated execution enabled
              </p>
            </div>
          </CardContent>
        </Card>
        
        {/* Trade log — exactly what was traded last */}
        {lastOrderQuery.data && (
          <Card className="bg-slate-800 border-slate-700 mb-6 border-green-500/30">
            <CardHeader>
              <CardTitle className="text-green-400">Trade log — last trade</CardTitle>
              <CardDescription>
                Exactly what was traded when you clicked Trade Now
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex flex-wrap items-center gap-2 text-sm">
                <span className="font-bold text-white">{lastOrderQuery.data.symbol}</span>
                <span className="text-slate-400">
                  {lastOrderQuery.data.structureType.replace(/_/g, " ")} ({lastOrderQuery.data.legsCount} leg{lastOrderQuery.data.legsCount !== 1 ? "s" : ""})
                </span>
                <span className="text-slate-500">
                  {new Date(lastOrderQuery.data.filledTime).toLocaleString()}
                </span>
              </div>
              <div className="bg-slate-900 rounded p-3 font-mono text-sm space-y-1">
                {lastOrderQuery.data.legsDetail.map((leg: { strike: number; optionType: string; action: string; fillPrice: number; quantity: number }, i: number) => (
                  <div key={i} className="flex justify-between text-slate-300">
                    <span>{leg.action} {leg.strike}{leg.optionType}</span>
                    <span>@ ${Number(leg.fillPrice).toFixed(2)} × {leg.quantity}</span>
                  </div>
                ))}
              </div>
              {Number.isFinite((lastOrderQuery.data as { totalCost?: number }).totalCost) && (
                <p className="text-green-400 font-medium text-sm">
                  Total cost: ${((lastOrderQuery.data as { totalCost: number }).totalCost).toFixed(2)} USD
                </p>
              )}
              <p className="text-slate-400 text-sm">{lastOrderQuery.data.message}</p>
            </CardContent>
          </Card>
        )}

        {/* Open Positions - always visible so you see where Trade Now goes */}
        <Card className="bg-slate-800 border-slate-700 mb-8">
          <CardHeader>
            <CardTitle>Open Positions (manual trades)</CardTitle>
            <CardDescription>
              Trades from &quot;Trade Now&quot; on Market Opportunities appear here. Place orders below or close positions.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {comboEntries.length > 0 ? (
              <div className="space-y-3">
                {comboEntries.map(([key, trades]: [string, any[]]) => {
                  const isCombo = trades[0]?.comboId && trades.length > 1;
                  const structureLabel = (trades[0]?.structureType ?? "").replace(/_/g, " ");
                  const totalPnL = trades.reduce((sum, t) => sum + (Number(t.unrealizedPnL) || 0), 0);
                  const pnlOk = Number.isFinite(totalPnL);
                  const costAtEntry = trades.reduce(
                    (sum, t) => sum + (t.action === "BUY" ? 1 : -1) * (Number(t.entryPrice) || 0) * (Number(t.quantity) || 0) * 100,
                    0
                  );
                  const costOk = Number.isFinite(costAtEntry) && costAtEntry !== 0;
                  const costLabel = costOk ? (costAtEntry >= 0 ? `Cost: $${costAtEntry.toFixed(2)}` : `Credit: $${Math.abs(costAtEntry).toFixed(2)}`) : null;

                  return (
                    <div key={key} className="bg-slate-700 rounded p-3 space-y-2">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-white">{trades[0].symbol}</span>
                          {isCombo && (
                            <span className="text-green-400 font-medium">
                              {structureLabel} ({trades.length} legs)
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-4">
                          {costLabel && (
                            <span className="text-slate-300 text-sm">{costLabel}</span>
                          )}
                          <span className={pnlOk && totalPnL >= 0 ? "text-green-400 font-medium" : pnlOk && totalPnL < 0 ? "text-red-400 font-medium" : "text-slate-400"}>
                            Total: ${pnlOk ? totalPnL.toFixed(2) : "0.00"}
                          </span>
                          {isCombo ? (
                            <Button
                              size="sm"
                              className="bg-green-600 hover:bg-green-700"
                              onClick={() => handleCloseCombo(trades[0].comboId)}
                              disabled={closeComboMutation.isPending}
                              aria-label="Close entire multi-leg strategy"
                            >
                              <X className="w-4 h-4 mr-1" />
                              Close strategy
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleClosePosition(trades[0])}
                              disabled={closePositionMutation.isPending}
                              aria-label="Close single position"
                            >
                              <X className="w-4 h-4" />
                              Close
                            </Button>
                          )}
                        </div>
                      </div>
                      <div className="text-slate-400 text-sm space-y-0.5">
                        {trades.map((trade: any) => {
                          const entryOk = Number.isFinite(Number(trade.entryPrice)) && Number(trade.entryPrice) > 0;
                          const actionLabel = trade.action === "SELL" ? "SELL " : trade.action === "BUY" ? "BUY " : "";
                          const expiryLabel = trade.expiry ? ` ${fmtExpiry(trade.expiry)}` : "";
                          return (
                            <div key={trade.tradeId}>
                              {actionLabel}{trade.strike}{trade.optionType}{expiryLabel} × {trade.quantity}
                              {entryOk ? ` @ $${Number(trade.entryPrice).toFixed(2)}` : ""}
                              {Number.isFinite(trade.unrealizedPnL) ? ` — $${Number(trade.unrealizedPnL).toFixed(2)}` : ""}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-slate-400 border border-dashed border-slate-600 rounded-lg">
                <p className="font-medium">No open positions</p>
                <p className="text-sm mt-1">Click &quot;Trade Now&quot; on Market Opportunities to add a trade. It will appear here.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Trade History - manual (Omega-0) closed trades */}
        <Card className="bg-slate-800 border-slate-700 mb-8">
          <CardHeader>
            <CardTitle>Recent Trades (manual)</CardTitle>
            <CardDescription>Last 10 closed positions from manual / Trade Now</CardDescription>
          </CardHeader>
          <CardContent>
            {closedTradesQuery.data && closedTradesQuery.data.length > 0 ? (
              <div className="space-y-2">
                {closedTradesQuery.data.map((trade: any) => {
                  const qty = Number(trade.quantity) || 1;
                  const entryOk = Number.isFinite(Number(trade.entryPrice)) && Number(trade.entryPrice) > 0;
                  const exitOk = Number.isFinite(Number(trade.exitPrice));
                  const pnlOk = Number.isFinite(Number(trade.pnl));
                  return (
                  <div key={trade.tradeId} className="flex items-center justify-between bg-slate-700 rounded p-3">
                    <div>
                      <span className="font-bold text-white">{trade.symbol}</span>
                      <span className="text-slate-400 ml-2">
                        {trade.strike}{trade.optionType} × {qty} contract{qty !== 1 ? "s" : ""}
                      </span>
                      <span className="text-slate-500 ml-2">
                        {entryOk ? `$${Number(trade.entryPrice).toFixed(2)}` : "—"} → {exitOk ? `$${Number(trade.exitPrice).toFixed(2)}` : "—"}
                      </span>
                    </div>
                    <div className={pnlOk && trade.pnl >= 0 ? "text-green-400 font-bold" : pnlOk && trade.pnl < 0 ? "text-red-400 font-bold" : "text-slate-400"}>
                      {pnlOk ? (trade.pnl >= 0 ? "+" : "") + fmtMoney(trade.pnl) : "—"}
                    </div>
                  </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-slate-400 border border-dashed border-slate-600 rounded-lg">
                <p>No closed trades yet. Close a position above to see it here.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Auto-trading engine - positions and recent trades in one place */}
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-500" />
              Auto-trading engine
            </CardTitle>
            <CardDescription>
              Autonomous engine positions and recent trades. Start the engine on the Auto Trading page.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Engine open positions */}
            <div>
              <h4 className="text-sm font-medium text-slate-300 mb-2">Engine open positions</h4>
              {enginePositions && enginePositions.length > 0 ? (
                <div className="space-y-2">
                  {enginePositions.map((pos: any, idx: number) => (
                    <div key={pos.id || idx} className="flex items-center justify-between bg-slate-700 rounded p-3">
                      <div>
                        <span className="font-bold text-white">{pos.symbol}</span>
                        <span className="text-slate-400 ml-2">
                          {pos.strike} {pos.optionType} × {pos.quantity} contract{pos.quantity !== 1 ? "s" : ""}
                        </span>
                        <span className="text-slate-500 ml-2">@ {Number.isFinite(Number(pos.entryPrice)) ? `$${Number(pos.entryPrice).toFixed(2)}` : "—"}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className={Number(pos.unrealizedPnL) >= 0 ? "text-green-400" : "text-red-400"}>
                          {Number.isFinite(Number(pos.unrealizedPnL)) ? `$${Number(pos.unrealizedPnL).toFixed(2)}` : "—"} unrealized
                        </span>
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-red-400 hover:text-red-300"
                          disabled={closeEnginePositionMutation.isPending}
                          onClick={() => closeEnginePositionMutation.mutate({ positionId: pos.id })}
                        >
                          <X className="w-4 h-4 mr-1" />
                          Close
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-4 text-slate-500 text-sm border border-dashed border-slate-600 rounded-lg">
                  No engine positions. Start the engine on Auto Trading to see autonomous trades here.
                </div>
              )}
            </div>
            {/* Engine recent trades */}
            <div>
              <h4 className="text-sm font-medium text-slate-300 mb-2">Engine recent trades</h4>
              {engineTrades && engineTrades.length > 0 ? (
                <div className="space-y-2">
                  {engineTrades.slice(0, 10).map((t: any, idx: number) => (
                    <div key={t.id || idx} className="flex items-center justify-between bg-slate-700 rounded p-2 text-sm">
                      <div>
                        <span className="font-medium text-white">{t.symbol}</span>
                        <span className="text-slate-400 ml-2">{t.action}</span>
                        <span className="text-slate-500 ml-2">{new Date(t.timestamp).toLocaleTimeString()}</span>
                      </div>
                      <span className="text-slate-400">{t.reason}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-4 text-slate-500 text-sm border border-dashed border-slate-600 rounded-lg">
                  No engine trades yet. Start the engine on Auto Trading.
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
