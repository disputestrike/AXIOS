# AOIX-1 Runbook — Operations & Troubleshooting

Quick reference for running, deploying, and troubleshooting AOIX-1.

---

## 1. Startup

| Command | Purpose |
|--------|---------|
| `pnpm dev` | Start server + client (Vite dev). Auto-opens browser; auto-starts trading engine in dev. |
| `pnpm start` | Production: serve built client + API from `dist/`. |
| `pnpm build` | Build client (Vite) + server bundle (esbuild) to `dist/`. |

**Env:** `.env` and `.env.local` (override). Key vars: `PORT`, `NODE_ENV`, `JWT_SECRET`, `BACKTEST_DAYS`, `BACKTEST_MAX_POSITIONS`, `E2E_SERVER_URL` (E2E), `MAX_SLIPPAGE_PERCENT` (pre-flight reject, default 1.5), `MAX_ORDER_COST_USD` (default 50k), `MAX_DRAWDOWN_PERCENT` (auto-stop, default 15), `WALKFORWARD_SYMBOL` / `WALKFORWARD_WINDOWS` (5-window WF), `OPTIONS_FLOW_API_URL` (optional flow API; see `docs/FLOW_API_SETUP.md`).

---

## 2. Health & Readiness

- **HTTP:** `GET /api/health`  
  Returns: `ok`, `status`, `readyForTrade`, `timestamp`, `components` (count).  
  Use for load balancers and E2E. Returns 503 if system.health throws.

- **HTTP:** `GET /api/health/flow-api`  
  Returns: `connected`, `lastUpdate`, `alertsCount`, `status`. Options flow cache health.

- **HTTP:** `GET /api/health/iv-surface`  
  Returns: `lastCalibration`, `avgRsquared`, `status`. IV surface calibration health.

- **tRPC:** `system.health`  
  Full payload: `ok`, `status`, `readyForTrade`, `components[]`, `timestamp`.  
  Use from UI (System Health page) or internal callers.

**readyForTrade** is `true` only when overall status is `healthy` and all critical components (API Server, Market Data, Market Scanner, Database) are not `error`.

---

## 3. Backtest

| Command | Purpose |
|--------|---------|
| `pnpm backtest` | Full backtest (default 252 days, max 5 positions; override with `BACKTEST_DAYS`, `BACKTEST_MAX_POSITIONS`). |
| `pnpm backtest:optimal` | Grid-search optimizer over params. |
| `pnpm backtest:5window` | 5-window walk-forward; writes `backtest-results/5window-walkforward.json` (collapse ratio, robustness). |
| `pnpm backtest:stress-regime` | Regime transition stress (findRegimeFlips, pre/post Sharpe, recovery). |
| `pnpm backtest:stress-corr` | Correlation stress (identifyHighCorrelationPeriods, high-corr periods). |

Output: Sharpe, win rate, P&L, walk-forward summary; 5-window adds mean train/test Sharpe, avg collapse ratio, robustness (excellent/good/fair/poor).

---

## 4. Tests

| Command | Purpose |
|--------|---------|
| `pnpm test` | Run Vitest (unit + integration). |
| `E2E_SERVER_URL=http://localhost:3000 pnpm test` | Run E2E (health + full flow: login → scan → omega0.getStatus). Start server first (`pnpm dev`). |

---

## 5. Database

| Command | Purpose |
|--------|---------|
| `pnpm db:push` | Push schema (Drizzle). |
| `pnpm db:migrate` | Run migrations. |
| `pnpm db:generate` | Generate migrations. |

---

## 6. Deployment Checklist

1. Set `NODE_ENV=production`, `JWT_SECRET`, and any DB/IBKR env.
2. Run `pnpm build`.
3. Start with `pnpm start` (or `node dist/index.js`).
4. Verify `GET /api/health` returns `ok: true` and `readyForTrade` as expected.
5. Optional: run `node scripts/deploy-check.js` for a quick checklist.

---

## 7. Troubleshooting

| Symptom | Check |
|--------|--------|
| Health returns 503 | Logs for `[Health] system.health failed`. Fix failing component (DB, market data, scanner). |
| readyForTrade false | System Health page: which component is `error`. Often TWS/IBKR or Market Data. |
| Scan returns 0 opportunities | Yahoo rate limit, network, or symbol list. Check Market Data (Yahoo) component in health. |
| Paper order not filling | Paper fill logic in `omega0.placeOrder`; LMT uses `limitPrice`. Check order type and price. |
| E2E login/scan fails | Ensure server is up at `E2E_SERVER_URL`; tRPC paths: `auth.login` (POST), `marketScanner.scan` (GET). |

---

## 8. New Endpoints (Upgrade Plan)

- **regime.getRegimeHeatmap** — Live regime per symbol (color, recommendation, score).
- **signals.getActiveWithBreakdown** — Final score + breakdown (signal/regime/opportunity) + top 3 drivers.
- **omega0.getTCADrillDown** — TCA drill-down by orderId (entries, total slippage, execution quality).
- **autoTrading.getDrawdownMetrics** — Intra-month drawdown %, status (ok/warning/critical), time to reset.
- **autoTrading.getPortfolioGreeks** — Last aggregated delta/gamma/vega/theta (updated on getPortfolioRisk).
- **autoTrading.getGreeksImbalance** — Threshold breaches (delta/gamma/vega); optional thresholds.
- **Pre-flight validation:** `placeOrder` rejects if estimated slippage > `MAX_SLIPPAGE_PERCENT` or cost > `MAX_ORDER_COST_USD`; response includes `estimatedCost`, `estimatedSlippagePercent`.

**Upgrade roadmap status:** See **docs/UPGRADE_ROADMAP_STATUS.md** for roadmap vs codebase. **Rating: 9.5/10** (institutional-ready); see **docs/CODE_CHECK_AND_RATING.md**.

## 9. Key Files

- **Server entry:** `server/_core/index.ts`
- **Health logic:** `server/_core/systemRouter.ts` → `system.health`
- **Scanner:** `server/market-scanner.ts`; API: `marketScanner.scan`, `marketScanner.getTopOpportunities`, `marketScanner.getBestOne`
- **Execution:** `server/routers/omega0.ts` (placeOrder, getPortfolioRisk, getStatus, getTCADrillDown)
- **Drawdown:** `server/drawdown-limiter.ts`; synced from omega0 getStatus/close; `autoTrading.getDrawdownMetrics`
- **Backtest:** `server/backtest-runner.ts` (runWalkForward, runMultiWindowWalkForward); script: `scripts/run-5window-walkforward.ts`
- **Full system doc:** `docs/AOIX1_OPERATING_SYSTEM.md`
