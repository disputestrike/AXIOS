import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function ShadowSystem() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Shadow System</h1>
        <p className="text-slate-400 mt-2">Monte Carlo ruin simulations and existential threats</p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Latest Simulation</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <p><strong>Scenario:</strong> 3-day 10% drop + 50% IV spike</p>
            <p><strong>Max Drawdown:</strong> 4.2%</p>
            <p><strong>Probability of Ruin:</strong> 8%</p>
            <p><strong>Threat Level:</strong> Low</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
