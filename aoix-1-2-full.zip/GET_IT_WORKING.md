# Get the app working

**If nothing works (Connect always fails, 429, cookie not set):** Run **`pnpm run check:gateway`** in the project folder. It prints exactly what’s wrong and what to do. See **IF_NOTHING_WORKS.md**.

---

## 1. Start the app (see it in the browser)

1. Open a terminal in this folder (where `package.json` is).
2. Run:
   ```bash
   pnpm dev
   ```
   Wait until you see: **Server running: http://localhost:3000/**
3. In your browser go to: **http://localhost:3000**

You should see the app. If you get "Unable to connect", the server isn’t running — run `pnpm dev` again and leave that terminal open.

---

## 2. Why you see 0 opportunities / "nothing working"

The app is **IBKR-only**: all market data comes from Interactive Brokers. If the IB Gateway isn’t running or not logged in, you get **no data** and **0 opportunities**.

To get real data and opportunities:

**Two common issues:** (1) **429 rate limit** — wait 1–2 minutes without clicking, then click Connect once. (2) **Cookie not set** — get the `api` cookie (see below), add to `.env.local`, restart app, wait 1–2 min, then Connect. Full steps: **IB_GATEWAY_SETUP.md** → "Two common issues when Connect fails".

1. **Start IB Client Portal Gateway** (from Interactive Brokers).
2. In your browser open **http://localhost:5000** and log in (same port the Gateway uses, not 3000).  
   **If the login page says "Authentication failed"** — that’s your IB username, password, or 2FA. See **IB_GATEWAY_SETUP.md** → "Login page shows Authentication failed".
3. After login, copy the **`api`** cookie: F12 → Application → Cookies → `localhost:5000` → copy the **api** value; or if Gateway has **Settings → API**, copy the `api=` value from there.
4. In this folder, create or edit **`.env.local`** and add:
   ```bash
   TWS_PORT=5000
   IB_GATEWAY_COOKIE=api=PASTE_THE_VALUE_HERE
   ```
5. **Restart the app**: stop `pnpm dev` (Ctrl+C), then run `pnpm dev` again.
6. In the app, open **Market Opportunities** (or Recommendations) and click **Test SPY**.
   - If it shows **SPY = $XXX**, Gateway is working; run a scan to see opportunities.
   - If it shows **SPY failed**, check the server console for the exact error (cookie, port, etc.).

More detail: **IB_GATEWAY_SETUP.md**

---

## 3. Optional: run without IB (no real data)

If you only want the UI to load and don’t need real market data yet, you can use the app as-is: the server runs, you can open http://localhost:3000 and navigate. Market scans and opportunities will stay at 0 until IB Gateway is connected as above.
