/**
 * Realized volatility from historical daily returns (IV exit proxy for audit).
 * IB only: use IB historical data; no third-party data source.
 */

/** Annualized realized vol (decimal, e.g. 0.25 = 25%) from daily returns. */
export function annualizedRealizedVol(dailyReturns: number[]): number {
  if (dailyReturns.length < 2) return 0;
  const mean = dailyReturns.reduce((a, b) => a + b, 0) / dailyReturns.length;
  const variance = dailyReturns.reduce((s, r) => s + (r - mean) ** 2, 0) / (dailyReturns.length - 1);
  const dailyVol = Math.sqrt(variance);
  return dailyVol * Math.sqrt(252);
}

/**
 * Fetch historical closes and compute realized vol. IB only: use IB historical API.
 */
export async function getRealizedVol(
  _symbol: string,
  _startDate: Date,
  _endDate: Date
): Promise<number> {
  throw new Error("Realized vol requires IB historical data");
}

