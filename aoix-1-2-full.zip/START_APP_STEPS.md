# How to Start the App and Make It Work

## Step 1: Open a terminal in the project folder

- In VS Code / Cursor: **Terminal → New Terminal** (or `` Ctrl+` ``).
- Or open PowerShell / Command Prompt and go to the folder that contains `package.json`:
  ```bash
  cd "c:\Users\benxp\Downloads\aoix-1(2)"
  ```

---

## Step 2: Install dependencies (first time only)

```bash
pnpm install
```

*(If you don’t have pnpm: `npm install -g pnpm` then run `pnpm install` again.)*

---

## Step 3: Create `.env.local` (first time only)

1. Copy the example file:
   ```bash
   copy .env.local.example .env.local
   ```
   *(On Mac/Linux: `cp .env.local.example .env.local`)*

2. Open `.env.local` and set at least:
   - **JWT_SECRET** – any long random string (e.g. run `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` and paste the result).
   - **TWS_PORT=5000** – port for IB Client Portal Gateway.

   Leave **DATABASE_URL** commented out if you’re not using MySQL (app will run with in-memory auth).

---

## Step 4: Start the app

```bash
pnpm dev
```

Wait until you see something like:

```text
>>> Server running: http://localhost:3000/
>>> If the browser did not open, go to: http://localhost:3000/
```

*(If you see “Port 3000 is busy, using port 3001 instead”, use **http://localhost:3001** in the next step.)*

---

## Step 5: Open the app in your browser

- Go to: **http://localhost:3000**
- If the server said it’s on 3001, use: **http://localhost:3001**

You should see the app (login/dashboard). **Leave the terminal open** while you use the app; closing it stops the server.

---

## Step 6: Get market data and opportunities (IB Gateway)

The app is **IB only** – no market data without Interactive Brokers.

1. **Start IB Client Portal Gateway**
   - From Interactive Brokers: run the Client Portal Gateway app (not TWS).
   - Leave it running.

2. **Log in to the Gateway in your browser**
   - Open: **http://localhost:5000**
   - Log in with your IB credentials (and 2FA if required).
   - Wait until the Client Portal page loads fully.

3. **Set the cookie so the app can use the Gateway**
   - With **http://localhost:5000** open, press **F12** → **Application** (or **Storage**) → **Cookies** → **http://localhost:5000**.
   - Find the cookie named **`api`** and copy its **Value**.
   - Open `.env.local` and add (use your actual value):
     ```bash
     IB_GATEWAY_COOKIE=api=PASTE_THE_VALUE_HERE
     ```
   - Save the file, then **stop the app** (Ctrl+C in the terminal) and run **`pnpm dev`** again.

4. **Check that market data works**
   - In the app, go to **Market Opportunities** (or **Recommendations**).
   - Click **“Test SPY”**.
   - If you see **“SPY = $XXX”**, the Gateway connection works.
   - Click **“Scan”** (or wait for auto-scan) to load opportunities.

---

## Troubleshooting

| Problem | What to do |
|--------|------------|
| **“Unable to connect” / “Connection refused”** | The server isn’t running. Run `pnpm dev` in the project folder and use the URL it prints (e.g. http://localhost:3000 or 3001). |
| **0 opportunities / empty data** | Start IB Client Portal Gateway, log in at http://localhost:5000, set `IB_GATEWAY_COOKIE` in `.env.local`, restart the app (`Ctrl+C` then `pnpm dev`). |
| **“Test SPY” fails** | Gateway not running or cookie wrong/expired. Log in again at http://localhost:5000, copy the `api` cookie again, update `.env.local`, restart. |
| **"Authentication failed" on Gateway login** | That's IB rejecting your username, password, or 2FA. See **IB_GATEWAY_SETUP.md** → "Login page shows Authentication failed". |
| **Port 3000 in use** | The app will use 3001 (or another port). Use the URL shown in the terminal (e.g. http://localhost:3001). |

More detail: **IB_GATEWAY_SETUP.md** and **GET_IT_WORKING.md**.
