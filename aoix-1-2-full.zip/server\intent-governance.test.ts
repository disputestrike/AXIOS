/**
 * Intent governance: full organism — all regimes can trade all strategy classes; intent picks the best.
 */
import { describe, it, expect } from "vitest";
import {
  ALL_STRATEGY_CLASSES,
  STRATEGY_COMPATIBILITY,
  filterStrategies,
  normalizeRegimeToCanonical,
  getStructuresForClass,
  type Regime,
  type IntentDecision,
} from "./intent-governance";

const ALL_REGIMES: Regime[] = [
  "BULL_VOL_COMP",
  "BEAR_VOL_COMP",
  "TRENDING_BULL",
  "TRENDING_BEAR",
  "MEAN_REVERTING",
  "CHAOTIC",
  "CRISIS",
  "LIQUIDITY_DROUGHT",
  "SECTOR_ROTATION",
];

describe("intent-governance: full universe, no regime blocking", () => {
  it("every regime allows all strategy classes", () => {
    for (const regime of ALL_REGIMES) {
      const allowed = STRATEGY_COMPATIBILITY[regime];
      expect(allowed).toBeDefined();
      expect(allowed).toEqual(ALL_STRATEGY_CLASSES);
      expect(allowed!.length).toBe(ALL_STRATEGY_CLASSES.length);
    }
  });

  it("filterStrategies with full intent returns all classes for any regime", () => {
    const fullIntent: IntentDecision = {
      direction: "BULLISH",
      volatilityBias: "NEUTRAL",
      allowedClasses: [...ALL_STRATEGY_CLASSES],
      forbiddenClasses: [],
      confidence: 0.8,
      rationale: "Test full universe.",
    };
    for (const regime of ALL_REGIMES) {
      const filtered = filterStrategies(fullIntent, regime);
      expect(filtered).toEqual(ALL_STRATEGY_CLASSES);
    }
  });

  it("filterStrategies respects intent forbiddenClasses", () => {
    const intent: IntentDecision = {
      direction: "NEUTRAL",
      volatilityBias: "SELL",
      allowedClasses: [...ALL_STRATEGY_CLASSES],
      forbiddenClasses: ["VOLATILITY"],
      confidence: 0.7,
      rationale: "No vol structures.",
    };
    const filtered = filterStrategies(intent, "BULL_VOL_COMP");
    expect(filtered).not.toContain("VOLATILITY");
    expect(filtered.length).toBe(ALL_STRATEGY_CLASSES.length - 1);
  });

  it("filterStrategies respects intent allowedClasses subset", () => {
    const intent: IntentDecision = {
      direction: "BULLISH",
      volatilityBias: "SELL",
      allowedClasses: ["DIRECTIONAL_DEFINED_RISK", "NEUTRAL_RANGE"],
      forbiddenClasses: [],
      confidence: 0.8,
      rationale: "Directional or neutral only.",
    };
    const filtered = filterStrategies(intent, "BEAR_VOL_COMP");
    expect(filtered).toContain("DIRECTIONAL_DEFINED_RISK");
    expect(filtered).toContain("NEUTRAL_RANGE");
    expect(filtered.length).toBe(2);
  });

  it("getStructuresForClass returns structure ids for each class", () => {
    const directional = getStructuresForClass("DIRECTIONAL_DEFINED_RISK");
    expect(directional).toContain("vertical_call_spread");
    expect(directional).toContain("vertical_put_spread");
    const neutral = getStructuresForClass("NEUTRAL_RANGE");
    expect(neutral).toContain("iron_condor");
    expect(neutral).toContain("calendar_spread");
  });

  it("normalizeRegimeToCanonical maps scanner regimes to canonical", () => {
    expect(normalizeRegimeToCanonical("bull_vol_compression")).toBe("BULL_VOL_COMP");
    expect(normalizeRegimeToCanonical("bear_vol_compression")).toBe("BEAR_VOL_COMP");
    expect(normalizeRegimeToCanonical("mean_reverting")).toBe("MEAN_REVERTING");
    expect(normalizeRegimeToCanonical("chaotic")).toBe("CHAOTIC");
  });
});
