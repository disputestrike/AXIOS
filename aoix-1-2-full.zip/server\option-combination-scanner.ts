/**
 * Option Combination Scanner — IBKR only. Score strike/expiry/type combinations from IB option chain.
 */

export interface OptionContract {
  symbol: string;
  strike: number;
  expiry: string; // YYYYMMDD
  type: "C" | "P";
  bid: number;
  ask: number;
  mid: number;
  iv?: number;
  volume?: number;
  openInterest?: number;
  delta?: number;
}

export interface ScoredOption {
  contract: OptionContract;
  /** Composite score 0–100 (higher = better for the given direction) */
  score: number;
  /** Profitability proxy: e.g. credit for selling, or expected value from IV */
  edgeProxy: number;
  liquidityScore: number;
  ivScore: number;
}

export interface BestOptionsResult {
  /** Top N single-leg options by score */
  topCalls: ScoredOption[];
  topPuts: ScoredOption[];
  /** Best single contract overall for direction */
  bestCall: ScoredOption | null;
  bestPut: ScoredOption | null;
  totalCombinationsScored: number;
  source: "ibkr";
}

/**
 * Score a single option for a given direction.
 * Edge proxy: for selling premium we want high IV; for buying we want low IV / good delta.
 */
function scoreOption(
  contract: OptionContract,
  currentPrice: number,
  direction: "bullish" | "bearish" | "neutral"
): { score: number; edgeProxy: number; liquidityScore: number; ivScore: number } {
  let liquidityScore = 0.5;
  const spread = contract.ask - contract.bid;
  if (contract.mid > 0 && spread < contract.mid * 0.15) liquidityScore += 0.25;
  if (contract.mid > 0 && spread < contract.mid * 0.08) liquidityScore += 0.25;
  if ((contract.volume ?? 0) > 0) liquidityScore += Math.min(0.25, (contract.volume ?? 0) / 1000);
  if ((contract.openInterest ?? 0) > 0) liquidityScore += Math.min(0.15, (contract.openInterest ?? 0) / 2000);
  liquidityScore = Math.min(1, liquidityScore);

  const iv = contract.iv ?? 0.25;
  const ivPct = iv * 100;
  // High IV = good for selling premium (edge proxy = credit potential)
  const ivScore = Math.min(1, ivPct / 50) * 0.4 + (ivPct > 30 ? 0.3 : 0);
  const edgeProxy = contract.mid > 0 ? (iv / 0.25) * contract.mid : 0; // rough edge from IV

  let dirScore = 0.5;
  const delta = contract.delta ?? (contract.type === "C" ? 0.5 : -0.5);
  if (direction === "bullish" && contract.type === "C" && delta > 0.25 && delta < 0.75) dirScore += 0.35;
  if (direction === "bearish" && contract.type === "P" && delta < -0.25 && delta > -0.75) dirScore += 0.35;
  if (direction === "neutral" && Math.abs(delta) < 0.35) dirScore += 0.35;

  const score = (liquidityScore * 30 + ivScore * 30 + dirScore * 40);
  return { score: Math.min(100, score), edgeProxy, liquidityScore: liquidityScore * 100, ivScore: ivScore * 100 };
}

/**
 * Scan thousands of option combinations (strike × expiry × type) and return the best.
 * IBKR only: uses IB option chain.
 */
export async function scanBestOptionCombinations(
  symbol: string,
  currentPrice: number,
  direction: "bullish" | "bearish" | "neutral",
  options?: { maxCombinations?: number; topN?: number }
): Promise<BestOptionsResult> {
  const maxCombos = options?.maxCombinations ?? 3000;
  const topN = options?.topN ?? 10;

  let contracts: OptionContract[] = [];

  try {
    const { checkIBGatewayConnection } = await import("./ib-orders");
    if (await checkIBGatewayConnection()) {
      const { getIBOptionsChain } = await import("./ib-market-data");
      const chain = await getIBOptionsChain(symbol);
      if (chain?.options?.length) {
        contracts = chain.options.map((o) => ({
          symbol,
          strike: o.strike,
          expiry: o.expiry,
          type: o.right === "P" ? "P" : "C",
          bid: o.bid ?? 0,
          ask: o.ask ?? 0,
          mid: (((o.bid ?? 0) + (o.ask ?? 0)) / 2) || (o.last ?? 0),
          iv: o.impliedVolatility,
          volume: o.volume,
          openInterest: o.openInterest,
          delta: o.delta,
        }));
        source = "ibkr";
      }
    }
    } catch {
    // IB only
  }

  const spot = currentPrice;
  const inRange = (c: OptionContract) =>
    spot > 0 && Math.abs(c.strike - spot) / spot < 0.25;
  const limited = contracts.filter(inRange).slice(0, maxCombos);

  const scored: ScoredOption[] = limited.map((contract) => {
    const { score, edgeProxy, liquidityScore, ivScore } = scoreOption(
      contract,
      spot,
      direction
    );
    return {
      contract,
      score,
      edgeProxy,
      liquidityScore,
      ivScore,
    };
  });

  const byCall = scored.filter((s) => s.contract.type === "C").sort((a, b) => b.score - a.score);
  const byPut = scored.filter((s) => s.contract.type === "P").sort((a, b) => b.score - a.score);

  return {
    topCalls: byCall.slice(0, topN),
    topPuts: byPut.slice(0, topN),
    bestCall: byCall[0] ?? null,
    bestPut: byPut[0] ?? null,
    totalCombinationsScored: scored.length,
    source: "ibkr",
  };
}
