import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SignalBreakdown } from "@/components/SignalBreakdown";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { Activity, ChevronRight } from "lucide-react";

const DEFAULT_SYMBOLS = ["SPY", "QQQ", "AAPL", "NVDA", "TSLA", "MSFT"];

export default function SignalTaxonomy() {
  const [symbol, setSymbol] = useState("SPY");
  const { data: topData } = trpc.marketScanner.getTopOpportunities.useQuery(
    { count: 20 },
    { refetchInterval: 30_000 }
  );
  const topSymbols = topData?.opportunities?.map((o) => o.symbol).slice(0, 12) ?? DEFAULT_SYMBOLS;

  const [, navigate] = useLocation();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Signal Taxonomy</h1>
        <p className="text-slate-400 mt-2">Class A-D signals with confidence scores; signal breakdown by symbol (composite score, regime, opportunity).</p>
      </div>

      {/* Single source of truth: trading recommendations use Today's Opportunity */}
      <Card className="bg-emerald-500/10 border-emerald-500/40 border-slate-700">
        <CardContent className="pt-4 pb-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <p className="text-sm text-slate-300">
            <strong className="text-emerald-400">Trading recommendations</strong> use a single source of truth: <strong>Today&apos;s Opportunity</strong>. For intent-driven structure and direction, use Today&apos;s Opportunity.
          </p>
          <Button
            variant="outline"
            size="sm"
            className="border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/10 shrink-0"
            onClick={() => navigate("/today-opportunity")}
          >
            Open Today&apos;s Opportunity <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </CardContent>
      </Card>

      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Signal Breakdown by Symbol
          </CardTitle>
          <CardDescription>Reference only; not used for trade decisions. For trading use Today&apos;s Opportunity. Final score, win probability, and contributing factors from scanner + regime.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-slate-400">Symbol</Label>
            <div className="flex flex-wrap gap-2 mt-2">
              {Array.from(new Set([...topSymbols, symbol].filter(Boolean))).slice(0, 14).map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setSymbol(s)}
                  className={`px-3 py-1.5 rounded text-sm font-medium transition-colors ${
                    symbol === s ? "bg-blue-600 text-white" : "bg-slate-700 text-slate-300 hover:bg-slate-600"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
            <Input
              placeholder="Or type symbol (e.g. AAPL)"
              value={symbol}
              onChange={(e) => setSymbol(e.target.value.toUpperCase().trim() || "SPY")}
              className="mt-2 max-w-xs bg-slate-900 border-slate-600"
            />
          </div>
          <SignalBreakdown symbol={symbol} />
        </CardContent>
      </Card>

      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle>Active Signals (reference)</CardTitle>
          <CardDescription>Class A-D structural and flow signals</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-slate-900 rounded">
              <div>
                <div className="font-medium">Dealer Gamma Positioning</div>
                <div className="text-xs text-slate-400">Class A - Structural</div>
              </div>
              <Badge className="bg-green-600">0.68</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
