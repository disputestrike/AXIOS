/**
 * Regime and Strategy Coverage Diagnostic — for current market scan (top N opportunities).
 * Identifies whether empty dropdowns are due to market conditions, filter thresholds, or system gaps.
 * "Strategy" here = structure type (vertical_call_spread, iron_condor, etc.), not engine strategy (wheel, short_term).
 */

import { getMarketScanner } from "./market-scanner";
import { STRATEGY_CONFIGS } from "./strategy-types";

export interface OpportunityRow {
  symbol: string;
  regime: string;
  strategy: string;
  score: number;
  winProbability: number;
  expectedReturn: number;
}

export interface ByRegimeEntry {
  regime: string;
  opportunities: OpportunityRow[];
  count: number;
  highestScore: number;
  avgWinProb: number;
  reasonIfZero?: string;
}

export interface ByStrategyEntry {
  strategy: string;
  opportunities: OpportunityRow[];
  count: number;
  highestScore: number;
  avgWinProb: number;
  reasonIfZero?: string;
}

export interface ByRegimeStrategyEntry {
  regime: string;
  strategy: string;
  count: number;
  symbols: string[];
  highestScore: number;
  avgWinProb: number;
  reasonIfZero?: string;
}

export interface RegimeStrategyDiagnosticResult {
  timestamp: string;
  topN: number;
  totalOpportunities: number;
  byRegime: ByRegimeEntry[];
  byStrategy: ByStrategyEntry[];
  byRegimeStrategy: ByRegimeStrategyEntry[];
  summaryTable: Array<{
    regime: string;
    strategy: string;
    count: number;
    highestScore: number;
    avgWinProb: number;
    reasonIfZero: string | null;
  }>;
  filterNotes: {
    minScoreByStrategy: Record<string, number>;
    minWinProbabilityByStrategy: Record<string, number>;
    scannerFilters: string;
    possibleReasonsForZero: string[];
  };
}

const KNOWN_REGIMES = [
  "crisis",
  "liquidity_drought",
  "trending_bull",
  "trending_bear",
  "bull_vol_expansion",
  "bear_vol_expansion",
  "bull_vol_compression",
  "bear_vol_compression",
  "mean_reverting",
  "chaotic",
  "sector_rotation",
];

const KNOWN_STRATEGIES = [
  "iron_condor",
  "iron_butterfly",
  "vertical_call_spread",
  "vertical_put_spread",
  "calendar_spread",
  "diagonal_spread",
  "straddle",
  "strangle",
  "butterfly",
  "cash_secured_put",
  "covered_call",
].filter((v, i, a) => a.indexOf(v) === i);

function reasonForZero(
  label: string,
  totalOpps: number,
  filters: { minScore?: number; minWinProb?: number }
): string {
  if (totalOpps === 0) {
    return "No opportunities in current scan (run a scan first or check market data).";
  }
  const parts: string[] = [];
  if (filters.minScore != null) {
    parts.push(`min score ${filters.minScore} may exclude`);
  }
  if (filters.minWinProb != null) {
    parts.push(`min win prob ${filters.minWinProb}% may exclude`);
  }
  if (parts.length === 0) {
    return `No opportunities in top 100 match this ${label}; market conditions or IV/volume thresholds.`;
  }
  return `Possible filter: ${parts.join("; ")}. Or no symbols in scan match this ${label}.`;
}

/**
 * Run regime and strategy coverage diagnostic on top N opportunities (default 100).
 */
export function runRegimeStrategyDiagnostic(topN: number = 100): RegimeStrategyDiagnosticResult {
  const scanner = getMarketScanner();
  const opportunities = scanner.getTopOpportunities(topN);

  const rows: OpportunityRow[] = opportunities.map((o) => ({
    symbol: o.symbol,
    regime: o.regime ?? "unknown",
    strategy: (o.structure?.type ?? "vertical_call_spread").toString().replace(/\s+/g, "_").toLowerCase(),
    score: o.opportunity?.score ?? 0,
    winProbability: (o.opportunity?.winProbability ?? 0) * 100,
    expectedReturn: o.opportunity?.expectedReturn ?? 0,
  }));

  const byRegime = new Map<string, OpportunityRow[]>();
  const byStrategy = new Map<string, OpportunityRow[]>();
  const byRegimeStrategy = new Map<string, OpportunityRow[]>();

  for (const r of rows) {
    if (!byRegime.has(r.regime)) byRegime.set(r.regime, []);
    byRegime.get(r.regime)!.push(r);
    if (!byStrategy.has(r.strategy)) byStrategy.set(r.strategy, []);
    byStrategy.get(r.strategy)!.push(r);
    const key = `${r.regime}|${r.strategy}`;
    if (!byRegimeStrategy.has(key)) byRegimeStrategy.set(key, []);
    byRegimeStrategy.get(key)!.push(r);
  }

  const byRegimeEntries: ByRegimeEntry[] = [];
  const regimesToReport = Array.from(new Set([...KNOWN_REGIMES, ...Array.from(byRegime.keys())]));
  for (const regime of regimesToReport) {
    const list = byRegime.get(regime) ?? [];
    const count = list.length;
    const highestScore = count > 0 ? Math.max(...list.map((o) => o.score)) : 0;
    const avgWinProb = count > 0 ? list.reduce((s, o) => s + o.winProbability, 0) / count : 0;
    byRegimeEntries.push({
      regime,
      opportunities: list,
      count,
      highestScore: Math.round(highestScore * 10) / 10,
      avgWinProb: Math.round(avgWinProb * 10) / 10,
      reasonIfZero: count === 0 ? reasonForZero("regime", opportunities.length, {}) : undefined,
    });
  }

  const byStrategyEntries: ByStrategyEntry[] = [];
  const strategiesToReport = Array.from(new Set([...KNOWN_STRATEGIES, ...Array.from(byStrategy.keys())]));
  for (const strategy of strategiesToReport) {
    const list = byStrategy.get(strategy) ?? [];
    const count = list.length;
    const highestScore = count > 0 ? Math.max(...list.map((o) => o.score)) : 0;
    const avgWinProb = count > 0 ? list.reduce((s, o) => s + o.winProbability, 0) / count : 0;
    byStrategyEntries.push({
      strategy,
      opportunities: list,
      count,
      highestScore: Math.round(highestScore * 10) / 10,
      avgWinProb: Math.round(avgWinProb * 10) / 10,
      reasonIfZero: count === 0 ? reasonForZero("strategy", opportunities.length, {}) : undefined,
    });
  }

  const byRegimeStrategyEntries: ByRegimeStrategyEntry[] = [];
  const summaryTable: RegimeStrategyDiagnosticResult["summaryTable"] = [];

  for (const regime of regimesToReport) {
    for (const strategy of strategiesToReport) {
      const key = `${regime}|${strategy}`;
      const list = byRegimeStrategy.get(key) ?? [];
      const count = list.length;
      const highestScore = count > 0 ? Math.max(...list.map((o) => o.score)) : 0;
      const avgWinProb = count > 0 ? list.reduce((s, o) => s + o.winProbability, 0) / count : 0;
      byRegimeStrategyEntries.push({
        regime,
        strategy,
        count,
        symbols: list.map((o) => o.symbol),
        highestScore: Math.round(highestScore * 10) / 10,
        avgWinProb: Math.round(avgWinProb * 10) / 10,
        reasonIfZero: count === 0 ? reasonForZero("regime+strategy", opportunities.length, {}) : undefined,
      });
      summaryTable.push({
        regime,
        strategy,
        count,
        highestScore: Math.round(highestScore * 10) / 10,
        avgWinProb: Math.round(avgWinProb * 10) / 10,
        reasonIfZero: count === 0 ? reasonForZero("combo", opportunities.length, {}) : null,
      });
    }
  }

  const minScoreByStrategy: Record<string, number> = {};
  const minWinProbabilityByStrategy: Record<string, number> = {};
  for (const [k, v] of Object.entries(STRATEGY_CONFIGS)) {
    minScoreByStrategy[k] = 0;
    minWinProbabilityByStrategy[k] = (v.minWinProbability ?? 0.6) * 100;
  }

  return {
    timestamp: new Date().toISOString(),
    topN,
    totalOpportunities: opportunities.length,
    byRegime: byRegimeEntries,
    byStrategy: byStrategyEntries,
    byRegimeStrategy: byRegimeStrategyEntries,
    summaryTable,
    filterNotes: {
      minScoreByStrategy,
      minWinProbabilityByStrategy,
      scannerFilters:
        "getTopOpportunities(count, filters) supports: minScore, minWinProbability, structureType, regime, symbolSearch. No filters applied for this diagnostic.",
      possibleReasonsForZero: [
        "No scan run yet — run market scan first.",
        "Min score / min win probability filters (see STRATEGY_CONFIGS) may exclude opportunities.",
        "IV percentile or liquidity thresholds in scoring may drop symbols.",
        "Market conditions: current regime/vol may not produce certain structure types.",
        "Symbol universe: only symbols in scanner list are considered.",
      ],
    },
  };
}
