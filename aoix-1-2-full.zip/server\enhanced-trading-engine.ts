/**
 * Enhanced Trading Engine
 * Integrates all advanced improvements for maximum performance
 */

import { generateAdvancedSignal } from './advanced-signals';
import { calculateOptimalPositionSize, calculatePortfolioAwareSize } from './position-sizing';
import { analyzeMultiTimeframe } from './multi-timeframe';
import { calculateAdaptiveRisk, calculatePerformanceMetrics, determineMarketConditions } from './adaptive-risk';
import { determineExitStrategy } from './dynamic-exits';
import { getRealStockPrice, getRealOptionsData } from './real-market-data';
import type { MarketOpportunity } from './market-scanner';

export interface EnhancedPosition {
  id: string;
  symbol: string;
  entryPrice: number;
  currentPrice: number;
  quantity: number;
  entryTime: number;
  signal: any; // AdvancedSignal
  timeframeAnalysis: any; // MultiTimeframeSignal
  positionSize: any; // PositionSizeResult
  exitStrategy: any; // ExitDecision
  unrealizedPnL: number;
  unrealizedPnLPercent: number;
}

/**
 * Enhanced trading engine that uses all advanced features
 */
export class EnhancedTradingEngine {
  private positions: EnhancedPosition[] = [];
  private accountBalance: number = 100000;
  private performanceHistory: any[] = [];

  /**
   * Analyze opportunity with all advanced features
   */
  async analyzeOpportunity(opportunity: MarketOpportunity): Promise<{
    shouldTrade: boolean;
    signal?: any;
    timeframe?: any;
    positionSize?: any;
    riskAdjustment?: any;
    reason: string;
  }> {
    try {
      // 1. Generate advanced signal
      const priceData = await getRealStockPrice(opportunity.symbol);
      const optionsData = await getRealOptionsData(opportunity.symbol);
      
      if (!priceData || !optionsData) {
        return { shouldTrade: false, reason: 'No market data available' };
      }

      const advancedSignal = await generateAdvancedSignal(
        opportunity.symbol,
        priceData,
        optionsData,
        [] // Historical data would go here
      );

      if (!advancedSignal || advancedSignal.confidenceScore < 0.65) {
        return { 
          shouldTrade: false, 
          reason: `Signal confidence too low: ${advancedSignal?.confidenceScore || 0}` 
        };
      }

      // 2. Multi-timeframe analysis
      const timeframeAnalysis = await analyzeMultiTimeframe(opportunity.symbol);
      
      if (!timeframeAnalysis || timeframeAnalysis.overallConfidence < 0.6) {
        return { 
          shouldTrade: false, 
          reason: `Timeframe alignment too low: ${timeframeAnalysis?.alignment || 0}` 
        };
      }

      // 3. Calculate adaptive risk
      const performance = calculatePerformanceMetrics(
        this.performanceHistory,
        this.accountBalance,
        100000
      );

      const marketConditions = determineMarketConditions(
        20, // VIX - would come from market data
        opportunity.priceChangePercent,
        this.positions.map(p => ({ symbol: p.symbol }))
      );

      const riskAdjustment = calculateAdaptiveRisk(performance, marketConditions);

      // Check if risk-adjusted threshold is met
      if (advancedSignal.confidenceScore * 100 < riskAdjustment.minScoreThreshold) {
        return {
          shouldTrade: false,
          reason: `Risk-adjusted threshold not met: ${advancedSignal.confidenceScore * 100} < ${riskAdjustment.minScoreThreshold}`,
        };
      }

      // 4. Calculate optimal position size
      const optionPrice = opportunity.currentPrice * 0.02; // Estimate - would use real option price
      
      const positionSize = calculatePortfolioAwareSize(
        {
          accountBalance: this.accountBalance,
          winProbability: advancedSignal.winProbability,
          avgWinSize: advancedSignal.expectedMove / 100,
          avgLossSize: advancedSignal.expectedMove * 0.4 / 100,
          currentDrawdown: performance.currentDrawdown,
          volatility: optionsData.impliedVolatility,
          correlation: marketConditions.correlation,
          maxRiskPerTrade: 0.01 * riskAdjustment.riskMultiplier,
          optionPrice,
          strike: opportunity.currentPrice,
          currentPrice: opportunity.currentPrice,
        },
        this.positions.map(p => ({
          symbol: p.symbol,
          quantity: p.quantity,
          delta: 0.5, // Would calculate real delta
        }))
      );

      if (positionSize.quantity < 1) {
        return {
          shouldTrade: false,
          reason: 'Position size too small after risk adjustments',
        };
      }

      // 5. Final decision
      const shouldTrade = 
        advancedSignal.confidenceScore >= 0.65 &&
        timeframeAnalysis.overallConfidence >= 0.6 &&
        timeframeAnalysis.alignment >= 0.6 &&
        positionSize.quantity >= 1 &&
        this.positions.length < riskAdjustment.maxPositions;

      return {
        shouldTrade,
        signal: advancedSignal,
        timeframe: timeframeAnalysis,
        positionSize,
        riskAdjustment,
        reason: shouldTrade 
          ? `All criteria met: Signal ${(advancedSignal.confidenceScore * 100).toFixed(1)}%, Timeframe ${(timeframeAnalysis.overallConfidence * 100).toFixed(1)}%, Alignment ${(timeframeAnalysis.alignment * 100).toFixed(1)}%`
          : 'One or more criteria not met',
      };
    } catch (error) {
      console.error(`[EnhancedEngine] Error analyzing opportunity:`, error);
      return { shouldTrade: false, reason: `Error: ${error}` };
    }
  }

  /**
   * Determine exit for existing position
   */
  async determinePositionExit(position: EnhancedPosition): Promise<any> {
    const marketConditions = determineMarketConditions(
      20, // VIX
      0, // Market trend
      this.positions.map(p => ({ symbol: p.symbol }))
    );

    const performance = calculatePerformanceMetrics(
      this.performanceHistory,
      this.accountBalance,
      100000
    );

    return determineExitStrategy(
      {
        symbol: position.symbol,
        entryPrice: position.entryPrice,
        currentPrice: position.currentPrice,
        entryTime: position.entryTime,
        currentTime: Date.now(),
        takeProfitPrice: position.entryPrice * 1.30,
        stopLossPrice: position.entryPrice * 0.80,
        trailingStopPrice: null,
        highWaterMark: position.currentPrice,
        unrealizedPnL: position.unrealizedPnL,
        unrealizedPnLPercent: position.unrealizedPnLPercent,
        optionType: 'call',
        daysToExpiry: 14,
        regime: 'bull_vol_compression',
        signalClass: 'A',
        volatility: 0.25,
        volume: 1000000,
        avgVolume: 1000000,
      },
      {
        vix: 20,
        marketTrend: 0,
        regime: 'bull_vol_compression',
        timeOfDay: 'mid_day',
      },
      {
        winRate: performance.winRate,
        profitFactor: performance.profitFactor,
        recentPerformance: performance.recentPerformance,
      }
    );
  }
}
