# AOIX-1 Upgrade Plan — Assessment Before Full Implementation

**Plan:** 7–11 week sprint to 8.5–9.0 rating.  
**Purpose:** Rate, rank, compare the plan against the **current codebase** so you can approve with eyes open.

---

## 1. What You Already Have (Don’t Rebuild)

| Plan item | Current state | Recommendation |
|-----------|----------------|----------------|
| **Week 1: Options flow** | `options-flow.ts` + `OPTIONS_FLOW_API_URL` (HTTP fetch); `microstructure-signals.ts` uses `getUnusualFlow()`. Proxy/stub when no API. | **Don’t rewrite.** Add WebSocket only if your chosen provider (e.g. Sprout) requires it; otherwise keep HTTP + cache. Shorter: “Choose provider, add API key, test `getUnusualFlow()` returns `source: 'api'`.” |
| **Week 2: IV term structure** | `iv-surface-analyzer.ts`: `ivTermStructurePremium`, `volSkewAlignment`, `regimeVolAlignment`. **No** polynomial `fitIVSurface()` or strike-level surface. | **Week 2 is net-new.** Add `fitIVSurface()` / `getTermStructure()` and hook into chain if you want strike-level IV; otherwise current regime/term multipliers may be enough for 8.5. |
| **Week 3: TCA** | `tca.ts`: `logTCA`, `getTCASummary` (incl. **executionQualityScore**), `getTCALog`. `placeOrder` logs TCA. `autoTrading.getTCASummary`, `getTCALog` exposed. | **Don’t rebuild TCA.** Add only: **fill snapshot** (bid/ask/mid at fill time) if you need tick-level attribution. Otherwise Week 3 = “add captureFillSnapshot + optional getFillSnapshot(orderId)”. |
| **Week 4: Walk-forward** | `backtest-runner.ts`: **real** `runWalkForward()` (train/test via `simulateSlice` + `metricsFromReturns`). Single window. | **Extend, don’t replace.** Add `runMultiWindowWalkForward()` (5 windows) + collapse ratio + `pnpm backtest:5window` script. Week 4 scope = multi-window + robustness metric. |
| **Week 6: Order validation** | `omega0.placeOrder`: Zod validation (symbol, expiry, strike, quantity). `estimateOrderCost` exists. | **Add:** Pre-place **multi-leg slippage/cost** check; **reject** if over threshold; return `estimatedCost`/`estimatedSlippage` in response. No need for a whole new “order-validator” module if you fold into `placeOrder`. |
| **Week 7: Greeks / hedge** | `getPortfolioRisk` (omega0): **real Greeks from IB** when connected; `hedgeSuggestions` (text). | **Add:** Numeric hedge size (e.g. “Buy N shares”) + optional **auto-hedge** when |delta| > threshold. Tracker + realtime updates are incremental. |

**Takeaway:** Weeks 1, 3, 4, 6, 7 are partially or largely done. Plan reads like a greenfield build; in practice, ~40% is “wire and extend” and ~60% is net-new (IV surface fit, fill snapshot, multi-window WF, regime/correlation stress, drawdown limiter, heatmaps, drill-downs).

---

## 2. High-Value vs Lower-Priority

**Higher value (do first):**

- **Week 4 (multi-window walk-forward):** Extends existing WF; collapse ratio directly supports “8.5–9.0” and robustness narrative.
- **Week 6 (pre-flight order validation):** Reject bad orders before place; use existing `estimateOrderCost`; improves safety and rating.
- **Week 8 (drawdown limits + auto-stop):** New capability; important for live/paper discipline and ops.
- **Week 9 (regime heatmap + signal breakdown + TCA drill-down):** Transparency; supports “institutional” story and UX.

**Medium value (good but can trim):**

- **Week 2 (IV surface polynomial fit):** Only needed if you want strike-level IV and skew-driven structure selection; current IV term/skew helpers may suffice for 8.5.
- **Week 5 (regime transition + correlation stress):** Strong for robustness narrative; can be 1 script each (e.g. `stress-regime-transitions.ts`, `stress-correlation-periods.ts`) rather than full week each.
- **Week 7 (auto-hedge):** Suggest hedge size + optional auto-execute; you already have hedge suggestions.

**Lower priority / optional:**

- **Week 1 WebSocket:** Only if provider requires it; HTTP + cache is enough for many flow APIs.
- **Week 3 tick-level snapshot:** Add only if you need bid/ask/mid at fill for compliance or deeper TCA; current TCA + execution quality score already support 8.0+.

---

## 3. Risks and Dependencies

| Risk | Mitigation |
|------|------------|
| **Week 1: Paid flow API ($300–2000/mo)** | Decide provider and budget first. If budget is zero, keep proxy/stub and document “real flow when OPTIONS_FLOW_API_URL set”; rating still achievable. |
| **Week 2: mathjs / polynomial fit** | You may already have deps for numeric work; confirm. Synthetic tests first, then one expiry (e.g. SPY) before full chain. |
| **Week 4: 5-window run time** | 1–2 hrs is plausible; run in background, persist results to `backtest-results/5window-walkforward.json`. |
| **Week 7: Auto-hedge** | Start with **suggestions only**; add auto-execute behind a flag (e.g. `AUTO_HEDGE_ENABLED=true`) and document in RUNBOOK. |
| **Week 8: Auto-stop on drawdown** | Define override (e.g. admin-only or confirmation) so ops can restart after a stop. |

---

## 4. Suggested Sequencing (If You Want to Compress)

- **Weeks 1–2:** Flow API (key + test; skip WebSocket unless required). IV surface: add only if you explicitly want strike-level fit; otherwise keep current IV helpers.
- **Week 3:** Minimally: add **fill snapshot** (bid/ask/mid at fill) and optional `getFillSnapshot(orderId)`. Keep existing TCA summary/log.
- **Week 4:** Multi-window WF + script + collapse ratio (high leverage).
- **Week 5:** One script for regime stress, one for correlation stress; no need for five full days if you reuse existing regime/backtest code.
- **Week 6:** Pre-flight validation in `placeOrder` (slippage/cost threshold, return estimates).
- **Week 7:** Hedge size calculation + optional auto-hedge flag.
- **Week 8:** Drawdown limiter + auto-stop (new and valuable).
- **Week 9:** Regime heatmap + signal breakdown + TCA drill-down (APIs + UI).
- **Weeks 10–11:** Integration, RUNBOOK, go-live as in plan.

---

## 5. Rating Impact (Reality Check)

- **Current (after max-level push):** 8.0/10, all dimensions ≥ 8.
- **Plan target:** 8.5–9.0.
- **What actually moves the needle:**  
  - **8.5:** Multi-window WF with collapse > 0.8, pre-flight order validation, drawdown limits, regime heatmap + signal breakdown + TCA drill-down, RUNBOOK updated.  
  - **9.0:** All of the above + real flow API (if you pay), IV surface fit (if you want strike-level), tick-level fill snapshot (if you need it), optional auto-hedge, and a week of stable live/paper trading with no critical issues.

You can reach **8.5** without a paid flow API and without full polynomial IV surface if you prioritize WF robustness, validation, drawdown, and transparency (heatmap, breakdown, drill-down).

---

## 6. Verdict

- **Approve for implementation:** Yes, with the above as **adjustments**, not a rewrite.
- **Do first:** Multi-window walk-forward (Week 4), pre-flight order validation (Week 6), drawdown limiter (Week 8), regime heatmap + signal breakdown + TCA drill-down (Week 9).
- **Treat as optional or light:** WebSocket for flow (Week 1), full IV polynomial surface (Week 2), tick-level fill capture (Week 3), and long regime/correlation weeks (Week 5) — compress into scripts.
- **Document:** In RUNBOOK, which features are “when env set” (e.g. flow API, auto-hedge) and what the rollback flags are (as in your Emergency Rollback section).

If you want, next step can be a **short “Approved plan” checklist** (one page) that mirrors your week-by-week plan but with “existing / extend / new” and the optional items marked so the implementer doesn’t overbuild.
