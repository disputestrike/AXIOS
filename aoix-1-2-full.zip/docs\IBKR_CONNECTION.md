# Connect AOIX-1 to IBKR (Real Live Data + Paper Trading)

Use **IB Gateway** or **Trader Workstation (TWS)** so AOIX-1 can use **real live market data** and **paper trading** (or live) through Interactive Brokers.

---

## Connect to real IBKR data (short checklist)

AOIX-1 needs the **Client Portal Gateway** (REST API), not the socket-only TWS/Gateway.

1. **Get Client Portal Gateway**
   - Go to [IBKR API / Gateway](https://www.interactivebrokers.com/en/trading/ib-api.php) or search **"Client Portal API"** / **"CP Gateway"** on the IB site.
   - Download and install the **Client Portal Gateway** (the one that runs a local REST server).

2. **Run it**
   - Start the Client Portal Gateway. Log in with your **paper** or live account.
   - It will start a local server, usually on **port 5000**. Leave it running.

3. **In AOIX-1**
   - Open **Auto Trading** → click the **gear** next to **Connect**.
   - Set **Host:** `localhost`, **Port:** `5000`.
   - Click **Configure & Connect**.

4. **Verify**
   - The TWS card should show **TWS Connected**. You then get **real IBKR market data** and can paper-trade through your IBKR account.

---

## Why "TWS Disconnected" Even With Port 4002

AOIX-1 connects using the **Client Portal REST API** (HTTP: `http://localhost:PORT/v1/...`).  
Your **Socket port: 4002** in TWS/Gateway is the **native TWS API** (TCP socket), **not** HTTP. So the app’s connection test to port 4002 will fail unless something is serving the REST API there.

**Fix:** Run IB’s **Client Portal Gateway** (the one that provides the REST API). It’s a separate app from IB; when you run it and log in (paper or live), it starts a local HTTP server, usually on **port 5000**.

1. **Download:** [IBKR Client Portal Gateway](https://www.interactivebrokers.com/en/trading/ib-api.php) (or search “IBKR Client Portal Gateway” on the IB site).
2. **Run it** and log in with your paper (or live) account.
3. In AOIX-1: open the TWS config (gear), set **Host:** `localhost`, **Port:** `5000`.
4. Click **Configure & Connect**.

The status should change to **TWS Connected**.

---

## What You Need

1. **IBKR account** (paper or live)
2. **IB Gateway** or **Trader Workstation (TWS)** installed and running
3. **API enabled** in Gateway/TWS
4. **AOIX-1** configured to talk to the Gateway (host + port)

---

## Step 1: Install and Run IB Gateway (or TWS)

- **Download:** [Interactive Brokers – IB Gateway](https://www.interactivebrokers.com/en/trading/ibgateway-stable.php) (or TWS).
- **Paper trading:** Run **IB Gateway** and choose **Paper Trading** when you log in (so no real money is used).
- **Live:** Choose **Live Trading** only when you are ready to use real funds.

Leave the Gateway (or TWS) **running** and **logged in** while you use AOIX-1.

---

## Step 2: Enable the API in Gateway/TWS

1. In **IB Gateway** (or TWS): **Configure** → **Settings** (or **Edit** → **Global Configuration**).
2. Open **API** → **Settings**.
3. Enable:
   - **Enable ActiveX and Socket Clients** (for TWS API), **or**
   - **Enable Client Portal API** (if your version has it).
4. Note the **Socket port**:
   - **Paper:** often **4001**
   - **Live:** often **4002**
5. If you use the **Client Portal Gateway** (REST API), it may run on port **5000**. In that case use port **5000** in AOIX-1.
6. **Trusted IPs:** add `127.0.0.1` (and your machine’s IP if you run the app on another machine).
7. Save and restart Gateway/TWS if needed.

---

## Step 3: Configure AOIX-1 to Use the Gateway

AOIX-1 talks to the Gateway over **HTTP** at `http://<host>:<port>/v1`. It uses **TWS_HOST** and **TWS_PORT** (default: `localhost` and `4001`).

**Option A – In the app (easiest)**

1. Open AOIX-1 in the browser (e.g. `http://localhost:3006`).
2. Go to **Auto Trading** (or wherever the TWS/IB status card is).
3. Click the **gear** next to **TWS Disconnected** / **Connect**.
4. In **Configure TWS Connection**:
   - **Host:** `localhost` (or your Gateway machine’s IP if different).
   - **Port:** `4001` for paper, or `5000` if you use Client Portal Gateway on 5000.
5. Click **Configure & Connect**.
6. The card should show **Connected** when the Gateway is reachable.

**Option B – Environment variables**

In `.env.local` in the project root:

```env
TWS_HOST=localhost
TWS_PORT=4001
```

Use **4002** for live, or **5000** if your Client Portal Gateway runs there. Restart the AOIX-1 server after changing.

---

## Step 4: Verify Connection

- **System Health:** In AOIX-1, open **System Health**. The **TWS/IB Gateway** component should be **healthy** when connected.
- **Market data:** With the Gateway connected, option chains and live data use IBKR when available; otherwise the app falls back to Yahoo Finance.
- **Paper trading:** Orders placed in AOIX-1 (with the app in paper mode) go to your IBKR **paper** account when the Gateway is in **Paper Trading** mode.

---

## Port Summary

| Mode / API           | Typical port | Use in AOIX-1   |
|----------------------|-------------|------------------|
| Paper (TWS socket)   | 4001        | `TWS_PORT=4001`  |
| Live / Simulated (TWS socket) | **4002** | `TWS_PORT=4002`  |
| Client Portal (REST) | 5000        | `TWS_PORT=5000`  |

**If your Gateway shows "Socket port: 4002" (e.g. Simulated Trading):**  
In AOIX-1 set **Host:** `localhost`, **Port:** `4002` and click **Configure & Connect**.  
AOIX-1 uses the **Client Portal REST API** (HTTP). Some Gateways expose REST on the same port; if Connect fails, run the **Client Portal Gateway** (from IB) and use its port (often 5000) in AOIX-1.

---

## Troubleshooting

| Issue | What to do |
|-------|------------|
| **TWS Disconnected** | Ensure IB Gateway (or TWS) is running and logged in; enable API and set port (4001/4002/5000). |
| **Connection refused** | Check firewall; use Host `localhost` and the same port as in Gateway API settings. |
| **No live/option data** | When Gateway is connected, the app prefers IBKR; if it still uses Yahoo, check System Health and Gateway account/contract permissions. |
| **Paper vs live** | Use **Paper Trading** in the Gateway for paper; **Live** only when you intend to trade real money. |

---

## Data and Execution Flow

- **Without Gateway:** AOIX-1 uses **Yahoo Finance** for prices and **in‑app paper trading** (no real broker orders).
- **With Gateway:** AOIX-1 uses **IBKR** for live data and can send orders to your **paper** or **live** account; in‑app paper mode still simulates locally when you don’t want to hit the broker.

For **real live market data** and **paper trading via IBKR**, keep the Gateway running and connected as above.
