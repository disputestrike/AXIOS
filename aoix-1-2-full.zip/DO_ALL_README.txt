AOIX-1 - Start everything in one go
====================================

ONE-TIME (if TWS never connects):
  1. Right-click ALLOW_JAVA_FIREWALL.bat
  2. Click "Run as administrator"
  3. Click Yes, then press any key when done

EVERY TIME YOU WANT TO TRADE:
  1. Double-click START_EVERYTHING.bat
  2. Wait for both windows (Gateway + App) to open
  3. Log in at http://localhost:5000 if the browser asks
  4. In the app, click "Connect" or "I'm logged in at the gateway, confirm connection"
  5. Leave both windows open

To stop: Close the Gateway window and the App window (or Ctrl+C in each).

If the gateway folder is not next to this project, edit START_EVERYTHING.bat
and set GATEWAY_DIR to your clientportal.gw path (e.g. C:\Users\...\clientportal.gw).
