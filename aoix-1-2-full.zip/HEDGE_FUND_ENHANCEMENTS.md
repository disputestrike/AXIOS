# Hedge Fund–Style Enhancements (What Top Funds Use)

This doc describes what was **infused** into AOIX-1 so the system trades more like top quant funds (Citadel, Renaissance, Jane Street, D.E. Shaw) within retail constraints.

---

## 1. Regime-Based Position Sizing

**What funds do:** Low vol → larger size; crash → minimal size.  
**What we added:**

- **`getRegimePositionSizeMultiplier(regime)`** in `server/adaptive-risk.ts`:
  - **Crash / chaotic:** 25% position size  
  - **Bear:** 50%  
  - **Mean reverting:** 80%  
  - **Bull vol expansion:** 100%  
  - **Bull calm:** 150% (hedge fund style)

The auto-trading engine multiplies `maxRiskPerTrade` by this multiplier so position size scales with regime.

---

## 2. ML-Style Entry Probability

**What funds do:** Neural nets / Random Forests to predict win probability; only enter when prob > threshold.  
**What we added:**

- **`server/ml-entry-probability.ts`**:
  - **`computeEntryProbability(inputs)`** — factor ensemble: score 25%, win prob 30%, signal confidence 25%, regime + vol + return 20%.
  - **`shouldEnterByProbability(prob, threshold)`** — default threshold **0.65** (only enter when entry prob ≥ 65%).
  - **Plug point:** Replace the factor ensemble with a trained model (TensorFlow / XGBoost) on the same features for 5–10% win-rate improvement.

The auto-trading engine skips a trade if `entryProbability < ENTRY_PROBABILITY_THRESHOLD`.

---

## 3. Portfolio-Level Greeks & VaR (Hedge Fund Risk)

**What funds do:** Track total delta, gamma, theta, vega; VaR; hedge suggestions.  
**What we added:**

- **`server/portfolio-risk.ts`**:
  - **`estimatePositionGreeks(pos)`** — approximate delta/gamma/theta/vega per position from structure type.
  - **`aggregatePortfolioRisk(positions, accountValue)`** — total Greeks, **VaR 95% / 99%**, and **hedge suggestions** (e.g. “Portfolio delta long > 0.30 → reduce longs or add SPY short”).

- **Omega0 API:** **`getPortfolioRisk`** — returns `totalDelta`, `totalGamma`, `totalTheta`, `totalVega`, `var95`, `var99`, `hedgeSuggestions`, `isLongBiased`, `isShortBiased`.

Use this on the Execution / Risk page to show portfolio Greeks and suggested hedges.

---

## 4. Alternative Data Hooks

**What funds do:** Satellite, credit card, sentiment, flow.  
**What we added (retail-friendly):**

- **`server/alternative-data.ts`**:
  - **`getSentimentForSymbol(symbol)`** — stub (neutral); **plug in** Twitter/Reddit/Google Trends API (~$100/mo).
  - **`getFlowProxyFromOptionsData(putCallRatio, iv, avgIv)`** — option flow proxy from put/call ratio + IV (unusual volume flag, implied move %).
  - **`getAlternativeDataBoost(sentiment, flow)`** — combined ±10% boost/penalty for entry score.

Scanner/engine can call these and add the boost to composite score or entry probability when you wire real APIs.

---

## 5. Walk-Forward Optimization (Research Automation)

**What funds do:** Train on [T−k..T], test on [T..T+h], roll forward; avoid overfitting.  
**What we added:**

- **`server/backtest-runner.ts`** — comment + TODO for **walk-forward**: when historical series is available, add `runWalkForward({ trainDays, testDays, stepDays })`.

---

## 6. What Was Already There (Unchanged)

- **Adaptive risk** — drawdown, consecutive losses, win rate, profit factor, volatility regime.  
- **Regime risk overlay** — `getRegimeRiskMultiplier(regime, confidence)` (bear = tighten, bull = no extra tighten).  
- **Aggression tier** — consecutive wins → slight size increase; losses → reduce.  
- **Strategy–regime alignment** — wheel/short_term/iron_condor + regime-friendly structures.  
- **Portfolio-aware sizing** — correlation, 15% max delta exposure.  
- **Multi-timeframe** — alignment and confidence.  
- **Advanced signals** — pattern recognition, win probability.

---

## Summary Table

| Enhancement              | Module                  | API / Usage                                      |
|-------------------------|-------------------------|--------------------------------------------------|
| Regime position sizing  | `adaptive-risk.ts`      | Auto-engine uses multiplier on maxRiskPerTrade   |
| ML-style entry prob     | `ml-entry-probability.ts` | Auto-engine skips if prob < 0.65               |
| Portfolio Greeks / VaR  | `portfolio-risk.ts`     | `omega0.getPortfolioRisk`                       |
| Hedge suggestions       | `portfolio-risk.ts`     | Same response: `hedgeSuggestions[]`             |
| Alternative data        | `alternative-data.ts`   | Stub + flow proxy; plug sentiment/APIs          |
| Walk-forward            | `backtest-runner.ts`    | TODO when historical data available             |

---

## Expected Impact (From Doc)

- **Current system:** ~2.5% monthly → ~30% annual.  
- **With these enhancements:** regime sizing (fewer blow-ups), entry probability (higher win rate), portfolio hedges (better crash protection) → target **~3.2% monthly → ~39% annual** (≈30% improvement), with discipline and risk management in place.

---

## What To Add Next (Optional)

1. **Real ML model** — Train Random Forest / small neural net on `EntryProbabilityInputs` + outcome; replace `computeEntryProbability` with model.predict.  
2. **Sentiment API** — Twitter/Reddit/Google Trends; call from scanner and add `getAlternativeDataBoost` to score.  
3. **UI for portfolio risk** — Show `getPortfolioRisk` (Greeks, VaR, hedge suggestions) on Execution or Risk page.  
4. **Walk-forward backtest** — Once historical data is in, implement `runWalkForward` and expose in auto-trading router.
