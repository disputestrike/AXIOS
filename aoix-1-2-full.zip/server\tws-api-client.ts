import * as net from 'net';
import { EventEmitter } from 'events';

/**
 * TWS API Client - TCP Socket Protocol
 * Connects to Interactive Brokers TWS or IB Gateway
 * Implements core market data and order execution functionality
 */

interface TWSConfig {
  host: string;
  port: number;
  clientId: number;
}

interface ContractDetails {
  conId: number;
  symbol: string;
  secType: string;
  exchange: string;
  currency: string;
  strike?: number;
  right?: string;
  expiry?: string;
}

interface TickData {
  tickerId: number;
  field: number;
  value: number | string;
  attrib?: any;
}

interface MarketDataSnapshot {
  symbol: string;
  price: number;
  bid: number;
  ask: number;
  volume: number;
  iv?: number;
  bidSize?: number;
  askSize?: number;
  lastTradeTime?: number;
}

export class TWSAPIClient extends EventEmitter {
  private socket: net.Socket | null = null;
  private config: TWSConfig;
  private connected: boolean = false;
  private nextOrderId: number = 0;
  private contractCache: Map<string, ContractDetails> = new Map();
  private marketDataCache: Map<number, MarketDataSnapshot> = new Map();
  private tickerIdMap: Map<string, number> = new Map();
  private nextTickerId: number = 1;

  constructor(config: Partial<TWSConfig> = {}) {
    super();
    this.config = {
      host: config.host || 'localhost',
      port: config.port || 5000,
      clientId: config.clientId || 1,
    };
  }

  /**
   * Connect to TWS/IB Gateway
   */
  async connect(): Promise<boolean> {
    return new Promise((resolve) => {
      try {
        this.socket = net.createConnection(this.config.port, this.config.host);

        this.socket.on('connect', () => {
          console.log('[TWS] Connected to IB Gateway');
          this.connected = true;
          this.sendStartAPI();
          resolve(true);
        });

        this.socket.on('data', (data) => {
          this.handleData(data);
        });

        this.socket.on('error', (error) => {
          console.error('[TWS] Connection error:', error);
          this.connected = false;
          // Don't emit error to prevent unhandled error crash
          // this.emit('error', error);
          resolve(false);
        });

        this.socket.on('close', () => {
          console.log('[TWS] Connection closed');
          this.connected = false;
          this.emit('disconnected');
        });

        // Timeout after 5 seconds
        setTimeout(() => {
          if (!this.connected) {
            resolve(false);
          }
        }, 5000);
      } catch (error) {
        console.error('[TWS] Connection failed:', error);
        resolve(false);
      }
    });
  }

  /**
   * Disconnect from TWS/IB Gateway
   */
  disconnect(): void {
    if (this.socket) {
      this.socket.destroy();
      this.socket = null;
    }
    this.connected = false;
  }

  /**
   * Check if connected
   */
  isConnected(): boolean {
    return this.connected;
  }

  /**
   * Send start API message
   */
  private sendStartAPI(): void {
    const message = this.encodeMessage([
      '71', // startApi
      '2', // version
      this.config.clientId.toString(),
    ]);
    this.send(message);
  }

  /**
   * Request market data for a symbol
   */
  async requestMarketData(symbol: string): Promise<number> {
    if (!this.connected) {
      throw new Error('Not connected to TWS');
    }

    // Get or create ticker ID
    let tickerId = this.tickerIdMap.get(symbol);
    if (!tickerId) {
      tickerId = this.nextTickerId++;
      this.tickerIdMap.set(symbol, tickerId);
    }

    // Request contract details first
    const contract = await this.getContractDetails(symbol);
    if (!contract) {
      throw new Error(`Contract not found for ${symbol}`);
    }

    // Request market data
    const message = this.encodeMessage([
      '1', // reqMktData
      '11', // version
      tickerId.toString(),
      contract.conId.toString(),
      symbol,
      contract.secType,
      contract.expiry || '',
      contract.strike?.toString() || '',
      contract.right || '',
      contract.exchange,
      '',
      contract.currency,
      '',
      '',
      '0', // snapshot
      '0', // regulatory snapshot
      '', // mktDataOptions
    ]);

    this.send(message);
    return tickerId;
  }

  /**
   * Cancel market data subscription
   */
  cancelMarketData(tickerId: number): void {
    if (!this.connected) return;

    const message = this.encodeMessage([
      '2', // cancelMktData
      '2', // version
      tickerId.toString(),
    ]);

    this.send(message);
  }

  /**
   * Get contract details for a symbol
   */
  async getContractDetails(symbol: string): Promise<ContractDetails | null> {
    // Check cache first
    if (this.contractCache.has(symbol)) {
      return this.contractCache.get(symbol) || null;
    }

    if (!this.connected) {
      return null;
    }

    // Request contract details
    const reqId = Math.floor(Math.random() * 10000);
    const message = this.encodeMessage([
      '15', // reqContractDetails
      '8', // version
      reqId.toString(),
      '', // apiClientVersion
      symbol,
      'STK', // secType
      '', // expiry
      '', // strike
      '', // right
      'SMART', // exchange
      '', // primaryExch
      '', // currency
      '', // localSymbol
      '0', // includeExpired
      '', // secIdType
      '', // secId
    ]);

    this.send(message);

    // Wait for response (simplified - in production would use proper event handling)
    return new Promise((resolve) => {
      setTimeout(() => {
        const cached = this.contractCache.get(symbol);
        resolve(cached || null);
      }, 1000);
    });
  }

  /**
   * Request historical data
   */
  async requestHistoricalData(
    symbol: string,
    endDateTime: string,
    durationStr: string,
    barSizeSetting: string,
    whatToShow: string
  ): Promise<any[]> {
    if (!this.connected) {
      throw new Error('Not connected to TWS');
    }

    const contract = await this.getContractDetails(symbol);
    if (!contract) {
      throw new Error(`Contract not found for ${symbol}`);
    }

    const reqId = Math.floor(Math.random() * 10000);
    const message = this.encodeMessage([
      '20', // reqHistoricalData
      '6', // version
      reqId.toString(),
      contract.conId.toString(),
      symbol,
      contract.secType,
      contract.expiry || '',
      contract.strike?.toString() || '',
      contract.right || '',
      contract.exchange,
      contract.currency,
      '',
      endDateTime,
      barSizeSetting,
      durationStr,
      '1', // useRTH
      whatToShow,
      '0', // formatDate
      '', // keepUpToDate
      '', // chartOptions
    ]);

    this.send(message);

    // Return cached data or empty array
    return [];
  }

  /**
   * Place an order
   */
  placeOrder(
    symbol: string,
    action: 'BUY' | 'SELL',
    quantity: number,
    orderType: string,
    limitPrice?: number
  ): number {
    if (!this.connected) {
      throw new Error('Not connected to TWS');
    }

    const orderId = ++this.nextOrderId;
    const contract = this.contractCache.get(symbol);

    if (!contract) {
      throw new Error(`Contract not found for ${symbol}`);
    }

    const message = this.encodeMessage([
      '3', // placeOrder
      '104', // version
      orderId.toString(),
      contract.conId.toString(),
      symbol,
      contract.secType,
      contract.expiry || '',
      contract.strike?.toString() || '',
      contract.right || '',
      contract.exchange,
      contract.currency,
      '',
      action,
      quantity.toString(),
      orderType,
      limitPrice?.toString() || '',
      '', // auxPrice
      'GTC', // timeInForce
      '', // ocaGroup
      '', // account
      '', // openClose
      '', // origin
      '', // orderRef
      '0', // transmit
      '0', // parentId
      '0', // blockOrder
      '0', // sweepToFill
      '', // displaySize
      '0', // triggerMethod
      '0', // outsideRth
      '', // hidden
      '', // goodAfterTime
      '', // goodTillDate
      '', // rule80A
      '', // percentOffset
      '', // overridePercentageConstraints
      '', // netLiquidity
      '', // etaType
      '', // conditions
      '', // conditionsIgnoreRth
      '', // conditionsCancelOrder
      '', // adjustedOrderType
      '', // lmtPriceOffset
      '', // conditions
      '', // adjustedStopPrice
      '', // adjustedStopPriceAdjustValue
      '', // adjustedStopPricePercentChange
      '', // adjustedStopPriceAdjustableValue
      '', // extOperand
      '', // nbboPriceCap
      '', // mktDataOptions
      '', // solicited
      '', // randomizeSize
      '', // randomizePrice
      '', // referenceContractId
      '', // isPeggedChangeAmountDecrease
      '', // peggedChangeAmount
      '', // referenceChangeAmount
      '', // referenceExchangeId
      '', // adjustedTrailingAmount
      '', // trailingPercent
      '', // trailingType
      '', // scaleInitLevelSize
      '', // scaleSubsLevelSize
      '', // scalePriceIncrement
      '', // scalePriceAdjustValue
      '', // scalePriceAdjustInterval
      '', // scaleProfitOffset
      '', // scaleAutoReset
      '', // scaleInitPosition
      '', // scaleInitFillQty
      '', // scaleRandomPercent
      '', // scaleTable
      '', // activeStartTime
      '', // activeStopTime
      '', // modelCode
      '', // extOperand
      '', // softDollarTier
      '', // cashQty
      '', // mktCapPrice
      '', // useAdaptiveAlgo
      '', // adaptiveAlgoStrategy
      '', // adaptiveAlgoInitLookback
      '', // adaptiveAlgoInitThreshold
      '', // adaptiveAlgoMaxTradeRate
      '', // adaptiveAlgoRandomPercentage
    ]);

    this.send(message);
    return orderId;
  }

  /**
   * Send message to TWS
   */
  private send(message: string): void {
    if (!this.socket || !this.connected) {
      console.warn('[TWS] Not connected, message not sent');
      return;
    }

    try {
      this.socket.write(message);
    } catch (error) {
      console.error('[TWS] Error sending message:', error);
    }
  }

  /**
   * Encode message in TWS format
   */
  private encodeMessage(fields: string[]): string {
    return fields.map((f) => `${f.length}:${f}`).join('') + '\n';
  }

  /**
   * Handle incoming data from TWS
   */
  private handleData(data: Buffer): void {
    const message = data.toString('utf-8');
    const lines = message.split('\n');

    for (const line of lines) {
      if (!line) continue;
      this.parseMessage(line);
    }
  }

  /**
   * Parse incoming message
   */
  private parseMessage(line: string): void {
    const fields: string[] = [];
    let currentPos = 0;

    while (currentPos < line.length) {
      const colonPos = line.indexOf(':', currentPos);
      if (colonPos === -1) break;

      const length = parseInt(line.substring(currentPos, colonPos), 10);
      const startPos = colonPos + 1;
      const endPos = startPos + length;

      if (endPos > line.length) break;

      fields.push(line.substring(startPos, endPos));
      currentPos = endPos;
    }

    if (fields.length === 0) return;

    const messageType = fields[0];

    switch (messageType) {
      case '21': // tickPrice
        this.handleTickPrice(fields);
        break;
      case '48': // tickSize
        this.handleTickSize(fields);
        break;
      case '88': // tickString
        this.handleTickString(fields);
        break;
      case '9': // nextValidId
        this.handleNextValidId(fields);
        break;
      case '67': // contractDetails
        this.handleContractDetails(fields);
        break;
    }
  }

  /**
   * Handle tick price update
   */
  private handleTickPrice(fields: string[]): void {
    const tickerId = parseInt(fields[1], 10);
    const tickType = parseInt(fields[2], 10);
    const price = parseFloat(fields[3]);

    const symbol = this.getSymbolFromTickerId(tickerId);
    if (!symbol) return;

    let snapshot = this.marketDataCache.get(tickerId) || {
      symbol,
      price: 0,
      bid: 0,
      ask: 0,
      volume: 0,
    };

    // Update based on tick type
    if (tickType === 1) snapshot.bid = price; // Bid
    else if (tickType === 2) snapshot.ask = price; // Ask
    else if (tickType === 4) snapshot.price = price; // Last
    else if (tickType === 9) snapshot.volume = price; // Volume

    this.marketDataCache.set(tickerId, snapshot);
    this.emit('marketData', snapshot);
  }

  /**
   * Handle tick size update
   */
  private handleTickSize(fields: string[]): void {
    const tickerId = parseInt(fields[1], 10);
    const tickType = parseInt(fields[2], 10);
    const size = parseInt(fields[3], 10);

    const snapshot = this.marketDataCache.get(tickerId);
    if (!snapshot) return;

    if (tickType === 0) snapshot.bidSize = size;
    else if (tickType === 3) snapshot.askSize = size;

    this.marketDataCache.set(tickerId, snapshot);
    this.emit('marketData', snapshot);
  }

  /**
   * Handle tick string update
   */
  private handleTickString(fields: string[]): void {
    const tickerId = parseInt(fields[1], 10);
    const tickType = parseInt(fields[2], 10);
    const value = fields[3];

    const snapshot = this.marketDataCache.get(tickerId);
    if (!snapshot) return;

    if (tickType === 106) {
      // Implied volatility
      snapshot.iv = parseFloat(value);
    } else if (tickType === 48) {
      // Last trade time
      snapshot.lastTradeTime = parseInt(value, 10);
    }

    this.marketDataCache.set(tickerId, snapshot);
    this.emit('marketData', snapshot);
  }

  /**
   * Handle next valid order ID
   */
  private handleNextValidId(fields: string[]): void {
    this.nextOrderId = parseInt(fields[1], 10);
    this.emit('nextValidId', this.nextOrderId);
  }

  /**
   * Handle contract details
   */
  private handleContractDetails(fields: string[]): void {
    const reqId = parseInt(fields[1], 10);
    const conId = parseInt(fields[2], 10);
    const symbol = fields[3];

    const contract: ContractDetails = {
      conId,
      symbol,
      secType: fields[4],
      exchange: fields[5],
      currency: fields[6],
      strike: fields[7] ? parseFloat(fields[7]) : undefined,
      right: fields[8] || undefined,
      expiry: fields[9] || undefined,
    };

    this.contractCache.set(symbol, contract);
    this.emit('contractDetails', contract);
  }

  /**
   * Get symbol from ticker ID
   */
  private getSymbolFromTickerId(tickerId: number): string | null {
    const entries = Array.from(this.tickerIdMap.entries());
    for (const [symbol, id] of entries) {
      if (id === tickerId) return symbol;
    }
    return null;
  }

  /**
   * Get market data snapshot
   */
  getMarketData(symbol: string): MarketDataSnapshot | null {
    const tickerId = this.tickerIdMap.get(symbol);
    if (!tickerId) return null;
    return this.marketDataCache.get(tickerId) || null;
  }

  /**
   * Get all market data
   */
  getAllMarketData(): Map<number, MarketDataSnapshot> {
    return this.marketDataCache;
  }
}

// Global client instance
let globalClient: TWSAPIClient | null = null;

export function getTWSClient(config?: Partial<TWSConfig>): TWSAPIClient {
  if (!globalClient) {
    globalClient = new TWSAPIClient(config);
  }
  return globalClient;
}
