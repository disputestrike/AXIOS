# Direction: Single Source of Truth

## The Problem (Contradiction)

- **Market thesis** said: "Strong **bearish** sentiment (70% strength)", confidence 85%.
- **Display** showed: Direction **"bullish"** in the header badge.
- **Tiers** showed: Conservative = Strangle (neutral), Balanced = Vertical put spread (bearish), Aggressive = Straddle (neutral).

So the system was **detecting** bearish sentiment, **writing** a bearish thesis, but **displaying** bullish and **ordering** strategies in a way that didn’t match the thesis.

## Root Causes

### 1. Display used scanner, not intent

- **Today’s Opportunity** header badge used `opp.signal?.direction` (scanner).
- Scanner `signal.direction` can differ from **intent** (e.g. different source, bug, or stale).
- **Intent** is the single source of truth for “what we’re recommending” (Claude or enhanced fallback).

So the UI showed scanner direction instead of intent direction → **thesis said bearish, header said bullish**.

### 2. Tier order didn’t respect intent direction

- `structurePool` came from intent (allowed structures).
- Tiers were assigned with a **rotation** by symbol+regime: `structurePool[(i + rotateBy) % length]`.
- So Conservative could get a **neutral** structure (e.g. strangle) even when intent was **BEARISH**, and Balanced could get the bearish one.

Result: Conservative didn’t match the stated direction → **strategy coherence failure**.

## Fixes (Lasting)

### 1. Display: intent is the source for direction

**File:** `client/src/pages/TodayOpportunity.tsx`

- **Before:** `<Badge>{opp.signal?.direction ?? "—"}</Badge>`
- **After:** `<Badge>{intent?.direction ? intent.direction.toLowerCase() : (opp.signal?.direction ?? "—")}</Badge>`

Rule: **Whenever we have intent, show intent.direction.** Fall back to scanner only when intent is missing.

### 2. Tier ordering: Conservative matches intent when directional

**File:** `server/catalyst-options-generation.ts` (`generateTradeOptionsWithIntent`)

- When `intent.direction` is **BULLISH** or **BEARISH**, the **direction-matching structure** is forced to the **front** of `structurePool`:
  - BEARISH → `vertical_put_spread` first (if allowed).
  - BULLISH → `vertical_call_spread` first (if allowed).
- Conservative tier uses `structurePool[0]`, so Conservative **always** gets the direction-matching structure when intent is directional.
- Rotation by symbol+regime is **only** used when intent is **NEUTRAL**, so we don’t contradict a directional thesis.

Rule: **For directional intent, Conservative = direction-matching structure; no rotation.**

## Data Flow (After Fix)

1. **Scanner** → `opportunity.signal.direction` (e.g. "bearish") and composite score.
2. **MarketContext** → sentiment number from signal (e.g. bearish → low sentiment).
3. **Intent** (Claude or fallback) → `intent.direction` (e.g. "BEARISH") and rationale.
4. **Options** → `directionFromIntent` on every option (e.g. "bearish"); structure pool ordered so Conservative is direction-matching when intent is directional.
5. **Display** → **intent.direction** in the header/badge; tiers show structures in the order above.

So: **one chain from intent → options → UI; no second source overriding direction in the header.**

## Validation

- If thesis says BEARISH and confidence is high → header must show **bearish**, Conservative must be a **bearish** strategy (e.g. vertical put spread).
- If thesis says BULLISH → header **bullish**, Conservative **bullish** (e.g. vertical call spread).
- If thesis says NEUTRAL → header **neutral**, strategies can be neutral and rotation by symbol is allowed.

## Sentiment vs direction (reference)

- **Sentiment** in code is a number 0–100 (50 = neutral; &gt;50 = bullish bias, &lt;50 = bearish bias), derived from scanner `signal.direction` and `signal.confidence`.
- **Direction** is the **decision**: BULLISH | BEARISH | NEUTRAL. It comes from **intent** (Claude or fallback). Fallback uses sentiment: e.g. sentiment ≥ 60 → BULLISH, ≤ 40 → BEARISH, else NEUTRAL.
- Display and strategy selection must use **intent.direction**, not raw sentiment and not scanner signal alone.
