# AOIX-1 API Reference (10/10 Documentation)

Single source for tRPC routers and key procedures. Base URL: `http://localhost:3000` (or your server).

---

## Omega0 (Execution)

| Procedure | Type | Description |
|-----------|------|-------------|
| `omega0.getStatus` | query | Paper trading status, account value, open/total trades |
| `omega0.getAccountSummary` | query | Net liquidation, buying power, unrealized P&L |
| `omega0.getOptionChain` | query | Option chain for symbol (expirations, strikes). Input: `{ symbol, expiryDaysOut? }` |
| `omega0.placeOrder` | mutation | Place single-leg or multi-leg order. Input: `symbol, expiry, strike, optionType, quantity, structureType?, direction?, diagonalFarStrikeOffset?` |
| `omega0.estimateOrderCost` | query | Pre-trade cost + max loss + slippage. Input: same as placeOrder (no execution). Returns: `estimatedCost, maxLossEstimate, breakdown, estimatedSlippagePercent?, estimatedSlippageDollars?, estimatedCostWithSlippage?` |
| `omega0.getLastOrderSummary` | query | Last executed order (trade log): message, legs, totalCost |
| `omega0.closePosition` | mutation | Close single position. Input: `tradeId?, symbol, expiry, strike, optionType, quantity` |
| `omega0.closeStrategyByComboId` | mutation | Close all legs of a multi-leg strategy. Input: `comboId` |
| `omega0.getPortfolioRisk` | query | Portfolio Greeks, VaR 95/99, actionable hedge suggestions |
| `omega0.getOpenTrades` | query | Open positions with unrealized P&L |

**Structures (getLegsForStructure):** `cash_secured_put`, `covered_call`, `vertical_call_spread`, `vertical_put_spread`, `iron_condor`, `iron_butterfly`, `calendar_spread`, `diagonal_spread`, `straddle`, `strangle`, `butterfly`. See `server/routers/omega0.ts` and `TRADE_STRATEGIES_COMPLETE.md`.

---

## Market Scanner

| Procedure | Type | Description |
|-----------|------|-------------|
| `marketScanner.scan` | query | Trigger full scan (Yahoo Finance). Returns opportunities array |
| `marketScanner.getTopOpportunities` | query | Top N by composite score. Input: `count?, minScore?, minWinProbability?, structureType?, regime?, symbolSearch?` |
| `marketScanner.getKnownStrategies` | query | Strategy types + regimes for filter dropdowns |

**Composite score:** score (32%) + win prob (38%) + expected return (22%) + signal confidence (18%) + growth bias + regime stability (0–100).

---

## Auto Trading

| Procedure | Type | Description |
|-----------|------|-------------|
| `autoTrading.getState` | query | Engine state: isRunning, positions, regime, lastOpportunities, strategyType, aggressionTier |
| `autoTrading.start` | mutation | Start auto-trading engine |
| `autoTrading.stop` | mutation | Stop engine |
| `autoTrading.setStrategy` | mutation | Set strategy: `adaptive` \| `wheel` \| `short_term` \| `iron_condor` |

---

## Backtest

| Procedure / Function | Description |
|----------------------|-------------|
| `runBacktest(config)` | Server: `server/backtest-runner.ts`. Config: `strategy, symbols?, startDate?, endDate?, initialCapital, maxPositions`. Returns: `simulatedTrades, opportunitiesEvaluated, structureSummary, sharpeRatio?, maxDrawdownPercent?, winRate?, profitFactor?, seed?, configSnapshot?` |
| `runWalkForward(config)` | Walk-forward stub. Config: `trainDays, testDays, stepDays, strategy, initialCapital`. Requires historical series for full implementation |

---

## Environment (10/10 plug points)

| Variable | Description |
|----------|-------------|
| `ENTRY_PROBABILITY_THRESHOLD` | 0–1. Default 0.65. Only enter when entry probability ≥ this |
| `SENTIMENT_API_URL` | GET `?symbol=XXX` returns `{ score, strength }`. If unset, sentiment stub (neutral) |
| `TWS_HOST`, `TWS_PORT` | IB Gateway for live/paper execution |

---

See also: `TRADE_STRATEGIES_COMPLETE.md`, `RUNBOOK.md`, `README.md`.
