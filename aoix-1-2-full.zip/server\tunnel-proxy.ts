import net from 'net';
import https from 'https';

/**
 * TCP to HTTPS Proxy
 * Converts TCP connections to HTTPS requests to LocalTunnel
 */

const TUNNEL_HOST = 'six-stars-laugh.loca.lt';
const LOCAL_PORT = 9001; // Port for AOIX-1 to connect to

const server = net.createServer((socket) => {
  console.log('[Tunnel Proxy] Client connected');

  const req = https.request({
    hostname: TUNNEL_HOST,
    port: 443,
    path: '/',
    method: 'CONNECT',
    headers: {
      'Connection': 'Upgrade',
    },
  }, (res) => {
    console.log('[Tunnel Proxy] Connected to tunnel');
  });

  req.on('upgrade', (res, socket2, head) => {
    console.log('[Tunnel Proxy] Upgrade successful');
    
    // Pipe data both ways
    socket.pipe(socket2);
    socket2.pipe(socket);

    socket.on('end', () => {
      console.log('[Tunnel Proxy] Client disconnected');
      socket2.destroy();
    });

    socket2.on('end', () => {
      console.log('[Tunnel Proxy] Tunnel disconnected');
      socket.destroy();
    });

    socket.on('error', (err) => {
      console.error('[Tunnel Proxy] Socket error:', err);
      socket2.destroy();
    });

    socket2.on('error', (err) => {
      console.error('[Tunnel Proxy] Tunnel error:', err);
      socket.destroy();
    });
  });

  req.on('error', (err) => {
    console.error('[Tunnel Proxy] Request error:', err);
    socket.destroy();
  });

  socket.on('data', (data) => {
    req.write(data);
  });

  socket.on('end', () => {
    req.end();
  });

  req.end();
});

server.listen(LOCAL_PORT, 'localhost', () => {
  console.log(`[Tunnel Proxy] Listening on localhost:${LOCAL_PORT}`);
  console.log(`[Tunnel Proxy] Forwarding to ${TUNNEL_HOST}`);
});

server.on('error', (err) => {
  console.error('[Tunnel Proxy] Server error:', err);
});
