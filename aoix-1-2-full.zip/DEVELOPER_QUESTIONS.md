# Questions for Your Developer / Team

Use this list to figure out where the app stands and what needs to happen next. **Copy-paste the questions to your developer, then fill in the "Answers" section below (or in a separate doc) and use that to drive an action plan.**

---

## Questions to Ask Your Developer

### **Current State**
1. **Can you run the app right now?** (`npm run dev` → `http://localhost:3000`)
   - Does it start without errors?
   - Can you log in?

2. **What parts are actually working?**
   - Can you scan for market opportunities?
   - Can you place a paper trade (without TWS)?
   - Can you see trades on the Execution page?
   - Can you see System Health without errors?

3. **What's broken or not working?**
   - Which specific page/feature fails?
   - What error message do you see (or just "nothing happens")?
   - Does it fail every time or sometimes?

### **Infrastructure & Setup**
4. **What backend services are running?**
   - Is the Express backend running? (Should be on same localhost:3000)
   - Is the SQLite database connected?
   - Is Yahoo Finance data connection working?
   - Is Omega-0 (paper trading) running?

5. **Do you have TWS/IB Gateway?**
   - Is IB Gateway installed and running?
   - What host:port is it on?
   - Has anyone tried to connect it yet?

6. **What's the database state?**
   - Is there test data in it?
   - Do you need to seed it with sample trades/users?
   - Is Drizzle ORM migrated?

### **What Needs to Happen Next**
7. **What's your immediate goal?**
   - Just get the app running and working for paper trades?
   - Get auto-trading working?
   - Get TWS/live trading working?
   - Deploy it somewhere?

8. **What's the priority order?**
   - Which feature matters most right now?
   - Which can wait?

9. **Who needs to do what?**
   - Who's building the frontend?
   - Who's maintaining the backend?
   - Who's testing it?

### **Known Issues or Blockers**
10. **Are there any known bugs or blockers?**
    - Specific error messages in console/logs?
    - Features that are stubbed out / not implemented yet?
    - Performance issues?

11. **Are there parts of the code that aren't done?**
    - Unfinished routers/endpoints?
    - Missing database migrations?
    - Incomplete UI components?

---

## Answers (from codebase + fixes applied)

| # | Question topic | Answer / notes |
|---|----------------|----------------|
| **1** | **App runs / login** | **Yes.** `npm run dev` starts Express + Vite on same host (e.g. http://localhost:3000). Windows prod start uses `cross-env NODE_ENV=production`. Login: demo user via `auth.login` (name/email optional); session cookie set. No separate API port. |
| **2** | **What's working** | **Market scan** (Yahoo via marketScanner.scan / getTopOpportunities). **Paper trade** (omega0.placeOrder from Trade Now dialog with contracts). **Execution page** shows manual open positions + recent trades and auto-trading engine positions/trades; Close buttons work. **System Health** (system.health) works; getDataCache fixed. **Auto Trading** page: start/stop engine, state, performance, positions, trades, unrealized/total P&L. **Trade Now** opens dialog, Place order sends order; positions appear on Execution. |
| **3** | **What's broken** | **Nothing critical** after fixes. TWS shows "Disconnected" unless IB Gateway is running at configured host:port — that's expected; paper trading works without it. Engine Daily P&L is $0 until a position closes (by design); Unrealized P&L and Total P&L show dynamic values when there are open positions. |
| **4** | **Backend services** | **Express** runs on same port as frontend (e.g. 3000). **SQLite** via Drizzle — optional; app works without DB (demo user in-memory, paper trades in-memory only; DB used for persist). **Yahoo** (real-market-data) used for scan and option price fallback. **Omega-0** is in-memory paper trading + optional dbTradeService persist. **Auto-trading engine** runs in-process; auto-starts in dev. |
| **5** | **TWS/IB Gateway** | **Optional.** Used only for live option chains and live data. Default: localhost:4001. Configure via Auto Trading → TWS card → gear → Host + Port → "Configure & Connect". Connection works only if IB Gateway (or TWS) is actually running at that URL. Paper trading and Yahoo data work without TWS. |
| **6** | **Database state** | **Drizzle ORM**; schema in drizzle/. Used for users (auth), trade persist (omega0, auto-trading). Can run with empty DB: demo user created on login; paper trades in-memory unless persist is on. Migrations: run `npx drizzle-kit push` or equivalent if schema changed. No required seed for basic paper trading. |
| **7** | **Immediate goal** | **Paper trading + Execution working** (done). Optional: auto-trading running, TWS connected for live data, then deploy. |
| **8** | **Priority order** | (1) App runs + paper trades + Execution visible. (2) Auto-trading start/stop + positions/trades. (3) TWS if you need live option data. (4) Deploy. |
| **9** | **Who does what** | **Owner to assign.** Frontend: client/src (React, wouter, tRPC). Backend: server/ (Express, tRPC routers, omega0, auto-trading-engine, market-scanner, ib-market-data). DB: drizzle/ + server/db. |
| **10** | **Known bugs/blockers** | **Fixed in this codebase:** Trade Now missing openTradeDialog + Dialog (added). Option P&L used underlying price → fake huge P&L (fixed: use option premium via getCurrentOptionPrice). $NaN for account/P&L (safeNum/fmtMoney). TWS Configure not changing connection (getIBGatewayUrl from TWS_HOST/TWS_PORT). getDataCache not a function (exported getDataCache). Overlapping TWS card (layout + hint below). **Remaining:** TWS stays disconnected if no IB Gateway at host:port. Engine performance metrics 0 until there are closed trades. |
| **11** | **Unfinished parts** | **Routers** (market, regime, signals, structures, risk, execution, trades, metaIntelligence, failures, shadowSystem, correlations) exist and read from DB — may return empty if DB not populated; core flows (omega0, autoTrading, marketScanner, twsConnection) are implemented. **Execution Interface** page exists at /execution/interface. **Migrations** — ensure Drizzle schema is pushed/migrated if you rely on persist. **UI** — all main pages (Auto Trading, Recommendations, Execution, System Health) are wired; some dashboards (Regime, Signals, etc.) may show empty data until DB or services are populated. |

---

## Once You Have Answers

You can use the responses to:

- **Write a quick start guide** for your specific setup
- **Create a debug checklist** for what to check when things break
- **Identify missing pieces** and prioritize what to build next
- **Suggest test data** to make manual testing easier
- **Create a deployment plan** if that's needed

Share the filled-in answers (or a summary) and you can get a clear action plan tailored to your situation.
