/**
 * Portfolio Greeks — calculation, imbalance check, hedge suggestion.
 * Run: pnpm test -- --grep "greek"
 */
import { describe, it, expect } from "vitest";
import {
  updatePortfolioGreeks,
  checkGreeksImbalance,
  suggestDeltaHedge,
  getPortfolioGreeks,
  type PortfolioGreeks,
  type GreeksImbalance,
} from "./portfolio-greeks-tracker";

describe("greek — portfolio Greeks calculation", () => {
  it("greek: updatePortfolioGreeks aggregates delta, gamma, vega, theta", () => {
    const positions = [
      { symbol: "SPY", delta: 0.5, gamma: 0.02, vega: 10, theta: -5, quantity: 1, action: "BUY" },
      { symbol: "SPY", delta: -0.3, gamma: 0.01, vega: -5, theta: 3, quantity: 1, action: "SELL" },
    ];
    const greeks = updatePortfolioGreeks(positions);
    expect(greeks).toHaveProperty("delta");
    expect(greeks).toHaveProperty("gamma");
    expect(greeks).toHaveProperty("vega");
    expect(greeks).toHaveProperty("theta");
    expect(greeks).toHaveProperty("timestamp");
    // BUY 0.5 => +0.5; SELL -0.3 => q=-1 so (-0.3)*(-1)=+0.3 => total 0.8
    expect(greeks.delta).toBeCloseTo(0.8, 4);
  });

  it("greek: updatePortfolioGreeks scales by quantity and action (SELL = -1)", () => {
    const positions = [
      { symbol: "SPY", delta: 0.5, gamma: 0, vega: 0, theta: 0, quantity: 2, action: "BUY" },
    ];
    const greeks = updatePortfolioGreeks(positions);
    expect(greeks.delta).toBe(1); // 0.5 * 2
  });

  it("greek: getPortfolioGreeks returns cached Greeks or null", () => {
    updatePortfolioGreeks([{ symbol: "SPY", delta: 0.5, quantity: 1, action: "BUY" }]);
    const greeks = getPortfolioGreeks("default");
    expect(greeks).toBeDefined();
    expect(greeks).toHaveProperty("delta");
    expect(greeks!.delta).toBe(0.5);
  });
});

describe("greek — Greeks imbalance detection", () => {
  it("greek: checkGreeksImbalance returns list of issues when over threshold", () => {
    updatePortfolioGreeks([
      { symbol: "SPY", delta: 60, gamma: 0, vega: 0, theta: 0, quantity: 1, action: "BUY" },
    ]);
    const issues = checkGreeksImbalance("default", { maxDeltaAbsolute: 50 });
    expect(Array.isArray(issues)).toBe(true);
    const deltaIssue = issues.find((i) => i.dimension === "delta");
    if (deltaIssue) {
      expect(deltaIssue.status).toMatch(/warning|critical/);
      expect(deltaIssue.current).toBe(60);
    }
  });

  it("greek: checkGreeksImbalance returns empty when within limits", () => {
    updatePortfolioGreeks([
      { symbol: "SPY", delta: 10, gamma: 5, vega: 100, theta: -50, quantity: 1, action: "BUY" },
    ]);
    const issues = checkGreeksImbalance("default", {
      maxDeltaAbsolute: 50,
      maxGammaAbsolute: 20,
      maxVegaAbsolute: 500,
      maxThetaAbsolute: 200,
    });
    expect(Array.isArray(issues)).toBe(true);
  });

  it("greek: suggestDeltaHedge returns hedge size and direction to reach target delta", () => {
    updatePortfolioGreeks([
      { symbol: "SPY", delta: 50, gamma: 0, vega: 0, theta: 0, quantity: 1, action: "BUY" },
    ]);
    const suggestion = suggestDeltaHedge("default", 0);
    expect(suggestion).toBeDefined();
    expect(suggestion).toHaveProperty("hedgeSize");
    expect(suggestion).toHaveProperty("direction");
    expect(["BUY", "SELL"]).toContain(suggestion.direction);
  });
});

describe("greek — Greeks accuracy", () => {
  it("greek: portfolio delta sum is sum of position deltas * quantity * direction", () => {
    const positions = [
      { symbol: "SPY", delta: 0.5, gamma: 0, vega: 0, theta: 0, quantity: 2, action: "BUY" },
      { symbol: "SPY", delta: 0.5, gamma: 0, vega: 0, theta: 0, quantity: 1, action: "SELL" },
    ];
    const greeks = updatePortfolioGreeks(positions);
    expect(greeks.delta).toBe(0.5); // 0.5*2 - 0.5*1
  });

  it("greek: empty positions yields zero Greeks", () => {
    const greeks = updatePortfolioGreeks([]);
    expect(greeks.delta).toBe(0);
    expect(greeks.gamma).toBe(0);
    expect(greeks.vega).toBe(0);
    expect(greeks.theta).toBe(0);
  });
});
