#!/usr/bin/env node
/**
 * IB Gateway connection diagnostic – run this when "nothing works".
 * Usage: node scripts/check-ib-gateway.js   (or: pnpm run check:gateway)
 */
import { config } from "dotenv";
import { existsSync } from "fs";
import { dirname, join, resolve } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const projectRoot = resolve(__dirname, "..");
const envLocalPath = join(projectRoot, ".env.local");

console.log("\n--- IB Gateway check ---\n");
console.log("Project root:", projectRoot);
console.log(".env.local path:", envLocalPath);
console.log(".env.local exists:", existsSync(envLocalPath));

if (!existsSync(envLocalPath)) {
  console.log("\n>>> FIX: Create .env.local in the project root (same folder as package.json).");
  console.log("    Copy .env.local.example to .env.local, then add:");
  console.log("    TWS_PORT=5000");
  console.log("    IB_GATEWAY_COOKIE=api=YOUR_VALUE  (get from browser after logging in at http://localhost:5000)\n");
  process.exit(1);
}

const loadResult = config({ path: envLocalPath, override: true });
if (loadResult.error) {
  console.log("\n>>> FIX: Error loading .env.local:", loadResult.error.message);
  process.exit(1);
}

const port = (process.env.TWS_PORT || "5000").trim();
const host = (process.env.TWS_HOST || "localhost").trim();
const cookie = process.env.IB_GATEWAY_COOKIE?.trim();
const gatewayUrl = `http://${host}:${port}/v1/api`;

console.log("TWS_HOST:", host);
console.log("TWS_PORT:", port);
console.log("IB_GATEWAY_COOKIE set:", !!cookie);
console.log("Gateway URL:", gatewayUrl);

async function check() {
  const url = `${gatewayUrl}/iserver/accounts`;
  const headers = {
    "User-Agent": "AOIX-1-check/1.0",
    Accept: "*/*",
  };
  if (cookie) headers["Cookie"] = cookie;

  try {
    const res = await fetch(url, { headers, redirect: "manual" });
    const status = res.status;
    let body = "";
    try {
      body = await res.text();
    } catch (_) {}

    console.log("\nGateway response:", status, res.statusText);

    if (status === 200) {
      console.log("\n>>> Gateway is OK. In the app, click Connect. If it still fails, restart the app (Ctrl+C, pnpm dev) and try again.\n");
      return;
    }
    if (status === 401 || status === 302) {
      console.log("\n>>> 401 Unauthorized – Gateway needs your session cookie.");
      if (!cookie) {
        console.log("    1. Open http://localhost:5000 in your browser and log in (with 2FA if asked).");
        console.log("    2. Press F12 → Application → Cookies → http://localhost:5000");
        console.log("    3. Copy the value of the cookie named 'api'");
        console.log("    4. In .env.local add: IB_GATEWAY_COOKIE=api=PASTE_THE_VALUE_HERE");
        console.log("    5. Run this script again, then restart the app (Ctrl+C, pnpm dev).\n");
      } else {
        console.log("    Cookie is set but may be wrong or expired. Log in again at http://localhost:5000, copy the new 'api' cookie, update .env.local, restart app.\n");
      }
      return;
    }
    if (status === 429) {
      console.log("\n>>> 429 Rate limit – Gateway is throttling. Wait 2 minutes, then run this script again. Do not click Connect repeatedly.\n");
      return;
    }
    if (status === 400) {
      console.log("\n>>> 400 – Gateway session not ready. Log in at http://localhost:5000, wait until the Client Portal page loads, then set IB_GATEWAY_COOKIE and restart.\n");
      return;
    }
    console.log("\n>>> Gateway returned", status, "– Ensure you are logged in at http://localhost:5000. Set IB_GATEWAY_COOKIE in .env.local and restart.\n");
  } catch (err) {
    console.log("\n>>> Cannot reach Gateway:", err.message || err);
    console.log("    1. Start the Client Portal Gateway app (from Interactive Brokers).");
    console.log("    2. Open http://localhost:5000 in your browser and log in.");
    console.log("    3. Then set IB_GATEWAY_COOKIE in .env.local (copy 'api' cookie from F12 → Application → Cookies) and run this script again.\n");
  }
}

check();
