/**
 * Automated "8 Quick Manual Tests" — no browser, no manual steps.
 * Runs against a live server (start with pnpm dev) or auto-starts when E2E_SERVER_URL is not set.
 *
 * Run: pnpm test:smoke
 * Or with existing server: E2E_SERVER_URL=http://localhost:3001 pnpm test:smoke
 */
import { describe, it, expect, beforeAll, afterAll } from "vitest";
import type { Server } from "node:http";

const E2E_PORT = process.env.E2E_PORT || "3021";
let serverUrl = process.env.E2E_SERVER_URL?.replace(/\/$/, "") || "";
let e2eServer: Server | null = null;

async function waitForHealth(baseUrl: string, maxWaitMs = 15_000): Promise<boolean> {
  const start = Date.now();
  while (Date.now() - start < maxWaitMs) {
    try {
      const res = await fetch(`${baseUrl}/api/health`, { method: "GET" });
      if (res.ok) return true;
    } catch {
      // ignore
    }
    await new Promise((r) => setTimeout(r, 300));
  }
  return false;
}

function base() {
  return serverUrl || `http://localhost:${E2E_PORT}`;
}

function trpcData(res: unknown): unknown {
  if (Array.isArray(res)) {
    const first = res[0] as { result?: { data?: unknown; json?: unknown } };
    return first?.result?.data ?? first?.result?.json;
  }
  const r = res as { result?: { data?: { json?: unknown }; json?: unknown }; data?: unknown };
  const data = r?.result?.data ?? r?.result?.json ?? r?.data;
  if (data && typeof data === "object" && "json" in data) return (data as { json: unknown }).json;
  return data;
}

async function trpcPost(
  path: string,
  input: unknown,
  headers: Record<string, string> = {}
): Promise<Response> {
  return fetch(`${base()}/api/trpc/${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...headers },
    body: JSON.stringify({ json: input }),
  });
}

/** Call opportunity.getTodayOpportunities via server-side caller (avoids Express GET input parsing). */
async function callGetTodayOpportunities(runScanIfEmpty: boolean, topN: number) {
  const { appRouter } = await import("../routers.js");
  const { createContext } = await import("../_core/context.js");
  const mockReq = { headers: {}, url: "/" } as any;
  const mockRes = { getHeader: () => undefined, setHeader: () => {}, cookie: () => {}, clearCookie: () => {} } as any;
  const ctx = await createContext({ req: mockReq, res: mockRes });
  const caller = appRouter.createCaller(ctx);
  return caller.opportunity.getTodayOpportunities({ runScanIfEmpty, topN });
}

beforeAll(async () => {
  if (process.env.E2E_SERVER_URL) {
    serverUrl = process.env.E2E_SERVER_URL.replace(/\/$/, "");
    const ok = await waitForHealth(serverUrl, 10_000);
    if (!ok) throw new Error(`E2E_SERVER_URL ${serverUrl} not ready (GET /api/health failed)`);
    return;
  }
  const prevPort = process.env.PORT;
  const prevNodeEnv = process.env.NODE_ENV;
  process.env.PORT = E2E_PORT;
  process.env.NODE_ENV = "test";
  const { startServerForE2E } = await import("../_core/index.js");
  const { server, port } = await startServerForE2E();
  e2eServer = server;
  serverUrl = `http://localhost:${port}`;
  if (prevPort !== undefined) process.env.PORT = prevPort;
  else delete process.env.PORT;
  if (prevNodeEnv !== undefined) process.env.NODE_ENV = prevNodeEnv;
  else delete process.env.NODE_ENV;
  const ok = await waitForHealth(serverUrl, 15_000);
  if (!ok) {
    e2eServer?.close();
    e2eServer = null;
    throw new Error(`E2E server did not respond at ${serverUrl}`);
  }
}, 30_000);

afterAll(async () => {
  if (e2eServer) {
    await new Promise<void>((resolve) => {
      e2eServer!.close(() => {
        e2eServer = null;
        resolve();
      });
    });
  }
});

describe("Smoke — 8 automated checks (no manual browser)", () => {
  // 1) Start server — covered by beforeAll
  it("1. Server is up and health returns ok", async () => {
    const res = await fetch(`${base()}/api/health`, { method: "GET" });
    expect(res.ok).toBe(true);
    const data = (await res.json()) as { ok?: boolean; readyForTrade?: boolean };
    expect(typeof data?.readyForTrade).toBe("boolean");
  });

  // 2) Open dashboard — GET / returns 200 and HTML (or 404 when client not built in E2E)
  it("2. Dashboard (/) returns 200 and HTML", async () => {
    const res = await fetch(`${base()}/`, { method: "GET", redirect: "manual" });
    const text = await res.text();
    expect([200, 404]).toContain(res.status);
    expect(text.length).toBeGreaterThan(0);
    if (res.status === 200) {
      expect(text.toLowerCase()).toMatch(/<!DOCTYPE html|<html|root|aoix|react/i);
    }
  });

  // 3) Load Today's Opportunity — getTodayOpportunities (no full scan to avoid timeout)
  it("3. Today's Opportunity API returns data or empty list", { timeout: 15_000 }, async () => {
    const data = await callGetTodayOpportunities(false, 5);
    expect(data?.success).toBe(true);
    expect(Array.isArray(data?.opportunities)).toBe(true);
    expect(typeof data?.timestamp).toBe("number");
  });

  // 4) Validate with Claude — validateTrade (may skip if no API key; we only check it doesn’t crash)
  it("4. Validate trade API responds (approve/reject/modify or not configured)", { timeout: 45_000 }, async () => {
    const input = {
      tier: "conservative" as const,
      symbol: "AAPL",
      structureType: "iron_condor",
      direction: "neutral",
      impliedMovePercent: 2,
      historicalMovePercent: 1.5,
      moveComparison: "implied_above_historical",
      catalystSummary: "E2E smoke test",
      tierScore: 0.7,
      winProbability: 0.65,
      expectedReturn: 0.1,
      currentPrice: 150,
      regime: "low_vol",
    };
    const res = await trpcPost("opportunity.validateTrade", input);
    expect(res.status).toBe(200);
    const body = (await res.json()) as unknown;
    const data = trpcData(body) as { success?: boolean; validation?: { verdict?: string; reason?: string } };
    expect(data?.success).toBe(true);
    const verdict = data?.validation?.verdict;
    expect(["approve", "reject", "modify"].includes(verdict ?? "") || (verdict === undefined && data?.validation?.reason)).toBe(true);
  });

  // 5) Place an order (paper) — login then placeOrder; illiquid symbol may reject, we accept both
  it("5. Place order API accepts request (paper or illiquid rejection)", { timeout: 30_000 }, async () => {
    const loginRes = await trpcPost("auth.login", { name: "Smoke User", email: "smoke@aoix.local" }, { redirect: "manual" } as any);
    expect(loginRes.ok).toBe(true);
    const cookie = loginRes.headers.get("set-cookie");
    const authHeaders: Record<string, string> = cookie ? { Cookie: cookie.split(";")[0]! } : {};

    const orderRes = await trpcPost(
      "omega0.placeOrder",
      {
        symbol: "AAPL",
        expiry: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
        strike: 150,
        optionType: "C",
        action: "BUY",
        quantity: 1,
        orderType: "MKT",
      },
      authHeaders
    );
    // 200 = order placed (paper); 4xx/5xx with message = rejected (e.g. illiquid) — both are valid API behavior
    const body = (await orderRes.json()) as unknown;
    const data = trpcData(body);
    const error = (body as { error?: { json?: { message?: string } } })?.error?.json?.message;
    if (orderRes.ok) {
      expect(data).toBeDefined();
    } else {
      expect(typeof error).toBe("string");
      expect(error!.length).toBeGreaterThan(0);
    }
  });

  // 6) Verify Execution — getStatus (already have auth from 5; reuse or login again)
  it("6. Execution / getStatus returns data", async () => {
    const loginRes = await trpcPost("auth.login", { name: "Smoke User", email: "smoke@aoix.local" }, { redirect: "manual" } as any);
    const cookie = loginRes.headers.get("set-cookie");
    const authHeaders: Record<string, string> = cookie ? { Cookie: cookie.split(";")[0]! } : {};

    const res = await fetch(`${base()}/api/trpc/omega0.getStatus`, { method: "GET", headers: authHeaders });
    expect(res.ok).toBe(true);
    const body = (await res.json()) as unknown;
    const data = trpcData(body);
    expect(data !== undefined).toBe(true);
  });

  // 7) Error handling — invalid input returns error or success (no crash)
  it("7. Error handling: invalid input returns error (no crash)", async () => {
    const res = await trpcPost("opportunity.validateTrade", {
      tier: "conservative",
      symbol: "", // invalid: min 1
      structureType: "x",
      direction: "x",
      impliedMovePercent: 1,
      historicalMovePercent: 1,
      moveComparison: "x",
      catalystSummary: "",
      tierScore: 0,
      winProbability: 0,
      expectedReturn: 0,
      currentPrice: 0,
      regime: "x",
    });
    const body = (await res.json()) as { error?: unknown; result?: unknown };
    // Server responded (no crash): either error in body or result
    expect(body?.error !== undefined || body?.result !== undefined).toBe(true);
  });

  // 8) Performance — Today's Opportunity load < 15s (generous for CI / cold scan)
  it("8. Performance: Today's Opportunity load within 15s", { timeout: 20_000 }, async () => {
    const start = Date.now();
    const data = await callGetTodayOpportunities(false, 5);
    const elapsed = Date.now() - start;
    expect(data?.success).toBe(true);
    expect(elapsed).toBeLessThan(15_000);
  });
});
