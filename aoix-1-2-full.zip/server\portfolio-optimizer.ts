/**
 * A+++ Pillar 4: Risk contribution & portfolio correlation.
 * Risk contribution %, correlation to existing positions, diversification score,
 * Greeks imbalance penalty (delta > 5000 or vega > 50000 → -15%).
 */

import { aggregatePortfolioRisk, type OpenPositionForRisk, type PortfolioRiskSnapshot } from './portfolio-risk';
import { calculatePortfolioCorrelation } from './market-utils';

export interface PositionForOptimizer {
  symbol: string;
  delta?: number;
  gamma?: number;
  theta?: number;
  vega?: number;
  quantity: number;
  entryPrice: number;
  structureType?: string;
  optionType?: 'C' | 'P';
  strike?: number;
}

export interface PortfolioOptimizerResult {
  /** Risk contribution % (this position's contribution to portfolio vol / notional). */
  riskContributionPct: number;
  /** Avg |correlation| to existing positions (0–1). */
  avgCorrelation: number;
  /** Diversification score: 1 - avgCorrelation * 0.7, +0.15 if uncorrelated. */
  diversificationScore: number;
  /** Alignment multiplier for composite: 0.85–1.15 (penalty if correlated or Greeks imbalanced). */
  alignmentMultiplier: number;
  /** Greeks imbalance penalty: true if portfolio delta > 5000 or vega > 50000. */
  greeksImbalance: boolean;
}

const DELTA_CAP = 5000;
const VEGA_CAP = 50000;
const CORR_HIGH_THRESHOLD = 0.7;
const CORR_MID_THRESHOLD = 0.5;

/**
 * Compute portfolio alignment for a new opportunity vs existing positions.
 * Uses correlation (symbol-level when available), risk contribution proxy, and Greeks caps.
 */
export async function getPortfolioAlignment(
  newSymbol: string,
  newDelta: number | undefined,
  existingPositions: PositionForOptimizer[],
  accountValue: number = 100_000
): Promise<PortfolioOptimizerResult> {
  if (existingPositions.length === 0) {
    return {
      riskContributionPct: 0,
      avgCorrelation: 0,
      diversificationScore: 1.15, // +0.15 uncorrelated
      alignmentMultiplier: 1.0,
      greeksImbalance: false,
    };
  }

  const symbols = Array.from(new Set(existingPositions.map(p => p.symbol))).slice(0, 15);
  let avgCorr = 0;
  try {
    avgCorr = await calculatePortfolioCorrelation(symbols, newSymbol);
  } catch {
    // Proxy from delta direction
    const existingDelta = existingPositions.reduce((s, p) => s + (p.delta ?? 0), 0);
    const sameDir = (existingDelta > 0 && (newDelta ?? 0) > 0) || (existingDelta < 0 && (newDelta ?? 0) < 0);
    avgCorr = sameDir ? 0.6 : 0.2;
  }

  const diversificationScore = avgCorr < 0.3 ? 1.15 : Math.max(0.5, 1 - avgCorr * 0.7);

  const openForRisk: OpenPositionForRisk[] = existingPositions.map(p => ({
    symbol: p.symbol,
    structureType: p.structureType,
    optionType: (p.optionType ?? 'C') as 'C' | 'P',
    action: 'BUY',
    quantity: p.quantity,
    entryPrice: p.entryPrice,
    strike: p.strike ?? 0,
  }));

  const snapshot: PortfolioRiskSnapshot = aggregatePortfolioRisk(openForRisk, accountValue, 1.0);
  const greeksImbalance = Math.abs(snapshot.totalDelta) > DELTA_CAP || Math.abs(snapshot.totalVega) > VEGA_CAP;

  let alignmentMultiplier = diversificationScore;
  if (avgCorr > CORR_HIGH_THRESHOLD) alignmentMultiplier *= 0.8;   // -20%
  else if (avgCorr > CORR_MID_THRESHOLD) alignmentMultiplier *= 0.92; // -8%
  if (greeksImbalance) alignmentMultiplier *= 0.85; // -15% spec

  const riskContributionPct = Math.min(100, (Math.abs(snapshot.totalDelta) * accountValue * 0.01) / accountValue * 100);

  return {
    riskContributionPct,
    avgCorrelation: Math.min(1, Math.abs(avgCorr)),
    diversificationScore,
    alignmentMultiplier: Math.max(0.85, Math.min(1.15, alignmentMultiplier)),
    greeksImbalance,
  };
}
