/**
 * E2E: health, full flow (login → scan → execution status).
 * Starts server in beforeAll when E2E_SERVER_URL is not set; otherwise uses existing server.
 * Run: pnpm test (server auto-started) or E2E_SERVER_URL=http://localhost:3000 pnpm test (use existing).
 */
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import type { Server } from 'node:http';

const E2E_PORT = process.env.E2E_PORT || '3020';
let serverUrl = process.env.E2E_SERVER_URL?.replace(/\/$/, '') || '';
let e2eServer: Server | null = null;

async function waitForHealth(baseUrl: string, maxWaitMs = 10_000): Promise<boolean> {
  const start = Date.now();
  while (Date.now() - start < maxWaitMs) {
    try {
      const res = await fetch(`${baseUrl}/api/health`, { method: 'GET' });
      if (res.ok) return true;
    } catch {
      // ignore
    }
    await new Promise((r) => setTimeout(r, 200));
  }
  return false;
}

function base() {
  return serverUrl || `http://localhost:${E2E_PORT}`;
}

/** Unwrap tRPC response (single or batch). */
function trpcData(res: unknown): unknown {
  if (Array.isArray(res)) {
    const first = res[0] as { result?: { data?: unknown; json?: unknown } };
    return first?.result?.data ?? first?.result?.json;
  }
  const r = res as { result?: { data?: { json?: unknown }; json?: unknown }; data?: unknown };
  const data = r?.result?.data ?? r?.result?.json ?? r?.data;
  if (data && typeof data === 'object' && 'json' in data) return (data as { json: unknown }).json;
  return data;
}

beforeAll(async () => {
  if (process.env.E2E_SERVER_URL) {
    serverUrl = process.env.E2E_SERVER_URL.replace(/\/$/, '');
    const ok = await waitForHealth(serverUrl, 5_000);
    if (!ok) throw new Error(`E2E_SERVER_URL ${serverUrl} not ready (GET /api/health failed)`);
    return;
  }
  const prevPort = process.env.PORT;
  const prevNodeEnv = process.env.NODE_ENV;
  process.env.PORT = E2E_PORT;
  process.env.NODE_ENV = 'test';
  const { startServerForE2E } = await import('../_core/index.js');
  const { server, port } = await startServerForE2E();
  e2eServer = server;
  serverUrl = `http://localhost:${port}`;
  if (prevPort !== undefined) process.env.PORT = prevPort; else delete process.env.PORT;
  if (prevNodeEnv !== undefined) process.env.NODE_ENV = prevNodeEnv; else delete process.env.NODE_ENV;
  const ok = await waitForHealth(serverUrl, 5_000);
  if (!ok) {
    e2eServer.close();
    e2eServer = null;
    throw new Error(`E2E server did not respond at ${serverUrl} (GET /api/health)`);
  }
}, 25_000);

afterAll(async () => {
  if (e2eServer) {
    await new Promise<void>((resolve) => {
      e2eServer!.close(() => {
        e2eServer = null;
        resolve();
      });
    });
  }
});

describe('E2E Health', () => {
  it('GET /api/health returns ok and readyForTrade', async () => {
    const res = await fetch(`${base()}/api/health`, { method: 'GET' });
    expect(res.ok).toBe(true);
    const data = (await res.json()) as { ok?: boolean; readyForTrade?: boolean; status?: string };
    expect(typeof data?.readyForTrade).toBe('boolean');
    expect(data?.status !== undefined || data?.ok !== undefined).toBe(true);
  });
});

describe('E2E Full flow', () => {
  it('login → scan → getStatus (auth + scan + execution)', { timeout: 120_000 }, async () => {
    const b = base();
    // 1) Login (get session cookie)
    const loginRes = await fetch(`${b}/api/trpc/auth.login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ json: { name: 'E2E User', email: 'e2e@aoix.local' } }),
      redirect: 'manual',
    });
    expect(loginRes.ok).toBe(true);
    const loginBody = (await loginRes.json()) as unknown;
    const loginData = trpcData(loginBody) as { user?: unknown };
    expect(loginData?.user).toBeDefined();
    const cookie = loginRes.headers.get('set-cookie');
    const authHeaders: Record<string, string> = cookie ? { Cookie: cookie.split(';')[0]! } : {};

    // 2) Scan (public; no auth required)
    const scanRes = await fetch(`${b}/api/trpc/marketScanner.scan`, { method: 'GET' });
    expect(scanRes.ok).toBe(true);
    const scanBody = (await scanRes.json()) as unknown;
    const scanData = trpcData(scanBody) as { success?: boolean; count?: number };
    expect(scanData?.success).toBe(true);
    expect(typeof scanData?.count).toBe('number');

    // 3) Execution status (protected; requires auth)
    const statusRes = await fetch(`${b}/api/trpc/omega0.getStatus`, {
      method: 'GET',
      headers: authHeaders,
    });
    expect(statusRes.ok).toBe(true);
    const statusBody = (await statusRes.json()) as unknown;
    const statusData = trpcData(statusBody);
    expect(statusData).toBeDefined();
  });
});
