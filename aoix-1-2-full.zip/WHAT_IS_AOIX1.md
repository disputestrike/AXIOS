# What is AOIX-1? Complete Guide

## 🎯 What is AOIX-1?

**AOIX-1** (Autonomous Options Intelligence Exchange) is a **fully autonomous trading system** that automatically scans markets, identifies trading opportunities, and executes options trades using real market data and real-time analysis.

Think of it as a **self-driving car for options trading** - it makes decisions, executes trades, and manages risk automatically, 24/7.

---

## 🏗️ What Does It Do?

### Core Capabilities

1. **Market Scanning** 📊
   - Scans 100+ stocks in real-time
   - Uses real market data from Yahoo Finance and IB Gateway
   - Identifies profitable trading opportunities
   - Ranks opportunities by profit probability (0-100%)

2. **Signal Generation** 🎯
   - Generates Class A/B/C/D trading signals
   - Analyzes dealer gamma, options flow, momentum
   - Calculates confidence scores for each signal
   - Tracks signal decay over time

3. **Autonomous Trading** 🤖
   - Automatically executes trades on high-confidence signals
   - Manages positions with take-profit and stop-loss
   - Respects risk limits (1% max risk per trade, 3 max positions)
   - Monitors and exits positions automatically

4. **Risk Management** 🛡️
   - Limits risk per trade to 1% of account
   - Maximum 3 positions at once
   - 5% daily loss limit (kill switch)
   - Automatic exits: +30% take profit, -20% stop loss, 10% trailing stop

5. **Real-Time Monitoring** 📈
   - Live dashboards showing all system components
   - Real-time P&L tracking
   - Position monitoring
   - System health checks

---

## 🔧 How Does It Work?

### Architecture

```
┌─────────────────────────────────────────────────────────┐
│              AOIX-1 Trading System                       │
│                                                           │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │ Market Scanner│  │Signal Engine │  │Risk Manager  │  │
│  │ (100+ stocks) │  │ (A/B/C/D)    │  │ (1% per trade)│  │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  │
│         │                  │                  │          │
│         └──────────────────┼──────────────────┘          │
│                            │                              │
│                   ┌────────▼────────┐                     │
│                   │ Trading Engine  │                     │
│                   │  (Auto Execute) │                     │
│                   └────────┬────────┘                     │
│                            │                              │
│         ┌──────────────────┼──────────────────┐          │
│         │                  │                  │          │
│  ┌──────▼──────┐  ┌───────▼──────┐  ┌───────▼──────┐  │
│  │ IB Gateway  │  │   Database   │  │  Dashboards  │  │
│  │ (Real Data) │  │ (Trade Hist) │  │  (Monitor)   │  │
│  └─────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────┘
```

### Data Flow

1. **Market Data Collection**
   - Fetches real stock prices from Yahoo Finance
   - Gets real options data from IB Gateway (if connected)
   - Calculates volatility, Greeks, and market metrics

2. **Opportunity Identification**
   - Analyzes each stock for trading signals
   - Calculates profit probability
   - Ranks opportunities by score

3. **Trade Execution**
   - Selects top opportunities (score ≥ 60%)
   - Validates risk limits
   - Executes trades through IB Gateway (paper or live)
   - Tracks positions in database

4. **Position Management**
   - Monitors open positions
   - Updates P&L with real prices
   - Executes exits at take-profit/stop-loss levels
   - Records all trades in database

---

## 👥 Who Is This For?

### Target Users

1. **Options Traders** 📈
   - Experienced traders who want automation
   - Traders who want to trade 24/7 without manual monitoring
   - Those who want systematic, rule-based trading

2. **Quantitative Traders** 🔬
   - Traders who use algorithmic strategies
   - Those who want backtested, systematic approaches
   - Traders who value data-driven decisions

3. **Risk-Conscious Traders** 🛡️
   - Traders who want strict risk management
   - Those who want automated position sizing
   - Traders who want kill switches and safety limits

4. **Tech-Savvy Traders** 💻
   - Traders comfortable with technology
   - Those who want to customize and extend the system
   - Developers who want to build on the platform

### Who Should NOT Use This

- ❌ Complete beginners (requires options trading knowledge)
- ❌ Traders who want full manual control
- ❌ Those uncomfortable with automated trading
- ❌ Traders without Interactive Brokers account

---

## 🚀 How to Use It

### Prerequisites

1. **Interactive Brokers Account**
   - Paper trading account (for testing)
   - Live account (for real trading)
   - Options trading enabled

2. **IB Gateway**
   - Download from Interactive Brokers
   - Install and configure API (port 4001)
   - Enable API access

3. **Technical Requirements**
   - Node.js 22+
   - pnpm package manager
   - MySQL/TiDB database (or connection string)

### Setup Steps

1. **Install Dependencies**
   ```bash
   pnpm install
   ```

2. **Configure Environment**
   ```bash
   cp .env.local.example .env.local
   # Edit .env.local with your credentials
   ```

3. **Run Database Migrations**
   ```bash
   pnpm db:push
   ```

4. **Start IB Gateway**
   - Launch IB Gateway
   - Log in to your account
   - Enable API on port 4001

5. **Start AOIX-1**
   ```bash
   pnpm dev
   ```

6. **Access Dashboard**
   - Open http://localhost:5173
   - Navigate to Auto Trading page
   - Click "Start Engine"

### Basic Workflow

1. **Monitor System Health**
   - Check System Health dashboard
   - Verify IB Gateway connection
   - Ensure all components are green

2. **Scan for Opportunities**
   - Go to Market Opportunities page
   - Click "Scan Market"
   - Review top 20 opportunities

3. **Start Auto Trading**
   - Go to Auto Trading page
   - Click "Start Engine"
   - Monitor as it executes trades automatically

4. **Monitor Performance**
   - Watch P&L in real-time
   - Check open positions
   - Review trade history

---

## 📊 Key Features Explained

### 1. Market Scanner

**What it does:**
- Scans 100+ stocks every 5 minutes
- Fetches real prices from Yahoo Finance
- Calculates trading signals for each stock
- Ranks opportunities by profit probability

**How to use:**
- Navigate to Market Opportunities page
- Click "Scan Market" button
- Review ranked opportunities
- Click "Trade Now" on any opportunity

### 2. Signal Classification

**Class A (Structural)** - Long-term regime signals
- Confidence: 80-100%
- Based on market structure and regime
- Highest conviction trades

**Class B (Flow)** - Options flow anomalies
- Confidence: 70-90%
- Based on unusual options activity
- Strong directional signals

**Class C (Momentum)** - Price momentum signals
- Confidence: 60-80%
- Based on price trends
- Medium-term trades

**Class D (Catalyst)** - Event-driven signals
- Confidence: 50-70%
- Based on news/events
- Short-term trades

### 3. Risk Management

**Position Sizing:**
- Maximum 1% risk per trade
- Maximum 3 positions at once
- Automatic position sizing based on account value

**Exit Rules:**
- Take Profit: +30% automatic exit
- Stop Loss: -20% automatic exit
- Trailing Stop: 10% locks in profits

**Kill Switch:**
- Activates if daily loss exceeds 5%
- Activates if ruin probability > 10%
- Stops all trading immediately

### 4. Dashboards

**Auto Trading Dashboard:**
- Engine status (running/stopped)
- Current positions
- Real-time P&L
- Recent trades
- Performance metrics

**Market Opportunities:**
- Top 20 ranked opportunities
- Signal details
- Recommended structures
- One-click trading

**System Health:**
- Component status
- Response times
- Error tracking
- Connection status

---

## 💰 Trading Modes

### Paper Trading (Recommended for Testing)

**What it is:**
- Simulated trading with real market data
- No real money at risk
- Perfect for testing strategies
- Real market prices, simulated execution

**How to use:**
- Start IB Gateway in Paper Trading mode
- AOIX-1 automatically detects paper mode
- All trades are simulated
- Perfect for learning and testing

### Live Trading (Production)

**What it is:**
- Real money trading
- Real order execution through IB Gateway
- Actual positions in your account
- Real P&L

**How to use:**
- Start IB Gateway in Live Trading mode
- Ensure all tests pass in paper mode first
- Start with small position sizes
- Monitor closely initially

---

## 🔒 Safety Features

### Risk Limits (Cannot Be Overridden)

1. **1% Max Risk Per Trade**
   - System calculates position size automatically
   - Never risks more than 1% of account per trade

2. **3 Max Positions**
   - Limits exposure to 3 positions maximum
   - Prevents over-concentration

3. **5% Daily Loss Limit**
   - Kill switch activates at -5% daily loss
   - Stops all trading immediately

4. **Automatic Exits**
   - Take profit at +30%
   - Stop loss at -20%
   - Trailing stop at 10%

### Monitoring

- Real-time P&L tracking
- Position monitoring
- System health checks
- Error alerts
- Performance metrics

---

## 📈 Performance Metrics

The system tracks:

- **Win Rate** - % of profitable trades
- **Profit Factor** - Gross profit / Gross loss
- **Sharpe Ratio** - Risk-adjusted returns
- **Max Drawdown** - Largest peak-to-trough decline
- **Total P&L** - Cumulative profit/loss
- **Average Win/Loss** - Average trade sizes

---

## 🛠️ Technology Stack

### Frontend
- **React 19** - Modern UI framework
- **TypeScript** - Type-safe code
- **TailwindCSS** - Styling
- **tRPC** - Type-safe API calls

### Backend
- **Node.js** - Server runtime
- **Express** - Web server
- **tRPC** - API layer
- **Drizzle ORM** - Database access

### Database
- **MySQL/TiDB** - Data persistence
- Stores trades, market data, signals

### External Services
- **Yahoo Finance** - Stock prices (free)
- **IB Gateway** - Options data & execution
- **Polygon.io** - Optional market data

---

## 📚 Documentation

### Setup Guides
- `README.md` - Quick start guide
- `LOCAL_DEPLOYMENT.md` - Detailed setup
- `IB_GATEWAY_SETUP.md` - Gateway configuration
- `SETUP_CHECKLIST.md` - Step-by-step checklist

### Trading Guides
- `QUICKSTART.md` - Trading workflow
- `OMEGA_0_SETUP.md` - Execution layer setup

### Technical Docs
- `ANALYSIS_AND_IMPROVEMENT_PLAN.md` - System analysis
- `REMOVED_PLACEHOLDERS.md` - What was removed
- `CLEANUP_COMPLETE.md` - Cleanup summary

---

## ⚠️ Important Notes

### Disclaimer

- **Not Financial Advice** - This is a trading tool, not investment advice
- **Risk of Loss** - Trading involves risk of financial loss
- **Test First** - Always test in paper trading mode first
- **Monitor Closely** - Even automated systems need monitoring
- **Your Responsibility** - You are responsible for all trades

### Requirements

- **IB Account Required** - Must have Interactive Brokers account
- **Options Trading Enabled** - Account must allow options trading
- **Market Data Subscriptions** - May need data subscriptions for some symbols
- **Technical Knowledge** - Requires some technical setup knowledge

---

## 🎓 Learning Resources

### Understanding Options Trading

1. **Options Basics**
   - Calls vs Puts
   - Strike prices
   - Expiration dates
   - Greeks (Delta, Gamma, Theta, Vega)

2. **Trading Strategies**
   - Vertical spreads
   - Iron condors
   - Straddles/Strangles
   - Risk management

3. **Market Analysis**
   - Volatility analysis
   - Options flow
   - Dealer gamma
   - Regime classification

### Using AOIX-1

1. **Start with Paper Trading**
   - Learn the interface
   - Understand signals
   - Test strategies
   - Monitor performance

2. **Study the Dashboards**
   - Understand each metric
   - Learn what signals mean
   - Review trade history
   - Analyze performance

3. **Customize Settings**
   - Adjust risk parameters
   - Modify signal thresholds
   - Configure exit rules
   - Set up alerts

---

## 🚀 Getting Started Checklist

- [ ] Install Node.js 22+
- [ ] Install pnpm
- [ ] Set up Interactive Brokers account
- [ ] Download and install IB Gateway
- [ ] Configure IB Gateway API (port 4001)
- [ ] Clone/download AOIX-1 code
- [ ] Run `pnpm install`
- [ ] Create `.env.local` file
- [ ] Fill in all required environment variables
- [ ] Run `pnpm db:push` (database migrations)
- [ ] Start IB Gateway in Paper Trading mode
- [ ] Run `pnpm dev`
- [ ] Open http://localhost:5173
- [ ] Verify System Health dashboard
- [ ] Test Market Scanner
- [ ] Review opportunities
- [ ] Start Auto Trading engine (paper mode)
- [ ] Monitor for 24-48 hours
- [ ] Review performance
- [ ] Adjust settings as needed
- [ ] When ready, switch to Live Trading mode

---

## 💡 Tips for Success

1. **Start Small**
   - Test thoroughly in paper mode
   - Start with small position sizes
   - Gradually increase as you gain confidence

2. **Monitor Regularly**
   - Check system health daily
   - Review trade history
   - Analyze performance metrics
   - Adjust settings based on results

3. **Understand the Signals**
   - Learn what each signal class means
   - Understand confidence scores
   - Know when to trust signals
   - Recognize when to be cautious

4. **Respect Risk Limits**
   - Don't override risk limits
   - Trust the kill switch
   - Let take-profit/stop-loss work
   - Don't manually override exits

5. **Keep Learning**
   - Study market conditions
   - Understand why trades win/lose
   - Adjust strategies over time
   - Stay updated on market changes

---

## 📞 Support & Resources

### Documentation
- All guides in the project root
- Inline code comments
- Type definitions for API

### Troubleshooting
- Check System Health dashboard
- Review logs in `.manus-logs/` directory
- Verify IB Gateway connection
- Check environment variables

### Community
- Interactive Brokers API docs
- Options trading resources
- Quantitative trading forums

---

## 🎯 Summary

**AOIX-1** is a fully autonomous options trading system that:

✅ Scans 100+ stocks automatically  
✅ Identifies profitable opportunities  
✅ Executes trades automatically  
✅ Manages risk with strict limits  
✅ Monitors positions 24/7  
✅ Uses only real market data  
✅ Provides comprehensive dashboards  

**Perfect for:**
- Options traders who want automation
- Quantitative traders who want systematic strategies
- Risk-conscious traders who want strict limits
- Tech-savvy traders who want customization

**Requires:**
- Interactive Brokers account
- IB Gateway installed and configured
- Basic technical setup knowledge
- Options trading knowledge

**Start with:**
- Paper trading mode (testing)
- Small position sizes
- Close monitoring
- Gradual scaling

---

**Ready to get started?** Follow the setup checklist above and begin with paper trading mode!
