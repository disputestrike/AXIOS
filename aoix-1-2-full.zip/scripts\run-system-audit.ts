/**
 * Run System Audit — Produces Sections 1–7 (tables/JSON) for audit.
 * Usage: pnpm tsx scripts/run-system-audit.ts
 *        SCAN_FIRST=1 pnpm tsx scripts/run-system-audit.ts   # run market scan first
 * Writes: backtest-results/system-audit-YYYY-MM-DD.json, system-audit-YYYY-MM-DD.md
 */

import { runSystemAudit, type AuditTradeInput } from "../server/system-audit";
import { getMarketScanner } from "../server/market-scanner";
import { mkdir, writeFile } from "fs/promises";
import { join } from "path";

const TOP_N = 10;
const OUT_DIR = process.env.BACKTEST_RESULTS_DIR ?? join(process.cwd(), "backtest-results");

function opportunityToAuditTrade(opp: {
  symbol: string;
  regime?: string;
  signal?: { confidence?: number };
  opportunity?: { score?: number; expectedReturn?: number; winProbability?: number };
  structure?: { type?: string };
  impliedVolatility?: number;
  greeks?: { delta?: number; gamma?: number; theta?: number; vega?: number };
  currentPrice?: number;
}): AuditTradeInput {
  const structureType = (opp.structure?.type ?? "vertical_call_spread").toString().replace(/\s+/g, "_").toLowerCase();
  return {
    symbol: opp.symbol,
    structureType: structureType || "vertical_call_spread",
    optionType: "C",
    action: "BUY",
    quantity: 1,
    entryPrice: 2,
    strike: Math.round(opp.currentPrice ?? 100),
    score: opp.opportunity?.score ?? 0,
    confidence: opp.signal?.confidence ?? 0.7,
    expectedReturn: opp.opportunity?.expectedReturn ?? 0,
    winProbability: opp.opportunity?.winProbability ?? 0.5,
    regime: opp.regime ?? "neutral",
    impliedVolatility: opp.impliedVolatility ?? 25,
    greeks: opp.greeks,
    spreadWidth: 5,
    netCreditPerContract: 1.5 * 100,
  };
}

function reportToMarkdown(report: ReturnType<typeof runSystemAudit>): string {
  const lines: string[] = [
    "# System Audit Report",
    "",
    `**Generated:** ${report.timestamp}`,
    `**Trades audited:** ${report.tradesAudited}`,
    "",
    "---",
    "",
    "## Section 1 – Trade Risk / Reward Verification",
    "",
    "| Trade | Max Risk ($) | Max Profit ($) | Historical P/L | Assignment Risk (%) |",
    "|-------|--------------|----------------|----------------|---------------------|",
  ];
  for (const r of report.section1) {
    lines.push(`| ${r.trade} | ${r.maxRiskDollars} | ${r.maxProfitDollars} | ${r.historicalPnl ?? "—"} | ${r.assignmentRiskPercent} |`);
  }
  lines.push("", "## Section 2 – Probability Calibration", "");
  lines.push("| Trade | Score | Confidence | Historical Win Rate (%) | Avg Loss ($) | Max Loss ($) | Regime |");
  lines.push("|-------|-------|-------------|--------------------------|--------------|--------------|--------|");
  for (const r of report.section2) {
    lines.push(`| ${r.trade} | ${r.score} | ${r.confidence} | ${r.historicalWinRatePercent} | ${r.avgLossDollars} | ${r.maxLossDollars} | ${r.regime} |`);
  }
  lines.push("", "## Section 3 – Volatility and IV Analysis", "");
  lines.push("| Trade | IV Start | IV Exit | P/L @ IV−20% | P/L @ IV−50% | Delta | Gamma | Vega | Theta |");
  lines.push("|-------|----------|---------|--------------|--------------|-------|-------|------|-------|");
  for (const r of report.section3) {
    lines.push(`| ${r.trade} | ${r.ivStart} | ${r.ivExit} | ${r.plAtIvMinus20} | ${r.plAtIvMinus50} | ${r.delta} | ${r.gamma} | ${r.vega} | ${r.theta} |`);
  }
  lines.push("", "## Section 4 – Execution Realism", "");
  lines.push("| Trade | Bid/Ask Spread | Filled vs Theoretical | Open Interest | Avg Volume |");
  lines.push("|-------|----------------|------------------------|---------------|------------|");
  for (const r of report.section4) {
    lines.push(`| ${r.trade} | ${r.bidAskSpreadPct}% | ${r.filledVsTheoretical} | ${r.openInterest ?? "—"} | ${r.avgVolume ?? "—"} |`);
  }
  lines.push("", "## Section 5 – Portfolio Risk / Correlation", "");
  lines.push(`**Total dollar risk (VaR99):** ${report.section5.totalDollarRisk} | **VaR95:** ${report.section5.var95} | **Max drawdown:** ${report.section5.maxDrawdownPercent ?? "—"}%`, "");
  lines.push("| Trade Pair | Correlation | Combined Max Risk ($) |");
  lines.push("|------------|-------------|------------------------|");
  for (const r of report.section5.rows) {
    lines.push(`| ${r.tradePair} | ${r.correlation} | ${r.combinedMaxRiskDollars} |`);
  }
  lines.push("", "## Section 6 – Stress-Test / Crisis Simulation", "");
  lines.push("| Trade | Event | P/L | Margin Calls | Realized vs Theoretical |");
  lines.push("|-------|-------|-----|--------------|---------------------------|");
  for (const r of report.section6) {
    lines.push(`| ${r.trade} | ${r.event} | ${r.pl} | ${r.marginCalls} | ${r.realizedVsTheoretical} |`);
  }
  lines.push("", "## Section 7 – Explainability / Transparency", "");
  lines.push("| Trade | Score Reasoning | Expected Return Assumptions | Confidence Interval |");
  lines.push("|-------|-----------------|-----------------------------|---------------------|");
  for (const r of report.section7) {
    lines.push(`| ${r.trade} | ${r.scoreReasoning} | ${r.expectedReturnAssumptions} | ${r.confidenceInterval} |`);
  }
  lines.push("", "---", "", "## Methodology", "", report.methodology, "", "## Data Sources", "");
  report.dataSources.forEach((s) => lines.push(`- ${s}`));
  lines.push("", "## Assumptions", "");
  report.assumptions.forEach((s) => lines.push(`- ${s}`));
  return lines.join("\n");
}

async function main() {
  const scanFirst = process.env.SCAN_FIRST === "1" || process.env.SCAN_FIRST === "true";
  const scanner = getMarketScanner();

  if (scanFirst && scanner.getStatus().totalOpportunities === 0) {
    console.log("[System Audit] Running market scan first...");
    await scanner.scan();
  }

  const opportunities = scanner.getTopOpportunities(TOP_N);
  if (opportunities.length === 0) {
    console.warn("[System Audit] No opportunities in scanner. Use SCAN_FIRST=1 or run a scan first. Using mock trades.");
    const mockTrades: AuditTradeInput[] = [
      { symbol: "SPY", structureType: "vertical_call_spread", score: 85, confidence: 0.75, regime: "trending_bull", impliedVolatility: 18 },
      { symbol: "AAPL", structureType: "vertical_put_spread", score: 78, confidence: 0.7, regime: "mean_reverting", impliedVolatility: 22 },
    ];
    await runAndWrite(mockTrades);
  } else {
    const trades: AuditTradeInput[] = opportunities.map(opportunityToAuditTrade);
    console.log(`[System Audit] Auditing top ${trades.length} opportunities.`);
    await runAndWrite(trades);
  }
}

async function runAndWrite(trades: AuditTradeInput[]) {
  const report = runSystemAudit({ trades });
  const date = new Date().toISOString().slice(0, 10);
  await mkdir(OUT_DIR, { recursive: true });
  const jsonPath = join(OUT_DIR, `system-audit-${date}.json`);
  const mdPath = join(OUT_DIR, `system-audit-${date}.md`);
  await writeFile(jsonPath, JSON.stringify(report, null, 2), "utf-8");
  await writeFile(mdPath, reportToMarkdown(report), "utf-8");
  console.log("[System Audit] Wrote:", jsonPath);
  console.log("[System Audit] Wrote:", mdPath);
  process.exit(0);
}

main().catch((e) => {
  console.error("[System Audit] Error:", e);
  process.exit(1);
});
