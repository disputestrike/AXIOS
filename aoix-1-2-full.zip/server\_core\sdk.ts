import { AXIOS_TIMEOUT_MS, COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { ForbiddenError } from "@shared/_core/errors";
import axios, { type AxiosInstance } from "axios";
import { parse as parseCookieHeader } from "cookie";
import type { Request } from "express";
import { SignJWT, jwtVerify } from "jose";
import type { User } from "../../drizzle/schema";
import * as db from "../db";
import { ENV } from "./env";
import type {
  ExchangeTokenRequest,
  ExchangeTokenResponse,
  GetUserInfoResponse,
  GetUserInfoWithJwtRequest,
  GetUserInfoWithJwtResponse,
} from "./types/manusTypes";
// Utility function
const isNonEmptyString = (value: unknown): value is string =>
  typeof value === "string" && value.length > 0;

export type SessionPayload = {
  openId: string;
  appId: string;
  name: string;
};

const EXCHANGE_TOKEN_PATH = `/webdev.v1.WebDevAuthPublicService/ExchangeToken`;
const GET_USER_INFO_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfo`;
const GET_USER_INFO_WITH_JWT_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfoWithJwt`;

class OAuthService {
  constructor(private client: ReturnType<typeof axios.create>) {
    console.log("[OAuth] Initialized with baseURL:", ENV.oAuthServerUrl);
    if (!ENV.oAuthServerUrl) {
      console.error(
        "[OAuth] ERROR: OAUTH_SERVER_URL is not configured! Set OAUTH_SERVER_URL environment variable."
      );
    }
  }

  private decodeState(state: string): string {
    const redirectUri = atob(state);
    return redirectUri;
  }

  async getTokenByCode(
    code: string,
    state: string
  ): Promise<ExchangeTokenResponse> {
    const payload: ExchangeTokenRequest = {
      clientId: ENV.appId,
      grantType: "authorization_code",
      code,
      redirectUri: this.decodeState(state),
    };

    const { data } = await this.client.post<ExchangeTokenResponse>(
      EXCHANGE_TOKEN_PATH,
      payload
    );

    return data;
  }

  async getUserInfoByToken(
    token: ExchangeTokenResponse
  ): Promise<GetUserInfoResponse> {
    const { data } = await this.client.post<GetUserInfoResponse>(
      GET_USER_INFO_PATH,
      {
        accessToken: token.accessToken,
      }
    );

    return data;
  }
}

const createOAuthHttpClient = (): AxiosInstance =>
  axios.create({
    baseURL: ENV.oAuthServerUrl,
    timeout: AXIOS_TIMEOUT_MS,
  });

class SDKServer {
  private readonly client: AxiosInstance;
  private readonly oauthService: OAuthService;
  private _secretLogged: boolean = false;

  constructor(client: AxiosInstance = createOAuthHttpClient()) {
    this.client = client;
    this.oauthService = new OAuthService(this.client);
  }

  private deriveLoginMethod(
    platforms: unknown,
    fallback: string | null | undefined
  ): string | null {
    if (fallback && fallback.length > 0) return fallback;
    if (!Array.isArray(platforms) || platforms.length === 0) return null;
    const set = new Set<string>(
      platforms.filter((p): p is string => typeof p === "string")
    );
    if (set.has("REGISTERED_PLATFORM_EMAIL")) return "email";
    if (set.has("REGISTERED_PLATFORM_GOOGLE")) return "google";
    if (set.has("REGISTERED_PLATFORM_APPLE")) return "apple";
    if (
      set.has("REGISTERED_PLATFORM_MICROSOFT") ||
      set.has("REGISTERED_PLATFORM_AZURE")
    )
      return "microsoft";
    if (set.has("REGISTERED_PLATFORM_GITHUB")) return "github";
    const first = Array.from(set)[0];
    return first ? first.toLowerCase() : null;
  }

  /**
   * Exchange OAuth authorization code for access token
   * @example
   * const tokenResponse = await sdk.exchangeCodeForToken(code, state);
   */
  async exchangeCodeForToken(
    code: string,
    state: string
  ): Promise<ExchangeTokenResponse> {
    return this.oauthService.getTokenByCode(code, state);
  }

  /**
   * Get user information using access token
   * @example
   * const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
   */
  async getUserInfo(accessToken: string): Promise<GetUserInfoResponse> {
    const data = await this.oauthService.getUserInfoByToken({
      accessToken,
    } as ExchangeTokenResponse);
    const loginMethod = this.deriveLoginMethod(
      (data as any)?.platforms,
      (data as any)?.platform ?? data.platform ?? null
    );
    return {
      ...(data as any),
      platform: loginMethod,
      loginMethod,
    } as GetUserInfoResponse;
  }

  private parseCookies(cookieHeader: string | undefined) {
    if (!cookieHeader) {
      return new Map<string, string>();
    }

    const parsed = parseCookieHeader(cookieHeader);
    return new Map(Object.entries(parsed));
  }

  private getSessionSecret() {
    // Try multiple sources for the secret
    let secret = process.env.JWT_SECRET || ENV.cookieSecret || "";
    
    // Only log once to avoid spam
    if (!this._secretLogged) {
      console.log("[Auth] JWT_SECRET check:", {
        fromEnv: !!process.env.JWT_SECRET,
        fromENV: !!ENV.cookieSecret,
        length: secret.length,
      });
      this._secretLogged = true;
    }
    
    // Generate a default secret if not set (for local development)
    if (!secret || secret.length === 0) {
      console.warn("[Auth] JWT_SECRET not set in environment, generating default secret for local development");
      // Use a deterministic default secret for local dev (not secure, but works)
      secret = "aoix-1-local-dev-secret-key-change-in-production-default-key-12345";
    }
    
    if (secret.length < 32) {
      console.warn("[Auth] JWT_SECRET is too short, extending it");
      secret = secret.padEnd(32, "0");
    }
    
    if (secret.length === 0) {
      throw new Error("JWT_SECRET cannot be empty. Please set JWT_SECRET in .env.local");
    }
    
    return new TextEncoder().encode(secret);
  }

  /**
   * Create a session token for a Manus user openId
   * @example
   * const sessionToken = await sdk.createSessionToken(userInfo.openId);
   */
  async createSessionToken(
    openId: string,
    options: { expiresInMs?: number; name?: string } = {}
  ): Promise<string> {
    return this.signSession(
      {
        openId,
        appId: ENV.appId,
        name: options.name || "",
      },
      options
    );
  }

  async signSession(
    payload: SessionPayload,
    options: { expiresInMs?: number } = {}
  ): Promise<string> {
    try {
      const issuedAt = Date.now();
      const expiresInMs = options.expiresInMs ?? ONE_YEAR_MS;
      const expirationSeconds = Math.floor((issuedAt + expiresInMs) / 1000);
      const secretKey = this.getSessionSecret();
      
      console.log("[Auth] Signing session with secret length:", secretKey.length);

      return await new SignJWT({
        openId: payload.openId,
        appId: payload.appId,
        name: payload.name,
      })
        .setProtectedHeader({ alg: "HS256", typ: "JWT" })
        .setExpirationTime(expirationSeconds)
        .sign(secretKey);
    } catch (error) {
      console.error("[Auth] Sign session error:", error);
      throw new Error(`Failed to sign session: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  async verifySession(
    cookieValue: string | undefined | null
  ): Promise<{ openId: string; appId: string; name: string } | null> {
    if (!cookieValue) {
      console.warn("[Auth] Missing session cookie");
      return null;
    }

    try {
      const secretKey = this.getSessionSecret();
      console.log("[Auth] Verifying session, cookie length:", cookieValue.length, "secret length:", secretKey.length);
      const { payload } = await jwtVerify(cookieValue, secretKey, {
        algorithms: ["HS256"],
      });
      const { openId, appId, name } = payload as Record<string, unknown>;

      if (
        !isNonEmptyString(openId) ||
        !isNonEmptyString(appId) ||
        !isNonEmptyString(name)
      ) {
        console.warn("[Auth] Session payload missing required fields", { openId, appId, name });
        return null;
      }

      console.log("[Auth] Session verified successfully for:", openId);
      return {
        openId,
        appId,
        name,
      };
    } catch (error) {
      console.warn("[Auth] Session verification failed", String(error));
      return null;
    }
  }

  async getUserInfoWithJwt(
    jwtToken: string
  ): Promise<GetUserInfoWithJwtResponse> {
    const payload: GetUserInfoWithJwtRequest = {
      jwtToken,
      projectId: ENV.appId,
    };

    const { data } = await this.client.post<GetUserInfoWithJwtResponse>(
      GET_USER_INFO_WITH_JWT_PATH,
      payload
    );

    const loginMethod = this.deriveLoginMethod(
      (data as any)?.platforms,
      (data as any)?.platform ?? data.platform ?? null
    );
    return {
      ...(data as any),
      platform: loginMethod,
      loginMethod,
    } as GetUserInfoWithJwtResponse;
  }

  async authenticateRequest(req: Request): Promise<User> {
    // Regular authentication flow
    const cookies = this.parseCookies(req.headers.cookie);
    const sessionCookie = cookies.get(COOKIE_NAME);
    console.log("[Auth] authenticateRequest - cookie present:", !!sessionCookie, "cookie name:", COOKIE_NAME);
    const session = await this.verifySession(sessionCookie);

    if (!session) {
      throw ForbiddenError("Invalid session cookie");
    }

    const sessionUserId = session.openId;
    const signedInAt = new Date();
    let user: User | null = null;
    
    // Try to get user from database (but don't fail if DB unavailable)
    try {
      user = (await db.getUserByOpenId(sessionUserId)) ?? null;
    } catch (dbError) {
      console.warn("[Auth] Database query failed (non-critical):", dbError);
    }

    // If user not in DB, create local demo user (for local auth)
    if (!user) {
      if (sessionUserId === "demo-user-local") {
        // Try to create local demo user in database
        try {
          await db.upsertUser({
            openId: sessionUserId,
            name: session.name || "Demo User",
            email: "demo@aoix.local",
            loginMethod: "local",
            lastSignedIn: signedInAt,
          });
          user = (await db.getUserByOpenId(sessionUserId)) ?? null;
        } catch (dbError) {
          console.warn("[Auth] Database not available for demo user, using in-memory:", dbError);
        }
        
        // If still no user (DB unavailable or query failed), create in-memory user
        if (!user) {
          user = {
            id: 1,
            openId: sessionUserId,
            name: session.name || "Demo User",
            email: "demo@aoix.local",
            loginMethod: "local",
            role: "user" as const,
            lastSignedIn: signedInAt,
            createdAt: signedInAt,
            updatedAt: signedInAt,
          } as User;
          console.log("[Auth] Created in-memory demo user");
        }
      } else {
        // Try to sync from OAuth server (for backward compatibility)
        try {
          const userInfo = await this.getUserInfoWithJwt(sessionCookie ?? "");
          await db.upsertUser({
            openId: userInfo.openId,
            name: userInfo.name || null,
            email: userInfo.email ?? null,
            loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
            lastSignedIn: signedInAt,
          });
          user = (await db.getUserByOpenId(userInfo.openId)) ?? null;
        } catch (error) {
          console.error("[Auth] Failed to sync user from OAuth:", error);
          // Don't throw - allow local auth to work
        }
      }
    }

    if (!user) {
      // For demo user, create in-memory user as fallback
      if (sessionUserId === "demo-user-local") {
        user = {
          id: 1,
          openId: sessionUserId,
          name: session.name || "Demo User",
          email: "demo@aoix.local",
          loginMethod: "local",
          role: "user" as const,
          lastSignedIn: signedInAt,
          createdAt: signedInAt,
          updatedAt: signedInAt,
        } as User;
        console.log("[Auth] Created in-memory demo user as fallback");
      } else {
        throw ForbiddenError("User not found");
      }
    }

    // Try to update last signed in (but don't fail if DB unavailable)
    try {
      await db.upsertUser({
        openId: user.openId,
        lastSignedIn: signedInAt,
      });
    } catch (dbError) {
      console.warn("[Auth] Failed to update last signed in (non-critical):", dbError);
    }

    console.log("[Auth] Authentication successful for:", user.openId);
    return user;
  }
}

export const sdk = new SDKServer();
