/**
 * Today's Opportunity — Multiple top picks + Conservative/Balanced/Aggressive + Trade immediately.
 */

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { skipToken } from "@tanstack/react-query";
import {
  RefreshCw,
  CheckCircle2,
  XCircle,
  Edit3,
  Zap,
  Target,
  TrendingUp,
  Crown,
  Loader2,
  Rocket,
  Info,
  ChevronDown,
  ChevronRight,
} from "lucide-react";

interface GeneratedOption {
  tier: string;
  symbol: string;
  structureType: string;
  direction: string;
  suggestedExpiryDays: { min: number; max: number };
  strikeMultiplier: number;
  impliedMovePercent: number;
  historicalMovePercent: number;
  moveComparison: string;
  catalystSummary: string;
  tierScore: number;
  winProbability: number;
  probMaxLoss?: number;
  expectedReturn: number;
  currentPrice: number;
  regime: string;
  timestamp: number;
  earningsBeforeExpiration?: string;
  priceVs52wPercent?: number;
}

interface OpportunityRow {
  opportunity: {
    symbol: string;
    currentPrice?: number;
    structure?: { type?: string };
    regime?: string;
    opportunity?: { score?: number; scoreBeforeLiquidity?: number; winProbability?: number };
    signal?: { direction?: string };
    ivRank?: number;
    isIlliquid?: boolean;
  };
  options: GeneratedOption[];
  intent?: { rationale?: string; confidence?: number; direction?: string };
}

function getExpiryAndStrike(currentPrice: number, direction: string): { optionType: "C" | "P"; strike: number; expiryStr: string } {
  const optionType = direction === "bearish" ? "P" : "C";
  const strike = Math.round(currentPrice / 5) * 5 || Math.round(currentPrice);
  const today = new Date();
  const daysUntilFriday = (5 - today.getDay() + 7) % 7 || 7;
  const expiry = new Date(today);
  expiry.setDate(today.getDate() + daysUntilFriday);
  const expiryStr = expiry.toISOString().split("T")[0].replace(/-/g, "");
  return { optionType, strike, expiryStr };
}

const TOP_N = 15;

export default function TodayOpportunity() {
  const [runScan, setRunScan] = useState(false); // false = use cached scan; click Refresh to run scan
  const [validatingTier, setValidatingTier] = useState<string | null>(null);
  const [lastValidation, setLastValidation] = useState<{
    verdict: string;
    reason: string;
    suggestedChanges?: string;
  } | null>(null);
  const [tradeDialog, setTradeDialog] = useState<{
    symbol: string;
    structureType: string;
    direction: string;
    currentPrice: number;
  } | null>(null);
  const [tradeQuantity, setTradeQuantity] = useState(1);
  const [selectedExpiry, setSelectedExpiry] = useState<string | null>(null);
  const [selectedStrike, setSelectedStrike] = useState<number | null>(null);
  const [strategiesExpanded, setStrategiesExpanded] = useState(false);

  const [useIntentGovernance, setUseIntentGovernance] = useState(true);
  const opportunitiesQuery = trpc.opportunity.getTodayOpportunities.useQuery(
    { runScanIfEmpty: runScan, topN: TOP_N, useIntentGovernance },
    { refetchOnWindowFocus: false, staleTime: 0 }
  );
  const blueprintStatus = trpc.opportunity.getBlueprintStatus.useQuery(undefined, { staleTime: 60_000 });
  const structureTypesQuery = trpc.opportunity.getStructureTypes.useQuery(undefined, { staleTime: 300_000 });
  const structureMap = (structureTypesQuery.data?.structures ?? []).reduce<Record<string, { label: string; description: string }>>((acc, s) => {
    acc[s.id] = { label: s.label, description: s.description };
    return acc;
  }, {});
  const getStructureLabel = (id: string) => structureMap[id]?.label ?? (id ?? "").replace(/_/g, " ");
  const getStructureDescription = (id: string) => structureMap[id]?.description ?? "";
  const { refetch: triggerScan } = trpc.marketScanner.scan.useQuery(undefined, { enabled: false });
  const validateMutation = trpc.opportunity.validateTrade.useMutation({
    onSuccess: (data) => {
      setValidatingTier(null);
      setLastValidation(data.validation);
      const v = data.validation.verdict;
      if (v === "approve") toast.success("Risk check: Approved — " + data.validation.reason.slice(0, 80));
      else if (v === "reject") toast.error("Risk check: Rejected — " + data.validation.reason.slice(0, 80));
      else toast.info("Risk check: Modify — " + (data.validation.suggestedChanges ?? data.validation.reason).slice(0, 80));
    },
    onError: (e) => {
      setValidatingTier(null);
      toast.error("Risk check failed: " + e.message);
    },
  });
  const placeOrderMutation = trpc.omega0.placeOrder.useMutation({
    onSuccess: (data) => {
      const msg = data.message ?? `Order placed: ${data.symbol}`;
      toast.success(`${msg} Check your IB account to confirm fill.`);
      setTradeDialog(null);
    },
    onError: (e) => {
      toast.error("Order failed: " + e.message);
    },
  });

  const optionChainQuery = trpc.omega0.getOptionChainForTrade.useQuery(
    { symbol: tradeDialog?.symbol ?? "" },
    { enabled: !!tradeDialog?.symbol, staleTime: 30_000 }
  );
  const chain = optionChainQuery.data;
  const hasChain = chain && !("error" in chain && chain.error) && chain.options?.length > 0;
  const fallbackParams = tradeDialog ? getExpiryAndStrike(tradeDialog.currentPrice, tradeDialog.direction) : null;
  const effectiveExpiry = (hasChain && selectedExpiry) ? selectedExpiry : fallbackParams?.expiryStr ?? "";
  const effectiveStrike = (hasChain && selectedStrike != null) ? selectedStrike : (fallbackParams?.strike ?? 0);
  const effectiveOptionType = tradeDialog ? (tradeDialog.direction === "bearish" ? "P" as const : "C" as const) : "C";
  const riskPreviewParams = tradeDialog && (effectiveExpiry && effectiveStrike > 0)
    ? { expiryStr: effectiveExpiry, strike: effectiveStrike, optionType: effectiveOptionType }
    : null;
  const riskPreview = trpc.omega0.estimateOrderCost.useQuery(
    tradeDialog && riskPreviewParams
      ? {
          symbol: tradeDialog.symbol,
          expiry: riskPreviewParams.expiryStr,
          strike: riskPreviewParams.strike,
          optionType: riskPreviewParams.optionType,
          quantity: tradeQuantity,
          structureType: tradeDialog.structureType || undefined,
          direction: (tradeDialog.direction === "bearish" || tradeDialog.direction === "neutral" ? tradeDialog.direction : "bullish") as "bullish" | "bearish" | "neutral",
        }
      : skipToken,
    { refetchOnMount: false, enabled: !!tradeDialog && !!riskPreviewParams }
  );

  const validationPayload = (opt: GeneratedOption) => ({
    tier: opt.tier as "conservative" | "balanced" | "aggressive",
    symbol: opt.symbol,
    structureType: opt.structureType,
    direction: opt.direction,
    impliedMovePercent: opt.impliedMovePercent,
    historicalMovePercent: opt.historicalMovePercent,
    moveComparison: opt.moveComparison,
    catalystSummary: opt.catalystSummary,
    tierScore: opt.tierScore,
    winProbability: opt.winProbability,
    expectedReturn: opt.expectedReturn,
    currentPrice: opt.currentPrice,
    regime: opt.regime,
  });

  /** Trade now: with market thesis (intent) we skip validation — intent already governed options. Otherwise run risk check first. */
  const handleTradeClick = async (opt: GeneratedOption) => {
    if (useIntentGovernance) {
      setLastValidation(null);
      setTradeDialog({
        symbol: opt.symbol,
        structureType: opt.structureType,
        direction: opt.direction,
        currentPrice: opt.currentPrice,
      });
      setTradeQuantity(1);
      return;
    }
    setValidatingTier(opt.tier);
    setLastValidation(null);
    try {
      const data = await validateMutation.mutateAsync(validationPayload(opt));
      setValidatingTier(null);
      setLastValidation(data.validation);
      const v = data.validation.verdict;
      if (v === "reject") {
        toast.error("Trade does not meet risk criteria — " + (data.validation.reason?.slice(0, 100) ?? "Review risk tier and constraints."));
        return;
      }
      if (v === "approve") toast.success("Risk check passed — opening order.");
      if (v === "modify") toast.info("Suggested modifications — review below before placing.");
      setTradeDialog({
        symbol: opt.symbol,
        structureType: opt.structureType,
        direction: opt.direction,
        currentPrice: opt.currentPrice,
      });
      setTradeQuantity(1);
    } catch (e) {
      setValidatingTier(null);
      toast.error("Risk check failed: " + (e instanceof Error ? e.message : String(e)));
    }
  };

  const handlePlaceOrder = async () => {
    if (!tradeDialog) return;
    const expiryStr = effectiveExpiry || fallbackParams?.expiryStr;
    const strike = (effectiveStrike ?? fallbackParams?.strike) ?? 0;
    const optionType = effectiveOptionType;
    if (!expiryStr || strike <= 0) {
      toast.error("Select an expiry and strike from the option chain.");
      return;
    }
    const qty = Math.min(100, Math.max(1, tradeQuantity));
    try {
      await placeOrderMutation.mutateAsync({
        symbol: tradeDialog.symbol,
        action: "BUY",
        quantity: qty,
        optionType,
        strike,
        expiry: expiryStr,
        structureType: tradeDialog.structureType || undefined,
        direction: (tradeDialog.direction === "bearish" || tradeDialog.direction === "neutral" ? tradeDialog.direction : "bullish") as "bullish" | "bearish",
      });
    } catch {
      // Handled by mutation
    }
  };

  // When dialog opens or chain loads, set default expiry/strike (first expiry, ATM strike)
  useEffect(() => {
    if (!tradeDialog || !hasChain || !chain || !("options" in chain)) return;
    const expirations = chain.expirations ?? [];
    const strikes = chain.strikes ?? [];
    const price = chain.currentPrice ?? tradeDialog.currentPrice;
    if (expirations.length && selectedExpiry === null) setSelectedExpiry(expirations[0]!);
    if (strikes.length && selectedStrike === null) {
      const atm = strikes.reduce((a, b) => (Math.abs(b - price) < Math.abs(a - price) ? b : a));
      setSelectedStrike(atm);
    }
  }, [tradeDialog, hasChain, chain, tradeDialog?.currentPrice, selectedExpiry, selectedStrike]);
  // Reset selection when dialog closes
  useEffect(() => {
    if (!tradeDialog) {
      setSelectedExpiry(null);
      setSelectedStrike(null);
    }
  }, [tradeDialog]);

  const { data, isLoading, isFetching, error, refetch } = opportunitiesQuery;
  const opportunities: OpportunityRow[] = data?.opportunities ?? [];
  const hasOpportunities = opportunities.length > 0;
  const vix = data?.vix;

  const handleRefresh = async () => {
    setRunScan(true);
    await triggerScan().catch(() => {});
    await refetch();
  };

  return (
    <div className="space-y-6 p-4 md:p-6">
      {/* 10/10 Blueprint banner — visible so the work is obvious */}
      <Card className="border-emerald-500/40 bg-emerald-500/5">
        <CardContent className="py-3">
          <div className="flex flex-wrap items-center gap-2">
            <Crown className="h-5 w-5 text-emerald-500" />
            <span className="font-semibold text-emerald-400">10/10 Blueprint</span>
            <Badge variant="outline" className="border-emerald-500/50 text-emerald-400 text-xs">
              LIVE
            </Badge>
            <span className="text-muted-foreground text-sm">Intent governance · Strategy compatibility · Outcome logging on close · Calibration every 50 trades</span>
            {blueprintStatus.data && (
              <span className="text-xs text-muted-foreground ml-auto">
                Store: {blueprintStatus.data.outcomeStore} · Sizing: {blueprintStatus.data.enableConfidenceSizing ? "on" : "off"} · Calibration: {blueprintStatus.data.enableConfidenceCalibration ? "on" : "off"}
              </span>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-bold tracking-tight">
            <Crown className="h-7 w-7 text-amber-500" />
            Today's Opportunity
          </h1>
          <p className="text-muted-foreground mt-1">
            Top {TOP_N} picks · Market thesis and risk-tier options; risk check before order when not using market thesis. Conservative / Balanced / Aggressive differ by risk (tight / medium / wide), DTE, and capital.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <label className="flex items-center gap-2 text-sm text-muted-foreground cursor-pointer">
            <input
              type="checkbox"
              checked={useIntentGovernance}
              onChange={(e) => setUseIntentGovernance(e.target.checked)}
              className="rounded border-input"
            />
            Include market thesis
          </label>
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={isLoading || isFetching}
          >
            {isLoading || isFetching ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            <span className="ml-2">{isLoading ? "Loading…" : isFetching ? "Scanning… (1–2 min)" : "Refresh"}</span>
          </Button>
        </div>
      </div>

      {error && (
        <Card className="border-destructive/50">
          <CardContent className="pt-6">
            <p className="text-destructive">{error.message}</p>
            <Button variant="outline" className="mt-2" onClick={() => refetch()}>
              Retry
            </Button>
          </CardContent>
        </Card>
      )}

      {!error && !hasOpportunities && !isLoading && (
        <Card>
          <CardContent className="pt-6">
            <p className="text-muted-foreground">
              No opportunities yet. Click below to run a market scan (takes 1–2 min with IB data).
            </p>
            <Button className="mt-2" onClick={handleRefresh} disabled={isFetching}>
              {isFetching ? "Scanning…" : "Run scan and load"}
            </Button>
          </CardContent>
        </Card>
      )}

      {hasOpportunities && (
        <>
          <div className="space-y-6">
            {opportunities.map((row, idx) => {
              const opp = row.opportunity;
              const options = row.options;
              const intent = row.intent;
              const isFirst = idx === 0;
              return (
                <Card key={opp.symbol} className={isFirst ? "border-primary/30" : ""}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      {isFirst ? <Crown className="h-5 w-5 text-amber-500" /> : <Target className="h-5 w-5" />}
                      {isFirst ? "Top pick" : `#${idx + 1}`}: {opp.symbol}
                    </CardTitle>
                    <CardDescription>
                      {(intent && options[0] ? getStructureLabel(options[0].structureType) : opp.structure?.type) ?? "—"} · {opp.regime ?? "—"} · Score {intent && options[0] ? options[0].tierScore : (opp.opportunity?.scoreBeforeLiquidity ?? opp.opportunity?.score ?? "—")} · Win prob{" "}
                      {intent && options[0] ? ((options[0].winProbability ?? 0) * 100).toFixed(0) : ((opp.opportunity?.winProbability ?? 0) * 100).toFixed(0)}%
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {intent?.rationale && (
                      <div className="rounded-lg border bg-muted/30 p-3 text-sm">
                        <p className="font-medium text-muted-foreground mb-1">Market thesis</p>
                        <p className="text-sm">{intent.rationale}</p>
                        {intent.confidence != null && (
                          <p className="text-xs text-muted-foreground mt-1">Confidence {(intent.confidence * 100).toFixed(0)}%</p>
                        )}
                      </div>
                    )}
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary">${Number(opp.currentPrice ?? 0).toFixed(2)}</Badge>
                      <Badge variant="outline">{intent?.direction ? intent.direction.toLowerCase() : (opp.signal?.direction ?? "—")}</Badge>
                      <Badge variant="outline">IV rank {opp.ivRank ?? "—"}</Badge>
                      {opp.isIlliquid && (
                        <Badge variant="secondary" className="bg-amber-500/20 text-amber-700 dark:text-amber-400">Lower liquidity</Badge>
                      )}
                    </div>
                    {options.length > 0 && (
                      <div>
                        <h3 className="mb-2 text-sm font-medium">Tiers</h3>
                        <div className="grid gap-3 sm:grid-cols-3">
                          {options.map((opt) => (
                            <div key={opt.tier} className="rounded-lg border bg-muted/30 p-3 text-sm">
                              <p className="font-medium capitalize">{opt.tier}</p>
                              {getStructureDescription(opt.structureType) ? (
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <p className="text-muted-foreground text-xs flex items-center gap-1 cursor-help">
                                        {getStructureLabel(opt.structureType)} <Info className="h-3 w-3 opacity-60" />
                                      </p>
                                    </TooltipTrigger>
                                    <TooltipContent side="top" className="max-w-xs text-xs">
                                      {getStructureDescription(opt.structureType)}
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              ) : (
                                <p className="text-muted-foreground text-xs">{getStructureLabel(opt.structureType)}</p>
                              )}
                              <p className="text-muted-foreground text-xs">
                                DTE {opt.suggestedExpiryDays.min}–{opt.suggestedExpiryDays.max} · {opt.moveComparison.replace(/_/g, " ")}
                              </p>
                              <p className="mt-1 text-xs">Score {opt.tierScore} · Win {((opt.winProbability ?? 0) * 100).toFixed(0)}%{opt.probMaxLoss != null ? ` · Prob max loss ~${opt.probMaxLoss}%` : ""}</p>
                              {opt.priceVs52wPercent != null && (
                                <p className="text-muted-foreground text-xs">Price vs 52w: {opt.priceVs52wPercent}%</p>
                              )}
                              {opt.earningsBeforeExpiration && (
                                <p className="text-amber-600 dark:text-amber-400 text-xs font-medium">Earnings before expiry</p>
                              )}
                              <div className="mt-2">
                                <Button
                                  size="sm"
                                  className="h-8 text-xs w-full bg-green-600 hover:bg-green-700"
                                  onClick={() => handleTradeClick(opt)}
                                  disabled={placeOrderMutation.isPending || (validatingTier !== null && validatingTier !== opt.tier)}
                                  title={useIntentGovernance ? "Place order (market thesis already governed options)" : "Run risk check, then open order dialog"}
                                >
                                  {validatingTier === opt.tier ? <Loader2 className="h-3 w-3 animate-spin" /> : <Rocket className="h-3 w-3" />}
                                  <span className="ml-1">Trade now</span>
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {lastValidation && (
            <Card className="border-muted">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-base">
                  {lastValidation.verdict === "approve" && <CheckCircle2 className="h-5 w-5 text-green-500" />}
                  {lastValidation.verdict === "reject" && <XCircle className="h-5 w-5 text-red-500" />}
                  {lastValidation.verdict === "modify" && <Edit3 className="h-5 w-5 text-amber-500" />}
                  Last risk check: {lastValidation.verdict}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <p>{lastValidation.reason}</p>
                {lastValidation.suggestedChanges && (
                  <p className="text-muted-foreground">
                    <strong>Suggested:</strong> {lastValidation.suggestedChanges}
                  </p>
                )}
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <TrendingUp className="h-5 w-5" />
                Dynamic Momentum Glide
              </CardTitle>
              <CardDescription>
                For open positions: hold, tighten stop, extend target, take partial, or exit. Use Execution dashboard for live positions.
              </CardDescription>
            </CardHeader>
          </Card>

          {/* Trading strategies reference */}
          <Card>
            <CardHeader
              className="cursor-pointer select-none"
              onClick={() => setStrategiesExpanded((e) => !e)}
            >
              <CardTitle className="flex items-center gap-2 text-base">
                {strategiesExpanded ? <ChevronDown className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
                Trading strategies
              </CardTitle>
              <CardDescription>
                Supported options structures and what they mean. Click to expand.
              </CardDescription>
            </CardHeader>
            {strategiesExpanded && structureTypesQuery.data?.structures && (
              <CardContent className="pt-0">
                <ul className="space-y-3 text-sm">
                  {structureTypesQuery.data.structures.map((s) => (
                    <li key={s.id} className="border-b border-muted/50 pb-3 last:border-0 last:pb-0">
                      <span className="font-medium">{s.label}</span>
                      <p className="text-muted-foreground mt-0.5">{s.description}</p>
                    </li>
                  ))}
                </ul>
              </CardContent>
            )}
          </Card>
        </>
      )}

      {/* Trade dialog */}
      <Dialog open={!!tradeDialog} onOpenChange={(open) => !open && setTradeDialog(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto max-w-2xl">
          <DialogHeader>
            <DialogTitle>Place order</DialogTitle>
            <DialogDescription>
              {tradeDialog
                ? `${tradeDialog.symbol} — ${tradeDialog.structureType?.replace(/_/g, " ")} (${tradeDialog.direction}). Pick expiry and strike from live chain.`
                : "Select a tier and click Trade now."}
            </DialogDescription>
          </DialogHeader>
          {tradeDialog && lastValidation && (
            <div className="rounded-lg border bg-muted/50 p-3 text-sm">
              <p className="font-medium flex items-center gap-2">
                {lastValidation.verdict === "approve" && <CheckCircle2 className="h-4 w-4 text-green-600" />}
                {lastValidation.verdict === "reject" && <XCircle className="h-4 w-4 text-red-600" />}
                {lastValidation.verdict === "modify" && <Edit3 className="h-4 w-4 text-amber-600" />}
                Risk check: {lastValidation.verdict.toUpperCase()}
              </p>
              <p className="text-muted-foreground mt-1">{lastValidation.reason}</p>
              {lastValidation.suggestedChanges && (
                <p className="text-muted-foreground mt-1"><strong>Suggested:</strong> {lastValidation.suggestedChanges}</p>
              )}
            </div>
          )}
          {tradeDialog && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <span className="text-muted-foreground">Symbol</span>
                <span className="font-medium">{tradeDialog.symbol}</span>
                <span className="text-muted-foreground">Structure</span>
                <span className="font-medium">{getStructureLabel(tradeDialog.structureType)}</span>
              </div>

              {optionChainQuery.isLoading && (
                <div className="flex items-center gap-2 text-muted-foreground py-4">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Loading option chain from IB…
                </div>
              )}

              {!optionChainQuery.isLoading && chain && (("error" in chain && chain.error) || !(chain.options?.length)) ? (
                <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-4 text-sm">
                  <p className="font-medium text-red-700 dark:text-red-400">No options available</p>
                  <p className="text-muted-foreground mt-1">
                    No option chain for {tradeDialog.symbol}. Try a different symbol or expiry. Ensure IB Gateway is connected and the symbol has listed options.
                  </p>
                  {chain.expirations?.length ? (
                    <p className="text-muted-foreground mt-1 text-xs">Available expirations from IB: {chain.expirations.slice(0, 5).join(", ")}</p>
                  ) : null}
                </div>
              ) : null}

              {!optionChainQuery.isLoading && hasChain && chain && "options" in chain && (
                <>
                  <div className="space-y-2">
                    <Label>Expiration</Label>
                    <select
                      className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm"
                      value={selectedExpiry ?? ""}
                      onChange={(e) => setSelectedExpiry(e.target.value || null)}
                    >
                      {(chain.expirations ?? []).map((exp) => (
                        <option key={exp} value={exp}>{exp}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label>Strike (select one — used as center for spreads)</Label>
                    <div className="rounded border overflow-x-auto max-h-48 overflow-y-auto">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="border-b bg-muted/50">
                            <th className="text-left p-2">Strike</th>
                            <th className="text-right p-2">Call bid</th>
                            <th className="text-right p-2">Call ask</th>
                            <th className="text-right p-2">Put bid</th>
                            <th className="text-right p-2">Put ask</th>
                          </tr>
                        </thead>
                        <tbody>
                          {(chain.strikes ?? []).map((strike) => {
                            const forExpiry = selectedExpiry ?? (chain.expirations ?? [])[0];
                            const norm = (s: string) => String(s ?? "").replace(/[-/\s]/g, "").slice(0, 8);
                            const forNorm = forExpiry ? norm(forExpiry) : "";
                            const call = chain.options?.find((o: { strike: number; expiry: string; right: string }) => o.strike === strike && norm(o.expiry) === forNorm && o.right === "C");
                            const put = chain.options?.find((o: { strike: number; expiry: string; right: string }) => o.strike === strike && norm(o.expiry) === forNorm && o.right === "P");
                            return (
                              <tr
                                key={strike}
                                className={`border-b cursor-pointer hover:bg-muted/50 ${selectedStrike === strike ? "bg-primary/10" : ""}`}
                                onClick={() => setSelectedStrike(strike)}
                              >
                                <td className="p-2 font-medium">{strike}</td>
                                <td className="text-right p-2">{call && (call.bid > 0 || call.ask > 0) ? call.bid.toFixed(2) : "—"}</td>
                                <td className="text-right p-2">{call && (call.bid > 0 || call.ask > 0) ? call.ask.toFixed(2) : "—"}</td>
                                <td className="text-right p-2">{put && (put.bid > 0 || put.ask > 0) ? put.bid.toFixed(2) : "—"}</td>
                                <td className="text-right p-2">{put && (put.bid > 0 || put.ask > 0) ? put.ask.toFixed(2) : "—"}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {riskPreview.data?.breakdown && riskPreview.data.breakdown.length > 0 && (
                    <div className="rounded-lg border border-slate-500/30 bg-slate-500/5 p-3 text-sm space-y-1">
                      <p className="font-medium text-slate-700 dark:text-slate-300">Legs (what will be sent to IB)</p>
                      <ul className="list-disc list-inside text-muted-foreground">
                        {riskPreview.data.breakdown.map((leg: { action: string; strike: number; optionType: string; fillPrice: number; quantity: number }, i: number) => (
                          <li key={i}>
                            {leg.action} {leg.strike}{leg.optionType} @ ${leg.fillPrice.toFixed(2)} × {leg.quantity}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {riskPreview.data && (
                    <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 text-sm space-y-1">
                      <p className="font-medium text-amber-700 dark:text-amber-400">Risk metrics</p>
                      <p>Max loss: <strong>${Math.abs(riskPreview.data.maxLossEstimate ?? 0).toFixed(0)}</strong></p>
                      <p>Max profit: <strong>${(riskPreview.data.maxProfitEstimate ?? 0) < 1e9 ? (riskPreview.data.maxProfitEstimate ?? 0).toFixed(0) : "∞"}</strong></p>
                      {Array.isArray(riskPreview.data.breakevens) && riskPreview.data.breakevens.length > 0 && (
                        <p>Breakeven: <strong>{riskPreview.data.breakevens.map((b: number) => `$${b.toFixed(1)}`).join(", ")}</strong></p>
                      )}
                    </div>
                  )}
                </>
              )}

              {tradeDialog && !hasChain && !optionChainQuery.isLoading && fallbackParams && (
                <>
                  <p className="text-muted-foreground text-xs">Using approximate strike/expiry (no chain loaded). Connect IB Gateway to see live strikes.</p>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <span className="text-muted-foreground">Strike (approx)</span>
                    <span className="font-medium">{fallbackParams.strike}</span>
                    <span className="text-muted-foreground">Expiry</span>
                    <span className="font-medium">{fallbackParams.expiryStr}</span>
                  </div>
                  {riskPreview.data && (
                    <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 text-sm space-y-1">
                      <p className="font-medium text-amber-700 dark:text-amber-400">Risk metrics</p>
                      <p>Max loss: <strong>${Math.abs(riskPreview.data.maxLossEstimate ?? 0).toFixed(0)}</strong></p>
                      <p>Max profit: <strong>${(riskPreview.data.maxProfitEstimate ?? 0) < 1e9 ? (riskPreview.data.maxProfitEstimate ?? 0).toFixed(0) : "∞"}</strong></p>
                      {Array.isArray(riskPreview.data.breakevens) && riskPreview.data.breakevens.length > 0 && (
                        <p>Breakeven: <strong>{riskPreview.data.breakevens.map((b: number) => `$${b.toFixed(1)}`).join(", ")}</strong></p>
                      )}
                    </div>
                  )}
                </>
              )}

              <div className="space-y-2">
                <Label htmlFor="qty">Contracts</Label>
                <Input
                  id="qty"
                  type="number"
                  min={1}
                  max={100}
                  value={tradeQuantity}
                  onChange={(e) => setTradeQuantity(Math.max(1, Number(e.target.value) || 1))}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setTradeDialog(null)}>Cancel</Button>
            <Button
              className="bg-green-600 hover:bg-green-700"
              onClick={handlePlaceOrder}
              disabled={!tradeDialog || placeOrderMutation.isPending || (hasChain && (!selectedExpiry || selectedStrike == null)) || (chain && (("error" in chain && !!chain.error) || !(chain.options?.length)))}
            >
              {placeOrderMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Rocket className="h-4 w-4" />}
              <span className="ml-2">{placeOrderMutation.isPending ? "Executing…" : "Place order"}</span>
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
