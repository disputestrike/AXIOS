# AOIX-1 Quick-Start Guide

## System Ready for Live Paper Trading

Your AOIX-1 Sovereign Market Organism is now fully operational with Omega-0 IBKR execution layer connected to your paper trading account.

---

## Dashboard Navigation

### 1. **Market Data Dashboard** (`/market-data`)
**Purpose:** Real-time market data monitoring
- **Displays:** SPX price, IV rank, GEX/DEX levels, flow metrics
- **Use Case:** Monitor market conditions before entering trades
- **Key Metrics:** Current price, 30-day IV, IV percentile, implied move

### 2. **Regime Classification** (`/regime`)
**Purpose:** Identify market regime and transition probability
- **Displays:** 4-quadrant regime map (Bull/Bear × Vol-Compression/Expansion)
- **Use Case:** Confirm regime alignment before trading
- **Key Metrics:** Current regime, transition probability, LSI (Liquidity Stress Index)
- **Trading Rule:** Only trade when regime is stable (transition probability < 30%)

### 3. **Signal Taxonomy** (`/signals`)
**Purpose:** Class A-D signal generation and decay tracking
- **Displays:** Active signals with confidence scores and time decay
- **Use Case:** Identify high-conviction trade opportunities
- **Signal Classes:**
  - **Class A (Structural):** Long-term regime signals (confidence 80-100%)
  - **Class B (Flow):** Options flow anomalies (confidence 70-90%)
  - **Class C (Momentum):** Price momentum signals (confidence 60-80%)
  - **Class D (Catalyst):** Event-driven signals (confidence 50-70%)
- **Trading Rule:** Only trade Class A or B signals with confidence > 75%

### 4. **Structure Selector** (`/structures`)
**Purpose:** Optimal options structure recommendations
- **Displays:** Recommended structures with CVaR analysis and Greek exposure
- **Structures:** Verticals, spreads, straddles, iron condors
- **Use Case:** Select structure based on market outlook
- **Key Metrics:** Max risk, max profit, breakeven points, Greeks (Delta/Gamma/Theta/Vega)
- **Trading Rule:** Always use structures with defined risk (spreads/verticals)

### 5. **Risk Engine** (`/risk`)
**Purpose:** Portfolio-level risk monitoring and position sizing
- **Displays:** Current exposure, correlation-aware limits, volatility-scaled sizing
- **Use Case:** Ensure position size respects risk limits
- **Key Metrics:** Current risk %, max risk %, available buying power, Greeks exposure
- **Trading Rule:** Max 1% risk per trade, max 1 position at a time

### 6. **Execution Dashboard** (`/execution`)
**Purpose:** Live trade execution and monitoring
- **Displays:** Account balance, open positions, P&L, order status
- **Use Case:** Place trades and monitor fills in real-time
- **Entry Gates:** Requires volatility + flow + structural confirmation
- **Exit Logic:** Automatic +30% take profit, -20% stop loss
- **Trading Rule:** Wait for all 3 entry gates to align before trading

### 7. **Meta-Intelligence** (`/meta-intelligence`)
**Purpose:** System self-awareness and edge tracking
- **Displays:** Edge half-life, regime performance, self-doubt coefficient
- **Use Case:** Monitor system health and edge degradation
- **Key Metrics:** Win rate, profit factor, Sharpe ratio, overconfidence kill switch
- **Trading Rule:** Reduce position size if edge half-life < 5 days

### 8. **Failure Taxonomy** (`/failures`)
**Purpose:** Post-mortem analysis of losing trades
- **Displays:** Loss classification into 9 categories with attribution
- **Use Case:** Learn from losses and adjust signal weights
- **Categories:** Regime change, flow reversal, slippage, gap risk, correlation break, etc.
- **Trading Rule:** Analyze every loss and adjust strategy accordingly

### 9. **Shadow System** (`/shadow-system`)
**Purpose:** Monte Carlo ruin simulations and existential threat detection
- **Displays:** Ruin probability, max drawdown scenarios, mitigation actions
- **Use Case:** Stress-test portfolio against extreme market moves
- **Key Metrics:** Ruin probability %, max drawdown %, recovery time
- **Trading Rule:** Reduce position size if ruin probability > 5%

### 10. **Cross-Asset Reflexivity** (`/correlations`)
**Purpose:** Real-time correlation monitoring and break detection
- **Displays:** SPX/TLT, VIX/Gold, HY Spreads correlations
- **Use Case:** Detect systemic regime transitions
- **Key Metrics:** Current correlation, historical correlation, break detection alerts
- **Trading Rule:** Reduce exposure if correlation breaks detected

---

## Trading Workflow

### Step 1: Check Market Regime
1. Go to **Regime Classification** dashboard
2. Verify regime is stable (transition probability < 30%)
3. Note current regime (Bull/Bear, Vol-Compression/Expansion)

### Step 2: Identify Trade Opportunity
1. Go to **Signal Taxonomy** dashboard
2. Look for Class A or B signals with confidence > 75%
3. Note signal type and expected move range

### Step 3: Verify Risk Conditions
1. Go to **Risk Engine** dashboard
2. Check current risk % (should be < 0.5%)
3. Verify max risk per trade is 1%
4. Confirm available buying power

### Step 4: Select Structure
1. Go to **Structure Selector** dashboard
2. Choose structure based on signal type and outlook
3. Review max risk and Greeks exposure
4. Confirm structure aligns with regime

### Step 5: Execute Trade
1. Go to **Execution Dashboard**
2. Verify all 3 entry gates are aligned:
   - ✅ Volatility confirmation (IV > IV percentile 50)
   - ✅ Flow confirmation (options flow positive)
   - ✅ Structural confirmation (regime aligned)
3. Click "Place Order" to execute
4. Monitor fill status and entry price

### Step 6: Monitor Position
1. Stay on **Execution Dashboard**
2. Watch for automatic take profit (+30%) or stop loss (-20%)
3. Monitor P&L in real-time
4. Check **Meta-Intelligence** for edge tracking

### Step 7: Post-Trade Analysis
1. After trade closes, go to **Failure Taxonomy** dashboard
2. If loss: Analyze why and adjust signal weights
3. If win: Document what worked for future reference
4. Review **Shadow System** for stress-test results

---

## Key Risk Rules (Immutable)

These rules cannot be overridden and are enforced by the system:

1. **Max Risk Per Trade:** 1% of account
2. **Max Positions:** 1 at a time (no multi-leg exposure)
3. **Take Profit:** +30% automatic exit
4. **Stop Loss:** -20% automatic exit
5. **Entry Gates:** All 3 confirmations required (volatility + flow + structural)
6. **Kill Switch:** Emergency stop if ruin probability > 10%
7. **Daily Loss Limit:** -5% (optional, can be configured)

---

## Emergency Procedures

### Kill Switch (Emergency Stop)
- **When:** If overconfidence coefficient > 0.9 OR ruin probability > 10%
- **Action:** All positions closed immediately
- **Recovery:** Manual review required before resuming

### Regime Transition Alert
- **When:** Regime transition probability > 70%
- **Action:** Reduce position size to 50%
- **Recovery:** Wait for regime to stabilize

### Correlation Break Alert
- **When:** SPX/TLT or VIX/Gold correlation breaks historical pattern
- **Action:** Reduce exposure by 50%
- **Recovery:** Wait for correlation to normalize

---

## Performance Metrics to Track

### Daily Metrics
- **Win Rate:** % of profitable trades (target: > 55%)
- **Profit Factor:** Gross profit / Gross loss (target: > 1.5)
- **Average Win/Loss Ratio:** Avg win size / Avg loss size (target: > 1.5)

### Weekly Metrics
- **Sharpe Ratio:** Return / Volatility (target: > 1.0)
- **Max Drawdown:** Largest peak-to-trough decline (target: < 10%)
- **Edge Half-Life:** Days until edge decays 50% (target: > 5 days)

### Monthly Metrics
- **Return on Risk:** Total P&L / Total risk deployed (target: > 2.0)
- **Win Rate Consistency:** Std dev of daily win rates (target: < 10%)
- **Regime Performance:** Win rate by regime (should vary < 20%)

---

## Troubleshooting

### "Connection Error" in Execution Dashboard
- **Cause:** IB Gateway not running or logged out
- **Fix:** Restart IB Gateway and log in with benxpeter / 48Regular?

### "No Signals Generated"
- **Cause:** Market regime unstable or no flow anomalies
- **Fix:** Wait for regime to stabilize, check Signal Taxonomy for decay timers

### "Entry Gate Failed"
- **Cause:** One or more confirmations not aligned
- **Fix:** Check Market Data and Regime dashboards, wait for all 3 gates to align

### "Position Not Closing at Take Profit"
- **Cause:** Slippage or liquidity issue
- **Fix:** Check order status in Execution Dashboard, manually close if needed

---

## Next Steps

1. **Verify All Dashboards Load:** Click through all 10 dashboards to ensure they render correctly
2. **Monitor Account:** Check Execution Dashboard to see current account balance and buying power
3. **Place First Test Trade:** Execute a small test trade to validate the complete flow
4. **Track Metrics:** Monitor daily win rate and profit factor
5. **Adjust as Needed:** Use Failure Taxonomy to learn and improve

---

## Support & Documentation

- **OMEGA_0_SETUP.md:** Detailed IBKR integration guide
- **server/services.ts:** Core quantitative algorithms
- **server/routers/omega0.ts:** Execution layer API
- **client/src/pages/ExecutionDashboard.tsx:** Real-time monitoring UI

---

**Status: READY FOR LIVE PAPER TRADING**

Your system is fully operational and ready to start trading. Good luck! 🚀
