# AOIX-1: All Routers, Endpoints, Connections & What To Do

This doc lists every router and endpoint, where things connect, what the app does, and what you're supposed to do (why and how).

---

## 1. How the app connects (big picture)

```
Browser (client)
    │
    │  HTTP to same origin (e.g. http://localhost:3000)
    ▼
Frontend (Vite/React)
    │
    │  tRPC calls to /api/trpc
    ▼
Backend (Express)
    │  /api/trpc  →  appRouter (tRPC)
    │  /api/health → health check JSON
    │  /api/oauth/* → OAuth (if used)
    │
    ├── Database (Drizzle/SQLite) — users, trades, regime, signals, etc.
    ├── Omega-0 (paper trading) — in-memory + DB persist
    ├── Auto-trading engine — in-memory state, scans, positions, trades
    ├── Market scanner — Yahoo Finance (real data)
    ├── IB Gateway (optional) — TWS_HOST:TWS_PORT → http://host:port/v1
    └── Gateway adapter — paper vs live mode
```

- **Single server:** Frontend is served by the same Express server (Vite in dev, static in prod). No separate “API port” for the app; everything goes to the same host (e.g. `http://localhost:3000`).
- **API surface:** All app API is tRPC. The only “REST” endpoint is `GET /api/health`.
- **Client → API:** The React app uses `trpc.*.useQuery` / `trpc.*.useMutation`; the tRPC client is pointed at `url: "/api/trpc"` (relative, so same host).

---

## 2. Backend: tRPC routers and procedures (endpoints)

All are under **one router** `appRouter` and exposed at **POST /api/trpc** (tRPC batch/query/mutation).  
Call pattern: `trpc.<router>.<procedure>` (e.g. `trpc.omega0.placeOrder.useMutation()`).

### Auth — `auth`
| Procedure | Type | Description |
|-----------|------|--------------|
| `me` | query | Current user from session |
| `login` | mutation | Login (name, email optional) → sets session cookie |
| `logout` | mutation | Clears session cookie |

### System health — `system`
| Procedure | Type | Description |
|-----------|------|--------------|
| `health` | query | Full system health (DB, engines, market data, TWS, cache, etc.) |

### Market data — `market`
| Procedure | Type | Description |
|-----------|------|--------------|
| `getLatestData` | query | Latest market data for underlying |
| `getHistory` | query | History for underlying (limit) |

### Regime — `regime`
| Procedure | Type | Description |
|-----------|------|--------------|
| `getLatest` | query | Latest regime state for underlying |
| `analyze` | query | Regime analysis from inputs |

### Signals — `signals`
| Procedure | Type | Description |
|-----------|------|--------------|
| `getActive` | query | Active signals for underlying |
| `getByClass` | query | Signals by class (A/B/C/D) |
| `generateDealerGamma` | query | Dealer gamma signal |
| `generateFlow` | query | Flow signal |
| `generateMomentum` | query | Momentum signal |
| `generateCatalyst` | query | Catalyst signal |

### Structures — `structures`
| Procedure | Type | Description |
|-----------|------|--------------|
| `getLatestRecommendation` | query | Latest structure recommendation |
| `selectOptimal` | query | Optimal structure from regime/signals |

### Risk — `risk`
| Procedure | Type | Description |
|-----------|------|--------------|
| `getLatestMetrics` | query | Latest risk metrics (protected) |
| `calculateDynamic` | query | Dynamic risk from inputs |

### Execution — `execution`
| Procedure | Type | Description |
|-----------|------|--------------|
| `validateGates` | query | Validate execution gates |
| `calculateSlippage` | query | Slippage model |

### Trades (DB) — `trades`
| Procedure | Type | Description |
|-----------|------|--------------|
| `getOpenTrades` | query | User open trades from DB (protected) |
| `getHistory` | query | User trade history (protected) |

### Meta-intelligence — `metaIntelligence`
| Procedure | Type | Description |
|-----------|------|--------------|
| `getLatest` | query | Latest meta-intelligence (protected) |
| `calculate` | query | Meta-intelligence from inputs |

### Failures — `failures`
| Procedure | Type | Description |
|-----------|------|--------------|
| `getUserFailures` | query | User failures (protected) |
| `getByType` | query | Failures by type (protected) |
| `classify` | query | Classify failure from inputs |

### Shadow system — `shadowSystem`
| Procedure | Type | Description |
|-----------|------|--------------|
| `getLatestReport` | query | Latest shadow report (protected) |
| `getReports` | query | Shadow reports (protected) |
| `runSimulation` | query | Run shadow simulation |

### Correlations — `correlations`
| Procedure | Type | Description |
|-----------|------|--------------|
| `getLatest` | query | Latest cross-asset correlations |
| `getHistory` | query | Correlation history |

---

### Omega-0 (paper trading) — `omega0`

**Where it connects:** In-memory paper trades + optional DB persist; option prices from IB Gateway (if connected) or Yahoo/estimate.

| Procedure | Type | Description |
|-----------|------|--------------|
| `getStatus` | query | Paper trading status (connected, account, open/total trades) |
| `getAccountSummary` | query | Net liquidation, buying power, unrealized P&L |
| `getOptionChain` | query | Option chain for symbol (IB or fallback) |
| `placeOrder` | mutation | Place paper order (symbol, expiry, strike, optionType, action, quantity) |
| `closePosition` | mutation | Close open position (symbol, strike, optionType) |
| `getOpenTrades` | query | Open paper positions (with unrealized P&L) |
| `getClosedTrades` | query | Closed paper trades (limit) |
| `getPerformanceMetrics` | query | Win rate, Sharpe, profit factor, max drawdown, etc. |
| `tradeOpportunity` | mutation | Trade from opportunity (structure, symbol, quantity, direction) |

---

### Auto-trading engine — `autoTrading`

**Where it connects:** In-memory engine state; market data from Yahoo; optional IB for live data.

| Procedure | Type | Description |
|-----------|------|--------------|
| `getState` | query | Running, regime, positions, dayPnL, totalPnL, unrealizedPnL, lastUpdate, etc. |
| `getPerformance` | query | Win rate, Sharpe, profit factor, max drawdown, total trades |
| `getPositions` | query | Open engine positions |
| `getAllPositions` | query | All positions (limit) |
| `getTrades` | query | Recent engine trades (limit) |
| `getRiskMetrics` | query | Risk metrics |
| `getSignalQueue` | query | Signal queue |
| `getLogs` | query | Engine logs (limit) |
| `getLastOpportunities` | query | Last opportunities found |
| `start` | mutation | Start engine (protected) |
| `stop` | mutation | Stop engine (protected) |
| `reset` | mutation | Reset account (protected) |
| `closePosition` | mutation | Close one position by id (protected) |
| `deactivateKillSwitch` | mutation | Deactivate kill switch (protected) |

---

### Gateway (IB Gateway adapter) — `gateway`

**Where it connects:** Gateway adapter (paper vs live mode) and auto-trading engine.

| Procedure | Type | Description |
|-----------|------|--------------|
| `getStatus` | query | Gateway connection status |
| `getConfig` | query | Gateway config (protected) |
| `setConfig` | mutation | Update config (protected) |
| `connect` | mutation | Connect to Gateway (protected) |
| `disconnect` | mutation | Disconnect (protected) |
| `enable` | mutation | Enable Gateway / live (protected) |
| `disable` | mutation | Disable Gateway / paper (protected) |
| `isLiveMode` | query | Is live mode vs paper |

---

### Market scanner — `marketScanner`

**Where it connects:** Yahoo Finance (real market data) via market-scanner service.

| Procedure | Type | Description |
|-----------|------|--------------|
| `scan` | query | Run full market scan (returns opportunities) |
| `getTopOpportunities` | query | Top N opportunities (count) |
| `getOpportunity` | query | One opportunity by symbol |
| `getAllOpportunities` | query | All scanned opportunities |
| `getStatus` | query | Scanner status (isScanning, lastScanTime, etc.) |
| `clear` | mutation | Clear all opportunities |

---

### TWS connection — `twsConnection`

**Where it connects:** IB Gateway HTTP API at `getIBGatewayUrl()` → `http://TWS_HOST:TWS_PORT/v1` (or `IB_GATEWAY_URL`). Used for live data and option chains when TWS is connected.

| Procedure | Type | Description |
|-----------|------|--------------|
| `getStatus` | query | Connected, host, port |
| `connect` | mutation | Initialize TWS connection (uses current host/port) |
| `disconnect` | mutation | Disconnect TWS |
| `getStatusCached` | query | Cached connection status |
| `configure` | mutation | Set host & port (then tries to connect) |

---

## 3. Other HTTP endpoints (non-tRPC)

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/health` | Simple health check (ok, timestamp) |
| * | `/api/trpc/*` | All tRPC (query/mutation/batch) |
| GET | `/api/oauth/*` | OAuth routes (if configured) |

---

## 4. Frontend routes (what you see in the app)

| URL path | Page | Main tRPC used |
|----------|------|----------------|
| `/` | Home | - |
| `/auto-trading` | Auto Trading | autoTrading.*, gateway.*, twsConnection.* |
| `/recommendations` | Market Opportunities | marketScanner.*, omega0.placeOrder |
| `/system-health` | System Health | system.health, omega0.getPerformanceMetrics |
| `/market-data` | Market Data | marketScanner.* |
| `/regime` | Regime | marketScanner.getTopOpportunities |
| `/signals` | Signals | - |
| `/structures` | Structures | - |
| `/risk` | Risk | - |
| `/execution` | Execution (dashboard) | omega0.*, autoTrading.getPositions, getTrades, closePosition |
| `/execution/interface` | Execution Interface | omega0.* (manual order form) |
| `/meta-intelligence` | Meta-Intelligence | - |
| `/failures` | Failures | - |
| `/shadow-system` | Shadow System | - |
| `/correlations` | Correlations | - |
| `/404` | Not found | - |

---

## 5. Where everything is “done” (backend)

- **Database (Drizzle):** `server/db`, `drizzle/` — users, trades, regime, signals, structures, risk, failures, shadow, correlations, market data.
- **Paper trading (Omega-0):** `server/routers/omega0.ts` — in-memory `paperTrades` + `dbTradeService` for persist; option price from `getCurrentOptionPrice()` (IB chain) or entry fallback.
- **Auto-trading engine:** `server/auto-trading-engine.ts` — scan loop, open/close positions, P&L, risk; state in memory; can persist closes via `dbTradeService`.
- **Market scanner:** `server/market-scanner.ts` — uses Yahoo (e.g. `server/real-market-data.ts`); results in memory.
- **TWS/IB Gateway:** `server/ib-market-data.ts` — `getIBGatewayUrl()` → `http://TWS_HOST:TWS_PORT/v1` or `IB_GATEWAY_URL`; used for live data and option chains when connected.
- **Gateway adapter:** `server/gateway-adapter.ts` — paper vs live mode for execution.

---

## 6. What you’re supposed to do (why and how)

### Run the app
1. **Install:** `npm install`
2. **Dev:** `npm run dev` — server + Vite (e.g. http://localhost:3000)
3. **Build:** `npm run build` then `npm start` (or `cross-env NODE_ENV=production node dist/index.js`)

### Use paper trading (no IB)
- **Market Opportunities:** Open `/recommendations`, click “Trade Now” on an opportunity → dialog: set contracts → “Place order”. Trades show on **Execution** (`/execution`).
- **Execution:** View open positions (manual + engine), close manual positions (“X Close”), place manual orders (symbol, expiry, strike, quantity, Buy Call/Put).
- **Auto-trading:** Open `/auto-trading`, start engine; it scans and opens/closes positions; view positions and trades on same page or on Execution. Close engine positions from Execution (“Close” on engine positions).

### Optional: connect TWS (IB Gateway)
- **Why:** Live option chains and live data instead of Yahoo/estimates.
- **How:** Run IB Gateway (or TWS) on your machine or tunnel (e.g. ngrok). In **Auto Trading**, TWS card: gear → set **Host** (e.g. `localhost` or tunnel host) and **Port** (e.g. `4001`) → “Configure & Connect”. Or click “Connect” to use current host/port. If nothing is running at that URL, TWS stays “Disconnected”; paper trading still works.

### Optional: system health
- **System Health** (`/system-health`) calls `system.health` and shows all components (DB, engines, market data, TWS, cache, etc.). Use it to see why something might be “warning” or “error” (e.g. TWS disconnected, getDataCache not a function — we fixed that in code).

---

## 7. Quick reference: main user flows

| Goal | Where | Action |
|------|--------|--------|
| See opportunities | Market Opportunities | Scan / auto-refresh; list shows top opportunities |
| Place a trade from list | Market Opportunities | “Trade Now” → set contracts → “Place order” |
| See / close manual positions | Execution | Open positions card; “X Close” per position |
| Place manual option order | Execution or Execution Interface | Symbol, expiry, strike, quantity, Buy Call/Put |
| Run auto-trading | Auto Trading | Start engine; watch positions/trades |
| Close engine position | Execution (or Auto Trading) | “Close” on engine position |
| Connect TWS | Auto Trading | TWS card → gear → host/port → Configure & Connect |
| Check why something failed | System Health | Inspect component status (TWS, Data Cache, etc.) |

---

## 8. Dependencies (what needs what)

```
Frontend (React)
    └── /api/trpc (tRPC) ─────────────────────────────────────────────────────────┐
                                                                                   │
omega0 (paper trading)     autoTrading (engine)     marketScanner     twsConnection │
    │                            │                        │                │       │
    ├── DB (optional persist)    ├── marketScanner         └── Yahoo        └── IB  │
    ├── getCurrentOptionPrice   ├── Yahoo (real-market-data)    (real data)   Gateway
    │   (option chain or entry) ├── position-sizing, adaptive-risk, etc.          │
    └── IB Gateway OR Yahoo     └── DB (optional persist on close)                 │
            (for option price)                                                      │
                                                                                   ▼
Gateway adapter ─────────────── paper vs live mode (uses engine; TWS optional)   Express
                                                                                   app
Database (Drizzle/SQLite) ─────── users, trades, regime, signals, etc. (optional)
```

- **Paper trading (omega0):** Works with **no** TWS and **no** DB. Option prices come from IB if connected, else Yahoo/estimate. DB is used only to persist trades (survive restart).
- **Auto-trading engine:** Needs **market data** (Yahoo is enough). TWS is optional (live data). DB is optional (persist closed trades).
- **Market scanner:** Needs **Yahoo** (real-market-data). No TWS or DB required.
- **TWS:** Optional everywhere. Only needed for live option chains and live quotes; paper trading and scans work without it.

---

## 9. Setup checklist

| Step | Action | How to verify |
|------|--------|----------------|
| 1 | `npm install` | No errors |
| 2 | `npm run dev` | Server starts; open http://localhost:3000 |
| 3 | Log in (if prompted) | Demo user / session works |
| 4 | **Market Opportunities** → Scan or wait for auto-scan | List of opportunities appears |
| 5 | **Trade Now** on one opportunity → set contracts → Place order | Toast; **Execution** shows open position |
| 6 | **Execution** → see open position, optional **X Close** | Position and P&L (or —) show |
| 7 | **Auto Trading** → Start engine (optional) | Status “Running”; positions/trades may appear over time |
| 8 | **System Health** (optional) | All components healthy or expected warnings (e.g. TWS disconnected) |
| 9 | TWS (optional): run IB Gateway, Configure & Connect | TWS card shows “Connected” |

You do **not** need TWS or a database for steps 1–7 to work (paper trading and scanner work with Yahoo and in-memory state).

---

## 10. Troubleshooting — when X breaks, check Y

| What’s broken | Check first | Then |
|---------------|-------------|------|
| **App won’t start** | Port 3000 free? `npm run dev` errors? | Try different PORT; check Node version |
| **Trade Now does nothing / error** | Browser console; Network tab for `/api/trpc` | `omega0.placeOrder` failing? Session cookie present? |
| **$NaN or wrong P&L** | Option price: we use **option** premium, not underlying | System Health; omega0/getAccountSummary and getOpenTrades |
| **No opportunities** | marketScanner.scan / getTopOpportunities | Yahoo/real-market-data; scan runs on mount + button |
| **TWS won’t connect** | IB Gateway running at host:port? Configure used? | Gear → host (e.g. localhost) + port (4001) → Configure & Connect |
| **getDataCache is not a function** | server/data-cache.ts exports `getDataCache` | Fixed in code; restart server |
| **Engine not opening trades** | Engine “Running”? Min score/threshold; market data | Auto Trading page: state, logs, last opportunities |
| **Positions/trades empty after restart** | DB persist: dbTradeService.saveTradeRecord called? | Check omega0/auto-trading-engine persist on place/close |

---

## 11. Common issues

- **“TWS Disconnected”** — Expected if IB Gateway isn’t running. Paper trading and Yahoo data still work. To connect: run IB Gateway (or tunnel), set host/port in TWS card → Configure & Connect.
- **“Trade Now” opens dialog but Place order fails** — Often missing/invalid session (log in again) or backend error (e.g. option chain/price). Check Network tab for the `omega0.placeOrder` request and server logs.
- **Account value or P&L shows $NaN** — Backend now uses `safeNum`/`fmtMoney` and option premium (not underlying price) for P&L. If it still happens, check System Health and the procedure that returns that value (e.g. getAccountSummary).
- **Open positions show huge fake profit (e.g. $69k)** — Caused by using **underlying** price instead of **option** price for P&L. Fixed by using `getCurrentOptionPrice()` (option chain) for omega0; restart and refresh.
- **Configure TWS but still connects to localhost** — Gateway URL must use TWS_HOST/TWS_PORT. We build `getIBGatewayUrl()` from those; ensure you clicked Configure & Connect after changing host/port.
- **Execution page empty / “no trades”** — Manual trades appear after Trade Now → Place order. Engine trades appear when the engine is running and has opened positions. Check Execution for both “Open Positions (manual)” and “Auto-trading engine”.
- **Engine Daily P&L always $0** — Day P&L updates when a position **closes**. Unrealized P&L is shown separately; Total P&L = realized + unrealized. If no trades have closed yet, $0 is correct.

---

**File locations (for reference):**
- **Routers:** `server/routers.ts` (appRouter), `server/routers/omega0.ts`, `server/routers/auto-trading.ts`, `server/routers/gateway.ts`, `server/routers/market-scanner.ts`, `server/routers/tws-connection.ts`, `server/_core/systemRouter.ts`
- **tRPC mount:** `server/_core/index.ts` — `app.use("/api/trpc", createExpressMiddleware({ router: appRouter, createContext }))`
- **Client tRPC base URL:** `client/src/main.tsx` — `url: "/api/trpc"`
- **Frontend routes:** `client/src/App.tsx` — wouter `Route` for each path above
