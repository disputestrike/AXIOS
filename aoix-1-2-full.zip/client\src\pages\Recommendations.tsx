/**
 * Market Opportunities Page
 * IBKR only. Real trading opportunities from IB Gateway — scan to load.
 * Auto-refreshes every 15s when data is available; optional initial scan on mount.
 */

import { useState, useEffect, useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { skipToken } from "@tanstack/react-query";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  TrendingUp,
  TrendingDown,
  Zap,
  Target,
  BarChart3,
  RefreshCw,
  Play,
  AlertCircle,
  Clock,
  Rocket,
  Filter,
  Crown,
  ChevronRight,
  Loader2,
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { SignalBreakdown } from "@/components/SignalBreakdown";

// Match the backend MarketOpportunity type exactly
interface MarketOpportunity {
  symbol: string;
  currentPrice: number;
  priceChange: number;
  priceChangePercent: number;
  volume: number;
  avgVolume: number;
  high52Week: number;
  low52Week: number;
  regime: string;
  signal: {
    class: string;
    confidence: number;
    direction: string;
  };
  opportunity: {
    score: number;
    scoreBeforeLiquidity?: number;
    expectedReturn: number;
    riskReward: number;
    winProbability: number;
  };
  structure: {
    type: string;
    direction: string;
    expectedValue: number;
    cvar: number;
  };
  impliedVolatility?: number;
  ivRank?: number;
  timestamp: number;
  dataSource: string;
  isIlliquid?: boolean;
}

const TOP_COUNT = 100; // Show top 100 best-of-best recommendations

export default function Recommendations() {
  const [isScanning, setIsScanning] = useState(false);
  const [selectedOpportunity, setSelectedOpportunity] = useState<MarketOpportunity | null>(null);
  /** Intent-driven row when symbol is in Top 15 with thesis; details tab shows intent when set. */
  const [selectedIntentItem, setSelectedIntentItem] = useState<{
    opportunity: MarketOpportunity;
    options: Array<{ structureType: string; tierScore: number; winProbability: number; expectedReturn: number; direction: string }>;
    intent?: { direction: string; rationale: string; confidence: number };
  } | null>(null);
  const [pendingTradeSymbol, setPendingTradeSymbol] = useState<string | null>(null);
  const [tradedSymbols, setTradedSymbols] = useState<Set<string>>(new Set());
  const [tradeDialogOpen, setTradeDialogOpen] = useState(false);
  const [tradeDialogOpp, setTradeDialogOpp] = useState<MarketOpportunity | null>(null);
  const [tradeQuantity, setTradeQuantity] = useState(1);
  const [selectedExpiry, setSelectedExpiry] = useState<string | null>(null);
  const [selectedStrike, setSelectedStrike] = useState<number | null>(null);
  // Filters for best-of-best: strategy, regime, min score, min win prob, symbol search
  const [filterStructure, setFilterStructure] = useState<string>("any");
  const [filterRegime, setFilterRegime] = useState<string>("any");
  const [filterMinScore, setFilterMinScore] = useState<number>(0);
  const [filterMinWinProb, setFilterMinWinProb] = useState<number>(0);
  const [filterSymbol, setFilterSymbol] = useState<string>("");
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();

  const getExpiryAndStrike = (opp: MarketOpportunity) => {
    const optionType = opp.signal.direction === "bullish" ? "C" : "P";
    const strike = Math.round(opp.currentPrice / 5) * 5;
    const today = new Date();
    const daysUntilFriday = (5 - today.getDay() + 7) % 7 || 7;
    const expiry = new Date(today);
    expiry.setDate(today.getDate() + daysUntilFriday);
    const expiryStr = expiry.toISOString().split("T")[0].replace(/-/g, "");
    return { optionType, strike, expiryStr };
  };
  const expiryStrikeForOpp = useMemo(
    () => (tradeDialogOpp ? getExpiryAndStrike(tradeDialogOpp) : null),
    [tradeDialogOpp]
  );

  // Refetch interval (ms) so list updates when engine scans in background
  const REFETCH_INTERVAL_MS = 15_000;

  const filterInput = {
    count: TOP_COUNT,
    minScore: filterMinScore > 0 ? filterMinScore : undefined,
    minWinProbability: filterMinWinProb > 0 ? filterMinWinProb : undefined,
    structureType: filterStructure !== "any" ? filterStructure : undefined,
    regime: filterRegime !== "any" ? filterRegime : undefined,
    symbolSearch: filterSymbol.trim() || undefined,
    includeIlliquid: true, // show all so list matches "Total Opportunities" (illiquid shown with badge)
  };

  const { data: knownStrategies } = trpc.marketScanner.getKnownStrategies.useQuery();
  const { data: twsStatus } = trpc.twsConnection.getStatus.useQuery(undefined, { refetchInterval: 10_000 });
  const { data: testMarketData, refetch: refetchTestMarket } = trpc.twsConnection.testMarketData.useQuery(undefined, { enabled: false });
  const { data: scannerStatus, refetch: refetchStatus } = trpc.marketScanner.getStatus.useQuery(undefined, {
    refetchInterval: REFETCH_INTERVAL_MS,
  });

  // tRPC queries - top 100, optional filters; auto-refresh
  const { data: topOpportunities, refetch: refetchTop, isLoading: isLoadingTop } = 
    trpc.marketScanner.getTopOpportunities.useQuery(
      filterInput,
      { refetchInterval: REFETCH_INTERVAL_MS }
    );

  const { data: allOpportunities, refetch: refetchAll } = 
    trpc.marketScanner.getAllOpportunities.useQuery(undefined, {
      refetchInterval: REFETCH_INTERVAL_MS,
    });

  // Scan - can be triggered manually or on mount (once)
  const { refetch: triggerScan } = trpc.marketScanner.scan.useQuery(
    undefined,
    { enabled: false, refetchOnWindowFocus: false }
  );

  // Top 15 with market thesis (intent) — same as Today's Opportunity; shown in card below.
  const TOP_N_INTENT = 15;
  const { data: intentData, isLoading: isLoadingIntent, isFetching: isFetchingIntent, refetch: refetchIntent } =
    trpc.opportunity.getTodayOpportunities.useQuery(
      { topN: TOP_N_INTENT, useIntentGovernance: true, runScanIfEmpty: false },
      { refetchInterval: REFETCH_INTERVAL_MS, staleTime: 60_000 }
    );
  const intentOpportunities = intentData?.opportunities ?? [];
  const intentPicksForBanner = intentOpportunities;

  // Optional: run one scan on mount so first-time visitors get data (after a short delay to let layout render)
  useEffect(() => {
    const t = setTimeout(() => {
      triggerScan().then(() => {
        refetchTop();
        refetchAll();
        refetchStatus();
        refetchIntent();
      }).catch(() => {});
    }, 2000);
    return () => clearTimeout(t);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps -- run once on mount
  
  // Place order mutation for quick trade
  const placeOrderMutation = trpc.omega0.placeOrder.useMutation({
    onSuccess: (data) => {
      const symbol = data.symbol;
      setPendingTradeSymbol(null);
      setTradedSymbols((prev) => new Set(prev).add(symbol));
      // Show exactly what was traded (full server message with all legs)
      const message = (data as { message?: string }).message || `Trade executed: ${symbol}`;
      toast.success(message, {
        duration: 10000,
        description: "View Trade log and positions on Execution page.",
        action: {
          label: "Open Execution",
          onClick: () => navigate("/execution"),
        },
      });
      utils.omega0.getOpenTrades.invalidate();
      utils.omega0.getLastOrderSummary.invalidate();
    },
    onError: (error) => {
      setPendingTradeSymbol(null);
      toast.error(`Trade failed: ${error.message}`);
    },
  });

  const handleScan = async () => {
    setIsScanning(true);
    toast.info(twsStatus?.connected ? "Scanning market with IBKR data..." : "Scanning market (thousands of symbols)...");
    try {
      const scanResult = await triggerScan();
      const scanCount = scanResult.data?.count ?? scanResult.data?.opportunities?.length ?? 0;
      if (scanCount === 0 && !scanResult.data?.success) {
        toast.error(scanResult.data?.error ?? "Scan failed - please try again");
        return;
      }
      await refetchTop();
      await refetchAll();
      await refetchStatus();
      const intentResult = await refetchIntent();
      const intentCount = intentResult.data?.opportunities?.length ?? 0;
      if (scanCount === 0) {
        toast.warning(
          "Scan finished but 0 opportunities. Connect IBKR Gateway on Auto Trading (or set IB_GATEWAY_COOKIE), then scan again.",
          { duration: 8000 }
        );
      } else {
        toast.success(`Scan complete! Top 100 from scan of thousands; Top ${intentCount} with market thesis loaded.`);
      }
    } catch (error) {
      const msg = error instanceof Error ? error.message : "Scan or load failed";
      toast.error(msg);
      await refetchTop();
      await refetchAll();
      await refetchIntent();
    } finally {
      setIsScanning(false);
    }
  };

  const openTradeDialog = (opp: MarketOpportunity, e: React.MouseEvent) => {
    e.stopPropagation();
    setTradeDialogOpp(opp);
    setTradeQuantity(1);
    setSelectedExpiry(null);
    setSelectedStrike(null);
    setTradeDialogOpen(true);
  };

  const optionChainQuery = trpc.omega0.getOptionChainForTrade.useQuery(
    { symbol: tradeDialogOpp?.symbol ?? "" },
    { enabled: !!tradeDialogOpp?.symbol, staleTime: 30_000 }
  );
  const chain = optionChainQuery.data;
  const hasChain = chain && !("error" in chain && chain.error) && chain.options?.length > 0;
  const fallbackParams = tradeDialogOpp ? getExpiryAndStrike(tradeDialogOpp) : null;
  const effectiveExpiry = (hasChain && selectedExpiry) ? selectedExpiry : fallbackParams?.expiryStr ?? "";
  const effectiveStrike = (hasChain && selectedStrike != null) ? selectedStrike : (fallbackParams?.strike ?? 0);
  const effectiveOptionType = tradeDialogOpp ? (tradeDialogOpp.signal?.direction === "bearish" ? "P" as const : "C" as const) : "C" as const;

  useEffect(() => {
    if (!tradeDialogOpp || !hasChain || !chain || !("options" in chain)) return;
    const expirations = chain.expirations ?? [];
    const strikes = chain.strikes ?? [];
    const price = chain.currentPrice ?? tradeDialogOpp.currentPrice;
    if (expirations.length && selectedExpiry === null) setSelectedExpiry(expirations[0]!);
    if (strikes.length && selectedStrike === null) {
      const atm = strikes.reduce((a, b) => (Math.abs(b - price) < Math.abs(a - price) ? b : a));
      setSelectedStrike(atm);
    }
  }, [tradeDialogOpp, hasChain, chain, tradeDialogOpp?.currentPrice, selectedExpiry, selectedStrike]);
  useEffect(() => {
    if (!tradeDialogOpp) {
      setSelectedExpiry(null);
      setSelectedStrike(null);
    }
  }, [tradeDialogOpp]);

  const effectiveStrikeForEstimate = (effectiveStrike ?? fallbackParams?.strike) ?? 0;
  const effectiveExpiryForEstimate = (effectiveExpiry ?? fallbackParams?.expiryStr) ?? "";
  const estimateCostForSuggest = tradeDialogOpp && effectiveExpiryForEstimate && effectiveStrikeForEstimate > 0
    ? { expiryStr: effectiveExpiryForEstimate, strike: effectiveStrikeForEstimate, optionType: effectiveOptionType, quantity: 1, symbol: tradeDialogOpp.symbol, structureType: tradeDialogOpp.structure?.type ?? "", direction: (tradeDialogOpp.signal?.direction === "bullish" ? "bullish" : "bearish") as "bullish" | "bearish" }
    : (expiryStrikeForOpp && tradeDialogOpp ? { ...expiryStrikeForOpp, quantity: 1, symbol: tradeDialogOpp.symbol, structureType: tradeDialogOpp.structure?.type ?? "", direction: (tradeDialogOpp.signal?.direction === "bullish" ? "bullish" : "bearish") as "bullish" | "bearish" } : null);
  const { data: estimateForSuggest } = trpc.omega0.estimateOrderCost.useQuery(
    tradeDialogOpp && estimateCostForSuggest
      ? {
          symbol: tradeDialogOpp.symbol,
          strike: estimateCostForSuggest.strike,
          expiry: estimateCostForSuggest.expiryStr,
          optionType: estimateCostForSuggest.optionType as "C" | "P",
          quantity: 1,
          structureType: estimateCostForSuggest.structureType || undefined,
          direction: estimateCostForSuggest.direction,
        }
      : skipToken,
    { enabled: !!tradeDialogOpp }
  );
  const optionPriceForSuggest = estimateForSuggest?.estimatedCost ?? (tradeDialogOpp ? tradeDialogOpp.currentPrice * 0.02 : 1);
  const winProb01 = tradeDialogOpp?.opportunity?.winProbability != null
    ? (tradeDialogOpp.opportunity.winProbability <= 1 ? tradeDialogOpp.opportunity.winProbability : tradeDialogOpp.opportunity.winProbability / 100)
    : 0.6;
  const { data: suggestQuantityData } = trpc.omega0.suggestQuantity.useQuery(
    tradeDialogOpp
      ? {
          symbol: tradeDialogOpp.symbol,
          optionPrice: Math.max(0.5, optionPriceForSuggest),
          winProbability: winProb01,
        }
      : skipToken,
    { enabled: !!tradeDialogOpp && optionPriceForSuggest > 0 }
  );
  useEffect(() => {
    if (tradeDialogOpen && tradeDialogOpp && suggestQuantityData?.quantity != null && suggestQuantityData.quantity >= 1) {
      setTradeQuantity((q) => (q === 1 ? Math.min(100, Math.max(1, suggestQuantityData.quantity)) : q));
    }
  }, [tradeDialogOpen, tradeDialogOpp?.symbol, suggestQuantityData?.quantity]);

  const estimateCostInput = tradeDialogOpp && effectiveExpiryForEstimate && effectiveStrikeForEstimate > 0
    ? {
        symbol: tradeDialogOpp.symbol,
        strike: effectiveStrikeForEstimate,
        expiry: effectiveExpiryForEstimate,
        optionType: effectiveOptionType,
        quantity: Math.min(100, Math.max(1, Number(tradeQuantity) || 1)),
        structureType: (tradeDialogOpp.structure?.type ?? "") || undefined,
        direction: (tradeDialogOpp.signal?.direction === "bullish" ? "bullish" : "bearish") as "bullish" | "bearish",
      }
    : null;
  const { data: estimateCost } = trpc.omega0.estimateOrderCost.useQuery(
    estimateCostInput ?? skipToken
  );

  const handlePlaceOrderFromDialog = async () => {
    if (!tradeDialogOpp) return;
    const expiryStr = effectiveExpiry || fallbackParams?.expiryStr;
    const strike = (effectiveStrike ?? fallbackParams?.strike) ?? 0;
    const optionType = effectiveOptionType;
    if (!expiryStr || strike <= 0) {
      toast.error("Select an expiry and strike from the option chain.");
      return;
    }
    setPendingTradeSymbol(tradeDialogOpp.symbol);
    const qty = Math.min(100, Math.max(1, Number(tradeQuantity) || 1));
    const direction = tradeDialogOpp.signal.direction === "bullish" ? "bullish" : "bearish";
    const structureType = tradeDialogOpp.structure?.type ?? "";
    try {
      await placeOrderMutation.mutateAsync({
        symbol: tradeDialogOpp.symbol,
        action: "BUY",
        quantity: qty,
        optionType,
        strike,
        expiry: expiryStr,
        structureType: structureType || undefined,
        direction,
      });
      setTradeDialogOpen(false);
      setTradeDialogOpp(null);
    } catch {
      // Error handled by mutation
    }
  };

  /** Safe: backend may send 0.20 (20%) or 20 (20%); never show e.g. 2011%. */
  const formatPercent = (value: number) =>
    value > 1 ? `${Number(value).toFixed(2)}%` : `${(value * 100).toFixed(2)}%`;
  const formatPrice = (value: number) => `$${value.toFixed(2)}`;
  const formatVolume = (value: number) => {
    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(0)}K`;
    return value.toString();
  };

  const getSignalColor = (signalClass: string) => {
    switch (signalClass) {
      case 'A': return 'bg-green-500/20 text-green-400 border-green-500/50';
      case 'B': return 'bg-blue-500/20 text-blue-400 border-blue-500/50';
      case 'C': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50';
      case 'D': return 'bg-red-500/20 text-red-400 border-red-500/50';
      default: return 'bg-slate-500/20 text-slate-400 border-slate-500/50';
    }
  };

  const getRegimeColor = (regime: string) => {
    if (regime.includes('bull')) return 'text-green-400';
    if (regime.includes('bear')) return 'text-red-400';
    return 'text-yellow-400';
  };

  const getStructureIcon = (type: string) => {
    if (type.includes('call') || type.includes('bull')) return '📈';
    if (type.includes('put') || type.includes('bear')) return '📉';
    if (type.includes('condor') || type.includes('butterfly')) return '🦋';
    if (type.includes('straddle') || type.includes('strangle')) return '⚡';
    return '📊';
  };

  // Main list: top 100 from scan (thousands of symbols). Intent card: top 15 with thesis.
  const opportunities = topOpportunities?.opportunities ?? [];
  const totalCount = allOpportunities?.count ?? 0;
  const dataSourceLabel = opportunities.length === 0
    ? "IBKR data (scan to load)"
    : "IBKR data";

  return (
    <div className="space-y-6">
      {/* Trade dialog: symbol, strike picker, expiry, contracts, Place order */}
      <Dialog open={tradeDialogOpen} onOpenChange={(open) => { if (!open) { setTradeDialogOpen(false); setTradeDialogOpp(null); } }}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white max-h-[90vh] overflow-y-auto max-w-2xl">
          <DialogHeader>
            <DialogTitle>Place order</DialogTitle>
            <DialogDescription>
              {tradeDialogOpp
                ? `${tradeDialogOpp.symbol} — pick expiry and strike from live chain. Orders appear on the Execution page.`
                : "Select an opportunity first."}
            </DialogDescription>
          </DialogHeader>
          {tradeDialogOpp && (
            <div className="space-y-4 py-2">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <span className="text-slate-400">Symbol</span>
                <span className="font-medium">{tradeDialogOpp.symbol}</span>
                <span className="text-slate-400">Structure</span>
                <span className="font-medium">{tradeDialogOpp.structure?.type?.replace(/_/g, " ") ?? "Single option"}</span>
              </div>

              {optionChainQuery.isLoading && (
                <div className="flex items-center gap-2 text-slate-400 py-4">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Loading option chain from IB…
                </div>
              )}

              {!optionChainQuery.isLoading && chain && (("error" in chain && chain.error) || !(chain.options?.length)) ? (
                <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-4 text-sm">
                  <p className="font-medium text-red-400">No options available</p>
                  <p className="text-slate-400 mt-1">
                    No option chain for {tradeDialogOpp.symbol}. Try SPY or QQQ, or ensure IB Gateway is connected.
                  </p>
                  {chain.expirations?.length ? (
                    <p className="text-slate-400 mt-1 text-xs">Available expirations: {chain.expirations.slice(0, 5).join(", ")}</p>
                  ) : null}
                </div>
              ) : null}

              {!optionChainQuery.isLoading && hasChain && chain && "options" in chain && (
                <>
                  <div className="space-y-2">
                    <Label>Expiration</Label>
                    <select
                      className="flex h-9 w-full rounded-md border border-slate-600 bg-slate-900 px-3 py-1 text-sm text-white"
                      value={selectedExpiry ?? ""}
                      onChange={(e) => setSelectedExpiry(e.target.value || null)}
                    >
                      {(chain.expirations ?? []).map((exp) => (
                        <option key={exp} value={exp}>{exp}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label>Strike (select one — used as center for spreads)</Label>
                    <div className="rounded border border-slate-600 overflow-x-auto max-h-48 overflow-y-auto bg-slate-900/50">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="border-b border-slate-600 bg-slate-800">
                            <th className="text-left p-2">Strike</th>
                            <th className="text-right p-2">Call bid</th>
                            <th className="text-right p-2">Call ask</th>
                            <th className="text-right p-2">Put bid</th>
                            <th className="text-right p-2">Put ask</th>
                          </tr>
                        </thead>
                        <tbody>
                          {(chain.strikes ?? []).map((strike) => {
                            const forExpiry = selectedExpiry ?? (chain.expirations ?? [])[0];
                            const norm = (s: string) => String(s ?? "").replace(/[-/\s]/g, "").slice(0, 8);
                            const forNorm = forExpiry ? norm(forExpiry) : "";
                            const call = chain.options?.find((o: { strike: number; expiry: string; right: string }) => o.strike === strike && norm(o.expiry) === forNorm && o.right === "C");
                            const put = chain.options?.find((o: { strike: number; expiry: string; right: string }) => o.strike === strike && norm(o.expiry) === forNorm && o.right === "P");
                            return (
                              <tr
                                key={strike}
                                className={`border-b border-slate-600/50 cursor-pointer hover:bg-slate-700/50 ${selectedStrike === strike ? "bg-blue-500/20" : ""}`}
                                onClick={() => setSelectedStrike(strike)}
                              >
                                <td className="p-2 font-medium">{strike}</td>
                                <td className="text-right p-2">{call && ((call as { bid: number }).bid > 0 || (call as { ask: number }).ask > 0) ? (call as { bid: number }).bid.toFixed(2) : "—"}</td>
                                <td className="text-right p-2">{call && ((call as { bid: number }).bid > 0 || (call as { ask: number }).ask > 0) ? (call as { ask: number }).ask.toFixed(2) : "—"}</td>
                                <td className="text-right p-2">{put && ((put as { bid: number }).bid > 0 || (put as { ask: number }).ask > 0) ? (put as { bid: number }).bid.toFixed(2) : "—"}</td>
                                <td className="text-right p-2">{put && ((put as { bid: number }).bid > 0 || (put as { ask: number }).ask > 0) ? (put as { ask: number }).ask.toFixed(2) : "—"}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {estimateCost?.breakdown && estimateCost.breakdown.length > 0 && (
                    <div className="rounded-lg border border-slate-500/30 bg-slate-500/10 p-3 text-sm space-y-1">
                      <p className="font-medium text-slate-300">Legs (what will be sent to IB)</p>
                      <ul className="list-disc list-inside text-slate-400">
                        {estimateCost.breakdown.map((leg: { action: string; strike: number; optionType: string; fillPrice: number; quantity: number }, i: number) => (
                          <li key={i}>
                            {leg.action} {leg.strike}{leg.optionType} @ ${leg.fillPrice.toFixed(2)} × {leg.quantity}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </>
              )}

              {tradeDialogOpp && !hasChain && !optionChainQuery.isLoading && fallbackParams && (
                <p className="text-slate-400 text-xs">Using approximate strike/expiry (no chain loaded). Connect IB Gateway to see live strikes.</p>
              )}

              <div className="space-y-2">
                <Label htmlFor="contracts">Number of contracts (1 = 100 shares)</Label>
                <Input
                  id="contracts"
                  type="number"
                  min={1}
                  max={100}
                  value={tradeQuantity}
                  onChange={(e) => setTradeQuantity(Number(e.target.value) || 1)}
                  className="bg-slate-900 border-slate-600"
                />
                {suggestQuantityData?.quantity != null && (
                  <p className="text-xs text-slate-400">
                    Suggested: {suggestQuantityData.quantity} contract{suggestQuantityData.quantity !== 1 ? "s" : ""}
                    {suggestQuantityData.capped ? " (capped by ADV)" : ""}
                  </p>
                )}
              </div>
              {estimateCost != null && Number.isFinite(estimateCost.estimatedCost) && (
                <div className="space-y-1 text-sm border border-green-500/40 rounded px-3 py-2 bg-green-500/10">
                  <p className="text-green-400 font-medium">
                    Estimated cost: ${estimateCost.estimatedCost.toFixed(2)} USD
                    {estimateCost.breakdown?.length > 1 && (
                      <span className="text-slate-400 font-normal ml-1">({estimateCost.breakdown.length} legs)</span>
                    )}
                  </p>
                  {(estimateCost as { estimatedSlippagePercent?: number; estimatedCostWithSlippage?: number }).estimatedSlippagePercent != null && (
                    <p className="text-slate-400 text-xs">
                      Est. slippage: {(estimateCost as { estimatedSlippagePercent: number }).estimatedSlippagePercent}% → with slippage: ${((estimateCost as { estimatedCostWithSlippage?: number }).estimatedCostWithSlippage ?? estimateCost.estimatedCost).toFixed(2)} USD
                    </p>
                  )}
                  {Number.isFinite((estimateCost as { maxLossEstimate?: number }).maxLossEstimate) && (
                    <p className="text-amber-400/90 text-xs">
                      Max loss (est.): ${((estimateCost as { maxLossEstimate: number }).maxLossEstimate).toFixed(2)} USD
                    </p>
                  )}
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => { setTradeDialogOpen(false); setTradeDialogOpp(null); }} className="border-slate-600">
              Cancel
            </Button>
            <Button
              className="bg-green-600 hover:bg-green-700"
              onClick={handlePlaceOrderFromDialog}
              disabled={!tradeDialogOpp || placeOrderMutation.isPending || (hasChain && (!selectedExpiry || selectedStrike == null)) || (chain && "error" in chain && !!chain.error)}
              aria-label={placeOrderMutation.isPending ? "Executing order" : "Place order for selected opportunity"}
            >
              {placeOrderMutation.isPending ? "Executing…" : "Place order"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Zap className="h-8 w-8 text-yellow-500" />
            Market Opportunities
          </h1>
          <p className="text-slate-400 mt-1">
            Real-time scan of 100+ stocks using {dataSourceLabel} — auto-refreshes every 15s. Click "Trade Now" to execute.
          </p>
        </div>
        <Button
          onClick={handleScan}
          disabled={isScanning || isLoadingTop}
          className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
          aria-label={isScanning ? "Scanning market" : "Scan market for opportunities"}
        >
          {isScanning ? (
            <>
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              Scanning REAL Data...
            </>
          ) : (
            <>
              <Play className="h-4 w-4 mr-2" />
              Scan Market
            </>
          )}
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{totalCount}</div>
            <p className="text-sm text-slate-400">Total Opportunities</p>
            <p className="text-xs text-green-400 mt-1">From {dataSourceLabel}</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-green-500">
              {opportunities.length > 0 ? (opportunities[0].opportunity?.scoreBeforeLiquidity ?? opportunities[0].opportunity?.score ?? 0) : 0}
            </div>
            <p className="text-sm text-slate-400">Top Score</p>
            <p className="text-xs text-slate-500">
              {opportunities.length > 0 ? opportunities[0].symbol : 'N/A'}
            </p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-yellow-500">
              {opportunities.length > 0
                ? formatPercent(opportunities.reduce((sum, o) => sum + (o.opportunity?.winProbability ?? 0), 0) / opportunities.length)
                : '0%'}
            </div>
            <p className="text-sm text-slate-400">Avg Win Probability</p>
            <p className="text-xs text-slate-500">Top 100</p>
          </CardContent>
        </Card>
        <Card className="bg-slate-800/50 border-slate-700">
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">
              {scannerStatus?.lastScanTime
                ? new Date(scannerStatus.lastScanTime).toLocaleTimeString()
                : opportunities.length > 0 && opportunities[0].timestamp
                  ? new Date(opportunities[0].timestamp).toLocaleTimeString()
                  : 'Never'}
            </div>
            <p className="text-sm text-slate-400">Last Scan</p>
            <p className="text-xs text-slate-500">Updated</p>
          </CardContent>
        </Card>
      </div>

      {/* Why no results: IBKR only + connection hint */}
      {totalCount === 0 && !scannerStatus?.isScanning && (
        <Card className="bg-amber-500/10 border-amber-500/40">
          <CardContent className="pt-4 pb-4">
            <p className="text-sm text-amber-200 font-medium mb-1">No opportunities yet</p>
            <p className="text-sm text-slate-400 mb-2">
              The scan uses <strong>IBKR data only</strong>. You need the Client Portal Gateway running and <strong>connected</strong> (same session as when you log in at http://localhost:5000).
            </p>
            {!twsStatus?.connected && (
              <p className="text-sm text-amber-200/90 mb-2">
                Gateway is <strong>not connected</strong>. Open <strong>Auto Trading</strong> in the sidebar, connect (or use the cookie workaround if you see 401/400), then come back and click <strong>Scan Market</strong>.
              </p>
            )}
            {twsStatus?.connected && (
              <p className="text-sm text-slate-400 mb-2">
                Gateway shows connected but scan returned 0. Try <strong>Scan Market</strong> again; if it still fails, check the terminal where <code className="bg-slate-800 px-1 rounded">pnpm dev</code> runs for <code className="bg-slate-800 px-1 rounded">[IB]</code> or <code className="bg-slate-800 px-1 rounded">[MarketScanner]</code> messages.
              </p>
            )}
            {scannerStatus?.errors && scannerStatus.errors.length > 0 && (
              <p className="text-xs text-slate-500 mt-2">
                Last scan had {scannerStatus.errors.length} symbol error(s). First: {scannerStatus.errors.slice(0, 2).join("; ")}
                {scannerStatus.errors.length > 2 ? "…" : ""} — check server console for [MarketScanner] / [IB] details.
              </p>
            )}
            <p className="text-sm text-slate-400 mt-2">
              <strong>Steps:</strong> 1) Connect on <strong>Auto Trading</strong> (or set <code className="bg-slate-800 px-1 rounded">IB_GATEWAY_COOKIE</code> in .env.local and restart). 2) Click <strong>Scan Market</strong> here.
            </p>
            <p className="text-sm text-slate-400 mt-2 flex items-center gap-2">
              <span>Test market data:</span>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="h-7 text-xs"
                onClick={() => refetchTestMarket()}
              >
                Test SPY
              </Button>
              {testMarketData !== undefined && (
                <span className={testMarketData.ok ? 'text-green-400' : 'text-amber-400'}>
                  {testMarketData.ok ? `SPY = $${testMarketData.price?.toFixed(2)}` : `SPY failed: ${testMarketData.error ?? 'no price'}`}
                </span>
              )}
            </p>
          </CardContent>
        </Card>
      )}

      {/* Top 100 from scan of thousands; Top 15 with market thesis (intent) below */}
      <Card className="bg-slate-800/50 border-slate-700 border-emerald-500/30">
        <CardContent className="pt-4 pb-4">
          <p className="text-sm text-slate-300">
            <strong className="text-emerald-400">Market Opportunities:</strong> Top 100 recommended from a scan of thousands. <strong className="text-emerald-400">Top 15 with market thesis</strong> (intent governance, same as Today&apos;s Opportunity) shown below.
          </p>
        </CardContent>
      </Card>

      {/* Top 15 with market thesis (intent) */}
      {intentPicksForBanner.length > 0 && (
        <Card className="bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border-emerald-500/40">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-lg text-emerald-400">
              <Crown className="h-5 w-5" />
              Top picks with market thesis
            </CardTitle>
            <CardDescription className="text-slate-400">
              Top 15 with market thesis (intent governance); full tiers on Today&apos;s Opportunity.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <ul className="space-y-2">
              {intentPicksForBanner.map((row, idx) => (
                <li key={row.opportunity.symbol} className="flex items-start gap-3 rounded-lg border border-emerald-500/20 bg-slate-800/50 p-3">
                  <span className="text-muted-foreground text-sm font-medium w-8">#{idx + 1}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold">{row.opportunity.symbol}</span>
                      <Badge variant="secondary" className="text-xs">
                        Score {row.options?.[0]?.tierScore ?? row.opportunity.opportunity?.score ?? "—"}
                      </Badge>
                      {row.intent?.confidence != null && (
                        <span className="text-xs text-slate-400">Confidence {(row.intent.confidence * 100).toFixed(0)}%</span>
                      )}
                    </div>
                    {row.intent?.rationale && (
                      <p className="text-sm text-slate-400 mt-1 line-clamp-2">{row.intent.rationale}</p>
                    )}
                  </div>
                </li>
              ))}
            </ul>
            <Button
              variant="outline"
              size="sm"
              className="border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/10"
              onClick={() => navigate("/today-opportunity")}
            >
              Open Today&apos;s Opportunity <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Filters — strategy, regime, min score, min win prob, symbol search */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Filter className="h-5 w-5" />
            Filters
          </CardTitle>
          <CardDescription>
            Narrow to best-of-best: strategy, regime, min score, min win probability, or symbol search. Ranking = score + win prob + expected return + signal confidence + high-growth bias.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <div>
            <Label className="text-slate-400">Strategy</Label>
            <Select value={filterStructure} onValueChange={setFilterStructure}>
              <SelectTrigger className="bg-slate-900 border-slate-600 mt-1">
                <SelectValue placeholder="Any strategy" />
              </SelectTrigger>
              <SelectContent>
                {(knownStrategies?.strategies ?? []).map((s) => (
                  <SelectItem key={s.id} value={s.id}>{s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-slate-400">Regime</Label>
            <Select value={filterRegime} onValueChange={setFilterRegime}>
              <SelectTrigger className="bg-slate-900 border-slate-600 mt-1">
                <SelectValue placeholder="Any regime" />
              </SelectTrigger>
              <SelectContent>
                {(knownStrategies?.regimes ?? []).map((r) => (
                  <SelectItem key={r.id} value={r.id}>{r.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-slate-400">Min score (0–100)</Label>
            <Slider
              value={[filterMinScore]}
              onValueChange={([v]) => setFilterMinScore(v)}
              min={0}
              max={100}
              step={5}
              className="mt-2"
            />
            <span className="text-xs text-slate-500">{filterMinScore}</span>
          </div>
          <div>
            <Label className="text-slate-400">Min win prob % (0–100)</Label>
            <Slider
              value={[filterMinWinProb]}
              onValueChange={([v]) => setFilterMinWinProb(v)}
              min={0}
              max={100}
              step={5}
              className="mt-2"
            />
            <span className="text-xs text-slate-500">{filterMinWinProb}%</span>
          </div>
          <div>
            <Label className="text-slate-400">Symbol search</Label>
            <Input
              placeholder="e.g. NVDA, AAPL"
              value={filterSymbol}
              onChange={(e) => setFilterSymbol(e.target.value)}
              className="bg-slate-900 border-slate-600 mt-1"
            />
          </div>
        </CardContent>
      </Card>

      {/* Opportunities Tabs */}
      <Tabs defaultValue="top100" className="space-y-4">
        <TabsList>
          <TabsTrigger value="top100">Top {TOP_N_INTENT} Opportunities</TabsTrigger>
          <TabsTrigger value="details">Opportunity Details</TabsTrigger>
        </TabsList>

        {/* Top 100 */}
        <TabsContent value="top100">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Top Ranked Opportunities (Best of Best)
              </CardTitle>
              <CardDescription>
                Top 100 recommended from a scan of thousands. Use &quot;Scan Market&quot; to load. Click &quot;Trade Now&quot; to execute; then open <strong>Execution</strong> in the sidebar.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {(() => {
                if (isLoadingTop && opportunities.length === 0) {
                  return (
                    <div className="flex items-center justify-center py-12 text-slate-400" role="status" aria-label="Loading opportunities">
                      <RefreshCw className="h-8 w-8 animate-spin mr-2" />
                      Loading top 100 from scan…
                    </div>
                  );
                }
                if (opportunities.length === 0) {
                  return (
                    <div className="text-center py-12 border border-dashed border-slate-600 rounded-lg bg-slate-900/30" role="status">
                      {isScanning ? (
                        <>
                          <RefreshCw className="h-8 w-8 mx-auto mb-3 animate-spin text-slate-400" />
                          <p className="text-slate-400 mb-2">Scanning thousands of symbols…</p>
                          <p className="text-sm text-slate-500">This may take 1–2 minutes. Do not close the page.</p>
                        </>
                      ) : (
                        <>
                          <p className="text-slate-400 mb-2">No opportunities yet.</p>
                          <p className="text-sm text-slate-500 mb-4">Click &quot;Scan Market&quot; to scan thousands of symbols and load the top 100.</p>
                          <Button onClick={handleScan} disabled={isScanning} className="bg-blue-600 hover:bg-blue-700">
                            <Play className="h-4 w-4 mr-2" />
                            Scan Market
                          </Button>
                        </>
                      )}
                    </div>
                  );
                }
                return (
                <div className="space-y-3">
                  {opportunities.map((opp: MarketOpportunity, idx: number) => {
                    const intentItem = intentOpportunities.find((i) => i.opportunity.symbol === opp.symbol) ?? null;
                    return (
                    <div
                      key={opp.symbol}
                      className={`p-4 rounded-lg border cursor-pointer transition-all ${
                        selectedOpportunity?.symbol === opp.symbol
                          ? 'bg-blue-900/30 border-blue-500'
                          : 'bg-slate-900/50 border-slate-700 hover:border-slate-600'
                      }`}
                      onClick={() => {
                        setSelectedOpportunity(opp);
                        setSelectedIntentItem(intentItem ?? null);
                      }}
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <span className="text-lg font-bold text-slate-500">#{idx + 1}</span>
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-bold text-lg">{opp.symbol}</span>
                              <span className="text-slate-400">{formatPrice(opp.currentPrice)}</span>
                              <span className={opp.priceChangePercent >= 0 ? 'text-green-400' : 'text-red-400'}>
                                {opp.priceChangePercent >= 0 ? '+' : ''}{opp.priceChangePercent.toFixed(2)}%
                              </span>
                              {opp.isIlliquid && (
                                <Badge variant="secondary" className="bg-amber-500/20 text-amber-600 dark:text-amber-400 text-xs">Lower liquidity</Badge>
                              )}
                            </div>
                            <p className={`text-sm ${getRegimeColor(opp.regime)}`}>
                              {opp.regime.replace(/_/g, ' ')} • Vol: {formatVolume(opp.volume)}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="text-right">
                            <div className="text-2xl font-bold text-green-500">
                              {opp.opportunity?.scoreBeforeLiquidity ?? opp.opportunity?.score ?? 0}
                            </div>
                            <p className="text-xs text-slate-400">Score</p>
                          </div>
                          {tradedSymbols.has(opp.symbol) ? (
                            <Button
                              size="sm"
                              variant="secondary"
                              className="bg-slate-600 text-green-400 hover:bg-slate-500 hover:text-green-300"
                              onClick={(e) => { e.stopPropagation(); navigate("/execution"); }}
                            >
                              <Target className="h-4 w-4 mr-1" />
                              Sent — View Execution
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              className="bg-green-600 hover:bg-green-700"
                              onClick={(e) => openTradeDialog(opp, e)}
                              disabled={placeOrderMutation.isPending && pendingTradeSymbol !== opp.symbol}
                            >
                              {placeOrderMutation.isPending && pendingTradeSymbol === opp.symbol ? (
                                <><RefreshCw className="h-4 w-4 mr-1 animate-spin" /> Trading...</>
                              ) : (
                                <><Rocket className="h-4 w-4 mr-1" /> Trade Now</>
                              )}
                            </Button>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-4 gap-3 mb-3" aria-label={`Opportunity ${idx + 1}: ${opp.symbol} score ${opp.opportunity?.score ?? 0}`}>
                        <div>
                          <Badge className={`${getSignalColor(opp.signal?.class ?? 'A')} border`}>
                            Class {opp.signal?.class ?? 'A'}
                          </Badge>
                          <p className="text-xs text-slate-400 mt-1">
                            {formatPercent(opp.signal?.confidence ?? 0.5)} confidence
                          </p>
                        </div>
                        <div>
                          <p className="text-sm font-bold">{formatPercent(opp.opportunity?.expectedReturn ?? 0)}</p>
                          <p className="text-xs text-slate-400">Expected Return</p>
                        </div>
                        <div>
                          <p className="text-sm font-bold text-blue-500">{opp.opportunity?.riskReward?.toFixed(2) ?? '—'}x</p>
                          <p className="text-xs text-slate-400">Risk/Reward</p>
                        </div>
                        <div>
                          <p className="text-sm font-bold text-green-500">{formatPercent(opp.opportunity?.winProbability ?? 0)}</p>
                          <p className="text-xs text-slate-400">Win Prob</p>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-sm">{getStructureIcon(opp.structure?.type ?? '—')}</span>
                          <span className="text-sm text-slate-400">{(opp.structure?.type ?? '—').replace(/_/g, ' ')}</span>
                          {intentItem && <span className="text-xs text-emerald-400">+ intent</span>}
                          {opp.impliedVolatility != null && (
                            <span className="text-xs text-slate-500">IV: {(opp.impliedVolatility * 100).toFixed(1)}%</span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-xs text-slate-400">
                          <Clock className="h-3 w-3" />
                          {new Date(opp.timestamp).toLocaleTimeString()}
                        </div>
                      </div>

                      <Progress value={opp.opportunity?.score ?? 0} className="mt-3 h-1" />
                    </div>
                    );
                  })}
                </div>
                );
              })()}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Opportunity Details */}
        <TabsContent value="details">
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                {selectedOpportunity ? `${selectedOpportunity.symbol} — Intent-driven analysis` : 'Select an Opportunity'}
              </CardTitle>
              <CardDescription className="text-slate-400">
                Same intent governance as Today&apos;s Opportunity. For full tiers and place order, use Today&apos;s Opportunity.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {selectedOpportunity ? (
                <div className="space-y-6">
                  {/* Price Info (from scan) */}
                  <div className="grid grid-cols-4 gap-4">
                    <div className="p-4 bg-slate-900/50 rounded-lg">
                      <p className="text-sm text-slate-400">Current Price</p>
                      <p className="text-2xl font-bold">{formatPrice(selectedOpportunity.currentPrice)}</p>
                      <p className={selectedOpportunity.priceChangePercent >= 0 ? 'text-green-400' : 'text-red-400'}>
                        {selectedOpportunity.priceChangePercent >= 0 ? '+' : ''}{selectedOpportunity.priceChangePercent.toFixed(2)}%
                      </p>
                    </div>
                    <div className="p-4 bg-slate-900/50 rounded-lg">
                      <p className="text-sm text-slate-400">52-Week High</p>
                      <p className="text-xl font-bold">{formatPrice(selectedOpportunity.high52Week)}</p>
                    </div>
                    <div className="p-4 bg-slate-900/50 rounded-lg">
                      <p className="text-sm text-slate-400">52-Week Low</p>
                      <p className="text-xl font-bold">{formatPrice(selectedOpportunity.low52Week)}</p>
                    </div>
                    <div className="p-4 bg-slate-900/50 rounded-lg">
                      <p className="text-sm text-slate-400">Volume</p>
                      <p className="text-xl font-bold">{formatVolume(selectedOpportunity.volume)}</p>
                      <p className="text-xs text-slate-500">Avg: {formatVolume(selectedOpportunity.avgVolume)}</p>
                    </div>
                  </div>

                  {/* Intent (single source of truth) */}
                  {selectedIntentItem?.intent && (
                    <div>
                      <h3 className="font-semibold mb-3 text-emerald-400">Market thesis (intent)</h3>
                      <div className="p-4 bg-slate-900/50 rounded-lg border border-emerald-500/20">
                        <p className="text-sm text-slate-300">{selectedIntentItem.intent.rationale}</p>
                        <div className="flex gap-4 mt-3 text-sm">
                          <span><strong>Direction:</strong> {selectedIntentItem.intent.direction}</span>
                          <span><strong>Confidence:</strong> {(selectedIntentItem.intent.confidence * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Recommended structure (from intent options) */}
                  {selectedIntentItem?.options?.[0] && (
                    <div>
                      <h3 className="font-semibold mb-3">Recommended structure (intent)</h3>
                      <div className="p-4 bg-slate-900/50 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-2xl">{getStructureIcon(selectedIntentItem.options[0].structureType)}</span>
                          <span className="text-lg font-bold">{selectedIntentItem.options[0].structureType.replace(/_/g, ' ')}</span>
                        </div>
                        <div className="grid grid-cols-3 gap-4 mt-4">
                          <div>
                            <p className="text-sm text-slate-400">Direction</p>
                            <p className="font-bold capitalize">{selectedIntentItem.options[0].direction ?? selectedIntentItem.intent?.direction ?? '—'}</p>
                          </div>
                          <div>
                            <p className="text-sm text-slate-400">Score</p>
                            <p className="font-bold text-green-400">{selectedIntentItem.options[0].tierScore ?? '—'}</p>
                          </div>
                          <div>
                            <p className="text-sm text-slate-400">Win prob</p>
                            <p className="font-bold">{formatPercent(selectedIntentItem.options[0].winProbability ?? 0)}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* CTA to Today's Opportunity */}
                  <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 rounded-lg">
                    <p className="text-sm text-slate-300 mb-2">Full Conservative/Balanced/Aggressive tiers and place order:</p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/10"
                      onClick={() => navigate("/today-opportunity")}
                    >
                      Open Today&apos;s Opportunity <ChevronRight className="h-4 w-4 ml-1" />
                    </Button>
                  </div>

                  {/* Signal breakdown — reference only */}
                  <div>
                    <p className="text-xs text-slate-500 mb-2">Reference only; not used for trade decisions. For trading use Today&apos;s Opportunity.</p>
                    <SignalBreakdown symbol={selectedOpportunity.symbol} compact />
                  </div>

                  {/* Trade Button — uses intent-driven synthetic opp */}
                  <Button
                    className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                    onClick={() => {
                      if (selectedIntentItem) {
                        const opp = selectedIntentItem.opportunity;
                        const top = selectedIntentItem.options?.[0];
                        const dir = selectedIntentItem.intent?.direction ?? opp.signal?.direction ?? 'neutral';
                        const synthetic: MarketOpportunity = {
                          ...opp,
                          signal: { ...opp.signal, direction: dir.toLowerCase(), confidence: selectedIntentItem.intent?.confidence ?? opp.signal?.confidence ?? 0.5 },
                          structure: {
                            type: top?.structureType ?? opp.structure?.type ?? 'vertical_call_spread',
                            direction: dir.toLowerCase(),
                            expectedValue: top?.expectedReturn ?? opp.structure?.expectedValue ?? 0,
                            cvar: opp.structure?.cvar ?? 0,
                          },
                          opportunity: { ...opp.opportunity, score: top?.tierScore ?? opp.opportunity?.score, expectedReturn: top?.expectedReturn ?? opp.opportunity?.expectedReturn, winProbability: top?.winProbability ?? opp.opportunity?.winProbability, riskReward: opp.opportunity?.riskReward },
                        };
                        setTradeDialogOpp(synthetic);
                      } else {
                        setTradeDialogOpp(selectedOpportunity);
                      }
                      setTradeQuantity(1);
                      setTradeDialogOpen(true);
                    }}
                    disabled={placeOrderMutation.isPending}
                  >
                    <Rocket className="h-5 w-5 mr-2" />
                    {placeOrderMutation.isPending ? "Executing…" : `Trade ${selectedOpportunity.symbol} Now`}
                  </Button>
                </div>
              ) : (
                <div className="text-center py-12 text-slate-400">
                  <Target className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Select an opportunity from the list to view intent-driven details</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
