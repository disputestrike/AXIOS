# AOIX-1 Local Setup Checklist

Use this checklist to ensure everything is properly configured for local development.

## ✅ Prerequisites

- [ ] **Node.js 22+** installed
  - Check: `node --version` (should be v22+)
  - Download: https://nodejs.org/

- [ ] **pnpm** installed
  - Check: `pnpm --version`
  - Install: `npm install -g pnpm`

- [ ] **MySQL/TiDB Database** accessible
  - Local MySQL installed OR
  - Remote database connection string available

- [ ] **IB Gateway** (Optional - for real market data)
  - Installed and configured
  - Running on localhost:4001
  - API enabled in settings

## ✅ Environment Configuration

- [ ] **`.env.local` file created**
  - Copied from `.env.local.example`
  - All required variables filled in

- [ ] **Required variables configured:**
  - [ ] `DATABASE_URL` - MySQL connection string
  - [ ] `JWT_SECRET` - Random secret key (generate with: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`)
  - [ ] `VITE_APP_ID` - OAuth app ID
  - [ ] `OAUTH_SERVER_URL` - OAuth server URL
  - [ ] `VITE_OAUTH_PORTAL_URL` - OAuth portal URL
  - [ ] `OWNER_NAME` - Your name
  - [ ] `OWNER_OPEN_ID` - Your OpenID
  - [ ] `BUILT_IN_FORGE_API_URL` - Forge API URL
  - [ ] `BUILT_IN_FORGE_API_KEY` - Forge API key
  - [ ] `VITE_FRONTEND_FORGE_API_URL` - Frontend Forge API URL
  - [ ] `VITE_FRONTEND_FORGE_API_KEY` - Frontend Forge API key
  - [ ] `TWS_HOST` - IB Gateway host (default: localhost)
  - [ ] `TWS_PORT` - IB Gateway port (default: 4001)

- [ ] **Run verification**
  ```bash
  pnpm verify
  ```
  - Should show all checks passing

## ✅ Database Setup

- [ ] **Database created** (if using local MySQL)
  ```sql
  CREATE DATABASE aoix1;
  ```

- [ ] **Dependencies installed**
  ```bash
  pnpm install
  ```

- [ ] **Database migrations run**
  ```bash
  pnpm db:push
  ```
  - Should create all tables successfully

- [ ] **Database connection verified**
  - Check in `pnpm verify` output
  - Or test manually with database client

## ✅ Application Startup

- [ ] **Server starts successfully**
  ```bash
  pnpm dev
  ```
  - No errors in console
  - Server running on http://localhost:3000 (or alternative port)

- [ ] **Frontend loads**
  - Open http://localhost:5173
  - Page loads without errors
  - No console errors in browser

- [ ] **API responds**
  - Health check: http://localhost:3000/api/trpc/system.health
  - Should return status

## ✅ Functionality Verification

- [ ] **System Health Dashboard**
  - Navigate to http://localhost:5173/system-health
  - All components show green/healthy status
  - No error indicators

- [ ] **Market Scanner**
  - Navigate to http://localhost:5173/recommendations
  - Click "Scan Market" button
  - Opportunities appear (may take 30-60 seconds)
  - Real stock symbols and prices shown

- [ ] **Auto Trading Dashboard**
  - Navigate to http://localhost:5173/auto-trading
  - Dashboard loads correctly
  - Engine status displayed
  - TWS connection status shown (if IB Gateway running)

- [ ] **Other Dashboards**
  - Market Data: http://localhost:5173/market-data
  - Regime Classification: http://localhost:5173/regime
  - Signal Taxonomy: http://localhost:5173/signals
  - All pages load without errors

## ✅ IB Gateway (Optional)

- [ ] **IB Gateway running**
  - Application is open
  - Logged in to account
  - API enabled in settings

- [ ] **Connection verified**
  - System Health shows "Connected" for Gateway
  - Auto Trading dashboard shows TWS connection status
  - Can fetch real market data

## ✅ Troubleshooting (If Issues)

- [ ] **Port conflicts resolved**
  - Port 3000 available OR
  - PORT set in .env.local to alternative port

- [ ] **Database issues resolved**
  - Connection string correct
  - Database running
  - Network/firewall allows connection

- [ ] **Environment variables**
  - All required vars set
  - No placeholder values
  - Values are correct

- [ ] **Dependencies**
  - `node_modules` exists
  - All packages installed
  - No missing modules

## 🎉 Success Criteria

Everything is working when:

1. ✅ Server starts without errors
2. ✅ Frontend loads at http://localhost:5173
3. ✅ System Health shows all green
4. ✅ Market scanner generates opportunities
5. ✅ All dashboards display correctly
6. ✅ No console errors (browser or server)
7. ✅ Database operations work
8. ✅ API endpoints respond

## 📝 Next Steps

Once everything is verified:

1. **Test Market Scanner** - Run scan and verify opportunities
2. **Test Trading Engine** - Enable paper trading and execute test trade
3. **Monitor System Health** - Check all components regularly
4. **Customize Configuration** - Adjust risk parameters and trading rules
5. **Review Documentation** - Read QUICKSTART.md for trading workflow

---

**Need Help?** See [ANALYSIS_AND_IMPROVEMENT_PLAN.md](./ANALYSIS_AND_IMPROVEMENT_PLAN.md) for detailed troubleshooting.
